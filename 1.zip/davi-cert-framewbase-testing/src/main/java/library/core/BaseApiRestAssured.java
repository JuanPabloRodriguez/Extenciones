package library.core;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URI;

import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import library.reporting.Reporter;

public abstract class BaseApiRestAssured {

	private File fileRequest = null;
	protected FileInputStream request = null;
	protected URI uri = null;
	protected String endPoint;

// **********************************************************************************************************************
	/**
	 * @author pyhocast (Yhon L. Castañeda)
	 * 
	 *         Constructor encargado de crear el archivo <xml> o <json> para el
	 *         request.
	 * @param: <xml> , <json>
	 */
	public BaseApiRestAssured(String type) {
		fileRequest = new File("request." + type);
		Reporter.write("FILE REQUEST CREADO");
	}

// **********************************************************************************************************************
	/**
	 * @author pyhocast (Yhon L. Castañeda)
	 * 
	 *         Constructor encargado de inicializar la clase cunando no hay un
	 *         archivo "xml" o "json" para el request. Es decir, cuando el consumo
	 *         del servicio se realiza mediante el endpoint.
	 */
	public BaseApiRestAssured() {
		super();
	}

// **********************************************************************************************************************
	/**
	 * @author pyhocast (Yhon L. Castañeda)
	 * 
	 *         Método encargado de escribir el cuerpo del request en el archivo ya
	 *         creado.
	 * @param body: Cuerpo del request (petición)
	 * @return: null (Si no se logra escribir en el archivo creado, la petición). No
	 *          null (Si la petición es escrita)
	 */
	public FileWriter writeRequest(String body) {
		FileWriter request = null;
		try {
			request = new FileWriter(fileRequest);
			request.write("");
			request.write(body);
			request.close();
			Reporter.write("*************** ESCRIBIENDO PETICIÓN ***************");
		} catch (IOException e) {
			Reporter.write("*************** ERROR ESCRIBIENDO PETICIÓN ***************");
			request = null;
		}

		return request;
	}

// **********************************************************************************************************************
	/**
	 * @author pyhocast (Yhon L. Castañeda)
	 * 
	 *         Este método se encarga de enviar la petición teniendo en cuenta el
	 *         archivo de petición que fue creado en el constructor. Lo anterior,
	 *         únicamente para servicio <SOAP>
	 * @param endpoint: Url a la que se envía la petición.
	 * @return: String con el cuerpo de la respuesta de la petición.
	 * @throws Exception 
	 */
	public String postSoapService(String endpoint) throws Exception {
		
		if (fileRequest == null)
			throw new Exception("ERROR - BaseApiRestAssured : El constructor usado no permite hacer uso de [postSoapService]");
		

		this.endPoint = endpoint;
		Reporter.write("*************** ENVIANDO PETICIÓN ***************");
		
		request = new FileInputStream(fileRequest);
		uri = new URI(this.endPoint);
		Response response = getResponse();
		/*
		Response response = RestAssured.given().header("Content-Type", "text/xml").and()
				.body(IOUtils.toString(request, "UTF-8")).when().post(uri).then().statusCode(200).and().log().all()
				.extract().response();
				
		*/
		if (response != null) {
			request.close();
			return response.asString();
		}
		return null;
	}
// **********************************************************************************************************************
	/**
	 * @author smzealo (Sandra M. Zea)
	 * 
	 *         Este método se encarga de retornar en un [JsonPath] la respuesta de un servicio REST.<br>
	 *         Importante que se cree clase que herede de esta e implmente el método <b>getResponse()</b>
	 * @param endpoint: Url de donde se pide la información
	 * @return String con la
	 *                  información de la trazabilidad.
	 * @throws Exception
	 */
	public JsonPath getRestService(String endpoint) throws Exception {

		this.endPoint = endpoint;
		Response response = getResponse();
		return response.jsonPath();
	}
// **********************************************************************************************************************
	/**
	 * @author pyhocast (Yhon L. Castañeda)
	 * 
	 *         Este método se encarga de retornar el archivo creado con el cuerpo de
	 *         la petición.
	 * @return: File
	 */
	public File getFileRequest() {
		return fileRequest;
	}
// **********************************************************************************************************************
	protected abstract Response getResponse();
// **********************************************************************************************************************
}
