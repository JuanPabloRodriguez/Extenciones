package library.core;

import java.io.File;

import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import library.common.Util;
import library.reporting.Reporter;
import library.settings.SettingsRun;

public class ListenerBaseTestNG_XBloque implements ITestListener {

    // MÉTODO INICIAL INVOCADO AL INICIO DEL LANZAMIENTO
//***********************************************************************************************************************
    @Override
    public void onStart(ITestContext context) {
    	// ESTE MÉTODO SE LLAMA ANTES DE TODOS LOS ANNOTATIONS DE TestNG
    }
//***********************************************************************************************************************
    @Override
    public void onTestStart(ITestResult result) {
    	Reporter.initializeSoftAssert();
    }
//***********************************************************************************************************************
    @Override
    public void onFinish(ITestContext context) {
        ITestListener.super.onFinish(context);
        
        // BORRA LA CARPETA DE EVIDENCIAS FINALES, SI NO CONTIENE ARCHIVOS
		File evidTestToolDir = new File(SettingsRun.getFinalEvidencesDir());
		if (Util.directoryExist(evidTestToolDir) && evidTestToolDir.listFiles().length == 0)
			evidTestToolDir.delete();
    }
//***********************************************************************************************************************
}
