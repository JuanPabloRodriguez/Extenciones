package library.core;

import java.awt.AWTException;
import java.awt.Graphics;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

import javax.imageio.ImageIO;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.JavascriptException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.NoSuchFrameException;
import org.openqa.selenium.NoSuchSessionException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.SessionNotCreatedException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;
import library.common.Util;
import library.common.VirtualKeyBoard;
import library.reporting.Evidence;
import library.reporting.Reporter;
import library.settings.SettingsRun;

public class BasePageWeb {

	public static boolean IGNORAR_PREFERENCES = false; // PONER EN TRUE SI DESEA IGNORAR LOS PREFERENCES
	private static String rumboScroll = "true";
	// VALORES BASE, PERO SI SALE EXCEPCIÓN, PUEDEN CAMBIAR LOS RESOURCE...
	private static String DIR_DRIVERS = "drivers";
	private static String DIR_LOCAL_DRIVERS = Util.getDirBaseTemp() + DIR_DRIVERS;
	// NOMBRES DE LOS DRIVERS A TOMAR
	private static String RESOURCE_CHROME = "chromedriver.exe";
	private static final String RESOURCE_IEXPLORE = "IEDriverServer.exe";
	private static final String RESOURCE_EDGE = "msedgedriver.exe";
	private static final String RESOURCE_FIREFOX = "geckodriver.exe";
	// NAVEGADORES QUE SE PUEDEN USAR PARA CARGAR PÁGINAS WEB
	public static final String EDGE = "EDGE";
	public static final String EXPLORER = "EXPLORER";
	public static final String CHROME = "CHROME";
	public static final String FIREFOX = "FIREFOX";
	private static final String MOBILE = "MOBILE";
	private List<String> listPrevPidDrivers = null;
	// private AppiumDriver<MobileElement> driverMobile = null;
	private BaseMobileApp mobileApp = null;
	private WebDriver driver;
	private String pidDriver; // NÚMERO DEL PROCESO DEL DRIVER QUE LEVANTA
	protected JavascriptExecutor jse;
	private String navegador;
	private String downloadFilePath; // RUTA DONDE SE DESCARGAN ARCHIVOS, SI ESTÁ VACÍO LA PÁGINA NO DESCARGA
										// ARCHIVOS
	private Actions action = null;
	private String initDriver;
	private boolean downloadDriver = false;
	private VirtualKeyBoard vkb;

//=======================================================================================================================
	/**
	 * Constructor que sólo recibe el navegador a usar para abrir la página Web. Se
	 * recomienda usar cuando NO se vayan a hacer descargas de archivos.
	 */
	public BasePageWeb(String navegador) {

		this.downloadFilePath = ""; // TOMARÁ LA RUTA POR DEFECTO QUE TENGA EL NAVEGADOR
		this.constructorBasePageWeb(navegador);
	}

	/**
	 * Constructor que recibe el navegador a usar para abrir la página Web y la ruta
	 * donde se hará descarga de archivos.
	 */
	public BasePageWeb(String navegador, String downloadFilePath) {

		this.downloadFilePath = downloadFilePath;
		this.constructorBasePageWeb(navegador);
	}

	/**
	 * Constructor que recibe otra página (página parent), la cual ya debe tener
	 * toda la información base de la página Web a usar, se genera una especie de
	 * clone de la página.
	 */
	public BasePageWeb(BasePageWeb parentPage) {

		this.mobileApp = parentPage.mobileApp;
		this.driver = parentPage.driver;
		this.pidDriver = parentPage.pidDriver;
		this.jse = parentPage.jse;
		this.navegador = parentPage.navegador;
		this.downloadFilePath = parentPage.downloadFilePath;
	}

	/**
	 * Constructor que se usa para los casos en que un dispositivo mobile tiene
	 * contexto Web. Ese contexto web se maneja como un BasePageWeb.
	 */
	public BasePageWeb(BaseMobileApp mobileApp) {

		// this.driverMobile = driver;
		this.mobileApp = mobileApp;
		this.driver = mobileApp.getDriver();
		this.pidDriver = null; // NO HAY NECESIDAD : LO CIERRA EL CONTROL DEL DISPOSTIVO MÓVIL
		this.jse = (JavascriptExecutor) this.driver;
		this.navegador = MOBILE;
	}

//***********************************************************************************************************************
	/**
	 * Método que carga los drivers de la máquina local y setea la propiedad
	 * respectiva.
	 */
	private void setPropertyDriver(String nbProperty, String nbDriver) {

		// LOS DRIVERS DEBEN ESTAR EN LA MÁQUINA LOCAL EN LA RUTA [DIR_LOCAL_DRIVERS] Y
		// DE ALLÍ SE EXTRAEN:
		/*
		 * if (Util.isLaunchJAR()) { // SE CAMBIA EL [DIR_LOCAL_DRIVERS] CUANDO ES
		 * LANZAMIENTO CON JAR String temp = new File(".").getAbsolutePath(); // VIENE
		 * POR EJEMPLO: [C:/Users/userX/Desktop/.] DIR_LOCAL_DRIVERS = Util.left(temp,
		 * temp.length() - 1); // LE QUITA EL PUNTO FINAL DIR_LOCAL_DRIVERS +=
		 * DIR_DRIVERS; }
		 */
//-----------------------------------------------------------------------------------------------------------------------
		// GARANTIZA LA EXISTENCIA DE LA CARPETA CON LOS DRIVERS EN LA MÁQUINA LOCAL
		if (!Util.directoryExist(DIR_LOCAL_DRIVERS))
			new File(DIR_LOCAL_DRIVERS).mkdirs();
		// VERIFICA LA EXISTENCIA DEL DRIVER EN LA MÁQUINA LOCAL
		String nbFileDriver = DIR_LOCAL_DRIVERS + File.separator + nbDriver;
		File fileDriver = new File(nbFileDriver);
		if (!fileDriver.exists())
			SettingsRun.exitTest("En la carpeta de Drivers [" + DIR_LOCAL_DRIVERS + "]\nNo se encuentra el Driver ["
					+ nbDriver + "]");
		// SI LLEGA A ESTE PUNTO ES PORQUE EL DRIVER BUSCADO EXISTE Y SE PUEDE CARGAR LA
		// PROPIEDAD
		System.setProperty(nbProperty, fileDriver.getAbsolutePath());
	}

//***********************************************************************************************************************
	private void constructorBasePageWeb(String navegador) {

		this.navegador = navegador;
		this.downloadDriver = Boolean.valueOf(SettingsRun.getProperty("prop.downloadDriver", "false"));
		if (navegador.equals(EDGE))
			this.edgeDriverConnection();
		else if (navegador.equals(EXPLORER))
			this.iExplorerDriverConnection();
		else if (navegador.equals(CHROME))
			this.chromeDriverConnection();
		else if (navegador.equals(FIREFOX))
			this.firefoxDriverConnection();
		else
			throw new WebDriverException("Navegador [" + navegador + "] NO contemplado");
		do { // ESPERA MIENTRAS EL BROWSER NO ESTÁ DISPONIBLE
			Util.wait(1);
		} while (!this.browserIsEnabled());
		jse = (JavascriptExecutor) this.driver;
	}

//***********************************************************************************************************************
	/**
	 * Genera una conexión al driver del navegador CHROME.
	 */
	protected void chromeDriverConnection() {

//-----------------------------------------------------------------------------------------------------------------------	
// Valida el tipo de Resource, dependiendo del SO (Windows/MacOS).
		RESOURCE_CHROME = Util.getSistemaOperativo().contains("MAC") ? "chromedriver" : "chromedriver.exe";
//-----------------------------------------------------------------------------------------------------------------------
		this.initDriver = "chromedriver";
		this.loadCurrentDriversPid(); // CARGA LOS PID DE PROCESOS DRIVER PREVIOS
		if (this.downloadDriver)
			WebDriverManager.chromedriver().setup();
		else
			this.setPropertyDriver("webdriver.chrome.driver", RESOURCE_CHROME);
//-----------------------------------------------------------------------------------------------------------------------
		try {
			this.loadChromeProperties();
		} catch (SessionNotCreatedException e) {
			String msg = e.getMessage();
			if (msg != null) {
				this.setPidDriver(); // SETEA EL PID DEL DRIVER CARGADO PARA LUEGO CERRARLO
				try {
					this.closePidDriver();
				} catch (IOException e1) {
				}
				String[] arrMsg = msg.split("Current browser version is ");
				String[] arrVer = arrMsg[1].split(" ");
				String version = arrVer[0];
				String msgError = "En la carpeta de Drivers [" + DIR_LOCAL_DRIVERS + "]\n" + "El driver ["
						+ RESOURCE_CHROME + "]\nNo corresponde a la versión [" + version + "]";
				if (this.downloadDriver)
					msgError = "No está funcionando [WebDriverManager.chromedriver().setup()]\n"
							+ "No corresponde a la versión [" + version + "]";
				e.printStackTrace();
				SettingsRun.exitTest(msgError);
			}
		}
	}

//***********************************************************************************************************************
	/**
	 * Carga las propiedades pertinentes del Chrome
	 */
	protected void loadChromeProperties() {

		boolean browserIsOpen = Boolean.valueOf(SettingsRun.getProperty(SettingsRun.PROP_WEB_OPENDRIVER, "false"));
		String port = SettingsRun.getProperty(SettingsRun.PROP_WEB_CHROMEPORT);
		if (browserIsOpen && port != null && !port.isEmpty()) {
			ChromeOptions options = new ChromeOptions();
			options.setExperimentalOption("debuggerAddress", "localhost:" + port);
			this.loadOtherCapabilitiesOrProfiles(options); // INVOCA EL CAMBIO DE CAPABILITIES
			this.driver = new ChromeDriver(options);
			this.pidDriver = SettingsRun.getProperty(SettingsRun.PROP_WEB_CHROMEPID);
		} else {
//-----------------------------------------------------------------------------------------------------------------------
			ChromeOptions options = new ChromeOptions(); // hereda de MutableCapabilities
			options.addArguments("--no-sandbox"); // PERMITIR EJECUCIONES DE FUENTES NO FIABLES: DEBE ESTAR DE 1RAS
			options.addArguments("safebrowsing.enabled=false"); // DESACTIVAR LA PROTECCIÓN DESCARGAS DE SITIOS NO
																// SEGUROS
			options.setCapability(CapabilityType.ACCEPT_INSECURE_CERTS, true); // SITIOS NO SEGUROS
			// IGNORAR LAS ALERTAS
			// options.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR,
			// UnexpectedAlertBehaviour.IGNORE);
			// options.setUnhandledPromptBehaviour(UnexpectedAlertBehaviour.IGNORE);
			// 1-DESACTIVA TODAS LAS EXTENSIONES DE CHROME - EVITA QUE ALGÚN PLUGIN DEL
			// NAVEGADOR INTENTE ABRIR PDFs
			// 2-DESACTIVA LA VISTA DE IMPRESIÓN PARA EVITAR NUEVAMENTE QUE ALGO INTENTE
			// ABRIR PDFs
			// 3-DESACTIVA EL BLOQUEO DE PANTALLAS EMERGENTES // "--disable-popup-blocking"
			options.addArguments("--disable-extensions", "--disable-print-preview");
			// options.addArguments("--disable-dev-shm-usage"); //DESHABILITAR USO DE
			// MEMORIA FISICA
			// options.addArguments("disable-infobars"); // disabling infobars
			// options.addArguments("--disable-gpu"); // applicable to windows os only
			options.addArguments("--disable-features=VizDisplayCompositor");
			// OPTION QUE EVITA ERROR [Unable to establish websocket connection to]
			options.addArguments("--remote-allow-origins=*");
			// options.addArguments(new String[] { "--disablenotifications"});
			// options.addArguments("--remote-debugging-port=9515"); //DETERMINAR PUERTO DE
			// EJECUCION REMOTA
			// options.addArguments("--headless");//EJECUCION SIN HEADDER/EN SEGUNDO PLANO
			// SIN COMPORTAMIENTO VISUAL
			// options.addArguments("--disable-web-security");
			// options.addArguments("--allow-running-insecure-content");
			// options.addArguments("--C:\\Users\\lntinjac\\AppData\\Local\\Google\\Chrome\\User
			// Data\\");
			this.loadOtherCapabilitiesOrProfiles(options); // INVOCA EL CAMBIO DE CAPABILITIES
//-----------------------------------------------------------------------------------------------------------------------
			// CAMBIAR EL USER AGENT POR EL DE AUTOMATIZACIÓN
			if (SettingsRun.CHANGE_USER_AGENT)
				options.addArguments("user-agent=" + SettingsRun.AUTO_USER_AGENT);
			// CONFIGURAR PREFERENCIAS Y CARGARLAS
			if (!IGNORAR_PREFERENCES) {
				Map<String, Object> prefs = new HashMap<String, Object>();
				if (!this.downloadFilePath.isEmpty()) {
					// CARPETA DE DOWNLOAD
					prefs.put("download.default_directory", this.downloadFilePath);
					// APAGAR LA VENTANA QUE PREGUNTA DÓNDE UBICAR Y CÓMO LLAMAR EL ARCHIVO POR
					// DESCARGAR
					prefs.put("download.prompt_for_download", false);
					// OPCIÓN PARA QUE CHROME PUEDA CREAR LA RUTA DE DESCARGA SI ES QUE NO EXISTE
					prefs.put("download.directory_upgrade", true);
					// PARA EVITAR QUE SALGA POPUP CHROME CUANDO HAY DESCARGA DE MÚLTIPLES ARCHIVOS
					prefs.put("profile.content_settings.exceptions.automatic_downloads.*.setting", 1);
				}
				// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
				// PARA QUE NO SAQUE PANTALLA PREGUNTANDO SI SALVA EL PASSWORD
				prefs.put("credentials_enable_service", false);
				prefs.put("profile.password_manager_enabled", false);
				// NAVEGACIÓN SEGURA ACTIVADA (OPCIONAL)
				prefs.put("safebrowsing.enabled", false);
				// PARA ABRIR PDFS EXTERNAMENTE: NO HACE DESCARGA
				prefs.put("plugins.always_open_pdf_externally", false);
				// profile.put("profile.default_content_settings.popups", 0);
				// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
				options.setExperimentalOption("prefs", prefs);
			}
//-----------------------------------------------------------------------------------------------------------------------
			this.driver = new ChromeDriver(options);
			this.setPidDriver(); // SETEA EL PID DEL DRIVER CREADO
			this.loadPortYPidAsProperty((ChromeDriver) this.driver);
		}
	}

//***********************************************************************************************************************
	/**
	 * Genera una conexión al driver del navegador FIREFOX.<br>
	 * Este método funciona para el ingreso de caracteres en las cajas de texto para
	 * Firefox57, si se usa el driver V0.25 / V0.26.
	 */
	private void firefoxDriverConnection() {

		this.initDriver = "geckodriver";
		this.loadCurrentDriversPid(); // CARGA LOS PID DE PROCESOS DRIVER PREVIOS
		if (this.downloadDriver)
			WebDriverManager.firefoxdriver().setup();
		else
			this.setPropertyDriver("webdriver.gecko.driver", RESOURCE_FIREFOX);
		if (this.downloadFilePath.isEmpty()) {
			this.driver = new FirefoxDriver();
		} else {
			FirefoxProfile profile = new FirefoxProfile();
			String apps = "application/octet-stream;image/jpeg;application/pdf";
			// 1-Se indica que debe utilizar la carpeta especificada en el paso siguiente.
			profile.setPreference("browser.download.folderList", 2); // #1
			// 2-Se indica la carpeta de download.
			profile.setPreference("browser.download.dir", this.downloadFilePath); // #2
			// 3-Se activa el uso del directorio asignado en el paso anterior.
			profile.setPreference("browser.download.useDownloadDir", true); // #3
			// 4-Se apaga la animación de comienzo de descarga (opcional).
			profile.setPreference("browser.download.manager.showWhenStarting", false); // 4#
			// 5-Paso importante, se pasa como parámetro los MIME type que quieren descargar
			// sin preguntar.
			profile.setPreference("browser.helperApps.neverAsk.saveToDisk", apps); // 5#
			// profile.setPreference("browser.helperApps.alwaysAsk.force", false); //#5
			// 6-Desactivar animación de descarga completa (opcional).
			profile.setPreference("browser.download.manager.showAlertOnComplete", false); // 6#
			// 7-Deshabilitar la ventana de descarga de firefox.
			profile.setPreference("browser.download.manager.useWindow", false); // 7#
			// 8-Apagar el plugin por defecto de firefox para leer archivos PDF.
			profile.setPreference("pdfjs.disabled", true); // 8#
			// 9-Cambia el user agent, si se requiere
			if (SettingsRun.CHANGE_USER_AGENT)
				profile.setPreference("general.useragent.override", SettingsRun.AUTO_USER_AGENT); // 9#
			this.loadOtherCapabilitiesOrProfiles(profile); // INVOCA EL CAMBIO DE CAPABILITIES
			FirefoxOptions options = new FirefoxOptions().setProfile(profile);
			this.driver = new FirefoxDriver(options);
		}
		this.setPidDriver(); // SETEA EL PID DEL DRIVER CREADO
	}

//***********************************************************************************************************************
	/**
	 * Genera una conexión al driver del navegador EDGE.
	 */
	private void edgeDriverConnection() {

		this.initDriver = "msedgedriver";
		this.loadCurrentDriversPid(); // CARGA LOS PID DE PROCESOS DRIVER PREVIOS
		if (this.downloadDriver)
			WebDriverManager.edgedriver().setup();
		else
			this.setPropertyDriver("webdriver.edge.driver", RESOURCE_EDGE);
		EdgeOptions options = new EdgeOptions();
//-----------------------------------------------------------------------------------------------------------------------
		if (!this.downloadFilePath.isEmpty()) {
			// CARPETA DE DOWNLOAD
			options.setCapability("download.default_directory", this.downloadFilePath);
			// APAGAR LA VENTANA QUE PREGUNTA DÓNDE UBICAR Y CÓMO LLAMAR EL ARCHIVO POR
			// DESCARGAR
			options.setCapability("download.prompt_for_download", false);
			// OPCIÓN PARA QUE CHROME PUEDA CREAR LA RUTA DE DESCARGA SI ES QUE NO EXISTE
			options.setCapability("download.directory_upgrade", true);
		}
//-----------------------------------------------------------------------------------------------------------------------
		// NAVEGACIÓN SEGURA ACTIVADA (OPCIONAL)
		options.setCapability("safebrowsing.enabled", true);
		// PARA ABRIR PDFS EXTERNAMENTE
		options.setCapability("plugins.always_open_pdf_externally", true);
		// profile.put("profile.default_content_settings.popups", 0);
//-----------------------------------------------------------------------------------------------------------------------
		this.loadOtherCapabilitiesOrProfiles(options); // INVOCA EL CAMBIO DE CAPABILITIES
		this.driver = new EdgeDriver(options);
		this.setPidDriver(); // SETEA EL PID DEL DRIVER CREADO
	}

//***********************************************************************************************************************
	/**
	 * Genera una conexión al driver del navegador EXPLORER.
	 */
	private void iExplorerDriverConnection() {

		this.initDriver = "IEDriverServer";
		this.loadCurrentDriversPid(); // CARGA LOS PID DE PROCESOS DRIVER PREVIOS
		if (this.downloadDriver)
			WebDriverManager.iedriver().setup();
		else
			this.setPropertyDriver("webdriver.ie.driver", RESOURCE_IEXPLORE);
		// TOMADO DE
		// [https://www.selenium.dev/documentation/webdriver/browsers/internet_explorer/]
		InternetExplorerOptions options = new InternetExplorerOptions();
		// options.attachToEdgeChrome();
		// options.withEdgeExecutablePath(System.getProperty("webdriver.edge.binary"));
		options.ignoreZoomSettings();
		options.introduceFlakinessByIgnoringSecurityDomains();
		options.setCapability("silent", true);
		if (this.downloadFilePath.isEmpty()) {
			options.setCapability("IntroduceInstabilityByIgnoringProtectedModeSettings", true);
			options.setCapability("browserFocus", true);
			options.requireWindowFocus();
			options.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, false); // "ignoreProtectedModeSettings"
			// capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS,
			// 1);
			// capabilities.setCapability("browserstack.ie.enablePopups", "true");
			// capabilities.setCapability("disable-popup-blocking", false);
		} else {
			Reporter.writeOnlyConsole("***** OJO ---- No se ha parametrizado *****");
			options.disableNativeEvents();
		}
		this.loadOtherCapabilitiesOrProfiles(options); // INVOCA EL CAMBIO DE CAPABILITIES
		this.driver = new InternetExplorerDriver(options);
		this.setPidDriver(); // SETEA EL PID DEL DRIVER CREADO
	}

//***********************************************************************************************************************
	/**
	 * Después de la carga de capabilities, este método permite cambiar o adicionar
	 * capabilities / options / profiles, debe ser sobreescrito por la clase que
	 * herede de esta clase y quiera cambiar o adicionar capabilities para la
	 * conexión.<br>
	 * [capabilities] puede ser de las siguientes clases: ChromeOptions /
	 * FirefoxProfile / EdgeOptions / DesiredCapabilities (IEXplorer)
	 */
	protected void loadOtherCapabilitiesOrProfiles(Object capabilities) {

		// TODO SOBREESCRIBIR SEGÚN SE REQUIERA EN LAS CLASES QUE HEREDAN
	}

//***********************************************************************************************************************
	/**
	 * Indica si la instancia corresponde al contexto web de la APP de un
	 * dispositivo mobile.
	 */
	public boolean isWebContextApp() {

		return this.navegador.equals(MOBILE);
	}

//***********************************************************************************************************************
	public void maximizeBrowser() {

		this.driver.manage().window().maximize();
	}

//***********************************************************************************************************************
	/**
	 * Metodo setSizeWindowsCurrentBrowser: Su proposito es setear un tamaño
	 * determinado a la ventana actual del Navegador.
	 * 
	 * @param x - int - Tamaño Horizontal de la Ventana deseado.
	 * @param y - int - Tamaño Vertical de la Ventana deseado.
	 * 
	 * @date 03/10/2023
	 * @author DAARUBIO
	 */
	public void setSizeWindowsCurrentBrowser(int x, int y) {

		this.driver.manage().window().setSize(new Dimension(x, y));
	}

//***********************************************************************************************************************
	/**
	 * Almacena la imagen como se encuentra de la página Web.
	 * 
	 * @param nbFilePath : Ruta completa con el nombre del archivo, debe ir con
	 *                   extensión de imagen.
	 */
	public void saveScreenshot(String nbFilePath) {

		File src;
		if (this.navegador.equals(MOBILE)) {
			// SE HACE EL CAMBIO PARA QUE EN LA EVIDENCIA QUEDE EL MARCO DEL DISPOSITIVO,
			// CON LA HORA
			String currentContext = this.mobileApp.getDriver().getContext();
			if (!this.mobileApp.isAndroid()) // iOS ES MUY RÁPIDO Y LAS EVIDENCIAS ESTÁN QUEDANDO CON EL TECLADO
				Util.wait(1);
			this.mobileApp.getDriver().context("NATIVE_APP");
			src = ((TakesScreenshot) this.driver).getScreenshotAs(OutputType.FILE);
			this.mobileApp.getDriver().context(currentContext);
		} else
			src = ((TakesScreenshot) this.driver).getScreenshotAs(OutputType.FILE);
		try {
			FileHandler.copy(src, new File(nbFilePath));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

//***********************************************************************************************************************
	/**
	 * Hace highLight de los elementos indicados
	 * 
	 * @param elements
	 */
	public void highlightElements(WebElement... elements) {

		// To highlight the elements
		for (WebElement elem : elements) {
			jse.executeScript("arguments[0].style.border='4px solid red'", elem);
		}
	}

//***********************************************************************************************************************
	/**
	 * Hace unhighLight de los elementos indicados
	 * 
	 * @param elements
	 */
	public void unhighlightElements(WebElement... elements) {

		// To remove border from highlighted element
		for (WebElement elem : elements) {
			jse.executeScript("arguments[0].style.border = \"none\";", elem);
		}
	}

//***********************************************************************************************************************
	/**
	 * Almacena la imagen del [element].
	 * 
	 * @param nbFilePath : Ruta completa con el nombre del archivo, debe ir con
	 *                   extensión de imagen.
	 */
	public void saveScreenshot(String nbFilePath, WebElement element) {

		try {
			File src = element.getScreenshotAs(OutputType.FILE);
			FileHandler.copy(src, new File(nbFilePath));
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ElementClickInterceptedException e) {
			jse.executeScript("arguments[0].scrollIntoView();", element);
			this.saveScreenshot(nbFilePath, element);
		}
	}

//***********************************************************************************************************************
	/**
	 * Almacena TODAS las imágenes del [frame], haciendo el scroll hacia la derecha
	 * y hacia abajo, según se requiera.<br>
	 * En ocasiones el Elemento cuando salva la imagen incluye el scroll y en la
	 * evidencia final queda ese corte de los scroll, en esos casos se debe indicar
	 * si tiene scroll a lo alto [conScrollHeight] o a lo ancho [conScrollWidth].
	 * 
	 * @param nbFilePath : Ruta completa con el nombre del archivo, debe ir con
	 *                   extensión de imagen.
	 */
	public void saveFullScreenshotElement(String nbFilePath, WebElement element, boolean conScrollHeight,
			boolean conScrollWidth) throws IOException {

		// SI SE TRATA DE UN FRAME, PUEDE HACER EL CAMBIO DE FRAME
		WebElement elementToSave = element;
		boolean isFrame = true;
		try {
			this.changeFrame(element);
			elementToSave = this.element(By.tagName("html")); // SALVA EL ELEMNTO HTML DENTRO DEL FRAME
		} catch (NoSuchFrameException e) {
			isFrame = false;
		}
//-----------------------------------------------------------------------------------------------------------------------
		// ALISTA LA CARPETA TEMPORAL DONDE SE ALMACENARÁN LOS PANTALLAZOS
		String nbFolder = SettingsRun.RESULT_DIR + "\\Temp_img";
		File folder = new File(nbFolder);
		if (!Util.directoryExist(nbFolder))
			folder.mkdirs(); // CREA EL ARCHIVO
		String screenTmp = nbFolder + "\\Image_";
//-----------------------------------------------------------------------------------------------------------------------
		final int TAM_SCROLL = 21;
		// ALTO Y ANCHO TOTAL DEL ELEMENTO, ALTO Y ANCHO DE LA PARTE VISIBLE DEL
		// ELEMENTO
		int fullHeight, fullWidth, elementHeight, elementWidth;
		if (isFrame) {
			fullHeight = elementToSave.getSize().getHeight();
			int fh2 = ((Number) jse.executeScript("return window.document.body.scrollHeight")).intValue();
			if (fh2 > fullHeight)
				fullHeight = fh2;
			fullWidth = elementToSave.getSize().getWidth();
			int fw2 = ((Number) jse.executeScript("return window.document.body.scrollWidth")).intValue();
			if (fw2 > fullWidth)
				fullWidth = fw2;
			elementHeight = ((Number) jse.executeScript("return window.innerHeight")).intValue();
			elementWidth = ((Number) jse.executeScript("return window.innerWidth")).intValue();
		} else {
			fullHeight = ((Number) jse.executeScript("return arguments[0].scrollHeight", element)).intValue();
			fullWidth = ((Number) jse.executeScript("return arguments[0].scrollWidth", element)).intValue();
			elementHeight = elementToSave.getSize().getHeight();
			elementWidth = elementToSave.getSize().getWidth();
		}
		if (conScrollHeight)
			elementWidth -= TAM_SCROLL;
		if (conScrollWidth)
			elementHeight -= TAM_SCROLL;
//-----------------------------------------------------------------------------------------------------------------------
		// CÁLCULO DE CUÁNTAS VECES SE DEBE HACER EL SCROLL HACIA ABAJO Y HACIA EL LADO
		int heightScrollCount = (fullHeight / elementHeight);
		if (heightScrollCount < (Double.valueOf(fullHeight) / Double.valueOf(elementHeight)))
			heightScrollCount++;
		int widthScrollCount = (fullWidth / elementWidth);
		if (widthScrollCount < (Double.valueOf(fullWidth) / Double.valueOf(elementWidth)))
			widthScrollCount++;
//-----------------------------------------------------------------------------------------------------------------------
		String script1 = "window.scrollBy(arguments[0], arguments[1]);";
		String script2 = "arguments[0].scrollBy(arguments[1], arguments[2]);";
		// GARANTIZA QUE EL SCROLL DEL FRAME ESTÁ AL INICIO
		if (isFrame)
			jse.executeScript(script1, -fullWidth, -fullHeight);
		else
			jse.executeScript(script2, element, -fullWidth, -fullHeight);
//-----------------------------------------------------------------------------------------------------------------------
		BufferedImage finalImg, image;
		String pathFile;
		// CAPTURA LOS PANTALLAZOS PONIENDO UN PREFIJO DE NUMERACIÓN POR SCROL REALIZADO
		for (int heightIt = 1; heightIt <= heightScrollCount; heightIt++) {
			for (int widthIt = 1; widthIt <= widthScrollCount; widthIt++) {
				pathFile = screenTmp + heightIt + "_" + widthIt + ".png";
				this.saveScreenshot(pathFile, elementToSave);
				image = ImageIO.read(new File(pathFile));
				// GARANTIZA QUE LAS IMÁGENES TEMPORALES QUEDEN CON LOS TAMAÑOS DE VISIBILIDAA
				if (elementWidth < image.getWidth() || elementHeight < image.getHeight()) {
					image = image.getSubimage(image.getMinX(), image.getMinY(),
							(image.getWidth() < elementWidth) ? image.getWidth() : elementWidth,
							(image.getHeight() < elementHeight) ? image.getHeight() : elementHeight);
					finalImg = new BufferedImage(elementWidth, elementHeight, BufferedImage.TYPE_INT_ARGB);
					finalImg.getGraphics().drawImage(image, 0, 0, null);
					ImageIO.write(finalImg, "PNG", new File(pathFile));
				}
				// SE MUEVA SÓLO A LO ANCHO
				if (isFrame)
					jse.executeScript(script1, elementWidth, 0);
				else
					jse.executeScript(script2, element, elementWidth, 0);
			}
			// DEVUELVE EL SCROLL HORIZONTAL AL INICIO, DEJANDO EL VERTICAL DONDE ESTÁ
			if (isFrame)
				jse.executeScript(script1, -fullWidth, 0);
			else
				jse.executeScript(script2, element, -fullWidth, 0);
			// HACE UN DOWN DEL SCROLL VERTICAL, LO ALTO DEL ELEMENT PARA TOMAR EL SIGUIENTE
			// PANTALLAZO
			if (isFrame)
				jse.executeScript(script1, 0, elementHeight);
			else
				jse.executeScript(script2, element, 0, elementHeight);
		}
		// DEVUELVE EL SCROLL VERTICAL AL INICIO, DEJANDO EL HORIZONTAL DONDE ESTÁ
		if (isFrame)
			jse.executeScript(script1, 0, -fullHeight);
		else
			jse.executeScript(script2, element, 0, -fullHeight);
//-----------------------------------------------------------------------------------------------------------------------
		try {
			// ARMA LA IMAGEN A PARTIR DE TODOS LOS PANTALLAZOS TEMPORALES, INDICANDO 0 EL
			// TAMAÑO DEL HEADER Y DEL FOOTER
			finalImg = makeFinalImage(screenTmp, fullHeight, fullWidth, heightScrollCount, widthScrollCount, 0, 0);
			// ESCRIBE LA IMAGEN FINAL EN EL ARCHIVO INDICADO
			ImageIO.write(finalImg, "PNG", new File(nbFilePath));
			FileUtils.deleteDirectory(folder); // BORRA EL DIRECTORIO TEMPORAL
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

//***********************************************************************************************************************
	/**
	 * Almacena la imagen de TODA la página Web.<br>
	 * Es posible que la página cuente con HEADER, si es así se recibe el locator
	 * por parámetro, este método se mueve al final de la pantalla, porque hay
	 * HEADERs que se muestran después del primer scroll.<br>
	 * Si la página tiene FOOTER, se recibe el WebElement respectivo, en caso
	 * contrario [null].
	 * 
	 * @param nbFilePath : Ruta completa con el nombre del archivo, debe ir con
	 *                   extensión de imagen (.PNG)
	 */
	public void saveFullScreenshot(String nbFilePath, By locatorHeader, WebElement footer) {

		WebElement header = null;
//-----------------------------------------------------------------------------------------------------------------------
		// SI HAY LOCATOR DE HEADER, SE MUEVE AL FINAL PARA ASEGURAR QUE EL OBJETO
		// HEADER SE MUESTRE Y ASÍ CONOCER
		// SU ALTURA
		if (locatorHeader != null) {
			// ALTO TOTAL DE LA PÁGINA
			int fullHeight = ((Number) jse.executeScript("return document.body.scrollHeight")).intValue();
			jse.executeScript("window.scrollBy(arguments[0], arguments[1])", 0, fullHeight);
			header = this.element(locatorHeader);
		}
		this.saveFullScreenshot(nbFilePath, header, footer);
	}

//***********************************************************************************************************************
	/**
	 * Almacena la imagen de TODA la página Web.<br>
	 * Es posible que la página cuente con HEADER y FOOTER, si es así se reciben los
	 * WebElement por parámetro, si alguno no existe [null].
	 * 
	 * @param nbFilePath : Ruta completa con el nombre del archivo, debe ir con
	 *                   extensión de imagen (.PNG)
	 */
	public void saveFullScreenshot(String nbFilePath, WebElement header, WebElement footer) {

		// DETERMINA ALTURA DEL HEADER Y DEL FOOTER SI HAY
		int headerHeight = 0, footerHeight = 0;
		if (header != null)
			headerHeight = header.getSize().getHeight();
		if (footer != null)
			footerHeight = footer.getSize().getHeight();
//-----------------------------------------------------------------------------------------------------------------------
		// ALISTA LA CARPETA TEMPORAL DONDE SE ALMACENARÁN LOS PANTALLAZOS
		String nbFolder = SettingsRun.RESULT_DIR + "\\Temp_img";
		File folder = new File(nbFolder);
		if (!Util.directoryExist(nbFolder))
			folder.mkdirs(); // CREA EL ARCHIVO
		String screenTmp = nbFolder + "\\Image_";
//-----------------------------------------------------------------------------------------------------------------------
		// ALTO Y ANCHO TOTAL DE LA PÁGINA
		int fullHeight = ((Number) jse.executeScript("return document.body.scrollHeight")).intValue();
		int fullWidth = ((Number) jse.executeScript("return document.body.scrollWidth")).intValue();
		// ALTO DE LA PARTE VISIBLE DE LA PÁGINA
		int browserHeight = ((Number) jse.executeScript("return window.innerHeight")).intValue();
		int browserWidth = ((Number) jse.executeScript("return window.innerWidth")).intValue();
//-----------------------------------------------------------------------------------------------------------------------
		String script = "window.scrollBy(arguments[0], arguments[1])";
		// GARANTIZA QUE EL SCROLL DE LA PANTALLA ESTÁ AL INICIO
		jse.executeScript(script, -fullWidth, -fullHeight);
//-----------------------------------------------------------------------------------------------------------------------
		// CAPTURA LOS PANTALLAZOS EN UNA CARPETA TEMPORAL
		int heightCaptured = 0, widthCaptured = 0;
		int heightMov = browserHeight - headerHeight - footerHeight;
		int heightNumImg = 1, widthNumIg;
		do {
			widthNumIg = 1;
			do {
				this.saveScreenshot(screenTmp + heightNumImg + "_" + widthNumIg + ".png");
				jse.executeScript(script, browserWidth, 0); // PARA QUE SE MUEVA SÓLO A LO ANCHO
				widthCaptured += browserWidth;
				widthNumIg++;
			} while (widthCaptured < fullWidth);
			// DEVUELVE EL SCROLL HORIZONTAL AL INICIO, DEJANDO EL VERTICAL DONDE ESTÁ
			jse.executeScript(script, -fullWidth, 0);
			// HACE UN DOWN DEL SCROLL VERTICAL, LO ALTO DEL BROWSER QUITANDO HEADER Y
			// FOOTER PARA TOMAR EL SIGUIENTE
			// PANTALLAZO
			jse.executeScript(script, 0, heightMov);
			heightCaptured += heightMov;
			heightNumImg++;
		} while (heightCaptured < fullHeight);
		// DEVUELVE EL SCROLL VERTICAL AL INICIO, DEJANDO EL HORIZONTAL DONDE ESTÁ
		jse.executeScript(script, 0, -fullHeight);
//-----------------------------------------------------------------------------------------------------------------------
		// TOTAL DE IMÁGENES CAPTURADAS A LO ALTO Y A LO ANCHO
		heightNumImg--;
		widthNumIg--;
		// -----------------------------------------------------------------------------------------------------------------------
		try {
			// ARMA LA IMAGEN A PARTIR DE TODOS LOS PANTALLAZOS TEMPORALES
			BufferedImage finalImg = makeFinalImage(screenTmp, fullHeight, fullWidth, heightNumImg, widthNumIg,
					headerHeight, footerHeight);
			// ESCRIBE LA IMAGEN FINAL EN EL ARCHIVO INDICADO
			ImageIO.write(finalImg, "PNG", new File(nbFilePath));
			FileUtils.deleteDirectory(folder); // BORRA EL DIRECTORIO TEMPORAL
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

//***********************************************************************************************************************
	/**
	 * Método para moverse al final del page - Se recomienda su uso para Contextos
	 * Web
	 */
	public void moveDownScreen() {

		// GARANTIZA QUE EL SCROLL DE LA PANTALLA ESTÁ AL INICIO
		WebElement html = driver.findElement(By.tagName("html"));
		html.sendKeys(Keys.END);
	}

	/**
	 * @author Sebastían Correa Mendez Pscorrea
	 * @date 20/10/2023
	 * @param cantidad
	 */
	public void scrollDownJavaScript(int cantidad) {

		jse.executeScript("window.scrollBy(0, " + cantidad + ");"); // Cambia el valor 250 según tus necesidades
	}

//***********************************************************************************************************************
	/**
	 * Método para moverse al inicio del page - Se recomienda su uso para Contextos
	 * Web
	 */
	public void moveUpScreen() {

		// GARANTIZA QUE EL SCROLL DE LA PANTALLA ESTÁ AL INICIO
		WebElement html = driver.findElement(By.tagName("html"));
		html.sendKeys(Keys.HOME);
	}

//***********************************************************************************************************************
	/**
	 * Método para moverse al final del elemento.
	 */
	public void moveDownElement(WebElement element) {

		jse.executeScript("arguments[0].scrollTo(0, arguments[0].scrollHeight)", element);
		Util.wait(1);
	}

//***********************************************************************************************************************
	/**
	 * Método para moverse al inicio del elemento.
	 */
	public void moveUpElement(WebElement element) {

		jse.executeScript("arguments[0].scrollTo(0, -arguments[0].scrollHeight)", element);
		Util.wait(1);
	}

//***********************************************************************************************************************
	/**
	 * Salva las imágenes de los pantallazos de la página Web.<br>
	 * Se usa más que todo para Pages de contexto web, ya que en estos conoces se
	 * desconoce el ALTO del browser.<br>
	 * [nbFilePath] trae en su nombre el texto "(ScrX)" el cual debe ser reemplazado
	 * por un número secuencial, si sólo hay 1 pantalla, el prefjo con el número
	 * secuencial desaparece del nombre del archivo.<br>
	 * Retorna en una lista los archivos creados (con path y extensión)
	 * 
	 * @param nbFilePath -- Si no contiene en el nombre del archivo el texto
	 *                   "(ScrX)" no guarda las imágenes de manera correcta.
	 */
	public String[] saveFullScreenshot(String nbFilePath) {

		// GARANTIZA QUE EL SCROLL DE LA PANTALLA ESTÁ AL INICIO
		WebElement html = driver.findElement(By.tagName("html"));
		html.sendKeys(Keys.HOME);
		List<String> filesList = new ArrayList<String>();
		String nbFile = nbFilePath.replace("(ScrX) ", "(01) ");
		this.saveScreenshot(nbFile); // PRIMERA IMAGEN
		filesList.add(nbFile);
//-----------------------------------------------------------------------------------------------------------------------
		// ALTO DE LA PARTE VISIBLE DE LA PÁGINA
		int browserHeight = ((Number) jse.executeScript("return window.innerHeight")).intValue();
		File lastImage, currentImage;
		boolean terminar;
		int numScreen = 1;
		String reemplazo, script = "window.scrollBy(arguments[0], arguments[1])";
		try {
			// LA ÚLTIMA IMAGEN ES EL PANTALLAZO ACTUAL
			lastImage = ((TakesScreenshot) this.driver).getScreenshotAs(OutputType.FILE);
			do {
				// for (int veces = 0; veces < numDown; veces++) {
				jse.executeScript(script, 0, browserHeight);
				numScreen++;
				reemplazo = "(" + Util.leftComplete(String.valueOf(numScreen), 2, '0') + ") ";
				currentImage = ((TakesScreenshot) this.driver).getScreenshotAs(OutputType.FILE);
				terminar = Util.equalImages(lastImage, currentImage); // TERMINA SI LA ACTUAL ES IGUAL A LA ANTERIOR
				if (!terminar) {
					nbFile = nbFilePath.replace("(ScrX) ", reemplazo);
					FileHandler.copy(currentImage, new File(nbFile));
					filesList.add(nbFile);
					lastImage = currentImage;
				}
			} while (!terminar);
//-----------------------------------------------------------------------------------------------------------------------
			if ((numScreen - 1) == 1) { // COMO SÓLO SE GUARDÓ 1 PANTALLA, SE LE QUITA EL CONTADOR "01" QUEDA VACÍO
				nbFile = filesList.get(0).replace("(01) ", "");
				Util.moveFile(filesList.get(0), nbFile);
				filesList.set(0, nbFile);
			} else // HAY MÁS DE 1 PANTALLA, SE DEJA AL INICIO DE LA PANTALLA
				html.sendKeys(Keys.HOME);
//-----------------------------------------------------------------------------------------------------------------------
		} catch (IOException e) {
			e.printStackTrace();
		}
		return Util.listToArray(filesList);
	}

//***********************************************************************************************************************
	/**
	 * Salva las imágenes de los pantallazos de la página Web, haciendo uso del AV
	 * PAG sobre el [element].<br>
	 * [nbFilePath] trae en su nombre el texto "(ScrX)" el cual debe ser reemplazado
	 * por un número secuencial, si sólo hay 1 pantalla, el prefjo con el número
	 * secuencial desaparece del nombre del archivo.<br>
	 * Retorna en una lista los archivos creados (con path y extensión)
	 * 
	 * @param nbFilePath -- Si no contiene en el nombre del archivo el texto
	 *                   "(ScrX)" no guarda las imágenes de manera correcta.
	 */
	public String[] saveFullElementWithAvPage(WebElement element, String nbFilePath) {
		Util.wait(2);
		// GARANTIZA QUE EL MOUSE ESTA SOBRE EL ELEMENTO Y LE PUEDE APLICAR EL AVANCE DE
		// PÁGINA (POR ESO DA CLICK)
		this.mouseOver(element);
		this.mouseClick();
		List<String> filesList = new ArrayList<String>();
		String nbFile = nbFilePath.replace("(ScrX) ", "(01) ");
		this.saveScreenshot(nbFile); // PRIMERA IMAGEN
		filesList.add(nbFile);
//-----------------------------------------------------------------------------------------------------------------------
		File lastImage, currentImage;
		boolean terminar;
		int numScreen = 1;
		String reemplazo;
		try {
			if (vkb == null)
				vkb = new VirtualKeyBoard();
			// LA ÚLTIMA IMAGEN ES EL PANTALLAZO ACTUAL
			lastImage = ((TakesScreenshot) this.getDriver()).getScreenshotAs(OutputType.FILE);
			do {
				Util.wait(1);
				vkb.avPag(); // VA AVANZANDO EN EL [element] CON EL AVANCE DE PÁGINA DEL TECLADO VIRTUAL
				numScreen++;
				reemplazo = "(" + Util.leftComplete(String.valueOf(numScreen), 2, '0') + ") ";
				currentImage = ((TakesScreenshot) this.getDriver()).getScreenshotAs(OutputType.FILE);
				// TERMINA SI LA IMAGEN QUE SE ACABA DE TOMAR ES IGUAL A LA ANTERIOR
				terminar = Util.equalImages(lastImage, currentImage);
				if (!terminar) {
					nbFile = nbFilePath.replace("(ScrX) ", reemplazo);
					FileHandler.copy(currentImage, new File(nbFile)); // VA DEJANDO LA IMAGEN
					filesList.add(nbFile);
					lastImage = currentImage;
				}
				Util.wait(1);
			} while (!terminar);
			if ((numScreen - 1) == 1) { // COMO SÓLO SE GUARDÓ 1 PANTALLA, SE LE QUITA EL CONTADOR "01" QUEDA VACÍO
				nbFile = filesList.get(0).replace("(01) ", "");
				Util.moveFile(filesList.get(0), nbFile);
				filesList.set(0, nbFile);
			}
		}
//-----------------------------------------------------------------------------------------------------------------------
		catch (Exception e) {
			e.printStackTrace();
		}
		return Util.listToArray(filesList);
	}

//***********************************************************************************************************************
	/**
	 * Retorna la imagen generada a partir de los pantallazos temporales, existentes
	 * en [screenTmpPath].
	 * 
	 * @param fullHeight   - Altura total que debe tener la imagen
	 * @param fullWidth    - Ancho total que debe tener la imagen
	 * @param numLastImgH  - Número de la última imagen por altura
	 * @param numLastImgW  - Número de la última imagen por ancho
	 * @param headerHeight - Altura del header
	 * @param footerHeight - Altura del footer
	 */
	private BufferedImage makeFinalImage(String screenTmpPath, int fullHeight, int fullWidth, int numLastImgH,
			int numLastImgW, int headerHeight, int footerHeight) throws IOException {

		// EL ALTO Y ANCHO DE LA IMAGEN FINAL DEBE COINCIDIR CON EL ALTO Y ANCHO TOTAL
		BufferedImage finalImg = new BufferedImage(fullWidth, fullHeight, BufferedImage.TYPE_INT_ARGB);
		Graphics g = finalImg.getGraphics();
//-----------------------------------------------------------------------------------------------------------------------
		// 1 - PONER EL ÚLTIMO PANTALLAZO (EL DE ABAJO Y LA DERECHA)
		BufferedImage image = ImageIO.read(new File(screenTmpPath + numLastImgH + "_" + numLastImgW + ".png"));
		int elementWidth = image.getWidth();
		int xInit = fullWidth - image.getWidth();
		int yInit = fullHeight - image.getHeight();
		if (xInit < 0)
			xInit = 0;
		if (yInit < 0)
			yInit = 0;
		g.drawImage(image, xInit, yInit, null);
//-----------------------------------------------------------------------------------------------------------------------
		// 2 - PONER LA FILA DE LA ÚLTIMA LÍNEA DE PANTALLAS, SIN EL ÚLTIMO PANTALLAZO
		// (DERECHA) QUE YA SE PUSO
		xInit = 0; // POSICIÓN DEL ANCHO
		yInit = fullHeight;// POSICIÓN DEL ALTO
		for (int widthIterator = 1; widthIterator < numLastImgW; widthIterator++) {
			image = ImageIO.read(new File(screenTmpPath + numLastImgH + "_" + widthIterator + ".png"));
			if (yInit == fullHeight)
				yInit -= image.getHeight();
			if (yInit < 0)
				yInit = 0;
			g.drawImage(image, xInit, yInit, null);
			xInit += image.getWidth(); // INCREMENTA LA POSICIÓN 'X' PARA LAS IMÁGENES DE LA LÍNEA FINAL
		}
//-----------------------------------------------------------------------------------------------------------------------
		// 3 - PONER EL RESTO DE PANTALLAZOS, SIN TENER EN CUENTA LA PARTE INFERIOR QUE
		// YA SE PUSO
		int maxHeight;
		yInit = 0; // SE EMPIEZAN A PONER LAS IMÁGENES DESDE LAS PRIMERAS
		for (int heightIterator = 1; heightIterator < numLastImgH; heightIterator++) {
			xInit = fullWidth - elementWidth;
			maxHeight = 0; // MÁXIMO HEIGHT POR LÍNEA DE IMÁGENES
			for (int widthIterator = numLastImgW; widthIterator >= 1; widthIterator--) {
				image = ImageIO.read(new File(screenTmpPath + heightIterator + "_" + widthIterator + ".png"));
				// SI ES PANTALLA SUPERIOR : SE LE DEJA HEADER Y SE LE QUITA FOOTER
				if (heightIterator == 1)
					image = image.getSubimage(image.getMinX(), image.getMinY(), image.getWidth(),
							image.getHeight() - footerHeight);
				// SI ES PANTALLA INTERMEDIA (NO ES LA SUPERIOR) : SE LE QUITA A LA IMAGEN EL
				// HEADER Y EL FOOTER
				else if (heightIterator != 1)
					image = image.getSubimage(image.getMinX(), image.getMinY() + headerHeight, image.getWidth(),
							image.getHeight() - headerHeight - footerHeight);
				g.drawImage(image, xInit, yInit, null);
				xInit -= image.getWidth(); // INCREMENTA LA POSICIÓN 'X' PARA LAS IMÁGENES DE LA LÍNEA FINAL
				if (xInit < 0)
					xInit = 0;
				if (maxHeight < image.getHeight())
					maxHeight = image.getHeight();
			}
			yInit += maxHeight; // INCREMENTA LA POSICIÓN 'Y' PARA LAS SIGUIENTES IMÁGENES
		}
		return finalImg;
	}

//***********************************************************************************************************************
	public void deleteCookies() {

		this.driver.manage().deleteAllCookies();
	}

//=======================================================================================================================
	// TODO >> MANEJO DE DIÁLOGOS - ALERTAS DE LAS PÁGINAS WEB:
	/**
	 * Indica si existe un diálogo (pantalla de alerta) en la página web.
	 * 
	 * @return boolean
	 */
	public boolean existDialog() {

		boolean existeAlerta = true;
		try {
			this.driver.switchTo().alert(); // SE GENERA EXCEPCIÓN SI NO HAY ALERTA
		} catch (NoAlertPresentException e) {
			existeAlerta = false;
		}
		return existeAlerta;
	}

//***********************************************************************************************************************
	/**
	 * Espera hasta que se presente el diálogo (alerta) en la página Web.
	 * 
	 * @param secondsWait : Segundos máximo de espera, si viene <= 0 toma un valor
	 *                    de 10 por defecto.
	 */
	public void waitDialog(int secondsWait) {

		int maximoEspera = secondsWait;
		if (secondsWait <= 0)
			maximoEspera = 10;
		WebDriverWait wait = new WebDriverWait(this.driver, maximoEspera);// Duration.ofSeconds(maximoEspera));
		// Wait for the alert to be displayed and store it in a variable
		wait.until(ExpectedConditions.alertIsPresent()); // @ZEA : PUSE driver -> PERO NO SÉ QUÉ SIGNIFICA
	}

//***********************************************************************************************************************
	/**
	 * Aceptar el diálogo (alerta) presentado en la página Web. Requerido que exista
	 * el diálogo, si no existe se presentará una excepción
	 * "NoAlertPresentException".
	 */
	public void acceptDialog() {

		this.driver.switchTo().alert().accept();
	}

//***********************************************************************************************************************
	/**
	 * Rechazar el diálogo (alerta) presentado en la página Web. Requerido que
	 * exista el diálogo, si no existe se presentará una excepción
	 * "NoAlertPresentException".
	 */
	public void rejectDialog() {

		this.driver.switchTo().alert().dismiss();
	}

//***********************************************************************************************************************
	/**
	 * Escribir en el diálogo (alerta) presentado en la página Web el texto [text].
	 * Requerido que exista el diálogo, si no existe se presentará una excepción
	 * "NoAlertPresentException".
	 */
	public void writeInDialog(String text) {

		this.driver.switchTo().alert().sendKeys(text);
	}

//***********************************************************************************************************************
	/**
	 * Retorna el mensaje presentado en el diálogo (alerta) presentado en la página
	 * Web. Requerido que exista el diálogo, si no existe se presentará una
	 * excepción "NoAlertPresentException".
	 */
	public String getMessageDialog() {

		return this.driver.switchTo().alert().getText();
	}

//=======================================================================================================================
	// TODO >> ALGUNOS MÉTODO GETTER Y SETTER
	/**
	 * Retorna el drive de la página Web.
	 */
	public WebDriver getDriver() {

		return this.driver;
	}

	public BaseMobileApp getScreenMobile() {

		return this.mobileApp;
	}

	public String getDownloadFilePath() {

		return this.downloadFilePath;
	}

	protected JavascriptExecutor getJse() {

		return this.jse;
	}

//***********************************************************************************************************************
	/**
	 * Setea el driver
	 */
	public void setDriver(WebDriver driverSet) {

		this.driver = driverSet;
	}

//***********************************************************************************************************************
	/**
	 * retorna el navegador de la página Web.
	 */
	public String getNavegador() {

		return this.navegador;
	}

//=======================================================================================================================
	// TODO >> ALGUNOS MÉTODO GETTER Y SETTER
	/**
	 * Navega a la [url] indicada.
	 */
	public void navigate(String url) {

		this.driver.get(url);
	}

//***********************************************************************************************************************
	/**
	 * Navega a la [url] indicada, esta es una URL que solicita autenticación, por
	 * eso es requerida la información del [username] y [password].
	 */
	public void navigate(String url, String username, String password) {

		String newUrl = url.replace("https://", "");
		this.navigate("https://" + username + ":" + password + "@" + newUrl);
	}

//***********************************************************************************************************************
	/**
	 * Cierra la ventana actual. Si sólo hay una ventana abierta, se cierra todo el
	 * Browser.
	 */
	public void closeCurrentBrowser() {

		this.driver.close();
	}

//***********************************************************************************************************************
	/**
	 * Cierra todos los Browser que se hayan abierto con el driver de la página Web
	 * actual.
	 */
	public void closeAllBrowsers() {

		if (this.browserIsEnabled()) {
			this.changeToOriginalDownloadDir_OpeningChrome();
			this.closeCurrentBrowser();
			this.driver.quit();
		}
		try {
			this.closePidDriver();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

//***********************************************************************************************************************
	/**
	 * Para cambiar en el chrome la ruta de descarga - se usa en
	 * [BasePageWeb_OpeningChrome] ya que lo hace a través de la configuración
	 * propia del Chrome
	 */
	protected void changeToOriginalDownloadDir_OpeningChrome() {

		// NO SE USA PARA [BasePageWeb], SE SOBREESCRIBE EN [BasePageWeb_OpeningChrome]
		// : ES INVOCADO POR [closeAllBrowsers]
	}

//***********************************************************************************************************************
	/**
	 * Carga en [listPrevPidDrivers] los PID de los driver [this.initDriver] que se
	 * están ejecutando en el sistema.<br>
	 * Se debe invocar antes de crear la instancia al driver.
	 */
	private void loadCurrentDriversPid() {

		if (this.listPrevPidDrivers != null)
			return; // YA FUE CARGADA LA INFORMACIÓN DE LOS PID ACTUALES, NO SE VULEVE A CARGAR
		this.listPrevPidDrivers = new ArrayList<String>();
		try {
			this.listPrevPidDrivers = Util.getTaskPidsBegins(this.initDriver);
		} catch (Exception e) {
		}
	}

//***********************************************************************************************************************
	/**
	 * Debe tener cargada la lista de drivers previos existentes
	 * [listPrevPidDrivers]<br>
	 * Carga los drivers existentes y los compara contra los de la lista
	 * [listPrevPidDrivers], aquel valor que no está debe corresponde al ID del
	 * proceso que corresponde al driver que se acaba de levantar.<br>
	 * Se debe invocar justo despuás de crear la instancia al driver.
	 */
	protected void setPidDriver() {

		List<String> currentPidDrivers = new ArrayList<String>();
		try {
			currentPidDrivers = Util.getTaskPidsBegins(this.initDriver);
		} catch (Exception e) {
		}
		this.pidDriver = null;
		for (String pid : currentPidDrivers) {
			if (!this.listPrevPidDrivers.contains(pid)) {
				this.pidDriver = pid;
				break;
			}
		}
	}

//***********************************************************************************************************************
	/**
	 * Método que carga el puerto y el ID del proceso al driver [ChromeDriver
	 * driverc], con el fin de que la PageWeb que se cargue no nazca nueva sino tome
	 * una que ya está abierta.
	 */
	protected void loadPortYPidAsProperty(ChromeDriver driverc) {

		if (Util.isLaunchJAR())
			return; // EN JAR NO SETEA ESTOS PROPERTIES
		Capabilities c = driverc.getCapabilities();
		Map<String, Object> m = c.asMap();
		String chromePort = null;
		for (Map.Entry<String, Object> e : m.entrySet()) {
			if (e.getKey().equals("goog:chromeOptions")) {
				chromePort = e.getValue().toString().replace("{debuggerAddress=localhost:", "").replace("}", "");
				SettingsRun.setProperty(SettingsRun.PROP_WEB_CHROMEPORT, chromePort);
				break;
			}
		}
		if (this.pidDriver != null) { // Para MacOs este valor esta llenado null, esta en proceso de Revision.
			SettingsRun.setProperty(SettingsRun.PROP_WEB_CHROMEPID, this.pidDriver);
			Reporter.writeTitle("chromePort [" + chromePort + "] - chromePID [" + pidDriver + "]");
		}
	}

//***********************************************************************************************************************
	/**
	 * Garantiza el cierre del proceso del Driver que corresponde al de la instancia
	 * actual.
	 */
	private void closePidDriver() throws IOException {

		if (this.pidDriver != null && !this.pidDriver.isEmpty()) {
			Runtime.getRuntime().exec("taskkill /F /PID " + this.pidDriver); // MATA EL PROCESO DEL DRIVER
		}
	}

//***********************************************************************************************************************
	/**
	 * Refresca el navegador actual.
	 */
	public void refresh() {

		this.driver.navigate().refresh();
	}

//***********************************************************************************************************************
	/**
	 * Retorna el [title] de la página Web actual.
	 */
	public String getTitle() {

		return this.driver.getTitle();
	}

//***********************************************************************************************************************
	/**
	 * Retorna el ID de la ventana actualmente abierta.
	 */
	public String getIdWindow() {

		return this.driver.getWindowHandle();
	}

//***********************************************************************************************************************
	/**
	 * Retorna el ID de todas las ventanas abiertas desde el driver actual.
	 */
	public List<String> getIdWindows() {

		return new ArrayList<>(this.driver.getWindowHandles());
	}

//***********************************************************************************************************************
	/**
	 * Cambia el foco del driver a la ventana cuyo ID corresponde a [idWindow]
	 */
	public void changeWindow(String idWindow) {

		this.driver.switchTo().window(idWindow);
		Util.wait(1);
	}

//***********************************************************************************************************************
	/**
	 * Hace el cambio de Window, a aquel Window cuyo title corresponda al recibido.
	 * La coincidencia del title debe ser exacta cuando [isEqual] es [true], cuando
	 * es [false] la coincidencia es de Contains.
	 * 
	 * @Note Método usado más que todo para aplicaciones móviles con contextos Web.
	 * @return [null], si ninguna de las window existentes coinciden con el [title].
	 *         Se deja el return, porque es la forma de identificar que no existe.
	 */
	public boolean changeWindowByTitle(String title, boolean isEqual) {

		if ((isEqual && this.getTitle().equals(title)) || (!isEqual && this.getTitle().contains(title)))
			return true;
		boolean encontroWindTitle = false;
		List<String> listaCurrentIds = this.getIdWindows();
		for (int i = 0; i < listaCurrentIds.size(); i++) {
			if (this.getIdWindow().equals(listaCurrentIds.get(i)))
				continue; // PARA QUE NO HAGA UN CHANGE WINDOW INNECESARIO
			this.changeWindow(listaCurrentIds.get(i));
			if (isEqual && this.getTitle().equals(title)) {
				encontroWindTitle = true;
				break;
			} else if (!isEqual && this.getTitle().contains(title)) {
				encontroWindTitle = true;
				break;
			}
		}
		return encontroWindTitle;
	}

//***********************************************************************************************************************
	/**
	 * Cambia al frame por default de la página, dejándolo en el PRINCIPAL.
	 */
	public void changeToDefaultFrame() {

		this.driver.switchTo().defaultContent();
		Util.wait(1);
	}

//***********************************************************************************************************************
	/**
	 * Cambia al frame cuyo WebElement se identifica con [locatorFrame]
	 */
	public void changeFrame(By locatorFrame) {

		this.changeFrame(this.element(locatorFrame));
		Util.wait(1);
	}

//***********************************************************************************************************************
	/**
	 * Cambia al frame cuyo WebElement corresponde a [element]
	 */
	public void changeFrame(WebElement element) {

		this.driver.switchTo().frame(element);
		Util.wait(1);
	}

//***********************************************************************************************************************
	/**
	 * Select a frame by its name or ID. Frames located by matching name attributes
	 * are always given precedence over those matched by ID. [nameIdFrame] the name
	 * of the frame window, the id of the frame. This driver focused on the given
	 * frame
	 */
	public void changeFrame(String nameIdFrame) {

		if (nameIdFrame.isEmpty())
			this.changeToDefaultFrame(); // CAMBIA AL CONTENIDO PRINCIPAL
		else {
			try {
				this.driver.switchTo().frame(nameIdFrame); // CAMBIA AL INDICADO
				Util.wait(1);
			} catch (Exception e) { // SALE EXCEPCIÓN PORQUE EL FRAME NO SE ENCUENTRA
				// HACE NADA!!!
			}
		}
	}

//***********************************************************************************************************************
	/**
	 * Método que cambia al primer frame [iframe / frame].
	 */
	public void changeToFirstFrame() {

		this.changeFrame(this.getFirstFrame());
	}

//***********************************************************************************************************************
	/**
	 * Método de apoyo que imprime en consola todos los elementos existentes en que
	 * correspondan a [xpath] si este dato viene VACÍO imprime todos los existentes.
	 */
	public void printAllElements(String xpath) {

		List<WebElement> elements = this.countAllElements(xpath);
		int cont = 1;
		String tagName;
		for (WebElement element : elements) {
			tagName = element.getAttribute("class");
			try {
				if (tagName.equalsIgnoreCase("SPAN") || tagName.equalsIgnoreCase("DIV"))
					Reporter.writeOnlyConsole(cont++ + " [" + tagName + " - " + element.getAttribute("class") + "]");
				else if (tagName.equalsIgnoreCase("A"))
					Reporter.writeOnlyConsole(cont++ + " [" + tagName + " - " + element.getText() + "]");
				else
					Reporter.writeOnlyConsole(cont++ + " [" + tagName + " - " + element.getAttribute("id") + "]");
			} catch (Exception e) {
				Reporter.writeOnlyConsole(cont++ + " [" + tagName + "]");
			}
		}
	}

	public List<WebElement> countAllElements(String xpath) {

		if (xpath.isEmpty())
			xpath = "//*"; // Busca todo
		List<WebElement> elements = this.findElements(By.xpath(xpath));
		Reporter.writeOnlyConsole("Se encontraron [" + elements.size() + "] elementos...");
		return elements;
	}

//=======================================================================================================================
	// TODO >> MÉTODO QUE USAN LOCALIZADORES
	public void focus(By locator) {

		this.focus(this.element(locator));
	}

	public void focus(WebElement element) {

		if (this.action == null)
			action = new Actions(this.driver);
		this.action.moveToElement(element).build().perform();
		// action.moveToElement(element).perform();
		/*
		 * if (element.getTagName().equals("input")) { element.sendKeys(Keys.SHIFT); }
		 * else { action.moveToElement(element).perform(); }
		 ******************************************************************
		 * WebElement txtUsername = driver.findElement(By.id("email")); Actions builder
		 * = new Actions(driver); Action seriesOfActions = builder
		 * .moveToElement(txtUsername) .click() .keyDown(txtUsername,Keys.SHIFT)
		 * .sendKeys(txtUsername,"hello") .keyUp(txtUsername,Keys.SHIFT) .doubleClick()
		 * .build(); seriesOfActions.perform();
		 */
	}

//***********************************************************************************************************************
	/**
	 * Espera hasta que el [element] sea clickable, retornando el WebElement que lo
	 * es.
	 * 
	 * @param secondsWait : Segundos máximo de espera, si viene <= 0 toma un valor
	 *                    de 10 por defecto.
	 */
	public WebElement waitClickable(WebElement element, int secondsWait) {

		int maximoEspera = (secondsWait <= 0) ? 10 : secondsWait;
		WebDriverWait wait = new WebDriverWait(this.driver, maximoEspera); // Duration.ofSeconds(maximoEspera));
		return wait.until(ExpectedConditions.elementToBeClickable(element));
	}

//***********************************************************************************************************************
	/**
	 * Ubica el mouse sobre el elemento correspondiente a [locator]
	 */
	public void mouseOver(By locator) {

		this.mouseOver(this.element(locator));
	}

//***********************************************************************************************************************
	/**
	 * Ubica el mouse sobre el elemento [element]
	 */
	public void mouseOver(WebElement element) {

		if (action == null)
			action = new Actions(this.driver);
		this.action.moveToElement(element).perform();
	}

//***********************************************************************************************************************
	/**
	 * Ubica el mouse sobre el elemento con un offSet tanto en "X" como en "Y".
	 * Tener en cuenta que el mouse posiciona en el centro del elemento.
	 * 
	 * @param element
	 * @param offsetX
	 * @param offsetY
	 * @author PYHOCAST (Yhon L. Castañeda)
	 */
	public void mouseOver(WebElement element, int offSetX, int offSetY) {

		if (action == null)
			action = new Actions(this.driver);
		this.action.moveToElement(element, offSetX, offSetY).perform();
	}

//***********************************************************************************************************************
	/**
	 * Ubica el mouse sobre las coordenadas "offSetX" y "offSetY".
	 * 
	 * @author smzealo (Sandra Zea)
	 */
	public void mouseOver(int offSetX, int offSetY) {

		if (action == null)
			action = new Actions(this.driver);
		this.action.moveByOffset(offSetX, offSetY).perform();
	}

//***********************************************************************************************************************
	/**
	 * Da click en la posición en donde se encuentre en este momento el mouse.<br>
	 * Se sugiere usar [mouseOver] para posicionar el mouse en el punto donde se
	 * quiere, para después dar Click.
	 */
	public void mouseClick() {

		if (action == null)
			action = new Actions(this.driver);
		action.click().build().perform();
	}

//***********************************************************************************************************************
	/**
	 * Da click en la mitad del elemento dado. Similar :
	 * Actions.moveToElement(element).click()
	 */
	public void mouseClick(WebElement element) {

		if (action == null)
			action = new Actions(this.driver);
		action.click(element).build().perform();
	}

//***********************************************************************************************************************
	public void unFocus(By locator) {

		this.unFocus(this.element(locator));
	}

	public void unFocus(WebElement element) {

		jse.executeScript("arguments[0].blur()", element);
	}

//***********************************************************************************************************************
	/**
	 * Limpia la caja de texto del elemento identificado con [locator].
	 */
	public void clearInputbox(By locator) {

		this.clearInputbox(this.element(locator));
	}

	/**
	 * Limpia la caja de texto del [elemento].
	 */
	public void clearInputbox(WebElement element) {

		element.clear(); // LO LIMPIA
	}

//***********************************************************************************************************************
	/**
	 * Escribe en el elemento identificado con [locator] el valor [inputText], si el
	 * elemento contiene información HACE el borrado de lo que contiene.
	 */
	public void write(By locator, String inputText) {

		this.write(this.element(locator), inputText);
	}

	/**
	 * Escribe en el [element] el valor [inputText], si el elemento contiene
	 * información HACE el borrado de lo que contiene.
	 */
	public void write(WebElement element, String inputText) {

		this.clearInputbox(element);
		element.sendKeys(inputText);
		if (this.navegador.equals(BasePageWeb.EXPLORER) || this.navegador.equals(BasePageWeb.EDGE))
			this.unFocus(element);
	}

	public void writeNoFocus(WebElement element, String inputText) {

		this.clearInputbox(element);
		element.sendKeys(inputText);
	}

//***********************************************************************************************************************
	/**
	 * Escribe en el elemento identificado con [locator] el valor [inputText], si el
	 * elemento contiene información NO borra lo que contiene.
	 */
	public void writeNoClear(By locator, String inputText) {

		this.writeNoClear(this.element(locator), inputText);
	}

	/**
	 * Escribe en el [element] el valor [inputText], si el elemento contiene
	 * información NO borra lo que contiene.
	 */
	public void writeNoClear(WebElement element, String inputText) {

		element.sendKeys(inputText);
		if (this.navegador.equals(BasePageWeb.EXPLORER) || this.navegador.equals(BasePageWeb.EDGE))
			this.unFocus(element);
	}

	public void writeNoClearNoFocus(WebElement element, String inputText) {

		element.sendKeys(inputText);
		if (this.navegador.equals(BasePageWeb.EXPLORER) || this.navegador.equals(BasePageWeb.EDGE))
			;
		// this.unFocus(element);
	}

//***********************************************************************************************************************
	/**
	 * Hace el submit correspondiente al elemento identificado con [locator].
	 */
	public void submit(By locator) {

		this.submit(this.element(locator));
	}

	/**
	 * Hace el submit correspondiente al [elemento].
	 */
	public void submit(WebElement element) {

		element.submit();
	}

//***********************************************************************************************************************
	/**
	 * Da click en el elemento identificado con [locator].<br>
	 * Si el elemento NO está visible, este método garantiza su visibilidad para
	 * darle el click.
	 */
	public void click(By locator) {

		this.click(this.element(locator));
	}

	/**
	 * Da click en el [elemento].<br>
	 * Para el caso de navegador [IEXPLORE] se hace de una manera diferente.<br>
	 * Si el elemento NO está visible, este método garantiza su visibilidad para
	 * darle el click.
	 */
	public void click(WebElement element) {

		try {
			if (this.navegador.equals(BasePageWeb.EXPLORER) || this.navegador.equals(BasePageWeb.EDGE))
				jse.executeScript("arguments[0].click()", element);
			else
				element.click();
			rumboScroll = "true"; // PARA QUE EN LOS SIGUIENTES CLICK EMPIECE MOVIMIENTO HACIA ABAJO SI NO
									// ENCUENTRA EL ELEMENTO
		} catch (ElementClickInterceptedException e) {
			// HACE SCROLL HASTA QUE EL ELEMENTO SEA ENCONTRADO: A [scrollIntoView] SE LE
			// PASA [] o [true] SI EL
			// ELEMENTO AL QUE SE DESPLAZA ESTÁ DEBAJO DE DONDE SE ENCUENTRA ACTUALMENTE,
			// [false] SI ESTÁ POR ENCIMA
			jse.executeScript("arguments[0].scrollIntoView(" + rumboScroll + ");", element);
			rumboScroll = rumboScroll.equals("true") ? "false" : "true";
			this.click(element);
		}
	}

//***********************************************************************************************************************
	/**
	 * Da click en el elemento identificado con [locator].<br>
	 * Si el elemento NO está visible, este método garantiza su visibilidad para
	 * darle el click.
	 */
	public void doubleClick(By locator) {

		WebElement element = this.element(locator);
		if (element != null)
			this.doubleClick(element);
	}

	/**
	 * Da click en el [elemento].<br>
	 * Para el caso de navegador [IEXPLORE] se hace de una manera diferente.<br>
	 * Si el elemento NO está visible, este método garantiza su visibilidad para
	 * darle el click.
	 */
	public void doubleClick(WebElement element) {

		try {
			if (this.action == null)
				action = new Actions(this.driver);
			this.action.doubleClick(element).perform();
			// this.action.doubleClick(element).build().perform();
		} catch (ElementClickInterceptedException e) {
			// HACE SCROLL HASTA QUE EL ELEMENTO SEA ENCONTRADO: A [scrollIntoView] SE LE
			// PASA [] o [true] SI EL
			// ELEMENTO AL QUE SE DESPLAZA ESTÁ DEBAJO DE DONDE SE ENCUENTRA ACTUALMENTE,
			// [false] SI ESTÁ POR ENCIMA
			jse.executeScript("arguments[0].scrollIntoView();", element);
			this.doubleClick(element);
		}
	}

//***********************************************************************************************************************
	/**
	 * Deja visible el elemento identificado con el [locator] en el WebPage.
	 */
	public void moveToElement(By locator) {

		this.moveToElement(this.element(locator));
	}

	/**
	 * Deja visible el elemento [element] en el WebPage.
	 */
	public void moveToElement(WebElement element) {

		jse.executeScript("arguments[0].scrollIntoView();", element);
	}

//***********************************************************************************************************************
	/**
	 * Da click en el elemento identificado con [locator].<br>
	 * Si el elemento NO está visible, se genera la respectiva Exception.
	 */
	public void clickNoScrollIntoView(By locator) {

		this.clickNoScrollIntoView(this.element(locator));
	}

	/**
	 * Da click en el [elemento].<br>
	 * Para el caso de navegador [IEXPLORE] se hace de una manera diferente.<br>
	 * Si el elemento NO está visible, se genera la respectiva Exception.
	 */
	public void clickNoScrollIntoView(WebElement element) {

		if (this.navegador.equals(BasePageWeb.EXPLORER) || this.navegador.equals(BasePageWeb.EDGE))
			jse.executeScript("arguments[0].click()", element);
		else
			element.click();
	}

//***********************************************************************************************************************
	/**
	 * Da click en el botón cuyo value es [valueButton].<br>
	 * Si el elemento NO está visible, este método garantiza su visibilidad para
	 * darle el click.
	 */
	public void clickButton(String valueButton) throws Exception {

		this.clickButton(valueButton, 0);
	}

	/**
	 * Da click en el botón cuya propiedad 'value' es [valueButton] y el índice
	 * corresponde a [indexButton].<br>
	 * Si el elemento NO está visible, este método garantiza su visibilidad para
	 * darle el click.
	 */
	public void clickButton(String valueButton, int indexButton) throws Exception {

		String xpath = "//input[@type='submit'][@value='" + valueButton + "']";
		List<WebElement> elements = this.findElements(By.xpath(xpath));
		int totalElements = elements.size();
		if (totalElements == 0) { // EN CASO QUE NO SE ENCUENTRE CON [type='submit'] SE BUSCA CON [type='button']
			xpath = "//input[@type='button'][@value='" + valueButton + "']";
			elements = this.findElements(By.xpath(xpath));
			totalElements = elements.size();
		}
//-----------------------------------------------------------------------------------------------------------------------
		boolean existeButton = false;
		if (indexButton < totalElements) { // SI HAY SUFICIENTES BUTTONS PARA ENCONTRAR EL QUE SE QUIERE CLICKEAR
			int index = 0;
			// SE RECORREN TODOS, PORQUE PUEDE QUE ESTÁN PERO NO SEAN VISIBLES
			for (int posLista = 0; posLista < totalElements; posLista++) {
				if (this.isDisplayed(elements.get(posLista))) {
					existeButton = (index == indexButton);
					// ENCONTRÓ EL BUTTON VISIBLE QUE CORRESPONDE AL INDEX INDICADO: SE LE DA CLICK
					// Y TERMINA EL CICLO
					if (existeButton) {
						this.click(elements.get(posLista));
						break;
					}
					index++; // PARA EL SIGUIENTE BUTTON, PORQUE EL ANTERIOR NO CORRESPONDÍA CON EL INDEX
								// REQUERIDO
				}
			}
		}
//-----------------------------------------------------------------------------------------------------------------------
		if (!existeButton) // NO SE DIO CLICK A NINGÚN BUTTON
			throw new NoSuchElementException(
					"BasePageWeb ERROR -- No se encuentra el button [" + valueButton + " - " + indexButton + "]");
	}

//***********************************************************************************************************************
	/**
	 * Chequea el CheckBox identificado con [locator].
	 */
	public void checkCheckBox(By locator) {

		this.checkCheckBox(this.element(locator));
	}

	/**
	 * Chequea el CheckBox identificado como [element].
	 */
	public void checkCheckBox(WebElement element) {

		if (!this.isSelected(element))
			this.click(element);
	}

//***********************************************************************************************************************
	/**
	 * Quita el chequeo del CheckBox identificado con [locator].
	 */
	public void uncheckCheckBox(By locator) {

		this.uncheckCheckBox(this.element(locator));
	}

	/**
	 * Quita el chequeo del CheckBox identificado como [element].
	 */
	public void uncheckCheckBox(WebElement element) {

		if (this.isSelected(element))
			this.click(element);
	}

//***********************************************************************************************************************
	/**
	 * Del radioButton identificado con [locatorRadioGroup], marca el
	 * correspondiente al [index] ingresado.<br>
	 * El index empieza en cero (0): Se sugiere que el locatorRadioGroup contenga
	 * todos los RadioButton.
	 */
	public void selectRadioButtonByIndex(By locatorRadioGroup, int index) {

		List<WebElement> radioButtons = this.findElements(locatorRadioGroup);
		int totalRBs = radioButtons.size();
		if (totalRBs == 0)
			throw new NoSuchElementException("Locator not found");
		else if (index > totalRBs - 1)
			throw new NoSuchElementException("Radio button with index [" + index + "] not found");
		else
			this.click(radioButtons.get(index));
	}

	/**
	 * Del radioButton identificado con [locatorRadioGroup], marca el
	 * correspondiente al [value] ingresado.<br>
	 * El index empieza en cero (0): Se sugiere que el locatorRadioGroup contenga
	 * todos los RadioButton.
	 */
	public void selectRadioButtonByValue(By locatorRadioGroup, String value) {

		List<WebElement> radioButtons = this.findElements(locatorRadioGroup);
		int totalRBs = radioButtons.size();
		boolean encontrado = false;
		String textoRadio = "";
		if (totalRBs == 0)
			throw new NoSuchElementException("Locator not found");
		else {
			for (WebElement radio : radioButtons) {
				textoRadio = this.getText(radio).trim(); // Quita los espacios iniciales y finales
				if (textoRadio.equalsIgnoreCase(value)) {
					this.click(radio);
					encontrado = true;
				}
			}
		}
		if (!encontrado)
			throw new NoSuchElementException("Radio button with value [" + value + "] not found");
	}

//***********************************************************************************************************************
	/**
	 * Selecciona el item cuyo [index] corresponde al ingresado, de la lista
	 * identificada con [locator].<br>
	 * Forma de seleccionar con objeto "Select": HTML <select> y <option>
	 */
	public void selectListItemByIndex(By locator, int index) {

		this.selectListItemByIndex(this.element(locator), index);
	}

	/**
	 * Selecciona el item cuyo [index] corresponde al ingresado, de la lista
	 * identificada como [element], la cual es un "select".<br>
	 * Forma de seleccionar con objeto "Select": HTML <select> y <option>
	 */
	public void selectListItemByIndex(WebElement element, int index) {

		Select selectList = new Select(element);
		selectList.selectByIndex(index);
	}

	/**
	 * Da click en el ítem identificado como [element], luego selecciona el item
	 * cuyo [index] corresponde al ingresado de la lista identificada como
	 * [elementsList], la cual es un "ul".<br>
	 * Forma de seleccionar con objeto "Ul": HTML
	 * <ul>
	 * <li>Funciona solo si es la única lista desplegable que se selecciona durante
	 * el recorrido del Page.
	 */
	public String selectListItemByIndex(WebElement element, List<WebElement> elementsList, int index) {

		String messageReturn = "";
		element.click();
		try {
			elementsList.get(index).click();
		} catch (IndexOutOfBoundsException e) {
			messageReturn = "Elemento [" + index + "] NO encontrado.";
		}
		return messageReturn;
	}

	/**
	 * Da click en el ítem identificado como [element], luego selecciona el item
	 * cuyo [valor] corresponda al ingresado de la lista identificada como
	 * [elementsList], la cual es un "ul".<br>
	 * Forma de seleccionar con objeto "Ul": HTML
	 * <ul>
	 * <li>Funciona solo si es la única lista desplegable que se selecciona durante
	 * el recorrido del Page.
	 */
	public String selectListItemByIndex(WebElement element, List<WebElement> elementsList, String valor) {

		String messageReturn = "";
		boolean datoEncontrado = false;
		element.click();
		for (WebElement newListElements : elementsList) {
			if (newListElements.getText().equals(valor)) {
				newListElements.click();
				datoEncontrado = true;
				break;
			}
		}
		if (!datoEncontrado) {
			messageReturn = "Elemento [" + valor + "] NO encontrado.";
		}
		return messageReturn;
	}

//***********************************************************************************************************************
	/**
	 * Selecciona el [item] que corresponde de forma exacta, de la lista
	 * identificada con [locator], la cual es un "select".
	 * 
	 * @return Mensaje de error en caso que no haya encontrado el elemento.<br>
	 *         El retorno es [null] si se pudo seleccionar.
	 */
	public String selectListItemExacto(By locator, String item) {

		return this.selectListItemExacto(this.element(locator), item);
	}

	/**
	 * Selecciona el [item] que corresponde de forma exacta, de la lista
	 * identificada como [element], la cual es un "select"
	 * 
	 * @return Mensaje de error en caso que no haya encontrado el elemento. El
	 *         retorno es [null] si se pudo seleccionar.
	 */
	public String selectListItemExacto(WebElement element, String item) {

		Select selectList = new Select(element);
		String valActual = this.getItemSelected(element);
		String msgRetorno = null; // VALOR POR DEFECTO, ASUME QUE SE ENCUENTRA
		if (valActual.equals(item)) // YA ESTÁ SELECCIONADO
			return msgRetorno;
		try {
			selectList.selectByVisibleText(item);
		} catch (NoSuchElementException e) {
			msgRetorno = "Elemento [" + item + "] NO presentado.";
		}
		return msgRetorno;
	}

//***********************************************************************************************************************
	/**
	 * Selecciona cualquiera de los elementos de la lista existente [elementsLista]
	 * Tiene que ser clickable.<br>
	 * 
	 * @author ldsalaza
	 */
	public void clickElementRandom(List<WebElement> elementsLista) {

		do {
			Util.wait(1); // PARA QUE ESPERE LOS ELEMENTOS DE LA LISTA
		} while (elementsLista.size() == 0);
		int random = Util.enteroRandom(0, elementsLista.size() - 1);
		this.click(elementsLista.get(random));
		Util.wait(1);
	}

//***********************************************************************************************************************
	/**
	 * Selecciona de forma aletoria uno de los elementos existentes en el elemento
	 * identificado con [locator], [with1stItem] indica si se debe incluir en la
	 * aleatoriedad el primer elemento de la lista, aveces es un item que no debería
	 * ser seleccionado.
	 */
	public void selectListItemRandom(By locator, boolean with1stItem) {

		this.selectListItemRandom(this.element(locator), with1stItem);
	}

	/**
	 * Selecciona de forma aletoria uno de los elementos existentes en el WebElement
	 * [element], la cual es un "select", [with1stItem] indica si se debe incluir en
	 * la aleatoriedad el primer elemento de la lista, aveces es un item que no
	 * debería ser seleccionado.
	 */
	public void selectListItemRandom(WebElement element, boolean with1stItem) {

		Select selectList = new Select(element);
		List<WebElement> options = selectList.getOptions();
		int firstIndex = 1;
		if (with1stItem)
			firstIndex = 0;
		int indexRandom = Util.enteroRandom(firstIndex, options.size() - 1);
		this.selectListItemByIndex(element, indexRandom);
	}

//***********************************************************************************************************************
	/**
	 * Selecciona de forma aleatoria uno de los elementos existentes de una lista
	 * que NO es un "select".
	 * 
	 * @param element       - AL dar click despliega los elementos .
	 * @param elementsLista - Elemento de lista de opciones.
	 * @desdePrimerElemento - Si esta en TRUE - Tiene en cuenta la primera posicion
	 *                      de la lista de opciones FALSE - No la tiene en cuenta.
	 * @author ldsalaza
	 */
	public void selectListItemRandom(WebElement element, List<WebElement> elementsLista, boolean desdePrimerElemento) {

		this.click(element); // PARA DESPLEGAR LA LISTA DE OPCIONES
		do {
			Util.wait(1); // PARA QUE ESPERE LISTA DE OPCIONES
		} while (elementsLista.size() == 0);
		int inicio = 1;
		if (desdePrimerElemento)
			inicio = 0;
		int random = Util.enteroRandom(inicio, elementsLista.size() - 1); // O NO SE TOMA PORQUE ES "-----------"
		this.click(elementsLista.get(random));
		Util.wait(1); // Wait PARA ESPERAR SELECCIÓN DEL DATO
	}

//***********************************************************************************************************************
	/**
	 * Selecciona de la lista que se encuentra en el campo identificado por
	 * [locator] el [item]. La búsqueda del elemento NO es case sensitive NI tiene
	 * en cuenta acentos, y selecciona el elemento si está contenido.
	 * 
	 * @param locator - Debe ser un [select]
	 * @param item    - Elemento a seleccionar
	 * @return Mensaje de error en caso que no haya encontrado el elemento.<br>
	 *         El retorno es [null] si se pudo seleccionar.
	 */
	public String selectListItem(By locator, String item) {

		return selectListItem(this.element(locator), item);
	}

	/**
	 * Selecciona de la lista que se encuentra en el campo identificado por
	 * [element] el [item]. La búsqueda del elemento NO es case sensitive NI tiene
	 * en cuenta acentos, y selecciona el elemento si está contenido.
	 * 
	 * @param element - Debe ser un [select]
	 * @param item    - Elemento a seleccionar
	 * @return Mensaje de error en caso que no haya encontrado el elemento. El
	 *         retorno es [null] si se pudo seleccionar.
	 */
	public String selectListItem(WebElement element, String item) {

		Select selectList = new Select(element);
		String valActual = this.getItemSelected(element);
		if (Util.equalsIgnoreCaseAndAccents(valActual, item))
			return null; // YA ESTÁ SELECCIONADO
		else if (!valActual.isEmpty() && (Util.containsIgnoreCaseAndAccents(valActual, item)
				|| Util.containsIgnoreCaseAndAccents(item, valActual))) {
			Reporter.writeOnlyConsole("Valor ya seleccionado [" + valActual + "] - no es igual a [" + item
					+ "] pero se deja por estar contenido.");
			return null; // YA ESTÁ SELECCIONADO
		}
		List<WebElement> options = selectList.getOptions();
		return this.getItemInOptions(options, item);
	}

//***********************************************************************************************************************
	/**
	 * Retorna en un String[] los elementos existentes en la lista identificada con
	 * [locator].
	 */
	public String[] getListItems(By locator) {

		return getListItems(this.element(locator));
	}

	/**
	 * Retorna en un String[] los elementos existentes en la lista identificada como
	 * [element], la cual es un "select".
	 */
	public String[] getListItems(WebElement element) {

		Select selectList = new Select(element);
		List<WebElement> options = selectList.getOptions();
		String[] items = new String[options.size()];
		int posArr = 0;
		for (WebElement option : options) {
			items[posArr++] = this.getText(option).trim();
		}
		return items;
	}

//***********************************************************************************************************************
	/**
	 * Selecciona de la lista que se encuentra en el campo identificado por
	 * [locator] el item que contenga los [items]. La búsqueda del elemento NO es
	 * case sensitive NI tiene en cuenta acentos.
	 * 
	 * @param locator - Debe ser un [select]
	 * @param items   - Datos a buscar en cada item de la lista
	 * @return Mensaje de error en caso que no haya encontrado el elemento.<br>
	 *         El retorno es [null] si se pudo seleccionar.
	 */
	public String selectListContainsItems(By locator, String... items) {

		return selectListContainsItems(this.element(locator), items);
	}

	/**
	 * Selecciona de la lista que se encuentra en el campo identificado por
	 * [element], el item que contenga los [items].<br>
	 * La búsqueda del elemento NO es case sensitive NI tiene en cuenta acentos.
	 * 
	 * @param element - Debe ser un [select]
	 * @param items   - Datos a buscar en cada item de la lista
	 * @return Mensaje de error en caso que no haya encontrado el elemento.<br>
	 *         El retorno es [null] si se pudo seleccionar.
	 */
	public String selectListContainsItems(WebElement element, String... items) {

		if (items.length == 1)
			return this.selectListItem(element, items[0]);
		Select selectList = new Select(element);
		String valActual = this.getItemSelected(element);
		boolean esValActual = true;
		for (String item : items) {
			esValActual = esValActual && Util.containsIgnoreCaseAndAccents(valActual, item);
		}
		if (esValActual)
			return null; // YA ESTÁ SELECCIONADO
		List<WebElement> options = selectList.getOptions();
		return this.getItemInOptions(options, items);
	}

//***********************************************************************************************************************
	/**
	 * Selecciona de la lista predictiva que se encuentra en el campo identificado
	 * por [locator] el primer elemento que coincida con el ingreso de [item].<br>
	 * Si ningún elemento coincide se retorna un mensaje que lo indica, en caso
	 * contrario el retorno es [null].
	 */
	public String selectPredictiveListItem(By locator, String item) {

		return this.selectPredictiveListItem(this.element(locator), item);
	}

	/**
	 * Selecciona de la lista predictiva que se encuentra en el campo identificado
	 * por [element] el primer elemento que coincida con el ingreso de [item].<br>
	 * Si ningún elemento coincide se retorna un mensaje que lo indica, en caso
	 * contrario el retorno es [null].
	 */
	public String selectPredictiveListItem(WebElement element, String item) {

		String msgError = null;
		if (element.getAttribute("value").equals(item))
			return msgError; // YA ESTÁ SELECCIONADO EL [item]
		element.click(); // NO SIRVE EL [write] DIRECTO, SE DEBE DAR PRIMERO CLICK
		element.sendKeys(item);
		Util.wait(1); // PARA QUE ESPERE COINCIDENCIAS
		element.sendKeys(Keys.TAB);
		Util.wait(1); // Wait para esperar que se active casilla
		if (element.getAttribute("value").isEmpty())
			msgError = "Elemento [" + item + "] NO presentado.";
		return msgError;
	}

	/**
	 * Selecciona de la lista predictiva que se encuentra en el campo identificado
	 * por [element] el primer elemento que coincida con el ingreso de [item].<br>
	 * Si ningún elemento coincide se retorna un mensaje que lo indica, en caso
	 * contrario el retorno es [null].
	 */
	public String selectPredictiveListRandom(WebElement element, String inicioItem, int random) {

		element.click(); // NO SIRVE EL [write] DIRECTO, SE DEBE DAR PRIMERO CLICK
		element.sendKeys(inicioItem);
		Util.wait(1); // PARA QUE ESPERE COINCIDENCIAS
		for (int i = 1; i < random; i++) {
			element.sendKeys(Keys.DOWN);
		}
		element.sendKeys(Keys.ENTER);
		Util.wait(1); // Wait para esperar que se active casilla
		String msgError = null;
		if (element.getAttribute("value").isEmpty())
			msgError = "Elemento random con inicio [" + inicioItem + "] NO presentado.";
		return msgError;
	}

//***********************************************************************************************************************
	public void sendKey(WebElement element, CharSequence key) {

		element.sendKeys(key);
	}

//***********************************************************************************************************************
	/**
	 * Seleccionar los [items] indicados, de la lista identificada con [locator].
	 */
	public void selectMultipleItems(By locator, String... items) {

		this.selectMultipleItems(this.element(locator), items);
	}

	public void selectMultipleItems(WebElement element, String... items) {

		Select selectList = new Select(element);
		if (!selectList.isMultiple())
			throw new NoSuchElementException("Select Element is not Multiple");
		else {
			for (String item : items) {
				selectList.selectByVisibleText(item);
			}
		}
	}

//***********************************************************************************************************************
	/**
	 * Seleccionar los items correspondientes a los [indexes] indicados, de la lista
	 * identificada con [locator].
	 */
	public void selectMultipleItems(By locator, int... indexes) {

		this.selectMultipleItems(this.element(locator), indexes);
	}

	/**
	 * Seleccionar los items correspondientes a los [indexes] indicados, de la lista
	 * identificada como [element].
	 */
	public void selectMultipleItems(WebElement element, int... indexes) {

		Select selectList = new Select(element);
		if (!selectList.isMultiple())
			throw new NoSuchElementException("Select Element is not Multiple");
		else {
			for (int index : indexes) {
				selectList.deselectByIndex(index);
			}
		}
	}

//***********************************************************************************************************************
	/**
	 * Ejemplo sacado de >> https://react-bootstrap.github.io/components/dropdowns/
	 * <br>
	 * Con HTML diferente a <select> y <option>
	 */
	public String selectListItem(By locatorDropDown, By locatorOptions, String item) {

		click(locatorDropDown);
		List<WebElement> options;
		do { // Espera mientras no se carguen las opciones
			this.waitInPage(1);
			options = this.findElements(locatorOptions);
		} while (options.size() == 0);
		return this.getItemInOptions(options, item);
	}

//***********************************************************************************************************************
	/**
	 * Método usado por los métodos [selectListItem]
	 */
	private String getItemInOptions(List<WebElement> options, String item) {

		String msgRetorno = "Elemento [" + item + "] NO presentado, tampoco hay un valor parecido."; // DEFAULT
		String itemBuscar = item.trim(); // Por si tiene espacios, se le quita.
		String itemInList = "";
		boolean itemEncontrado;
		for (WebElement option : options) {
			itemInList = this.getText(option).trim(); // Se le quitan los espacios por si tiene.
			itemEncontrado = Util.containsIgnoreCaseAndAccents(itemInList, itemBuscar)
					|| Util.containsIgnoreCaseAndAccents(itemBuscar, itemInList);
			if (itemEncontrado) {
				this.click(option);
				msgRetorno = null;
				break;
			}
		}
		return msgRetorno;
	}

//***********************************************************************************************************************
	/**
	 * Método usado por los métodos [selectListContainsItems]
	 */
	private String getItemInOptions(List<WebElement> options, String[] item) {

		String msgRetorno = "Elemento que contenga [" + Util.arrayToString(item, "|") + "] NO presentado."; // DEFAULT
		String itemBuscar;
		String itemInList = "";
		boolean itemEncontrado;
		for (WebElement option : options) {
			itemInList = this.getText(option).trim(); // Se le quitan los espacios por si tiene.
			itemEncontrado = true;
			for (int i = 0; i < item.length; i++) {
				itemBuscar = item[i].trim(); // Por si tiene espacios, se le quita
				itemEncontrado = itemEncontrado && Util.containsIgnoreCaseAndAccents(itemInList, itemBuscar);
			}
			if (itemEncontrado) {
				this.click(option);
				msgRetorno = null;
				break;
			}
		}
		return msgRetorno;
	}

//***********************************************************************************************************************
	/**
	 * Retorna el dato existente en la celda del elemento identificado con [locator]
	 * de la [fila] y [columna] indicados.
	 */
	public String getCellValue(By locator, int fila, int columna) {

		return this.getCellValue(this.element(locator), fila, columna);
	}

	/**
	 * Retorna el dato existente en la celda del elemento [elementWebTable] de la
	 * [fila] y [columna] indicados.
	 */
	public String getCellValue(WebElement elementWebTable, int fila, int columna) {

		By locCell = By.xpath(".//tr[" + fila + "]/td[" + columna + "]");
		return this.getText(elementWebTable.findElement(locCell));
	}

//***********************************************************************************************************************
	/**
	 * Retorna el número de filas que tiene el elemento identificado con [locator].
	 */
	public int getRowCount(By locator) {

		return this.getRowCount(this.element(locator));
	}

	/**
	 * Retorna el número de filas que tiene el elemento [elementWebTable].
	 */
	public int getRowCount(WebElement elementWebTable) {

		return this.findElements(elementWebTable, By.tagName("tr")).size();
	}

//***********************************************************************************************************************
	/**
	 * Retorna el número de columnas que tiene el elemento identificado con
	 * [locator] en la [fila] indicada.<br>
	 * <b>OJO: </b>La fila debe contener columnas con tag TD de lo contrario el
	 * retorno será 0.
	 */
	public int getColumnCount(By locator, int fila) {

		return this.getColumnCount(this.element(locator), fila);
	}

	/**
	 * Retorna el número de columnas que tiene el elemento [elementWebTable] en la
	 * [fila] indicada.<br>
	 * <b>OJO: </b>La fila debe contener columnas con tag TD de lo contrario el
	 * retorno será 0.
	 */
	public int getColumnCount(WebElement elementWebTable, int fila) {

		By locCols = By.xpath(".//tr[" + fila + "]/td");
		// DONDE HAYAN MÁS TABLAS
		List<WebElement> elems = elementWebTable.findElements(locCols);
		return elems.size(); // @ZEA OJO aveces toca restar revisar - 1;
	}

//***********************************************************************************************************************
	/**
	 * Retorna el número de columnas que tiene el elemento identificado con
	 * [locator] en la [filaHeader] indicada.<br>
	 * <b>OJO: </b>La fila debe contener columnas con tag TH de lo contrario el
	 * retorno será 0.
	 */
	public int getColumnCountHeader(By locator, int filaHeader) {

		return this.getColumnCount(this.element(locator), filaHeader);
	}

	/**
	 * Retorna el número de columnas que tiene el elemento [elementWebTable] en la
	 * [filaHeader] indicada.<br>
	 * <b>OJO: </b>La fila debe contener columnas con tag TH de lo contrario el
	 * retorno será 0.
	 */
	public int getColumnCountHeader(WebElement elementWebTable, int filaHeader) {

		By locCols = By.xpath(".//tr[" + filaHeader + "]/th");
		// DONDE HAYAN MÁS TABLAS
		List<WebElement> elems = elementWebTable.findElements(locCols);
		return elems.size() - 1;
	}

//***********************************************************************************************************************
	/**
	 * Retorna el número de la fila existente en la tabla reconocida con el
	 * [locator] en donde se encuentren los valores [valuesBuscar] en las
	 * respectivas columnas [columnasBuscar]. La comparación se hace exacta
	 * ignorando tildes y Case, a menos que la columna se encuentre en
	 * [colsContain], en estas columnas la comparación se hace si el dato en la
	 * página "contiene" el value enviado.
	 * 
	 * @return 0 - En caso de no encontrar la fila que contenga el valor buscado. En
	 *         caso contrario retorna la fila.
	 */
	public int getRowWithData(By locator, int filaInicio, int[] columnasBuscar, String[] valuesBuscar,
			int[] colsContain) {

		return this.getRowWithData(this.element(locator), filaInicio, columnasBuscar, valuesBuscar, colsContain);
	}

	/**
	 * Retorna el número de la fila existente en la tabla reconocida con el
	 * WebElement [elementWebTable] en donde se encuentren los valores
	 * [valuesBuscar] en las respectivas columnas [columnasBuscar]. La comparación
	 * se hace exacta ignorando tildes y Case, a menos que la columna se encuentre
	 * en [colsContain], en estas columnas la comparación se hace si el dato en la
	 * página "contiene" el value enviado.
	 * 
	 * @return 0 - En caso de no encontrar la fila que contenga el valor buscado. En
	 *         caso contrario retorna la fila.
	 */
	public int getRowWithData(WebElement elementWebTable, int filaInicio, int[] arrColsBuscar, String[] arrValuesBuscar,
			int[] colsContain) {

		int columna, numeroFilas = this.getRowCount(elementWebTable);
		String valueBuscar;
		int totalDatos = arrColsBuscar.length, filaRetorno = 0;
		boolean isFila;
		for (int fila = filaInicio; fila <= numeroFilas; fila++) {
			isFila = true;
			for (int col = 0; col < totalDatos; col++) {
				columna = arrColsBuscar[col];
				valueBuscar = arrValuesBuscar[col];
				String textoCelda = this.getCellValue(elementWebTable, fila, columna).trim();
				if (Util.itemInArray(columna, colsContain))
					isFila = isFila && (Util.containsIgnoreCaseAndAccents(textoCelda, valueBuscar)
							|| Util.containsIgnoreCaseAndAccents(valueBuscar, textoCelda));
				else
					isFila = isFila && Util.equalsIgnoreCaseAndAccents(textoCelda, valueBuscar);
				if (!isFila)
					break; // TERMINA EL CICLO INTERNO
			}
			if (isFila) {
				filaRetorno = fila;
				break; // TERMINA EL CICLO
			}
		}
		return filaRetorno;
	}

//***********************************************************************************************************************
	/**
	 * Este método sólo funciona si el elemento a localizar en la página está de la
	 * forma <input type="file">
	 * 
	 * @param locator    : elemento a buscar en la página web.
	 * @param nbFilePath : Ruta absoluta con ruta y extensión del arcivo a cargar.
	 */
	public void uploadFile(By locatorInputFile, String nbFilePath, By locatorButtonUpload) {

		this.write(locatorInputFile, nbFilePath);
		this.click(locatorButtonUpload);
	}

//***********************************************************************************************************************
	/**
	 * Este métood se enecarga de abrir la ventana de windows a través del botón
	 * cuyo localizador corresponde a [locatorButtOpenUploadWind], por robot ingresa
	 * la ruta del archivo a cargar [nbFilePath] da el ENTER y si
	 * [locatorButtonUpload] no es [null] da click en dicho botón.
	 */
	public void uploadFileOpeningWin(By locatorButtOpenUploadWind, String nbFilePath, By locatorButtonUpload) {

		this.uploadFileOpeningWin(this.element(locatorButtOpenUploadWind), nbFilePath, locatorButtonUpload);
	}

//***********************************************************************************************************************
	/**
	 * Este método se enecarga de abrir la ventana de windows a través del botón
	 * [elementButtOpenUploadWind], por robot ingresa la ruta del archivo a cargar
	 * [nbFilePath] da el ENTER y si [locatorButtonUpload] no es [null] da click en
	 * dicho botón.
	 */
	public void uploadFileOpeningWin(WebElement elementButtOpenUploadWind, String nbFilePath, By locatorButtonUpload) {

		// Put path to your file in a clipboard
		StringSelection ss = new StringSelection(nbFilePath);
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss, null);
		// Imitate mouse events like ENTER, CTRL+C, CTRL+V
		try {
			// Open upload window
			this.click(elementButtOpenUploadWind);
			Util.wait(3);
			Robot robot = new Robot();
			robot.delay(250);
			robot.keyPress(KeyEvent.VK_ENTER);
			robot.keyRelease(KeyEvent.VK_ENTER);
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_CONTROL);
			Evidence.saveDesktop("Carga Archivo");
			Util.wait(4);
			robot.keyPress(KeyEvent.VK_ENTER);
			robot.delay(50);
			robot.keyRelease(KeyEvent.VK_ENTER);
			if (locatorButtonUpload != null)
				this.click(locatorButtonUpload);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

//***********************************************************************************************************************
	/**
	 * Método que retorna el primer frame [iframe / frame].<br>
	 * Primero se mueve al DefaultFrame, para saber cuál es el primer frame.
	 */
	public WebElement getFirstFrame() {

		this.changeToDefaultFrame();
		List<WebElement> framesElem;
		do {
			framesElem = this.findElements(By.xpath("//iframe"));
			if (framesElem.size() == 0)
				framesElem = this.findElements(By.xpath("//frame"));
		} while (framesElem.size() == 0);
		return framesElem.get(0);
	}

//***********************************************************************************************************************
	/**
	 * Retorna un WebElement a partir de un [locator] dado.
	 */
	public WebElement element(By locator) {

		WebElement elementRet = null;
		try {
			elementRet = this.driver.findElement(locator);
		} catch (NoSuchElementException e) {
			elementRet = null;
		}
		return elementRet;
	}

	/**
	 * Método que retorna el WebElement que cumpla con la expresión
	 * [expressionXpath], esta expresión es para buscar por locator XPATH todos los
	 * elementos que cumplen, debería haber sólo 1, pero si no hay o hay muchos
	 * retorna [null]
	 */
	public WebElement element(String expressionXpath) {

		WebElement elementRet = null;
		List<WebElement> elements = this.findElements(By.xpath(expressionXpath));
		int totalElements = elements.size();
		// SI NO HAY ELEMENTOS O HAY MUCHOS EL RETORNO ES [null]
		if (totalElements == 1)
			elementRet = elements.get(0);
		else if (totalElements > 1)
			System.err.println("BasePageWeb ERROR -- Hay varios elementos [" + expressionXpath + "]");
		return elementRet;
	}

	/**
	 * Retorna un WebElement que se encuentra dentro de otro elemento. Se cuenta con
	 * el elemnto padre [elementParent] y el hijo se identifica a partir de
	 * [locator].
	 */
	public WebElement element(WebElement elementParent, By locator) {

		WebElement elementRet = null;
		try {
			elementRet = elementParent.findElement(locator);
		} catch (NoSuchElementException e) {
			elementRet = null;
		}
		return elementRet;
	}

	/**
	 * Retorna un WebElement que se encuentra dentro de otro elemento. El elemento
	 * padre se identifica a partir de [locatorParent] y el hijo a partir de
	 * [locator].
	 */
	public WebElement element(By locatorParent, By locator) {

		WebElement elementRet = null;
		try {
			elementRet = this.element(locatorParent).findElement(locator);
		} catch (NoSuchElementException e) {
			elementRet = null;
		}
		return elementRet;
	}

	/**
	 * Retorna el [WebElement] que se encuentre presente en la página, que
	 * corresponde al tag[tagName] y que adicional cuenta con las propiedades que se
	 * reciben.<br>
	 * En caso que [tagName] sea null o vacío busca en todos los TAGs en la
	 * página.<br>
	 * Las [properties] se reciben en el formato [atributo:=valorAtributo]<br>
	 * La propiedad "index" empieza desde 0<br>
	 * Si el elemento NO existe o HAY MUCHOS retorna el objeto en null, a menos que
	 * se haya indicado el "index".
	 */
	public WebElement element(String tagName, String... properties) {

		WebElement elementRet = null;
		// ARMA EL VALOR DEL XPATH:
		String xpath = "//" + tagName;
		String addTag = "";
		if (tagName == null)
			xpath = "//*";
		else if (tagName.isEmpty())
			xpath = "//*";
		else if (tagName.equals("table"))
			addTag = "/tbody";
		int index = -1;
		for (String property : properties) {
			String[] fields = property.split(":="); // 0:atributo, 1:valor
			if (fields[0].equals("index"))
				index = Integer.valueOf(fields[1]);
			else
				xpath += "[@" + fields[0] + "='" + fields[1] + "'" + "]";
		}
		xpath += addTag;
		// BUSCA EL ELEMENTO:
		List<WebElement> elements = this.findElements(By.xpath(xpath));
		if (index == -1 && elements.size() == 1) // SE ESPERA QUE HAYA SóLO UN ELEMENTO
			elementRet = elements.get(0);
		else if (index != -1 && elements.size() > index) // SE ENVIÓ INDEX COMO PARTE DE LOS PROPERTIES
			elementRet = elements.get(index);
		return elementRet;
	}

//***********************************************************************************************************************
	/**
	 * Retorna el elemento existente en un shadow-root (open) que corresponda al
	 * [jsPath] que se recibe por parámetro.<br>
	 * No olvide el [jsPath] se obtiene dando click derecho sobre el elemento / copy
	 * / y seleccionando la opción JS<br>
	 * Si no existe el retorno es [null]
	 */
	public WebElement elementInShadow(String jsPath) {

		try {
			Object element = this.jse.executeScript("return " + jsPath);
			if (element == null)
				return null;
			else
				return (WebElement) element;
		} catch (JavascriptException e) {
			System.out.println("ENTRA A [JavascriptException] EN [elementInShadow] ****\n" + e.getMessage());
			return null;
		}
	}

//***********************************************************************************************************************
	
	/**
	 * Retorna el primer botón cuya propiedad 'value' es [valueButton].<br>
	 * Es para aquellos botones cuyo tipo sea "submit" o "button".<br>
	 * El retorno es [null] si no se encuentra el Button.
	 */
	public WebElement elementButton(String valueButton) throws Exception {

		return this.elementButton(valueButton, 0);
	}

//***********************************************************************************************************************
	/**
	 * Retorna el botón cuya propiedad 'value' es [valueButton] y el índice
	 * corresponde a [indexButton].<br>
	 * Es para aquellos botones cuyo tipo sea "submit" o "button".<br>
	 * El retorno es [null] si no se encuentra el Button.
	 */
	public WebElement elementButton(String valueButton, int indexButton) throws Exception {

		String xpath = "//input[@type='submit'][@value='" + valueButton + "']";
		List<WebElement> elements = this.findElements(By.xpath(xpath));
		int totalElements = elements.size();
		if (totalElements == 0) { // EN CASO QUE NO SE ENCUENTRE CON [type='submit'] SE BUSCA CON [type='button']
			xpath = "//input[@type='button'][@value='" + valueButton + "']";
			elements = this.findElements(By.xpath(xpath));
			totalElements = elements.size();
		}
//-----------------------------------------------------------------------------------------------------------------------
		WebElement objButtonRet = null;
		if (indexButton < totalElements) { // SI HAY SUFICIENTES BUTTONS PARA ENCONTRAR EL QUE SE REQUIERE
			int index = 0;
			// SE RECORREN TODOS, PORQUE PUEDE QUE ESTÁN PERO NO SEAN VISIBLES
			for (int posLista = 0; posLista < totalElements; posLista++) {
				if (this.isDisplayed(elements.get(posLista))) {
					// ENCONTRÓ EL BUTTON VISIBLE QUE CORRESPONDE AL INDEX INDICADO: SE LE DA CLICK
					// Y TERMINA EL CICLO
					if (index == indexButton) {
						objButtonRet = elements.get(posLista);
						break;
					}
					index++; // PARA EL SIGUIENTE BUTTON, PORQUE EL ANTERIOR NO CORRESPONDÍA CON EL INDEX
								// REQUERIDO
				}
			}
		}
//-----------------------------------------------------------------------------------------------------------------------
		return objButtonRet;
	}

//***********************************************************************************************************************
	/**
	 * Retorna una lista de WebElement que corresponden al [locator] dado.
	 */
	public List<WebElement> findElements(By locator) {

		return this.driver.findElements(locator);
	}

	/**
	 * Retorna una lista de WebElement que corresponden al [locator] dado dentro del
	 * [element].
	 */
	// Busca el locator indicado dentro del 'element' recibido: OJO el [element]
	// debe existir
	public List<WebElement> findElements(WebElement element, By locator) {

		return element.findElements(locator);
	}

	/**
	 * Retorna una lista de [WebElement] que se encuentren presente en la página,
	 * que correspondan al tag[tagName] y que adicional cuentan con las propiedades
	 * que se reciben. En caso que [tagName] sea null o vacío busca en todos los
	 * TAGs en la página. Las [properties] se reciben en el formato
	 * [atributo:=valorAtributo]
	 */
	public List<WebElement> findElements(String tagName, String... properties) {

		// ARMA EL VALOR DEL XPATH:
		String xpath = "//" + tagName;
		if (tagName == null)
			xpath = "//*";
		else if (tagName.isEmpty())
			xpath = "//*";
		for (String property : properties) {
			String[] fields = property.split(":="); // 0:atributo, 1:valor
			xpath += "[@" + fields[0] + "='" + fields[1] + "']";
		}
		// RETORNA EL LISTADO DE ELEMENTOS:
		return this.findElements(By.xpath(xpath));
	}

//***********************************************************************************************************************
	/**
	 * Sólo sirve para hacer espera en la página Web, si hay una alerta en la página
	 * Web se genera Excepción .
	 * 
	 * @param segundos
	 */
	public void waitInPage(int segundos) {

		this.driver.manage().timeouts().implicitlyWait(segundos, TimeUnit.SECONDS);// Duration.ofSeconds(segundos));
	}

//***********************************************************************************************************************
	/**
	 * Retorna el texto que contiene el elemento identificado con [locator].<br>
	 * Para los elementos "input" retorna el valor que contiene la caja de texto.
	 */
	public String getText(By locator) {

		return this.getText(this.element(locator));
	}

	// ***********************************************************************************************************************
	/**
	 * Retorna el texto que contiene el [element].<br>
	 * Para los elementos "input" retorna el valor que contiene la caja de texto.
	 */
	public String getText(WebElement element) {

		if (!this.isDisplayed(element)) 
			return null;
		String texto = null;
		try {
			if (element.getTagName().equalsIgnoreCase("input"))
				texto = element.getAttribute("value");
			else {
				texto = element.getText();
				if (texto.isEmpty()) {
					texto = element.getAttribute("innerHTML");
					if (texto == null) {
						texto = element.getAttribute("textContent");
						if (texto == null) {
							texto = element.getAttribute("placeholder");
							if (texto == null) {
								texto = element.getAttribute("value");
								if (texto == null)
									texto = "";
							}
						}
					}
				}
			}
		} catch (Exception e) {
			// DEJA QUE EL RETORNO SEA [null]
		}
		if (texto == null || texto.isEmpty()) // SI DEFINITIVAMENTE NO LO ENCUENTRA, SE BUSCA POR JAVA SCRIPT 
			texto = this.getTextWithJS(element);
		return texto;
	}

//***********************************************************************************************************************
	/**
	 * Retorna el texto que contiene el elemento identificado con [locator] por
	 * sentencia JavaScript.
	 */
	public String getTextWithJS(By locator) {

		return getTextWithJS(this.element(locator));
	}

//***********************************************************************************************************************
	/**
	 * Retorna el texto que contiene el [element] por sentencia JavaScript.
	 */
	public String getTextWithJS(WebElement element) {

		String value = (String) jse.executeScript("return arguments[0].value", element);
		return value;
	}

	public void setTextWithJS(WebElement element, String texto) {

		// String value = (String) jse.executeScript("return
		// document.querySelector(arguments[0]).value", element);
		jse.executeScript("arguments[0].value='" + texto + "'", element);
	}

//***********************************************************************************************************************
	/**
	 * Retorna el valor del seleccionado en la lista identificada con [locator], la
	 * cual es un "select".<br>
	 * Si no hay elementos para seleccionar retorna [null].
	 */
	public String getItemSelected(By locator) {

		return this.getItemSelected(this.element(locator));
	}

//***********************************************************************************************************************
	/**
	 * Retorna el valor del seleccionado en la lista identificada como [element], la
	 * cual es un "select".<br>
	 * Si no hay elementos para seleccionar retorna [null].
	 */
	public String getItemSelected(WebElement element) {

		String itemSelected = null;
		try {
			Select selectList = new Select(element);
			itemSelected = this.getText(selectList.getFirstSelectedOption());
		} catch (StaleElementReferenceException e) {
			// stale element reference: element is not attached to the page document
		} catch (NoSuchElementException e) {
			itemSelected = ""; // NO HAY OPTIONS
		}
		return itemSelected;
	}

//***********************************************************************************************************************
	/**
	 * Indica si el elemento identificado con [locator] está desplegado en la página
	 * Web.
	 */
	public boolean isDisplayed(By locator) {

		return this.isDisplayed(this.element(locator));
	}

	/**
	 * Indica si el [element] está desplegado en la página Web.
	 */
	public boolean isDisplayed(WebElement element) {

		boolean isDisplay;
		try {
			isDisplay = element.isDisplayed();
		} catch (Exception e) {
			isDisplay = false; // EN CASO QUE HAYA DESAPARECIDO EL [WebElement]
		}
		if (!isDisplay) {

			try {
				String script = "return (arguments[0].offsetWidth || arguments[0].offsetHeight) === 0 ? false : true;";
				isDisplay = (boolean) jse.executeScript(script, element);

			} catch (Exception e) {
				return isDisplay;
			}

		}
		return isDisplay;
	}
	
//***********************************************************************************************************************
	/**
	 * Espera a que el elemento identificado con [locator] está desplegado en la
	 * página Web.
	 */
	public void waitElement(By locator) {

		do {
			Util.wait(1);
		} while (this.element(locator) == null);
		this.waitElement(this.element(locator));
	}

	/**
	 * Espera a que el [element] está desplegado en la página Web.
	 */
	public void waitElement(WebElement element) {

		do {
			Util.wait(1);
		} while (!this.isDisplayed(element));
	}

	/**
	 * Espera a que el [element] está desplegado en la página Web.
	 */
	public void waitElement(WebElement element, int maxTime) {

		int time = 0;
		do {
			Util.wait(1);
			time++;
		} while (!this.isDisplayed(element) && time <= maxTime);
	}

	/**
	 * Espera a que el [element] desaparezca de la página Web.
	 * 
	 * @author ppavegas.
	 */
	public void waitNoElement(WebElement element) {

		boolean isLoading;
		do { // ESPERA A QUE TERMINE DE MOSTRAR EL LOADING
			isLoading = this.isDisplayed(element);
		} while (isLoading);
		Util.wait(1);
	}

//***********************************************************************************************************************
	/**
	 * Metodo waitElements: Su proposito es esperar a que el [element] este
	 * desplegado en la pagina dentro de un tiempo determinado "maxTime" teniendo en
	 * cuenta la siguiente logica:<br>
	 * 
	 * <br>
	 * * Si el [element] ya se encuentra Desplegado, termina el ciclo Do While por
	 * this.isDisplayed (true) y msgError = null. <br>
	 * 
	 * <br>
	 * * Si el [element] no se encuentra Desplegado, termina el ciclo Do While por
	 * "Tiempo de Espera Maximo Superado y msgError = !null. <br>
	 * 
	 * @param maxTime  - int - Tiempo Maximo a esperar que el [element] este
	 *                 desplegado, dicho tiempo es en Segundos.
	 * @param elements - WebElement... - [element] o [elements] a esperar que se
	 *                 encuentren desplegados.
	 * 
	 * @return msgError - String - null (Elemento Desplegado) o != null (Elemento No
	 *         Desplegado).
	 * 
	 * @date 03/11/2023
	 * 
	 * @author DAARUBIO
	 * 
	 */
	public String waitElements(int maxTime, WebElement... elements) {

		String msgError = null;
		Boolean isDisplayed = false;
		Date currentDate = null, maxDateEspera = null;
// -----------------------------------------------------------------------------------------------------------------------		  
// Obtiene la Fecha Actual y calcula la Fecha Maxima a Esperar. 
// maxDateEsperaSuma = currentDate + maxTime (Seg). 	
		currentDate = new Date();
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(currentDate);
		calendar.add(Calendar.SECOND, maxTime);
		maxDateEspera = calendar.getTime();
// -----------------------------------------------------------------------------------------------------------------------		  
// Realiza la espera y validacion si el [element] se encuentra desplegado dentro del rango de tiempo maximo a esperar.		
		do {
			for (int i = 0; i < elements.length; i++) {
				isDisplayed = this.isDisplayed(elements[i]);
				if (isDisplayed)
					break;
			}
			currentDate = new Date();
		} while (!isDisplayed && currentDate.before(maxDateEspera));
// -----------------------------------------------------------------------------------------------------------------------		  
// Si el [element] no se encuentra desplegado dentro del rango de tiempo maximo a esperar, retorna el msgError.			
		if (!isDisplayed) {
			msgError = "Tiempo de Espera Maximo al Elemento [" + maxTime + " Seg] fue Superado.";
			System.out.println("*** FAILED - " + msgError);
		}
// -----------------------------------------------------------------------------------------------------------------------		  
// Retorna msgError. Si es null (Elemento Desplegado) o != null (Elemento No Desplegado).		
		return msgError;
	}

//***********************************************************************************************************************
	/**
	 * Indica si el elemento identificado con [locator] está seleccionado.
	 */
	public Boolean isSelected(By locator) {

		boolean valRetorno = false;
		if (this.element(locator) != null)
			valRetorno = this.isSelected(this.element(locator));
		return valRetorno;
	}

	/**
	 * Indica si el [element] está seleccionado.
	 */
	public Boolean isSelected(WebElement element) {

		boolean isSelect;
		try {
			isSelect = element.isSelected();
		} catch (Exception e) {
			isSelect = false; // EN CASO QUE HAYA DESAPARECIDO EL [WebElement]
		}
		return isSelect;
	}

//***********************************************************************************************************************
	/**
	 * Indica si el elemento identificado con [locator] está habilitado.
	 */
	public Boolean isEnabled(By locator) {

		boolean valRetorno = false;
		if (this.element(locator) != null)
			valRetorno = this.isEnabled(this.element(locator));
		return valRetorno;
	}

	/**
	 * Indica si el [element] está habilitado.<br>
	 * Si el objeto es null, el retorno es [false].
	 */
	public Boolean isEnabled(WebElement element) {

		boolean isEnab;
		try {
			isEnab = element.isEnabled();
		} catch (Exception e) {
			isEnab = false; // EN CASO QUE HAYA DESAPARECIDO EL [WebElement]
		}
		return isEnab;
	}

//***********************************************************************************************************************
	/**
	 * Método que indica si el Browser correspondiente al driver actual, cuenta con
	 * una ventana de Browser abierta.<br>
	 * Se usa para crear de nuevo el objeto, o para darle espera a que se abra.
	 */
	public boolean browserIsEnabled() {

		try {
			this.driver.manage().window().getSize(); // SE HACE ESTE LLAMADO PARA VER SI ALCANZA LA VENTANA
			return true;
		} catch (NoSuchSessionException nse) {
			return false;
		} catch (WebDriverException e) {
			return false;
		}
	}

//***********************************************************************************************************************
	/**
	 * Requiere que el Diálogo de buscar el archivo se encuentre abierto.
	 * 
	 * @NO_SE_ESTÁ_USANDO_ESTE_MÉTOOD
	 */
	public void uploadFile(String pathFileName) throws IOException {

		String resource = Util.getFullPathResource("exec/uploadFile.exe");
		String resourceExec = this.getClass().getResource(resource).getFile();
		Runtime.getRuntime().exec(resourceExec + " " + pathFileName);
	}

//***********************************************************************************************************************
	/**
	 * Hace scroll al inicio : teniendo como referencia el [element] el cual debe
	 * ser un [android.widget.ListView]
	 */
	public void downloadIE(WebElement element) throws InterruptedException {

		try {
			// get the focus on the element..don't use click since it stalls the driver
			// this.click(element);
			// Thread.sleep(2000);
			Robot robot = new Robot();
			System.out.println("Creando robot...");
			// simulate pressing enter
			robot.keyPress(KeyEvent.VK_ALT);
			System.out.println("Envió el ALT");
			robot.delay(10000);
			System.out.println("Terminó espera de 10");
			robot.keyPress(KeyEvent.VK_S);
			System.out.println("Envió la S");
			robot.keyRelease(KeyEvent.VK_S);
			System.out.println("Suelta la S");
			robot.keyRelease(KeyEvent.VK_ALT);
			System.out.println("Suelta el ALT");
		} catch (java.awt.AWTException e) {
			e.printStackTrace();
		}
	}

//***********************************************************************************************************************
	/**
	 * Selecciona de la lista que se encuentra en el campo identificado por
	 * [element] el [item]. La búsqueda del elemento NO es case sensitive NI tiene
	 * en cuenta acentos, y selecciona el elemento si está contenido.
	 * 
	 * @param element - Debe ser un [select]
	 * @param item    - Elemento a seleccionar
	 * @return Mensaje de error en caso que no haya encontrado el elemento. El
	 *         retorno es [null] si se pudo seleccionar.
	 * @author ppavegas.
	 */
	public String selectListOption(WebElement element, String item) {

		Select selectList = new Select(element);
		Util.wait(2);
		String valActual = this.getItemSelected(element);
		if (Util.equalsIgnoreCaseAndAccents(valActual, item))
			return null; // YA ESTÁ SELECCIONADO
		else if (Util.containsIgnoreCaseAndAccents(valActual, item)
				|| Util.containsIgnoreCaseAndAccents(item, valActual)) {
			Reporter.writeOnlyConsole("Valor ya seleccionado [" + valActual + "] - no es igual a [" + item
					+ "] pero se deja por estar contenido.");
			return null; // YA ESTÁ SELECCIONADO
		}
		Util.wait(2);
		List<WebElement> options = selectList.getOptions();
		return this.getItemInOptions(options, item);
	}

//***********************************************************************************************************************
	/**
	 * Selecciona de la lista que se encuentra en el campo identificado por
	 * [matSelect], el item.<br>
	 * La búsqueda del elemento NO es case sensitive NI tiene en cuenta acentos.
	 * 
	 * @author Lesly Barajas
	 * @param element           - Debe ser un [mat-select]
	 * @param locatorMatOptions - Debe ser un localizador de la lista de
	 *                          [mat-option],<br>
	 *                          con este localizador se debe poder identificar todas
	 *                          la opciones de mi [mat-select]
	 * @param item              - Datos a buscar en cada item de la lista
	 * @return Mensaje de error en caso que no haya encontrado el item o el
	 *         elemento.<br>
	 *         El retorno es [null] si se pudo seleccionar.
	 */
	public String selectMatListContainsItems(WebElement matSelect, By locatorMatOptions, String item) {

		this.click(matSelect);
		List<WebElement> matOptions;
		do { // Espera mientras no se carguen las opciones
			this.waitInPage(1);
			matOptions = this.findElements(locatorMatOptions);
		} while (matOptions.size() == 0);
		return this.getItemInOptions(matOptions, item);
	}

//***********************************************************************************************************************
	/**
	 * @author Manuel León
	 * @date 1/11/2022 Da click en el elemento identificado con [elemento]
	 *       ejecutando comando por JavaScript.<br>
	 *       Si el elemento NO está visible, este método garantiza su visibilidad
	 *       para darle el click.
	 * 
	 * @param elemento
	 */
	public void clickXJavaScript(WebElement elemento) {

		jse.executeScript("arguments[0].click();", elemento);
	}

//***********************************************************************************************************************
	private static String jsTxDirDefault = "document.querySelector(\"body > settings-ui\").shadowRoot.querySelector(\"#main\").shadowRoot.querySelector(\"settings-basic-page\").shadowRoot.querySelector(\"#advancedPage > settings-section:nth-child([NUMV]) > settings-downloads-page\").shadowRoot.querySelector(\"#defaultDownloadPath\")";
	private static String jsBtChange = "document.querySelector(\"body > settings-ui\").shadowRoot.querySelector(\"#main\").shadowRoot.querySelector(\"settings-basic-page\").shadowRoot.querySelector(\"#advancedPage > settings-section:nth-child([NUMV]) > settings-downloads-page\").shadowRoot.querySelector(\"#changeDownloadsPath\").shadowRoot.querySelector(\"cr-button\")";

	/**
	 * Cambia el directorio de descarga en un Browser CHROME por [newDir],
	 * garantizando la existencia de dicha carpeta.<br>
	 * Retorna el valor por default que se tenía antes del cambio.<br>
	 * Deja la pantalla en about:blank
	 */
	protected String changeDownloadDir_InChrome(String newDir) {

		if (this.jse == null)
			this.jse = (JavascriptExecutor) this.getDriver();
		this.navigate("chrome://settings/downloads");
		Util.wait(1);
		if (this.existDialog()) // PUEDE EXISTIR UN DIÁLOGO CUANDO SE QUIERE ABANDONAR UNA PÁGINA DE CHROME
								// PUNTUAL
			this.acceptDialog();
		WebElement objTxtDir = null;
		int numVFinal = 7;
		do { // ESPERA A QUE MUESTRE LA CAJA CON LA INFORMACIÓN DEL DIRECTORIO DE DESCARGA
			for (int numV = 7; numV <= 8; numV++) {
				objTxtDir = this.elementInShadow(jsTxDirDefault.replace("[NUMV]", String.valueOf(numV)));
				if (objTxtDir != null) {
					numVFinal = numV;
					break;
				}
			}
		} while (objTxtDir == null);
		String currentDir = this.getText(objTxtDir).trim();
		if (newDir == null || newDir.isEmpty() || newDir.equals(currentDir)) {
			this.navigate("about:blank");
			return currentDir;
		}
		if (!Util.directoryExist(newDir)) // GARANTIZA LA EXISTENCIA DE LA CARPETA REQUERIDA
			new File(newDir).mkdirs();
		this.click(this.elementInShadow(jsBtChange.replace("[NUMV]", String.valueOf(numVFinal))));
		Util.wait(2);
		try {
			if (vkb == null)
				vkb = new VirtualKeyBoard();
			vkb.type(newDir);
			vkb.tab(1);
			vkb.enter();
			this.navigate("about:blank");
		} catch (AWTException e) {
			e.printStackTrace();
		}
		return currentDir;
	}

//***********************************************************************************************************************
	/**
	 * Método que espera que un elemento esté visible (Displayed) en el page, o que
	 * se presente un locator de error.
	 * 
	 * @param element   El elemento que se está esperando
	 * @param ventError WebElement de la ventana o popup de error.
	 * @author Sebastian Vargas Jimenez (svarjim).
	 * @return En caso de éxito retorna vacio, en caso de error retorna el texto de
	 *         error presentado.
	 */
	public String waitElementToBeDisplayed(WebElement element, WebElement ventError) {

		boolean elementEncontrado = false, error = false;
		do {
			try {
				elementEncontrado = element.isDisplayed();
			} catch (org.openqa.selenium.NoSuchElementException | NullPointerException
					| StaleElementReferenceException e) {
				try {
					error = ventError.isDisplayed();
				} catch (org.openqa.selenium.NoSuchElementException | NullPointerException
						| StaleElementReferenceException e2) {
				}
			}
		} while (!elementEncontrado && !error);
		if (error)
			return "ERROR -" + ventError.getText();
		return "";
	}

//***********************************************************************************************************************
	/**
	 * Retorna a la pagína anterior.
	 * 
	 * @author Sebastian Correa
	 * @date 17/05/2023
	 */
	public void back() {

		this.driver.navigate().back();
	}

//***********************************************************************************************************************
	/**
	 * Método que valida 2 imgs Base 64, se recibe el path de la img1 en base 64, y
	 * el webelement de la img que se quiere comparar.
	 * 
	 * @param filePath
	 * @param imgAComparar
	 * @return
	 * @throws FileNotFoundException
	 * @author Sebastian Vargas Jimenez (SVARJIM) 25/08/2023
	 */
	public boolean validarImgsBase64(String filePath, WebElement imgAComparar) throws FileNotFoundException {

		File file = new File(filePath);
		Scanner sc = new Scanner(file);
		String base64Tarjeta = "";
		System.out.println("Antes del while");
		while (sc.hasNextLine())
			base64Tarjeta = sc.nextLine();
		sc.close();
		this.moveToElement(imgAComparar);
		do {
			// Realiza espera mientras esté vacío el src
		} while (imgAComparar.getAttribute("src").isEmpty());
		System.out.println("Salio de la espera de imgFranquicia");
		if (base64Tarjeta.equals(imgAComparar.getAttribute("src")))
			return true;
		return false;
	}

// ***********************************************************************************************************************
	/**
	 * Parametriza el page con el tamaño de zomm enviado por parametro
	 * 
	 * @author Sebastían Correa Mendez Pscorrea
	 * @date 12/10/2023
	 * @param zoom
	 */
	public void zoom(int zoom) {

		this.jse.executeScript("document.body.style.zoom='" + zoom + "%'");
	}

// ***********************************************************************************************************************
	/**
	 * Hace Scroll mientras sostiene un elemento [element]
	 * 
	 * @author Sebastían Correa Mendez Pscorrea
	 * @date 21/11/2023
	 * @param element
	 */
	public void clickAndScroll(WebElement element) {

		// Hacer clic y mantener presionado el elemento
		if (this.action == null)
			action = new Actions(this.driver);
		action.clickAndHold(element).perform();
		// Desplazarse hacia abajo mientras se mantiene presionado el elemento
		// JavascriptExecutor js = (JavascriptExecutor) driver;
		this.jse.executeScript("window.scrollBy(0, 500);");
		// Liberar el elemento después de hacer el scroll
		action.release().perform();
	}

// ***********************************************************************************************************************
	/**
	 * Espera que el elemento se encuentre listo para interactuar
	 * 
	 * @param localizador recibe el localizador del elemento
	 * @param time        recibe el tiempo que se va a esperar al elemento
	 * @return si el elemento esta disponible retorna NULL, de lo contrario rertorna
	 *         el error
	 */
	public String esperarExplicitamenteCliqueable(WebElement localizador, int time) {

		try {
			WebDriverWait myWaitVar = new WebDriverWait(getDriver(), time);
			myWaitVar.until(ExpectedConditions.elementToBeClickable(localizador));
			return null;
		} catch (Exception e) {
			return "No encontré el elemento" + localizador;
		}
	}

//***********************************************************************************************************************	
	/**
	 * Metodo que permite escribir caracter por caracter.
	 */
	public void writexCharacter(WebElement objetoWeb, String dato) {

		int longDato = dato.length();
		for (int pos = 0; pos < longDato; pos++) {
			this.writeNoClear(objetoWeb, String.valueOf(dato.charAt(pos)));
			Util.wait(2);
		}
	}

//***********************************************************************************************************************
	/**
	 * Espera que el elemento se encuentre visible y listo para interactuar.
	 * 
	 * @param localizador recibe el localizador del elemento
	 * @param time        recibe el tiempo que se va a esperar al elemento
	 * @return si el elemento esta disponible retorna NULL, de lo contrario rertorna
	 *         el error.
	 */
	public String esperarExplicitamenteElementoVisible(String localizador, int time) {

		try {
			WebDriverWait myWaitVar = new WebDriverWait(this.getDriver(), time);
			myWaitVar.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath(localizador)));
			return null;
		} catch (Exception e) {
			return "No encontré el elemento" + localizador;
		}
	}

//***********************************************************************************************************************
	/**
	 * Espera que el elemento se encuentre listo para interactuar
	 * 
	 * @param localizador recibe el String del xpath.
	 * @param time        recibe el tiempo que se va a esperar al elemento
	 * @return si el elemento esta disponible retorna NULL, de lo contrario rertorna
	 *         el error
	 */
	public String esperarExplicitamenteCliqueable(String localizador, int time) {

		System.out.println("Entro a la funcion");
		try {
			WebDriverWait myWaitVar = new WebDriverWait(this.getDriver(), time);
			myWaitVar.until(ExpectedConditions.elementToBeClickable(By.xpath(localizador)));
			return null;
		} catch (Exception e) {
			return "No encontré el elemento" + localizador;
		}
	}

//***********************************************************************************************************************
	/**
	 * Retorna el user agent con el que cuenta el page actual.
	 */
	public String getUserAgent() {

		String userAgent = (String) (this.jse).executeScript("return navigator.userAgent;");
		return userAgent;
	}

//***********************************************************************************************************************
	/**
	 * Setea el valor [newUserAgent] al UserAgent del page actual, este valor se
	 * mantiene de manera temporal: Cuando el page tiene un refresh o un action que
	 * lo actualiza, vuelve a to,ar el valor oroginal.
	 */
	public void setUserAgent(String newUserAgent) {

		String function = "Object.defineProperty(navigator, 'userAgent', { " + "    get: function () { return '"
				+ newUserAgent + "'; }" + "});";
		this.jse.executeScript(function);
	}

//***********************************************************************************************************************
	/**
	 * Método de prueba para ocultar el bot del WebDriver.
	 */
	public void undefinedWebDriver() {

		// https://zephyrnet.com/es/selenium-java-c%C3%B3mo-evitar-la-detecci%C3%B3n-de-bot-por-sitios-web-cuando-se-usa-chromedriver-exe/
		// LIMPIA NAVEGADOR DE OBJETOS
		this.jse.executeScript("Object.defineProperty(navigator, 'webdriver', {get: () => undefined})");
	}

//***********************************************************************************************************************
	/*
	 * Metodo encargado de realizar Scroll hacia abajo con cantidad indicada por el
	 * parametro
	 * 
	 * @author: JFQUINON
	 */
	public void scrollDown(int scrollCount) {

		for (int i = 0; i < scrollCount; i++) {
			// Realizar scroll hacia abajo
			jse.executeScript("window.scrollTo(0, document.body.scrollHeight);");
			// Esperar un breve período después de cada scroll
			try {
				Thread.sleep(500); // Puedes ajustar este valor según sea necesario
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

//********************************************************************************************************************
}