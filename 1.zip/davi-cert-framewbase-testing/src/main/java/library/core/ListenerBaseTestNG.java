package library.core;

import java.io.File;

import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import com.aventstack.extentreports.Status;

import library.common.Util;
import library.reporting.Reporter;
import library.settings.SettingsRun;

public class ListenerBaseTestNG implements ITestListener {

    // MÉTODO INICIAL INVOCADO AL INICIO DEL LANZAMIENTO
//***********************************************************************************************************************
    @Override
    public void onStart(ITestContext context) {
    	// ESTE MÉTODO SE LLAMA ANTES DE TODOS LOS ANNOTATIONS DE TestNG
    }
//***********************************************************************************************************************
    @Override
    public void onTestStart(ITestResult result) {
    	Reporter.initializeSoftAssert();
    }
//***********************************************************************************************************************
    @Override
    public void onTestSuccess(ITestResult result) {
        ITestListener.super.onTestSuccess(result);
		if (Reporter.test.getStatus().equals(Status.PASS)) {
			Reporter.setTestStatus("PASSED"); // SETEA EL ESTADO FINAL DEL TEST LO SALVA SI EXISTE ARCHIVO DE EVIDENCIAS
			Reporter.uploadEvidenceToTestTool();
		}
		else { // AUNQUE NO FUE ÉXITO, SETEA EL ESTADO FINAL DEL TEST LO SALVA SI EXISTE ARCHIVO DE EVIDENCIAS
			Reporter.setTestStatus(Reporter.test.getStatus().toString());
		}
    }
//***********************************************************************************************************************
    @Override
    public void onTestFailure(ITestResult result) {
        ITestListener.super.onTestFailure(result);
        if (Reporter.test.getStatus().equals(Status.FAIL)) {
        	//Reporter.test.fail(result.getThrowable()); // ADICIONA LA SECCIÓN [bug], PERO MUESTRA THROW EN REPORTE
        	Reporter.setTestStatus("FAILED"); // SETEA EL ESTADO FINAL DEL TEST LO SALVA SI EXISTE ARCHIVO DE EVIDENCIAS
        }
		else { // AUNQUE NO FUE ÉXITO, SETEA EL ESTADO FINAL DEL TEST LO SALVA SI EXISTE ARCHIVO DE EVIDENCIAS
			Reporter.setTestStatus(Reporter.test.getStatus().toString());
		}
    }
//***********************************************************************************************************************
    @Override
    public void onTestSkipped(ITestResult result) {
        ITestListener.super.onTestSkipped(result);
        Reporter.setTestStatus("NOT COMPLETED"); // DE PASO CIERRA EL ARCHIVO DE EVIDENCIAS
    }
//***********************************************************************************************************************
    @Override
    public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
    	System.out.println("5 Entra al [onTestFailedButWithinSuccessPercentage]");
        ITestListener.super.onTestFailedButWithinSuccessPercentage(result);
        Reporter.test.fail(result.getThrowable());
        Reporter.setTestStatus("FAILED"); // DE PASO CIERRA EL ARCHIVO DE EVIDENCIAS
    }
//***********************************************************************************************************************
    @Override
    public void onTestFailedWithTimeout(ITestResult result) {
    	System.out.println("6 Entra al [onTestFailedWithTimeout]");
        ITestListener.super.onTestFailedWithTimeout(result);
        Reporter.test.fail(result.getThrowable());
        Reporter.setTestStatus("FAILED"); // DE PASO CIERRA EL ARCHIVO DE EVIDENCIAS
    }
//***********************************************************************************************************************
    @Override
    public void onFinish(ITestContext context) {
        ITestListener.super.onFinish(context);

        // BORRA LA CARPETA DE EVIDENCIAS FINALES, SI NO CONTIENE ARCHIVOS
		File evidTestToolDir = new File(SettingsRun.getFinalEvidencesDir());
		if (Util.directoryExist(evidTestToolDir) && evidTestToolDir.listFiles().length == 0)
			evidTestToolDir.delete();
    }
//***********************************************************************************************************************
}
