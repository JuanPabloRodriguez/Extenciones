package library.core;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.InvalidSelectorException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.NoSuchWindowException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.remote.DesiredCapabilities;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.NoSuchContextException;
import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.touch.offset.PointOption;
//@BORRAR import library.catalogue.ProjectUrls;
import library.catalogue.SettingsAppium;
import library.common.Util;
import library.reporting.Reporter;
import library.settings.SettingsResources;
import library.settings.SettingsRun;

public abstract class BaseMobileApp {

	private static final String DIR_CHROME_DRIVER = Util.getDirBaseTemp() + "drivers";
	// SE RECOMIENDA QUE EL PUERTO LOCAL SEA 4722 CUANDO SE ESTÁ USANDO WinAppDriver YA QUE ESTE USA EL 4723
	private static final String APPIUM_SERVER_LOCAL = "http://127.0.0.1:LOCAL_PORT/wd/hub";
	private static final String APPIUM_SERVER_REMOTE = "http://REMOTE_SERVER/wd/hub";
	public static boolean MULTI_APPS = false;
//-----------------------------------------------------------------------------------------------------------------------	
	// VARIABLES PARA EL MANEJO DE APPIUM
	private static String APPIUM_SERVER = null;
	private static String CONEXION_APP = null; // TIPO DE CONEXIÓN CON APPIUM : LOCAL / REMOTE
	private static String DEVICE_APPIUM = null; // NOMBRE DEL DISPOSITIVO A USAR
	protected String NAME_APP = null; // NOMBRE DE LA APLICACIÓN A USAR
//-----------------------------------------------------------------------------------------------------------------------	
	// CRITERIOS QUE SE PUEDEN USAR EN EL LLAMDO DE [UiSelector]
	public static final String CRIT_CHECKABLE = "checkable"; // MANEJA boolean
	public static final String CRIT_CHECKED = "checked"; // MANEJA boolean
	public static final String CRIT_CLASSNAME = "className"; // MANEJA String
	public static final String CRIT_CLASSNAME_MATCH = "classNameMatches"; // MANEJA String EXPRESIÓN REGULAR
	public static final String CRIT_CLICKABLE = "clickable"; // MANEJA boolean
	public static final String CRIT_DESC = "description"; // MANEJA String
	public static final String CRIT_DESC_CONTAIN = "descriptionContains"; // MANEJA String
	public static final String CRIT_DESC_MATCH = "descriptionMatches"; // MANEJA String EXPRESIÓN REGULAR
	public static final String CRIT_DESC_START = "descriptionStartsWith"; // MANEJA String
	public static final String CRIT_ENABLED = "enabled"; // MANEJA boolean
	public static final String CRIT_FOCUSABLED = "focusable"; // MANEJA boolean
	public static final String CRIT_FOCUSED = "focused"; // MANEJA boolean
	public static final String CRIT_RESOURCEID = "resourceId"; // MANEJA String
	public static final String CRIT_RESOURCEID_MATCH = "resourceIdMatches"; // MANEJA String EXPRESIÓN REGULAR
	public static final String CRIT_SCROLLABLE = "scrollable"; // MANEJA boolean
	public static final String CRIT_SELECTED = "selected"; // MANEJA boolean
	public static final String CRIT_TEXT = "text"; // MANEJA String
	public static final String CRIT_TEXT_CONTAIN = "textContains"; // MANEJA String
	public static final String CRIT_TEXT_MATCH = "textMatches"; // MANEJA String EXPRESIÓN REGULAR
	public static final String CRIT_TEXT_START = "textStartsWith"; // MANEJA String
//-----------------------------------------------------------------------------------------------------------------------
	/* "childSelector"; // MANEJA UiSelector selector) "fromParent"; // MANEJA UiSelector selector) "index"; // MANEJA
	 * int index) "instance"; // MANEJA int instance) "longClickable"; // MANEJA boolean "packageName"; // MANEJA String
	 * name) "packageNameMatches"; // MANEJA String EXPRESIÓN REGULAR */
	// public static String APP_NAME = "";
//-----------------------------------------------------------------------------------------------------------------------
	// HASHMAP<STRING,OBJECT> KEY=NOMBRE CAPABILITY, VALUE=VALOR DEL CAPABILITY
	protected Map<String, Object> capabilities = new HashMap<String, Object>();
	private AppiumDriver<MobileElement> driver;
	//private String sistemaOp; // INDICA SI ES iOS / Android
	private int coordYStartContenido = 0; // COORDENADA [Y] DONDE EMPIEZA EL CONTENIDO, ES PARA APPs CON HEADER
	private int coordYEndContenido = 0; // COORDENADA [Y] DONDE TERMINA EL CONTENIDO, ES PARA APPs CON FOOTER
	protected String webContext; // SI ESTÁ EN [null] ES PORQUE LA APP NO TIENE CONTEXTO WEB
	protected BasePageWeb pageWebContext; // PÁGINA WEB DEL CONTEXTO WEB DE LA APP
	//private boolean webContextValidado;
	protected boolean isAndroid;

//=======================================================================================================================
	/**
	 * Retorna el nombre del dispositivo cargado
	 */
 	public String getDeviceName() {
 		return this.capabilities.get("deviceName").toString();
 	}
//***********************************************************************************************************************
	/**
	 * Este método se encarga de dar valor a la variable protected [NAME_APP], la idea es que las clases que hereden de
	 * BaseMobileApp implementen este método dándole un valor a [NAME_APP] para que se busque dicho valor en la hoja de
	 * datos "DF_AppiumApps.json"
	 */
	public abstract void loadAppName();
//***********************************************************************************************************************
	/**
	 * Garantiza que la aplicación se encuentra en el punto inicial de los lanzamientos.
	 */
	public abstract void waitAccesoApp();
//***********************************************************************************************************************
	/**
	 * Constructor que recibe otro BaseMobileApp (parentScreen), la cual ya debe tener toda la información base del
	 * Secreen del dispositivo a usar, se genera una especie de clone del Screen.
	 */
	protected BaseMobileApp(BaseMobileApp parentScreen) {

		this.capabilities = parentScreen.capabilities;
		this.driver = parentScreen.driver;
		this.coordYStartContenido = parentScreen.coordYStartContenido;
		this.coordYEndContenido = parentScreen.coordYEndContenido;
		this.webContext = parentScreen.webContext;
		this.isAndroid = parentScreen.isAndroid;
		this.pageWebContext=parentScreen.pageWebContext;
	}
//***********************************************************************************************************************
	/**
	 * Constructor que requiere que se hayan cargado las propiedades carga el nombre del dispositivo a usar y el de la
	 * aplicación a cargar, qu tanto la información del dispositivo como la de la aplicación debe existir en la hoja de
	 * datos usada por [DS_SettingsAppium], ya que de allá se extrae la información de los capabilities (Device y
	 * Application).
	 */
	public BaseMobileApp() {

		this.doCargaAppium();
	}
//***********************************************************************************************************************
	protected void doCargaAppium() {

		loadProperties(); // HACE LA CARGA DE LAS PROPIEDADES Y COMPLETA LOS DATOS DE CONEXIÓN VÍA APPIUM
		// EN ESTE PUNTO SE DEBIERON CARGAR TODOS LOS DATOS QUE PERMITEN HACER CONEXIÓN
		this.loadCapabilitiesDeviceAndCommon(); // CARGA LOS CAPABILITIES DEL DISPOSITIVO Y LAS COMUNES
		this.loadCapabilitiesBySO(); // CARGA LOS CAPABILITIES POR SISTEMA OPERATIVO - DE LA APLICACIÓN
		this.changeCapabilities(); // CAMBIA O ADICIONA CAPABILITIES (LAS ADICIONALES)
		if (capabilities.size() == 0)
			throw new NoSuchContextException(
				"BaseMobileApp ERROR -- No se cuenta con capabilities para cargar el Dispositivo ni la App...");
		else { // HACE LA CARGA RESPECTIVA PARA ABRIR EL DRIVER
			DesiredCapabilities cap = new DesiredCapabilities();
			// RECORRE EL HASHMAP PARA EXTRAER LOS CAPABILITIES
			for (HashMap.Entry<String, Object> capability : capabilities.entrySet()) {
				String capabilityName = capability.getKey();
				Object value = capability.getValue();
				cap.setCapability(capabilityName, value);
			}
			this.loadAppiumServer(); // CARGA EL APPIUM SERVER A USAR
			URL url = null;
			try {
				url = new URL(APPIUM_SERVER);
			}
			catch (MalformedURLException e) {
				e.printStackTrace();
				throw new NoSuchContextException("BaseMobileApp ERROR -- MalformedURLException");
			}
			if (this.isAndroid)
				this.driver = new AndroidDriver<MobileElement>(url, cap);
			else // ES iOS
				this.driver = new IOSDriver<MobileElement>(url, cap);
			if (!MULTI_APPS)
				System.out.println("*** APP [" + NAME_APP + "] Started...");
		}
		if (!MULTI_APPS)
			this.waitAccesoApp(); // GARANTIZA QUE LA APLICACIÓN SE ABRE Y ESTÁ EN EL PUNTO INCIAL
	}
//***********************************************************************************************************************
	/**
	 * Retorna el [BasePageWeb] correspondiente al contexto web.
	 */
	public BasePageWeb webContext() {

		do { // GARANTIZA QUE HAYA MÁS DE 1 CONTEXTO, EL NATIVO Y EL OTRO
			Util.wait(1);
		} while (this.getContexts().size() == 1);
//-----------------------------------------------------------------------------------------------------------------------
		// SI NO SE HA CARGADO EL CONTEXTO WEB O EL CONTEXTO WEB CARGADO NO ESTÁ EN LA LISTA DE CONTEXTOS:
		// BUSCA DENTRO DE LOS CONTEXTOS EL PRIMERO QUE EMPIECE CON "WEBVIEW"
		if (this.webContext == null || !this.getContexts().contains(this.webContext)) {
			this.webContext = "";
			for (String context : this.getContexts()) {
				if (context.startsWith("WEBVIEW")) {
					this.webContext = context;
					break;
				}
			}
		}
//-----------------------------------------------------------------------------------------------------------------------
		if (this.webContext.isEmpty())
			throw new NoSuchContextException(
				"BaseMobileAppERROR -- La configuración de la aplicación NO identificó un contexto Web");
//-----------------------------------------------------------------------------------------------------------------------
		String currentContext = this.getContext();
		if (!currentContext.equals(this.webContext)) {
			// SI EL ARCHIVO QUE CREA EXISTE, SE BORRA PARA QUE NO GENERE CONFLICTO
			/* 20230531 LA DESCARGA DEL DRIVE NO SE CONTEMPLA AUTOMÁTICA File f = new File(DIR_CHROME_DRIVER +
			 * "chromedriver_win32_v2.46.exe"); if (f.exists()) f.delete(); */
			// HACE EL CAMBIO DE CONTEXTO
			this.changeContext(this.webContext);
		}
//-----------------------------------------------------------------------------------------------------------------------
		if (this.pageWebContext == null) // SI NO SE HA CREADO LA PAGE WEB, SE CREA LA INSTANCIA
			this.pageWebContext = new BasePageWeb(this);
		return this.pageWebContext;
	}
//***********************************************************************************************************************
	/**
	 * Retorna el [BasePageWeb] correspondiente al contexto web.
	 */
	public BasePageWeb webContext(String nbContext) {
		
		String currentContext = this.getContext();
		if (!currentContext.equals(nbContext)) {
			boolean existe = false;
			for (String context : this.getContexts()) {
				if (context.equals(nbContext)) {
					existe = true;
					break;
				}
			}
			if (!existe)
				throw new NoSuchContextException("BaseMobileAppERROR -- NO existe el contexto [" + nbContext + "]");
			// SI EL ARCHIVO QUE CREA EXISTE, SE BORRA PARA QUE NO GENERE CONFLICTO
			/* 20230531 LA DESCARGA DEL DRIVE NO SE CONTEMPLA AUTOMÁTICA File f = new File(DIR_CHROME_DRIVER +
			 * "chromedriver_win32_v2.46.exe"); if (f.exists()) f.delete(); */
			// HACE EL CAMBIO DE CONTEXTO
			this.changeContext(nbContext);
		}
// -----------------------------------------------------------------------------------------------------------------------
		if (this.pageWebContext == null) // SI NO SE HA CREADO LA PAGE WEB, SE CREA LA INSTANCIA
			this.pageWebContext = new BasePageWeb(this);
		return new BasePageWeb(this);
	}
//***********************************************************************************************************************
	/**
	 * Método que realiza el cambio al contexto web cargado en [this.webContext] y hace el cambio de window de acuerdo al
	 * nombre que ingresa por párametro [nombreWindow], hace la búsqueda del nombre exacto si el parametro [isEqual]
	 * viene en true, de lo contrario hace la búsqueda indicando que contenga.<br>
	 * Finalmente retorna el [BasePageWeb] correspondiente.
	 * @return BasePageWeb correspondiente al cambio de contexto y al nombre del window recibido. Retorna [null] cuando
	 * no encuentra el [nombreWindow]
	 * @author NYBETANC (Narli Betancourth)
	 */
	public BasePageWeb webContext(String nombreWindow, boolean isEqual) {

		BasePageWeb page = this.webContext();
		try {
			if (page.changeWindowByTitle(nombreWindow, isEqual)) 
				return page;
		}
		catch (NoSuchWindowException e) {
			this.changeToNativeContext();
			return this.webContext(nombreWindow, isEqual); // RECURRENCIA
		}
		return null;
	}

//***********************************************************************************************************************
	/**
	 * Coordenada [Y] en donde inicia el contenido de la aplicación, es decir quitándole el encabezado que tenga la
	 * aplicación. Es útil para hacer swipe sobre la pantalla completa, sin un elemento dado.
	 */
	public void setCoordYStartContenido(int coordYStartContenido) {

		this.coordYStartContenido = coordYStartContenido;
	}
//***********************************************************************************************************************
	/**
	 * Coordenada [Y] en donde termina el contenido de la aplicación, es decir quitándole el footer que tenga la
	 * aplicación. Es útil para hacer swipe sobre la pantalla completa, sin un elemento dado.
	 */
	public void setCoordYEndContenido(int coordYEndContenido) {

		this.coordYEndContenido = coordYEndContenido;
	}
//***********************************************************************************************************************
	/**
	 * Indica si la aplicación mobile cuenta con Header, se reconoce porque la coordenada [Y] en donde inicia el
	 * contenido de la aplicación tiene un valor diferente de cero (0).
	 */
	public boolean tieneHeader() {

		return (this.coordYStartContenido != 0);
	}
//***********************************************************************************************************************
	/**
	 * Indica si la aplicación mobile cuenta con Header, se reconoce porque la coordenada [Y] en donde inicia el
	 * contenido de la aplicación tiene un valor diferente de cero (0).
	 */
	public boolean tieneFooter() {

		return (this.coordYEndContenido != 0);
	}
//***********************************************************************************************************************
	/**
	 * Carga la información del dispositivo a usar en [capabilities].<br>
	 * Este método es private porque esta es la única manera de cargar los capabilities del dispositivo.
	 */
	private void loadCapabilitiesDeviceAndCommon() {

		if (DEVICE_APPIUM == null || DEVICE_APPIUM.isEmpty())
			throw new NoSuchContextException(
				"BaseMobileApp ERROR -- Se requiere nombre del DISPOSITIVO - NO se ha cargado...");
		// {0-deviceName, 1-udid, 2-platformName, 3-platformVersion}
		String[] settingsDev;
		try {
			settingsDev = new SettingsAppium(SettingsAppium.DEVICE).getSettingsDevice(DEVICE_APPIUM);
		}
		catch (Exception e) {
			throw new NoSuchContextException(e.getMessage());
		}
		String platformName = settingsDev[2];
		// SI NO ES ANDROID, ES PORQUE ES iOS
		this.isAndroid = platformName.toUpperCase().equals("ANDROID");
//-----------------------------------------------------------------------------------------------------------------------
		// CAPABILITOES DEL DISPOSITIVO CONECTADO
		capabilities.put("deviceName", settingsDev[0]);
		capabilities.put("udid", settingsDev[1]);
		capabilities.put("platformName", platformName);
		capabilities.put("platformVersion", settingsDev[3]);
		//capabilities.put("webStorageEnabled", true);  //SOLO DE PRUEBA
//-----------------------------------------------------------------------------------------------------------------------
		// SI ES true, FUERZA LA DESINSTALACIÓN DE CUALQUIER APLICACIÓN WebDriverAgent EXISTENTE EN EL DISPOSITIVO
		capabilities.put("useNewWDA", false);
		// PARA QUE NO REINICIE LOS PERMISOS DE LA APLICACIÓN
		capabilities.put("noReset", true);
		capabilities.put("appWaitDuration", 700000); // TIEMPO DE ESPERA EN MILISEGUNDOS PARA ESPERAR QUE INICIE LA APP
		// CUÁNTO TIEMPO EN SEGUNDOS APPIUM ESPERA UN NUEVO COMANDO ANTES DE ASUMIR QUE SE SALDRÁ Y FINALIZARÁ SESIÓN.
		// PONERLO EN 0 DESACTIVA EL TIEMPO DE ESPERA DEL NUEVO COMANDO, PERMITIENDO QUE LAS SESIONES DE AUTOMATIZACIÓN
		// CONTINÚEN INFINITAMNETE SIN NINGÚN COMANDO NUEVO
		capabilities.put("newCommandTimeout", 0);
		// capabilities.put("unicodeKeyboard", true); // HABILITAR LA ENTRADA UNICODE
		// (PARA INGRESAR TEXTO SIN NECESIDAD DEL TECLADO DEL DEVICE)
		// capabilities.put("resetKeyboard", true); // EN [true] INACTIVA EL TECLADO DEL DISPOSITIVO
	}
//***********************************************************************************************************************
	/**
	 * Carga la información de los capabilities de la aplicación, que van según el sistema operativo:<br>
	 * - Para Android usar "appPackage" y "appActivity"<br>
	 * - Para iOS usar "app" y "appActivity"<br>
	 * Este método es private porque esta es la única manera de cargar los capabilities de la aplicación.
	 */
	private void loadCapabilitiesBySO() {

		// {0-appPackage, 1-appActivity, 2-nameIpa}
		String[] settingsApp;
		try {
			settingsApp = new SettingsAppium(SettingsAppium.APPLICATION).getSettingsApp(NAME_APP);
		}
		catch (Exception e) {
			throw new NoSuchContextException(e.getMessage());
		}
//-----------------------------------------------------------------------------------------------------------------------
		// CAPABILITIES ANDROID:::
		if (this.isAndroid) {
			capabilities.put("appPackage", settingsApp[0]);
			capabilities.put("appActivity", settingsApp[1]);
			//@NARLI DECIR A NARLI QUE PRUEBE EN ANDROID CON "browserName", "chrome") y capabilities.put("useNewWDA", false) a ver si necesitamos los drivers
			capabilities.put("chromedriverExecutableDir", DIR_CHROME_DRIVER);
			capabilities.put("webviewConnectTimeout", 100); // TIEMPO DE ESPERA PARA EL WEB VIEW
		}
//-----------------------------------------------------------------------------------------------------------------------
		// CAPABILITIES IOS:::
		else {
			capabilities.put("automationName", "xcuiTest");
			// ACEPTA AUTOMÁTICAMENTE TODAS LAS ALERTAS DE IOS SI APARECEN. ESTO INCLUYE ALERTAS DE PERMISOS DE ACCESO A
			// LA PRIVACIDAD (P. EJ., UBICACIÓN, CONTACTOS, FOTOS). EL VALOR PREDETERMINADO ES FALSO.
			capabilities.put("autoAcceptAlerts", true); // @zea NO SÉ SI FUNCIONE
			if (!BaseMobileApp.MULTI_APPS)
				capabilities.put("bundleId", settingsApp[0]);
		//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
			// DESCARGA EL IPA DE RESOURCES PARA INSTALARLO
			String nameIpa = settingsApp[2];
			if (nameIpa.isEmpty())
				throw new NoSuchContextException("BaseMobileApp ERROR -- Se requiere el nombre del instalador IPA...");
			try {
				String pathIpa = SettingsResources.getFullPathResource("ipas/" + nameIpa);
				capabilities.put("app", pathIpa);
			}
			catch (Exception e) {
				throw new NoSuchContextException("BaseMobileApp ERROR -- " + e.getMessage());
			}
		}
	}
//***********************************************************************************************************************
	/**
	 * Después de la carga de capabilities, este método permite cambiar o adicionar capabilities, debe ser sobreescrito
	 * por la clase que herede de esta clase y quiera cambiar o adicionar capabilities para la conexión.
	 */
	protected void changeCapabilities() {

		// TODO SOBREESCRIBIR SEGÚN SE REQUIERA EN LAS CLASES QUE HEREDAN
	}
//***********************************************************************************************************************
	/**
	 * Método encargado de abrir una app, no se debe haber cargado un BundleID en el driver que se esté usando.
	 */
	public void openApp(String nameApp) throws Exception {

		String[] settingsApp;
		try {
			settingsApp = new SettingsAppium(SettingsAppium.APPLICATION).getSettingsApp(NAME_APP);
		}
		catch (Exception e) {
			throw new NoSuchContextException(e.getMessage());
		}
		if (this.isAndroid) {
			// capabilities.put("appPackage", settingsApp[0]);
			// capabilities.put("appActivity", settingsApp[1]);
			// capabilities.put("noReset", true); // PARA QUE NO REINICIE LOS PERMISOS DE LA
			// APLICACIÓN
			this.webContext = null;
			if (!settingsApp[2].isEmpty() && !settingsApp[2].equals("N/A")) { // TIENE CONTEXTO WEB
				// this.webContext = settingsApp[2];
				// this.webContextValidado = false;
				// capabilities.put("chromedriverExecutableDir", DIR_CHROME_DRIVER);
			}
		}
		else {
			HashMap<String, Object> args = new HashMap<String, Object>();
			args.put("bundleId", settingsApp[0]);
			this.getDriver().executeScript("mobile: launchApp", args);
			System.out.println("*** APP [" + nameApp + "] Started...");
			this.waitAccesoApp();
		}
	}
//***********************************************************************************************************************
	/**
	 * Carga la información de la aplicación teniendo el APk a usar en [capabilities]: "app"<br>
	 * Este método es private porque esta es la única manera de cargar los capabilities de la aplicación.
	 */
	/* private void loadCapabilitiesApk(String apkFile) {
	 * 
	 * if (apkFile == null || apkFile.isEmpty()) throw new
	 * NoSuchContextException("BaseMobileApp ERROR -- Se requiere el APK - NO se ha cargado..." );
	 * 
	 * File file = new File(apkFile); capabilities.put("app", file.getAbsolutePath()); } */
//***********************************************************************************************************************
	/**
	 * Se encarga de llamar al método [loadAppName] que debió ser implementado por las clases que heredan de esta, para
	 * darle nombre a la aplicación que se va a abrir, OJO debe estar en el catálogo [DF_AppiumApps.json]<br>
	 * Si no se ha cargado el DEVICE_NAME se encarga de extraerlo de las propiedades.<br>
	 * Extrea la información de la propiedad de conexión, para saber si es LOCAL o REMOTE y dependiendo de su valor llama
	 * al método [loadAppiumServer]
	 */
	private void loadProperties() {

		this.loadAppName();
		if (NAME_APP == null)
			throw new NoSuchContextException(
				"BaseMobileApp ERROR -- No se ha cargado Nombre de la App (variable NAME_APP)");
		if (DEVICE_APPIUM == null) {
			DEVICE_APPIUM = SettingsRun.getProperty(SettingsRun.PROP_APPIUM_DEVICE);
			if (DEVICE_APPIUM == null || DEVICE_APPIUM.isEmpty())
				throw new NoSuchContextException("BaseMobileApp ERROR -- No se ha cargado Nombre del Dispositivo");
		}
		CONEXION_APP = SettingsRun.getProperty(SettingsRun.PROP_APPIUM_CONN);
		if (CONEXION_APP == null || CONEXION_APP.isEmpty())
			throw new NoSuchContextException("BaseMobileApp ERROR -- No se cuenta con la propiedad de ejecución"
				+ "... [" + SettingsRun.PROP_APPIUM_CONN + "]");
		else if (!CONEXION_APP.equals("LOCAL") && !CONEXION_APP.equals("REMOTE") && !CONEXION_APP.equals("FARM"))
			throw new NoSuchContextException("BaseMobileApp ERROR -- La propiedad de ejecución ["
				+ SettingsRun.PROP_APPIUM_CONN + "] sólo puede ser LOCAL / REMOTE / FARM");
		this.loadAppiumServer();
	}
	/* private void loadProperties() { DEVICE_APPIUM = SettingsRun.getProperty(SettingsRun.PROP_APPIUM_DEVICE); if
	 * (DEVICE_APPIUM == null || DEVICE_APPIUM.isEmpty()) { // SE DEBE PREGUNTAR POR EL DISPOSITIVO String[] listaDisp =
	 * {}; try { listaDisp = new SettingsAppium(SettingsAppium.DEVICE).getNbItems(); } catch (Exception e) {
	 * e.printStackTrace(); } String[] labelDatos = new String[] { "Dispositivo" }; String[] tipoDatos = { "JComboBox" };
	 * String[] datos = Util.pedirDatos("DEVICE SELECT", labelDatos, tipoDatos, listaDisp); DEVICE_APPIUM = datos[0]; }
	 * //---------------------------------------------------------------------------
	 * -------------------------------------------- NAME_APP_APPIUM =
	 * SettingsRun.getProperty(SettingsRun.PROP_APPIUM_NBAPP); if (NAME_APP_APPIUM == null || NAME_APP_APPIUM.isEmpty())
	 * { // SE DEBE PREGUNTAR POR LA APLICACIÓN String[] listaApps = {}; try { listaApps = new
	 * SettingsAppium(SettingsAppium.APPLICATION).getNbItems(); } catch (Exception e) { e.printStackTrace(); } String[]
	 * labelDatos = new String[] { "Nombre APP" }; String[] tipoDatos = { "JComboBox" }; String[] datos =
	 * Util.pedirDatos("MOBILE APP SELECT", labelDatos, tipoDatos, listaApps); NAME_APP_APPIUM = datos[0]; } } */
//***********************************************************************************************************************
	/**
	 * Carga la información del server de Appium a usar, dependiendo del tipo de conexión que se va a realizar.
	 */
	private void loadAppiumServer() {

		if (APPIUM_SERVER != null)
			return; // HACE NADA, PORQUE YA ESTÁ CARGADO EL DATO
		if (CONEXION_APP.equals("LOCAL")) { // PONE EL PUERTO DE APPIUM EN [APPIUM_SERVER]
			// String portConn = Util.getAppiumPort(); // NO SE USA PORQUE SE ESTÁ DEMORANDO
			// MUCHO
			// SI NO INDICÓ PUERTO, POR DEFECTO TOMA EL 4723
			String portConn = SettingsRun.getProperty(SettingsRun.PROP_APPIUM_PORT, "4723");
			if (portConn == null)
				throw new NoSuchContextException(
					"BaseMobileApp ERROR -- Revisar porque NO se detectó que APPIUM esté corriendo");
			APPIUM_SERVER = APPIUM_SERVER_LOCAL.replace("LOCAL_PORT", portConn);
		}
		else { // ES REMOTE / FARM
			String remoteServer = SettingsRun.getProperty(SettingsRun.PROP_APPIUM_REMOTE_SERVER);
			if (remoteServer == null || remoteServer.isEmpty())
				throw new NoSuchContextException(
					"BaseMobileApp ERROR -- Conexión REMOTE : No se cuenta con la propiedad " + "de ejecución... ["
						+ SettingsRun.PROP_APPIUM_REMOTE_SERVER + "]");
			if (CONEXION_APP.equals("REMOTE")) {
				String portConn = SettingsRun.getProperty(SettingsRun.PROP_APPIUM_PORT);
				// SI SE INDICÓ PUERTO SE CONCATENA CON EL [remoteServer]
				String server = (portConn != null && !portConn.isEmpty()) ? remoteServer + ":" + portConn : remoteServer;
				APPIUM_SERVER = APPIUM_SERVER_REMOTE.replace("REMOTE_SERVER", server);
			}
			else // FARM : GRANJA
				APPIUM_SERVER = remoteServer + "/wd/hub";
		}
	}
//***********************************************************************************************************************
	/**
	 * Cambia al contexto nativo de la aplicación mobile.
	 */
	public void changeToNativeContext() {

		if (this.webContext == null)
			return; // NO SE CONFIGURÓ CONTEXTO WEB, POR ENDE EL CONTEXTO POR DEFECTO ES EL
					// "NATIVE_APP"
		String currentContext = this.getContext();
		if (!currentContext.equals("NATIVE_APP"))
			this.changeContext("NATIVE_APP");
	}
//***********************************************************************************************************************
	/* public String getSistemaOp() { return sistemaOp; } */
	public AppiumDriver<MobileElement> getDriver() {

		return this.driver;
	}
//***********************************************************************************************************************
	/**
	 * Liberar el driver de la instancia actual.
	 */
	public void close() {

		if (this.driver != null)
			this.driver.closeApp();
	}
//***********************************************************************************************************************
	// SECCIÓN QUE MANEJA MÉTODOS PARA EL RETORNO DE [MobileElement], CUANDO EL
	// ELEMENTO NO EXISTE O EXISTE PERO NO SE
	// PRESENTA EN LA App (!isDisplayed), SE RETORNA UN OBJETO EN [null]
	/**
	 * Retorna el [MobileElement] que se encuentre presente en la APP, que corresponde a la clase [className] y que
	 * adicional cuenta con las propiedades que se reciben. Las [properties] se reciben en el formato
	 * [atributo:=valorAtributo] Si el elemento NO existe o NO está desplegado retorna el objeto en null.
	 */
	public MobileElement elementBy(String className, String... properties) {

		MobileElement elementRet = null;
		String valAttrib;
		List<MobileElement> elements = this.elementsByClassName(className);
		// if (elements.size() == 0)
		// throw new NoSuchElementException("No hay elementos con ClassName [" +
		// className + "]");
		if (properties.length == 0 && elements.size() != 0) {
			// Si no se reciben "properties" y sí hay elementos con el ClassName enviado, se
			// retorna el primer elemento
			elementRet = elements.get(0);
			// objetoEncontrado = true;
		}
		else {
			boolean objetoEncontrado;
			for (MobileElement element : elements) {
				objetoEncontrado = true; // Valor por defecto para concatenar condición de AND
				for (String property : properties) {
					String[] fields = property.split(":="); // 0:atributo, 1:valor
					if (fields[0].equals("id"))
						fields[0] = "resource-id";
					try {
						valAttrib = element.getAttribute(fields[0]);
						if (valAttrib == null)
							valAttrib = "";
					}
					catch (Exception e) {
						valAttrib = ""; // el elemento no cuenta con el atributo, deja el valor en vacío
					}
					objetoEncontrado = objetoEncontrado && valAttrib.equalsIgnoreCase(fields[1]);
					if (!objetoEncontrado)
						break; // Termina el ciclo, porque NO es el objeto buscado
				}
				if (objetoEncontrado) {
					elementRet = element;
					break; // Termina el ciclo, porque YA encontró el objeto buscado
				}
			}
		}
		// Si no está desplegado se retorna null:
		if (elementRet != null)
			if (!elementRet.isDisplayed())
				elementRet = null;
		return elementRet;
	}
//***********************************************************************************************************************
	/**
	 * Retorna el MobileElement cuyo [id] corresponda al ingresado por parámetro. Si no es visible en el dispositivo hace
	 * scroll para ver si se encuentra, si no se encuentra retorna [null].
	 */
	public MobileElement elementById(String id) {

		MobileElement element;
		try {
			element = this.driver.findElementById(id);
			if (!element.isDisplayed())
				element = null;
		}
		catch (Exception e) {
			element = this.elementByCriteria(CRIT_RESOURCEID, id);
		}
		return element;
	}
//***********************************************************************************************************************
	/**
	 * Retorna el MobileElement cuyo [id] corresponda al ingresado por parámetro. Si no es visible en el dispositivo NO
	 * hace scroll.<br>
	 * El retorno es [null] si no se encuentra.
	 */
	public MobileElement elementByIdSinScroll(String id) {

		MobileElement element;
		try {
			element = this.driver.findElementById(id);
			if (!element.isDisplayed())
				element = null;
		}
		catch (Exception e) {
			element = this.elementByCriteriaSinScroll(CRIT_RESOURCEID, id);
		}
		return element;
	}
//***********************************************************************************************************************
	/**
	 * Retorna el MobileElement cuyo [name] corresponda al ingresado por parámetro.
	 */
	public MobileElement elementByName(String name) {

		MobileElement element;
		try {
			element = this.driver.findElementByName(name);
			if (!element.isDisplayed())
				element = null;
		}
		catch (Exception e) {
			element = null;
		}
		return element;
	}
//***********************************************************************************************************************
	/**
	 * Retorna el MobileElement cuyo [className] corresponda al ingresado por parámetro. Si no es visible en el
	 * dispositivo hace scroll para ver si se encuentra, si no se encuentra retorna [null].
	 */
	public MobileElement elementByClassName(String className) {

		MobileElement element;
		try {
			element = this.driver.findElementByClassName(className);
			if (!element.isDisplayed())
				element = null;
		}
		catch (Exception e) {
			element = this.elementByCriteria(CRIT_CLASSNAME, className);
		}
		return element;
	}
//***********************************************************************************************************************
	/**
	 * Retorna el MobileElement cuyo [className] corresponda al ingresado por parámetro. Si no es visible en el
	 * dispositivo NO hace scroll.<br>
	 * El retorno es [null] si no se encuentra.
	 */
	public MobileElement elementByClassNameSinScroll(String className) {

		MobileElement element;
		try {
			element = this.driver.findElementByClassName(className);
			if (!element.isDisplayed())
				element = null;
		}
		catch (Exception e) {
			element = this.elementByCriteriaSinScroll(CRIT_CLASSNAME, className);
		}
		return element;
	}
//***********************************************************************************************************************
	/**
	 * Retorna el MobileElement cuyo AccessibilityId corresponda al ingresado por parámetro.
	 */
	public MobileElement elementByAccessibilityId(String accId) {

		MobileElement element;
		try {
			element = this.driver.findElementByAccessibilityId(accId);
			if (!element.isDisplayed())
				element = null;
		}
		catch (Exception e) {
			element = null;
		}
		return element;
	}
//***********************************************************************************************************************
	/**
	 * Método para encontrar un elemento haciendo uso de AndroidUIAutomator, con un selector directo, si no lo encuentra
	 * de manera directa, hace uso del método [elementbyuiautomatorscroll].<br>
	 * Si el elemento NO es visible en el dispositivo y [hacerScroll] es [true] hace scroll para ver si lo encuentra.<br>
	 * El retorno es [null] si el elemento NO es encontrado.
	 */
	protected MobileElement elementByUIAutomator(String selector, boolean hacerScroll) {

		MobileElement element;
		try {
			element = this.driver.findElement(MobileBy.AndroidUIAutomator(selector));
			if (!element.isDisplayed())
				element = null;
		}
		catch (Exception e) {
			element = null;
			// Es posible que no se encuentre porque se debe hacer scroll en la APP:
			if (hacerScroll)
				element = this.elementByUIAutomatorScroll(selector);
		}
		return element;
	}
//***********************************************************************************************************************
	/**
	 * Método para encontrar un elemento haciendo uso de AndroidUIAutomator, con un selector que involucra el Scroll.<br>
	 * Si no lo encuentra el retorno es [null].
	 */
	private MobileElement elementByUIAutomatorScroll(String selector) {

		// PRIMERO SE DEBE GARANTIZAR QUE ESTÁ AL INICIO LA PANTALLA
		this.swipeToStart();
		String scrollSelector = "new UiScrollable(new UiSelector().scrollable(true).instance(0)).scrollIntoView("
			+ selector + ")";
		MobileElement element;
		String sourceIni, sourceFin;
		do { // SE HACE CICLO, PORQUE SE DETECTA QUE EL [UiScrollable] NO ESTÁ HACIENDO TODOS
				// LOS SCROLL REQUERIDOS
			sourceIni = this.getDriver().getPageSource();
			try {
				element = this.driver.findElement(MobileBy.AndroidUIAutomator(scrollSelector));
				if (!element.isDisplayed())
					element = null;
			}
			catch (Exception e) {
				element = null;
			}
			sourceFin = "";
			if (element == null)
				sourceFin = this.getDriver().getPageSource();
		} while (!sourceIni.equals(sourceFin) && element == null);
//-----------------------------------------------------------------------------------------------------------------------
		if (element != null) {
			int coordYElement = element.getLocation().getY();
			// SI LA COORDENADA DEL ELEMENTO ES MENOR A LA COORDENADA [Y] DE INICIO DEL
			// CONTENIDO, ES PORQUE EL ELEMENTO
			// ESTÄ PERO NO ES VISIBLE (ESTÁ TAPADO POR EL HEADER), POR ENDE SE DEBE HACER 1
			// SWIPE
			if (coordYElement < this.coordYStartContenido) {
				Dimension size = this.getDriver().manage().window().getSize();
				int startX = (int) (size.width * 0.01); // TOMA DESDE EL EXTREMO IZQUIERDO
				int startY = this.coordYStartContenido;
				int endY = (int) (size.height * 0.95);
				this.doSwipe(new int[] { startX, startY }, new int[] { startX, endY });
				element = this.elementByUIAutomator(selector, false); // DEBERÍA VERSE SIN SCROLL
			}
		}
		return element;
	}
//***********************************************************************************************************************
	/**
	 * Método que retorna el [MobileElement] haciendo la búsqueda por AndroidUIAutomator.<br>
	 * En toda la App, hace Scroll.<br>
	 * Ver detalle en https://developer.android.com/reference/androidx/test/uiautomator/UiSelector
	 * 
	 * @param criteria Posibles valores los indicados en [BaseMobileApp.CRIT_]
	 * @param criteriaValue
	 */
	public MobileElement elementByCriteria(String criteria, String criteriaValue) {

		String selector = "new UiSelector()." + criteria + "(\"" + criteriaValue + "\").instance(0)";
		return this.elementByUIAutomator(selector, true); // [true] PARA QUE HAGA SCROLL
	}
	public MobileElement elementByCriteria(String criteria, String criteriaValue, int index) {

		String selector = "new UiSelector()." + criteria + "(\"" + criteriaValue + "\").instance(" + index + ")";
		return this.elementByUIAutomator(selector, true); // [true] PARA QUE HAGA SCROLL
	}
//***********************************************************************************************************************
	/**
	 * Retorna el MobileElement cuyo [xpath] corresponda al ingresado por parámetro. Si no es visible en el dispositivo
	 * hace scroll para ver si se encuentra, si no se encuentra retorna [null].
	 * 
	 * @author : Narli Betancourth
	 */
	public MobileElement elementByXpath(String xpath) {

		MobileElement element;
		try {
			element = this.driver.findElementByXPath(xpath);
			if (!element.isDisplayed())
				element = null;
		}
		catch (Exception e) {
			element = this.elementByCriteria(CRIT_RESOURCEID, xpath);
		}
		return element;
	}
//***********************************************************************************************************************
	/**
	 * Para que funcione el objeto debe estar visible en la aplicación, porque este método no hace scroll.
	 * 
	 * @param criteria Posibles valores cualquiera de los CRIT_... de esta clase.
	 * @param criteriaValue
	 */
	public MobileElement elementByCriteriaSinScroll(String criteria, String criteriaValue) {

		String selector = "new UiSelector()." + criteria + "(\"" + criteriaValue + "\")";
		return this.elementByUIAutomator(selector, false); // [false] PARA QUE NO HAGA SCROLL
	}
//***********************************************************************************************************************
	/**
	 * Retorna la lista de [MobileElement] cuyos [id] correspondan al ingresado.
	 */
	public List<MobileElement> elementsById(String id) {

		return this.driver.findElementsById(id);
	}
//***********************************************************************************************************************
	/**
	 * Retorna la lista de [MobileElement] cuyos [xPath] correspondan al ingresado.
	 * 
	 * @author Sebastian Correa
	 * @date 11/04/2022
	 * @param xpath
	 * @return lista de [MobileElement]
	 */
	public List<MobileElement> elementsByXpath(String xpath) {

		return this.driver.findElementsByXPath(xpath);
	}
//***********************************************************************************************************************
	/**
	 * Retorna la lista de [MobileElement] con [name] igual al ingresado.
	 */
	public List<MobileElement> elementsByName(String name) {

		return this.driver.findElementsByName(name);
	}
//***********************************************************************************************************************
	/**
	 * Retorna la lista de [MobileElement] con [className] igual al ingresado.
	 */
	public List<MobileElement> elementsByClassName(String className) {

		return this.driver.findElementsByClassName(className);
	}
//***********************************************************************************************************************
	/**
	 * Retorna la lista de [MobileElement] con [AccessibilityId] igual al ingresado.
	 */
	public List<MobileElement> elementsByAccessibilityId(String accId) {

		return this.driver.findElementsByAccessibilityId(accId);
	}
//***********************************************************************************************************************
	/**
	 * Método que retorna una lista de [MobileElement] haciendo la búsqueda por AndroidUIAutomator.<br>
	 * Ver detalle en https://developer.android.com/reference/androidx/test/uiautomator/UiSelector
	 * 
	 * @param criteria Posibles valores cualquiera de los CRIT_... de esta clase.
	 * @param criteriaValue
	 */
	public List<MobileElement> elementsByCriteria(String criteria, String criteriaValue) {

		String selector = "new UiSelector()." + criteria + "(\"" + criteriaValue + "\")";
		return this.driver.findElements(MobileBy.AndroidUIAutomator(selector));
	}
//***********************************************************************************************************************
	public String getContext() {

		return this.driver.getContext();
	}
//***********************************************************************************************************************
	public ArrayList<String> getContexts() {

		return new ArrayList<String>(this.driver.getContextHandles());
	}
//***********************************************************************************************************************
	public void changeContext(String nameContext) {

		this.driver.context(nameContext);
	}
//***********************************************************************************************************************
	/**
	 * Método que almacena la captura de pantalla de la APP en el archivo requerido.
	 * 
	 * @param nbFilePath = Debe venir con la ruta completa y la extensión de imagen deseada.
	 */
	public void saveScreenshot(String nbFilePath) {

		File dst = new File(nbFilePath);
		if (dst.exists())
			dst.delete(); // Lo borra en caso que exista
		File src = ((TakesScreenshot) this.driver).getScreenshotAs(OutputType.FILE);
		try {
			FileHandler.copy(src, dst);
		}
		catch (IOException e) {
			e.printStackTrace();
		}
	}
//***********************************************************************************************************************
	/**
	 * Mueve la pantalla del celular de las coordenadas [coord1] a las coordenadas [coord2]
	 * 
	 * @param coord1 Indica las coordenadas x, y iniciales
	 * @param coord2 Indica las coordenadas x, y finales
	 */
	@SuppressWarnings("rawtypes")
	public void doSwipe(int[] coord1, int[] coord2) {

		PointOption point1 = new PointOption();
		point1.withCoordinates(coord1[0], coord1[1]);
		PointOption point2 = new PointOption();
		point2.withCoordinates(coord2[0], coord2[1]);
		TouchAction ts = new TouchAction(this.driver);
		ts.press(point1).moveTo(point2).release().perform();
	}
	@SuppressWarnings("rawtypes")
	public void doClick(int coordX, int coordY) {

		PointOption point = new PointOption();
		point.withCoordinates(coordX, coordY);
		TouchAction ts = new TouchAction(this.driver);
		ts.press(point).release().perform();
	}
//***********************************************************************************************************************
	public void checkCheckBox(MobileElement checkBoxElement) {

		if (!checkBoxElement.isSelected())
			checkBoxElement.click();
	}
//***********************************************************************************************************************
	public void uncheckCheckBox(MobileElement checkBoxElement) {

		if (checkBoxElement.isSelected())
			checkBoxElement.click();
	}
//***********************************************************************************************************************
	public void clearInputbox(MobileElement element) {

		element.clear();
	}
//***********************************************************************************************************************
	/**
	 * Escribe el texto [inputText] en la caja de texto identificada por [element], borrando primero el contenido de la
	 * caja de texto.
	 */
	public void write(MobileElement element, String inputText) {

		this.clearInputbox(element);
		element.sendKeys(inputText);
	}
//***********************************************************************************************************************
	/**
	 * Escribe el texto [inputText] en la caja de texto identificada por [element] y adiciona un enter al final del
	 * texto, borrando primero el contenido de la caja de texto.
	 */
	public void writeAndEnter(MobileElement element, String inputText) {

		this.clearInputbox(element);
		element.sendKeys(inputText + Keys.ENTER);
	}
//***********************************************************************************************************************
	/**
	 * Escribe el texto [inputText] en la caja de texto identificada por [element], dejando el contenido existente en la
	 * caja de texto.
	 */
	public void writeNoClear(MobileElement element, String inputText) {

		element.sendKeys(inputText);
	}
//***********************************************************************************************************************
	/**
	 * Da click en el [element]
	 */
	public void click(MobileElement element) {

		element.click();
	}
//***********************************************************************************************************************
	/**
	 * Da click en el elemento cuyo atributo "text" sea igual a [nameButton], el elemento se considera como un Button.
	 */
	public void clickButton(String nameButton) {

		this.click(this.elementByCriteria(CRIT_TEXT, nameButton));
	}
//***********************************************************************************************************************
	/**
	 * Da click en el elemento cuyo atributo "text" sea igual a [nameButton] y cuyo index sea [indexButton], usar cuando
	 * existan varios elementos con el texto [nameButton], el elemento se considera como un Button.
	 */
	public void clickButton(String nameButton, int indexButton) {

		this.click(this.elementByCriteria(CRIT_TEXT, nameButton, indexButton));
	}
//***********************************************************************************************************************
	/**
	 * Espera a que se presente el elemento cuyo atributo "text" sea igual de forma exacta a [valText].<br>
	 * Retorna el objeto encontrado.
	 */
	public MobileElement waitObjectByText(String valText) {

		MobileElement objBuscado;
		do {
			objBuscado = this.elementByCriteria(CRIT_TEXT, valText);
		} while (objBuscado == null);
		return objBuscado;
	}
//***********************************************************************************************************************
	/**
	 * Espera a que se presente el elemento cuyo atributo "text" sea igual de forma exacta a [valText] y cuyo index sea
	 * [indexButton], usar cuando existan varios elementos con el texto [valText].<br>
	 * Retorna el objeto encontrado.
	 */
	public MobileElement waitObjectByText(String valText, int indexButton) {

		MobileElement objBuscado;
		do {
			objBuscado = this.elementByCriteria(CRIT_TEXT, valText, indexButton);
		} while (objBuscado == null);
		return objBuscado;
	}
//***********************************************************************************************************************
	/**
	 * Espera a que se presente el elemento cuyo atributo "text" sea igual a [nameButton] y le da click.<br>
	 * El elemento se considera como un Button.
	 */
	public void waitClickButton(String nameButton) {

		MobileElement objButton = this.waitObjectByText(nameButton);
		this.click(objButton);
	}
//***********************************************************************************************************************
	/**
	 * Espera a que se presente el elemento cuyo atributo "text" sea igual a [nameButton] y cuyo index sea [indexButton],
	 * usar cuando existan varios elementos con el texto [nameButton], y al encontrarlo le da click.<br>
	 * El elemento se considera como un Button.
	 */
	public void waitClickButton(String nameButton, int indexButton) {

		MobileElement objButton = this.waitObjectByText(nameButton, indexButton);
		this.click(objButton);
	}
//***********************************************************************************************************************
	/**
	 * Selecciona el elemento con texto [item] de la lista que se desplega al dar click en [objDato], en caso que no se
	 * presente el [item] de forma exacta, se selecciona el aquel que está contenido o que contenga el valor del [item]
	 * ignorando mayúsculas y acentos.<br>
	 * En caso que el elemento no se encuentre se retorna un [NoSuchElementException]<br>
	 * La lista que se muestra al dar click en [objDato] se identifica porque es de clase [android.widget.ListView]
	 * 
	 * @param objDato Es el elemento que al darle click despliega una lista de selección.
	 * @param item Texto de elemento a seleccionar de la lista.
	 */
	public void selectListItem(MobileElement objDato, String item) {

		String valActual = objDato.getText();
		if (Util.equalsIgnoreCaseAndAccents(valActual, item))
			return; // YA ESTÁ SELECCIONADO
		Util.wait(1);
		objDato.click(); // CLIC PARA QUE SE DESPLEGUE LA LISTA
		MobileElement elementList; // OBJETO QUE IDENTIFICA LA LISTA
		if (isAndroid) { // SI EL DISPOSITIVO ES ANDROID
			do { // ESPERA HASTA QUE SE DESPLEGUE LA LISTA
				elementList = this.elementByClassNameSinScroll("android.widget.ListView");
			} while (elementList == null);
		}
		else {// SI EL DISPOSITIVO ES IOS
			do { // ESPERA HASTA QUE SE DESPLEGUE LA LISTA
				elementList = this.elementByXpath("//XCUIElementTypeOther[@name=\"main\"]/XCUIElementTypeOther[5]");
			} while (elementList == null);
		}
		// EN EL SCREEN PRESENTADO, REVISA LA EXISTENCIA DEL [item]
		MobileElement objItem = null;
		List<MobileElement> listaElements;
		if (isAndroid)
			listaElements = this.elementsByCriteria(CRIT_TEXT_CONTAIN, item);
		else {
			do {
				listaElements = this
					.elementsByXpath("//XCUIElementTypeCollectionView/XCUIElementTypeCell/XCUIElementTypeButton");
			} while (listaElements.size() <= 0);
		}
		if (listaElements.size() > 0)
			objItem = listaElements.get(0); // RETORNA EL PRIMERO ENCONTRADO
		else
			objItem = this.buscarItemPorItem(item, false); // HACE BÚSQUEDA ELEMENTO A ELEMENTO
		if (objItem == null)
			throw new NoSuchElementException(
				"En 'selectListItem' -- elemento [" + item + "] NO presentado en la lista...");
		// SI LLEGA A ESTE PUNTO, SE PUEDE SELECCIONAR EL [item]
		objItem.click();
	}
//***********************************************************************************************************************
	/**
	 * Busca la lista de clase [android.widget.ListView], mueve el screen al inicio de la lista y empieza a buscar entre
	 * el texto de los elementos de clase [android.widget.CheckedTextView], si no encuentra el dato buscado mueve hacia
	 * abajo el screen hasta encontrarlo o hasta que ya no se pueda mover.<br>
	 * Si [buscarDatoExacto] es [true] el texto del elemento debe coincidir de forma exacta con [item]<br>
	 * En caso contrario el texto del elemento debe estar contenido o contener el valor del [item] ignorando mayúsculas y
	 * acentos.<br>
	 * Retorna el elemento que corresponda si se encuentra, en caso contrario el retorno es [null]
	 */
	// FUNCIONA PARA LAS LISTAS QUE CORRESPONDEN A LA CLASE
	// [android.widget.ListView]
	private MobileElement buscarItemPorItem(String item, boolean buscarDatoExacto) {

		MobileElement elementList = this.elementByClassNameSinScroll("android.widget.ListView");
		// PRIMERO SE DEJA AL INICIO DE LA LISTA
		this.swipeToStart(elementList);
		MobileElement objRet = null;
		List<MobileElement> items; // ELEMENTOS PRESENTADOS EN LA LISTA
		int totalItems;
		boolean hizoSwipe = false, itemEncontrado = false;
		String valItem;
		do {
			items = this.elementsByClassName("android.widget.CheckedTextView");
			totalItems = items.size();
			for (int i = 0; i < totalItems; i++) {
				valItem = items.get(i).getText();
				if (buscarDatoExacto)
					itemEncontrado = item.equals(valItem);
				else
					itemEncontrado = Util.containsIgnoreCaseAndAccents(valItem, item)
						|| Util.containsIgnoreCaseAndAccents(item, valItem);
				if (itemEncontrado) {
					objRet = items.get(i);
					if (!Util.equalsIgnoreCaseAndAccents(valItem, item))
						System.out.println("Valor seleccionado [" + valItem + "] porque es similar.");
					break; // TERMINA EL CICLO FOR
				}
			}
			if (!itemEncontrado) // SI NO SE HA ENCONTRADO SE MUEVE LA LISTA, PARA SEGUIR BUSCANDO
				hizoSwipe = this.swipeDown(elementList);
		} while (!itemEncontrado && hizoSwipe);
		return objRet;
	}
//***********************************************************************************************************************
	/**
	 * Selecciona exactamente el elemento con texto [item] de la lista que se desplega al dar click en [objDato]. La
	 * lista se identifica porque es de clase [android.widget.ListView]
	 * 
	 * @param objDato Es el elemento que al darle click despliega una lista de selección.
	 * @param item Texto de elemento a seleccionar de la lista.
	 */
	public void selectListItemExacto(MobileElement objDato, String item) {

		String valActual = objDato.getText();
		if (valActual.equals(item))
			return; // YA ESTÁ SELECCIONADO
		objDato.click(); // CLIC PARA QUE SE DESPLEGUE LA LISTA
		MobileElement elementList; // OBJETO QUE IDENTIFICA LA LISTA
		do { // ESPERA HASTA QUE SE DESPLEGUE LA LISTA
			elementList = this.elementByClassNameSinScroll("android.widget.ListView");
		} while (elementList == null);
		// EN EL SCREEN PRESENTADO, REVISA LA EXISTENCIA DEL [item] DE FORMA EXACTA
		MobileElement objItem = null;
		List<MobileElement> listaElements = this.elementsByCriteria(CRIT_TEXT, item);
		if (listaElements.size() > 0)
			objItem = listaElements.get(0); // RETORNA EL PRIMERO ENCONTRADO
		else
			objItem = this.buscarItemPorItem(item, true); // HACE BÚSQUEDA ELEMENTO A ELEMENTO
		if (objItem == null)
			throw new NoSuchElementException(
				"En 'selectListItemExacto' -- elemento [" + item + "]  NO presentado para la selección...");
		// SI LLEGA A ESTE PUNTO, SE PUEDE SELECCIONAR EL [item]
		objItem.click();
	}
//***********************************************************************************************************************
	/**
	 * Selecciona de forma aleatoria uno de los elementos presentados en la lista que se desplega al dar click en
	 * [objDato]. Este método funciona si los elementos que se desplegan corresponden a la clase
	 * [android.widget.CheckedTextView].
	 * 
	 * @param objDato Es el elemento que al darle click despliega una lista de selección.
	 * @param incluir1erItem Indica si el primer elemento se tiene en cuenta para la selección, en ocasiones el primer
	 * elemento es un "Seleccione" o vacíéo, por ende no debería tenerse en cuenta.
	 */
	public void selectListItemRandom(MobileElement objDato, boolean incluir1erItem) {

		// Aveces el primer elemento es un "Seleccione" o vacío
		int indexInic = 0;
		if (!incluir1erItem)
			indexInic = 1;
		objDato.click();
		List<MobileElement> items; // Elementos presentados en la lista
		int totalItems;
		do { // ESpera hasta que se desplegan los elementos a seleccionar
			items = this.elementsByClassName("android.widget.CheckedTextView");
			totalItems = items.size();
		} while (totalItems == 0);
		int index = Util.enteroRandom(indexInic, totalItems - 1);
		items.get(index).click();
	}
//***********************************************************************************************************************
	/**
	 * Se hace el ingreso completo de [item] en el campo [objDato], se presenta una lista predictiva de clase
	 * [android.widget.ListView], donde cada elemento es de clase [android.widget.TextView] y se selecciona el primer
	 * elemento que se presente. Si no se presenta la lista predictiva de clase [android.widget.ListView] se genera un
	 * [NoSuchElementException].
	 */
	public void selectPredictiveListItem(MobileElement objDato, String item) {

		this.setValueListPredictive(objDato, item, 0);
		// Selecciona el primer elemento, por eso la instancia se pone en (0), y que
		// empiece con [item]
		String selector = "new UiSelector().className(\"android.widget.TextView\").textStartsWith(\"" + item
			+ "\").instance(0)";
		this.elementByUIAutomator(selector, true).click(); // [true] PARA QUE HAGA SCROLL
	}
//***********************************************************************************************************************
	/**
	 * Se hace el ingreso de [item] desde el caracter 1 hasta el [predictiveLongitud] en el campo [objDato], se presenta
	 * una lista predictiva de clase [android.widget.ListView], donde cada elemento es de clase [android.widget.TextView]
	 * y se selecciona el elemento cuyo texto copleto corresponda a [item]. Si no se presenta la lista predictiva de
	 * clase [android.widget.ListView] se genera un [NoSuchElementException].
	 */
	public void selectPredictiveListItemExacto(MobileElement objDato, String item, int predictiveLongitud) {

		this.setValueListPredictive(objDato, item, predictiveLongitud);
		// Selecciona el elemento cuyo text sea [item]
		String selector = "new UiSelector().className(\"android.widget.TextView\").text(\"" + item + "\")";
		this.elementByUIAutomator(selector, true).click(); // [true] PARA QUE HAGA SCROLL
	}
//***********************************************************************************************************************
	// MÉTODO QUE DA CLICK EN EL ELEMENTO [objDato], INGRESA LA INFORMACIÓN DE
	// [item] DESDE EL CARACTER 1 HASTA EL
	// [predictiveLongitud], SI [predictiveLongitud] ES 0 LO INGRESA COMPLETO.
	// ESPERANDO QUE SE DESPLEGUE UNA LISTA
	// PREDICTIVA DE CLASE [android.widget.ListView], SI NO SE DESPLEGA SE GENERA UN
	// [NoSuchElementException].
	@SuppressWarnings("deprecation")
	private void setValueListPredictive(MobileElement objDato, String item, int predictiveLongitud) {

		objDato.click(); // Para dar foco al elemento
		String keysToSend = item;
		if (predictiveLongitud > 0)
			keysToSend = Util.left(item, predictiveLongitud);
		this.driver.getKeyboard().sendKeys(keysToSend);
		this.driver.navigate().back(); // Para que oculte el KeyBoard
		MobileElement objLista = this.elementByClassNameSinScroll("android.widget.ListView");
		if (objLista == null)
			throw new NoSuchElementException(
				"No se desplega un ListView para elementos que empiecen con [" + item + "]");
	}
//***********************************************************************************************************************
	@SuppressWarnings("deprecation")
	public void sendKeysByKeyBoard(CharSequence keysToSend) {

		this.driver.getKeyboard().sendKeys(keysToSend);
		// @DF this.driver.navigate().back(); //Para que oculte el KeyBoard
	}
//***********************************************************************************************************************
	/**
	 * Hace swipe al inicio : teniendo como referencia el [element], el swipe se hace sobre dicho elemento.
	 */
	public void swipeToStart(MobileElement element) {

		boolean hizoSwipe;
		do {
			hizoSwipe = this.swipeUp(element);
		} while (hizoSwipe);
	}
//***********************************************************************************************************************
	/**
	 * Hace swipe al inicio, haciendo el arrastre desde la mitad de la pantalla hasta el final.
	 */
	public void swipeToStart() {

		Dimension size = this.getDriver().manage().window().getSize();
		int startX = (int) (size.width * 0.01); // TOMA DESDE EL EXTREMO IZQUIERDO
		// SE TOMA DEL 1/4 DE LA PANTALLA HACIA EL FINAL, PERO SI SE CUENTA CON
		// COORDENADA [Y] DEL INICIO DEL CONTENIDO
		// SE USA ESTE VALOR
		int startY = (int) (size.height * 0.25);
		if (this.coordYStartContenido != 0)
			startY = this.coordYStartContenido;
		int endY = (int) (size.height * 0.95);
		String sourceIni, sourceFin = this.getDriver().getPageSource();
		do {
			sourceIni = sourceFin;
			this.doSwipe(new int[] { startX, startY }, new int[] { startX, endY });
			sourceFin = this.getDriver().getPageSource();
		} while (!sourceIni.equals(sourceFin)); // HIZO SWIPE SI LOS SOURCE INICIAL Y FINAL SON DIFERENTES, CONTINÚA
	}
//***********************************************************************************************************************
	/**
	 * Hace swipe a la derecha del Screen, haciendo el arrastre de derecha a izquierda.<br>
	 * La coordenada [Y] se ubica en la mitad de la pantalla.
	 */
	public void swipeToRight() {

		Dimension size = this.getDriver().manage().window().getSize();
		int startX = (int) (size.width * 0.9); // TOMA DESDE EL EXTREMO DERECHO
		int endX = (int) (size.height * 0.1); // HASTA EL EXTREMO IZQUIERADO
		// SE TOMA LA MITAD DE LA PANTALLA PARA LA COORDENADA [Y]
		int startY = (int) (size.height * 0.5);
		String sourceIni, sourceFin = this.getDriver().getPageSource();
		do {
			sourceIni = sourceFin;
			this.doSwipe(new int[] { startX, startY }, new int[] { endX, startY });
			sourceFin = this.getDriver().getPageSource();
		} while (!sourceIni.equals(sourceFin)); // HIZO SWIPE SI LOS SOURCE INICIAL Y FINAL SON DIFERENTES, CONTINÚA
	}
//***********************************************************************************************************************
	/**
	 * Hace swipe al final : teniendo como referencia el [element], el swipe se hace sobre dicho elemento.
	 */
	public void swipeToEnd(MobileElement element) {

		boolean hizoSwipe;
		do {
			hizoSwipe = this.swipeDown(element);
		} while (hizoSwipe);
	}
//***********************************************************************************************************************
	/**
	 * Hace swipe al final, haciendo el arrastre desde la mitad de la pantalla hasta el inicio.
	 */
	public void swipeToEnd() {

		Dimension size = this.getDriver().manage().window().getSize();
		int startX = (int) (size.width * 0.01); // TOMA DESDE EL EXTREMO IZQUIERDO
		int startY = (int) (size.height * 0.75); // DE 3/4 DE LA PANTALLA HACIA EL INICIO
		int endY = (int) (size.height * 0.05);
		String sourceIni, sourceFin = this.getDriver().getPageSource();
		do {
			sourceIni = sourceFin;
			this.doSwipe(new int[] { startX, startY }, new int[] { startX, endY });
			sourceFin = this.getDriver().getPageSource();
		} while (!sourceIni.equals(sourceFin)); // HIZO SWIPE SI LOS SOURCE INICIAL Y FINAL SON DIFERENTES, CONTINÚA
	}
	
	/**
	 * Hace swipe al final, haciendo el arrastre desde la mitad de la pantalla hasta el inicio.
	 * tiempo de espera maximo de 5 segundos.
	 */
	public void swipeToEnd2() {
	    Dimension size = this.getDriver().manage().window().getSize();
	    int startX = (int) (size.width * 0.01); // TOMA DESDE EL EXTREMO IZQUIERDO
	    int startY = (int) (size.height * 0.75); // DE 3/4 DE LA PANTALLA HACIA EL INICIO
	    int endY = (int) (size.height * 0.05);
	    String sourceIni, sourceFin = this.getDriver().getPageSource();

	    long startTime = System.currentTimeMillis(); // Tiempo de inicio
	    long timeout = 5000; // Tiempo máximo en milisegundos

	    do {
	        sourceIni = sourceFin;
	        this.doSwipe(new int[] { startX, startY }, new int[] { startX, endY });
	        sourceFin = this.getDriver().getPageSource();

	        Util.wait(1); // Espera de 1 segundo entre swipes

	        if (System.currentTimeMillis() - startTime > timeout) {
	            break; // Salir del bucle si se excede el tiempo de espera
	        }
	    } while (!sourceIni.equals(sourceFin)); // Continúa hasta que los contenidos sean iguales
	}
//***********************************************************************************************************************
	/**
	 * Swipe 1 vez hacia arriba : teniendo como referencia el [element] el cual debe ser un [android.widget.ListView]<br>
	 * Retorna [true] si se pudo hacer el swipe, en caso contrario retorna [false].
	 */
	public boolean swipeUp(MobileElement element) {

		int xSup = element.getLocation().getX();
		int ySup = element.getLocation().getY();
		int width = element.getSize().getWidth();
		int height = element.getSize().getHeight();
		int x = xSup + (int) (width / 2); // LO UBICA EN LA MITAD
		int y = ySup + height;
		String sourceIni = this.getDriver().getPageSource();
		this.doSwipe(new int[] { x, ySup }, new int[] { x, y });
		String sourceFin = this.getDriver().getPageSource();
		return !sourceIni.equals(sourceFin); // SI SON DIFERENTES, SE PUDO HACER EL SWIPE
	}
//***********************************************************************************************************************
	/**
	 * Swipe 1 vez hacia abajo : teniendo como refrencia el [element] el cual debe ser un [android.widget.ListView]<br>
	 * Retorna [true] si se pudo hacer el swipe, en caso contrario retorna [false].
	 */
	public boolean swipeDown(MobileElement element) {

		int xSup = element.getLocation().getX();
		int ySup = element.getLocation().getY();
		int width = element.getSize().getWidth();
		int height = element.getSize().getHeight();
		int x = xSup + (int) (width / 2); // LO UBICA EN LA MITAD
		int y = ySup + height;
		String sourceIni = this.getDriver().getPageSource();
		this.doSwipe(new int[] { x, y }, new int[] { x, ySup });
		String sourceFin = this.getDriver().getPageSource();
		return !sourceIni.equals(sourceFin); // SI SON DIFERENTES, SE PUDO HACER EL SWIPE
	}
//***********************************************************************************************************************
	/**
	 * Swipe 1 vez hacia abajo : haciendo el arrastre desde la mitad de la pantalla hasta el inicio.<br>
	 * Retorna [true] si se pudo hacer el swipe, en caso contrario retorna [false].
	 */
	public boolean swipeDown() {

		Dimension size = this.getDriver().manage().window().getSize();
		int startX = (int) (size.width * 0.01); // TOMA DESDE EL EXTREMO IZQUIERDO
		int startY = (int) (size.height * 0.75); // DE 3/4 DE LA PANTALLA HACIA EL INICIO
		int endY = (int) (size.height * 0.05);
		String sourceIni = this.getDriver().getPageSource();
		this.doSwipe(new int[] { startX, startY }, new int[] { startX, endY });
		String sourceFin = this.getDriver().getPageSource();
		return (!sourceIni.equals(sourceFin)); // SI SON DIFERENTES, SE PUDO HACER EL SWIPE
	}
//***********************************************************************************************************************
	/* public void swipeUpUntilTextExists(String expectedText, int howManyTimesToSwipe) { int i = 0; do { swipeUP(); i++;
	 * if (i == howManyTimesToSwipe) break; } while (!driver.getPageSource().contains(expectedText)); }
	 * 
	 * public void swipeUP () { Dimension size = driver.manage (). window (). getSize (); log.info (size); // calcular
	 * coordenadas para deslizar vertical int startVerticalY = (int) (size.height * 0.8); int endVerticalY = (int)
	 * (size.height * 0.2); int startVerticalX = (int) (size.width / 2); nuevo TouchAction (driver) .press (point
	 * (startVerticalX, startVerticalY)). waitAction (waitOptions (ofSeconds (3))). moveTo (point (startVerticalX,
	 * endVerticalY)). release (). perform (); } */
//***********************************************************************************************************************
	/**
	 * Muestra en pantalla el texto de los elementos existentes en la App y que corresponden a la clase [className]
	 */
	public void mostrarByClassName(String className) {

		List<MobileElement> elements = this.driver.findElementsByClassName(className);
		System.out.println("\n==================================================");
		System.out.println("ELEMENTOS DE LA CLASE [" + className + "]");
		for (MobileElement elem : elements) {
			System.out.println("Text [" + elem.getText() + "]");
		}
		System.out.println("==================================================\n");
	}
//***********************************************************************************************************************
	// TODO LOS SIGUIENTES SON MÉTODOS DE PRUEBA, PARA BORRAR
	public void scroll1Down() {

		String scrollSelector = "new UiScrollable(new UiSelector().resourceId(\"android:id/content\")).scrollForward()";
		// String scrollSelector = "new UiScrollable(new
		// UiSelector().scrollable(true).instance(0)).scrollForward()";
		try {
			this.driver.findElement(MobileBy.AndroidUIAutomator(scrollSelector));
		}
		catch (InvalidSelectorException e) {} // IGNORAR, SIEMPRE SALE
	}
	public void scroll1Up() {

		String scrollSelector = "new UiScrollable(new UiSelector().resourceId(\"android:id/content\")).scrollBackward()";
		// String scrollSelector = "new UiScrollable(new
		// UiSelector().scrollable(true).instance(0)).scrollBackward()";
		try {
			this.driver.findElement(MobileBy.AndroidUIAutomator(scrollSelector));
		}
		catch (InvalidSelectorException e) {} // IGNORAR, SIEMPRE SALE
	}
	public void scrollDown() {

		System.out.println("INICIO scrollDown : " + Util.hourToString("HH:mm:ss"));
		String sourceIni, sourceFin;
		do {
			sourceIni = this.getDriver().getPageSource();
			this.scroll1Down();
			sourceFin = this.getDriver().getPageSource();
		} while (!sourceIni.equals(sourceFin)); // HIZO SWIPE SI LOS SOURCE INICIAL Y FINAL SON DIFERENTES, CONTINÚA
		System.out.println("FIN scrollDown : " + Util.hourToString("HH:mm:ss"));
	}
	public void scrollUp() {

		System.out.println("INICIO scrollUp : " + Util.hourToString("HH:mm:ss"));
		String sourceIni, sourceFin;
		do {
			sourceIni = this.getDriver().getPageSource();
			this.scroll1Up();
			sourceFin = this.getDriver().getPageSource();
		} while (!sourceIni.equals(sourceFin)); // HIZO SWIPE SI LOS SOURCE INICIAL Y FINAL SON DIFERENTES, CONTINÚA
		System.out.println("FIN scrollUp : " + Util.hourToString("HH:mm:ss"));
	}
	public void scrollZea2() {

		String scrollSelector = "new UiScrollable(new UiSelector().scrollable(true).instance(0)).scrollToBeginning(10)";
		try {
			this.driver.findElement(MobileBy.AndroidUIAutomator(scrollSelector));
		}
		catch (InvalidSelectorException e) {
			System.out.println("Entra2 a InvalidSelectorException");
			// ignore
		}
		catch (Exception e) {
			System.out.println("Entra2 a Exception");
		}
	}
	public void ZEAexample() throws InterruptedException {

		// MobileBy.AndroidUIAutomator(uiautomatorText)
		// MobileBy.IosUIAutomation(iOSAutomationText)
		// driver.findElementByAndroidUIAutomator ("nuevo UiScrollable (nuevo UiSelector
		// ()). scrollIntoView (texto (" Ingrese su elemento "))");
		// ----------------------------------------------------------
		//
		String your_id = "";
		Dimension tamanno;
		while (driver.findElementsById(your_id).size() == 0) {
			tamanno = this.driver.manage().window().getSize();
			int starty = (int) (tamanno.height * 0.80);
			int endy = (int) (tamanno.height * 0.20);
			int startx = tamanno.width / 2;
			System.out.println("starty =" + starty + ", endy =" + endy + ", startx =" + startx);
			// driver.swipe (startx, starty, startx, endy, 3000);
			Thread.sleep(2000);
			// driver.swipe (startx, endy, startx, starty, 3000);
			Thread.sleep(2000);
		}
	}
//***********************************************************************************************************************
	/**
	 * @autor: Narli Yuliana Betancourth Hernandez Retorna el MobileElement cuyo [xpath] corresponda al ingresado por
	 * parámetro. no hace scroll
	 */
	public MobileElement elementByXpathSinScroll(String xpath) {

		MobileElement element;
		try {
			element = this.driver.findElementByXPath(xpath);
			if (!element.isDisplayed())
				element = null;
		}
		catch (Exception e) {
			element = null;
			// element = this.elementByCriteriaSinScroll(CRIT_RESOURCEID, xpath);
		}
		return element;
	}
//***********************************************************************************************************************
	/**
	 * @author Sebastian Vargas Jimenez Método encargado de realizar un scroll down en dispositivos IOS (Hay que revisar
	 * el script correspondiente en Android para unificar el método mediante la variable "isAndroid")
	 */
	public void scrollDownIOS() {

		HashMap<String, String> scrollObject = new HashMap<>();
		JavascriptExecutor js = this.getDriver();
		scrollObject.put("direction", "down");
		js.executeScript("mobile: scroll", scrollObject);
	}
//***********************************************************************************************************************
	/**
	 * @author Narli Yuiliana Betancourth Hernandez Escribe el texto [inputText] en la caja de texto identificada por
	 * [element] a través del teclado del dispositivo.
	 */
	@SuppressWarnings("deprecation")
	public void writeWithKeyboard(MobileElement element, String inputText) {

		element.click(); // Para dar foco al elemento
		this.driver.getKeyboard().sendKeys(inputText);
		this.driver.navigate().back(); // Para que oculte el KeyBoard
	}
//***********************************************************************************************************************
	/**
	 * Indica si el [element] está desplegado en la aplicación.
	 * 
	 * @param element
	 * @return
	 */
	public boolean isDisplayed(MobileElement element) {

		boolean esta;
		try {
			esta = element.isDisplayed();
		}
		catch (NoSuchElementException e) {
			esta = false;
		}
		return esta;
	}
//***********************************************************************************************************************
	/**
	 * @author Sebastian Abdul Correa Mendez Escribe el texto [inputText] en la caja de texto identificada por [element]
	 * a través del teclado del dispositivo caracter por caracter, se utiliza en campos donde se tiene que escribir dato
	 * por dato. back en true si requiere ocultar el teclado una vez haya terminado de escribir
	 */
	@SuppressWarnings("deprecation")
	public void writeWithKeyboardcharXchar(MobileElement element, String inputText, boolean back) {

		element.click(); // Para dar foco al elemento
		int longinputText = inputText.length();
		for (int pos = 0; pos < longinputText; pos++) {
			this.driver.getKeyboard().sendKeys(String.valueOf(inputText.charAt(pos)));
		}
		if (back)
			this.driver.navigate().back(); // Para que oculte el KeyBoard
	}
//***********************************************************************************************************************
	/**
	 * @autor: Narli Yuliana Betancourth Hernandez Hace swipe a la derecha del Screen, haciendo el arrastre de derecha a
	 * izquierda.<br>
	 * La coordenada [Y] se ubica en la primera parte superior de la pantalla, por eso se multiplica por 0.25.
	 */
	public boolean swipeToRightParteSuperiorAPP() {

		Dimension size = this.getDriver().manage().window().getSize();
		int startX = (int) (size.width * 0.9); // TOMA DESDE EL EXTREMO DERECHO
		int endX = (int) (size.height * 0.1); // HASTA EL EXTREMO IZQUIERADO
		// SE TOMA LA MITAD DE LA PANTALLA PARA LA COORDENADA [Y]
		int startY = (int) (size.height * 0.25);
		String sourceIni, sourceFin = this.getDriver().getPageSource();
		sourceIni = sourceFin;
		this.doSwipe(new int[] { startX, startY }, new int[] { endX, startY });
		sourceFin = this.getDriver().getPageSource();
		return (!sourceIni.equals(sourceFin));
		// HIZO SWIPE SI LOS SOURCE INICIAL Y FINAL SON DIFERENTES, CONTINÚA
	}
//************************************************************************************************************************
	/**
	 * @author Narli Betancourth :Swipe la cantidad de scroll que ingresa por variable hacia abajo : teniendo como
	 * refrencia el [element] el cual debe ser un [android.widget.ListView]<br>
	 * Retorna [true] si se pudo hacer el swipe, en caso contrario retorna [false].
	 */
	public boolean swipeDownVariosScroll(MobileElement element, int cantScroll) {

		int xSup, ySup, width, height, x, y;
		String sourceIni = "", sourceFin = "";
		// Hace el scroll la cantidad de veces que viene por parametro
		for (int i = 1; i < cantScroll; i++) {
			try {
				xSup = element.getLocation().getX();
				ySup = element.getLocation().getY();
				width = element.getSize().getWidth();
				height = element.getSize().getHeight();
				x = xSup + (int) (width / 2); // LO UBICA EN LA MITAD
				y = ySup + height;
				sourceIni = this.getDriver().getPageSource();
				this.doSwipe(new int[] { x, y }, new int[] { x, ySup });
				sourceFin = this.getDriver().getPageSource();
			}
			catch (Exception e) {
				break;
			}
		}
		return !sourceIni.equals(sourceFin); // SI SON DIFERENTES, SE PUDO HACER EL SWIPE
	}
//***********************************************************************************************************************
	/**
	 * @author Narli Betancourth Método de apoyo que imprime en consola todos los elementos existentes en que
	 * correspondan a [xpath] si este dato viene VACÍO imprime todos los existentes.
	 * 
	 */
	public void printAllElements(String xpath) {

		List<MobileElement> elements = this.countAllElements(xpath);
		int cont = 1;
		String tagName;
		for (MobileElement element : elements) {
			tagName = element.getAttribute("text");
			try {
				if (tagName.equalsIgnoreCase("SPAN"))
					Reporter.writeOnlyConsole(cont++ + " [" + tagName + " - " + element.getAttribute("class") + "]");
				else if (tagName.equalsIgnoreCase("A"))
					Reporter.writeOnlyConsole(cont++ + " [" + tagName + " - " + element.getText() + "]");
				else
					Reporter.writeOnlyConsole(cont++ + " [" + tagName + " - " + element.getAttribute("id") + "]");
			}
			catch (Exception e) {
				Reporter.writeOnlyConsole(cont++ + " [" + tagName + "]");
			}
		}
	}
//-----------------------------------------------------------------------------------------------------------------------
	public List<MobileElement> countAllElements(String xpath) {

		if (xpath.isEmpty())
			xpath = "//*"; // Busca todo
		List<MobileElement> elements = this.findElements(By.xpath(xpath));
		Reporter.writeOnlyConsole("Se encontraron [" + elements.size() + "] elementos...");
		return elements;
	}
	/**
	 * Retorna una lista de Mobile Element que corresponden al [locator] dado.
	 */
	public List<MobileElement> findElements(By locator) {

		return this.driver.findElements(locator);
	}
//***********************************************************************************************************************
	/**
	 * Método que retorna el anterior o siguiente elemento encontrado a partir del [txtLabel] ingresado por párametro, si
	 * [nextElement] viene en true, retorna el siguiente elemento, de lo contrario retorna el anterior
	 * 
	 * @param txtLabel String que indica el texto del label a búscar
	 * @param nextElement boleano que indica si es el siguiente elemento
	 * @return MobileElement
	 * @author Narli Betancourth
	 */
	public MobileElement getNextOrPreviousElementByLabel(String txtLabel, boolean nextElement) {

		MobileElement nextOrPreviousElement = null;
		Util.wait(3);
		List<MobileElement> elements = this.countAllElements("");
		String tagName = "";
		for (int i = elements.size(); i > 0; i--) {
			try {
				tagName = "";
				tagName = elements.get(i).getAttribute("text");
				if (tagName.contains(txtLabel)) {
					if (nextElement)
						nextOrPreviousElement = elements.get(i + 1);
					else
						nextOrPreviousElement = elements.get(i - 1);
					break;
				}
			}
			catch (Exception e) {}
		}
		return nextOrPreviousElement;
	}
// **********************************************************************************************************************
	/**
	 * Método Getter para la variable isAndroid; variable que define si el ambiente de ejecución es Android(<b>TRUE</b>)
	 * o IOS(<b>FALSE</b>).
	 * 
	 * @author Sebastian Vargas Jimenez (svarjim)
	 */
	public boolean isAndroid() {
		return this.isAndroid;
	}
	
// **********************************************************************************************************************
	
	/**
	 * 
	 * Metodo closeAllApp: Su Proposito es cerrar el App Actual, cerrando Driver Nativo (BaseMobileApp) y el Driver del Contexto Web (BasePageWeb) si llegase Aplicar.
	 * 
	 * @date 13/02/2024
	 * 
	 * @author DAARUBIO
	 * 
	 */
	
	public void closeAllApp() {
		
// -----------------------------------------------------------------------------------------------------------------------		  
// Realiza el Cierre del Drive Nativo (BaseMobileApp) del App.
		
		this.getDriver().quit();
// -----------------------------------------------------------------------------------------------------------------------		  
// Valida si Existe Contexto Web en el App, si es asi, cierra el Driver del Contexto Web (BasePageWeb) del App.
		
		if (pageWebContext != null) {
			pageWebContext.getDriver().quit();
			pageWebContext = null;
		}
		
	}
//***********************************************************************************************************************	
	
	/**
	 * 
	 * Metodo reanudarAppEstadoActualByAndroid: Su Proposito es reanudar el App en el Estado que se encontraba (Primer Plano - Sin Reiniciar App o Flujo), por medio del "Activity Manager" de Android. <br>
	 * 
	 * <br> Nota: Este metodo, solo aplica para SO Android, ya que se basa en parte de SDK de Android (adb) y "Activity Manager" que corresponde a Android.  <br>
	 * 
	 * @param appPackage - Object - appPackage del App.
	 * 
	 * @date 24/06/2024
	 * 
	 * @author DAARUBIO
	 * 
	 */
	
	public void reanudarAppEstadoActualByAndroid (Object appPackage) throws IOException {
		
		try {
			
			String comandoADB = "adb shell am start -n " + appPackage.toString() + "/.MainActivity"; // Construye el Comando adb.
			
			Runtime.getRuntime().exec(comandoADB); // Ejecuta Comando.
			
		} catch (Exception e) {
			  e.printStackTrace();
		}
		
	}
//***********************************************************************************************************************	
	
	/**
	 * 
	 * Metodo transferirArchivoDesdeMobileAPcByAndroid: Su Proposito es Transferir un Archivo almacenado en el Mobile al Pc (El Archivo No es Eliminado del Mobile). <br>
	 * 
	 * <br> Nota: Este metodo, solo aplica para SO Android, ya que se basa en parte de SDK de Android (adb).  <br>
	 * 
	 * @param rutaOrigenMobile - String - Ruta Origen donde se encuentra almacenado el Archivo en el Mobile.
	 * @param rutaDestinoPc    - String - Ruta Destino donde se desea almacenar el Archivo en el Pc.
	 * 
	 * @date 27/06/2024
	 * 
	 * @author DAARUBIO
	 * 
	 */
	
	public void transferirArchivoDesdeMobileAPcByAndroid(String rutaOrigenMobile, String rutaDestinoPc) {
		
	
		try {
			
			String comandoADB = "adb pull " + "\"" + rutaOrigenMobile + "\"" + " " + "\"" + rutaDestinoPc + "\"";  // Construye el Comando adb.
            
            Process process = Runtime.getRuntime().exec(comandoADB); // Ejecuta el Proceso.

            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream())); // Obtiene el Resultado del Proceso Ejecutado.
            
            String line;
            
            while ((line = reader.readLine()) != null) { // Valida el Resultado del Proceso Ejecutado.
            	
            	if (Util.containsIgnoreCaseAndAccents(line, "1 file pulled"))
            		 Reporter.write("Archivo Transferido desde Mobile al Pc Exitosamente. " + line);
            	else
            		 Reporter.write("Archivo No Transferido desde Mobile al Pc. " + line);
            }

            process.waitFor(); // Espera a que Finalice el Proceso.

        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
		
	}
//***********************************************************************************************************************	
	/* public boolean isDisplayedElementById(String id) { try { MobileElement element = this.elementById(id); return
	 * element.isDisplayed(); } catch (NoSuchElementException e) { return false; } } public boolean
	 * isDisplayedElementByName(String name) { try { MobileElement element = this.elementByName(name); return
	 * element.isDisplayed(); } catch (NoSuchElementException e) { return false; } } public boolean
	 * isDisplayedElementByClassName(String className) { try { MobileElement element =
	 * this.elementByClassName(className); return element.isDisplayed(); } catch (NoSuchElementException e) { return
	 * false; } } public boolean isDisplayedElementByAccessibilityId(String accId) { try { MobileElement element =
	 * this.elementByAccessibilityId(accId); return element.isDisplayed(); } catch (NoSuchElementException e) { return
	 * false; } } */
//***********************************************************************************************************************
}
