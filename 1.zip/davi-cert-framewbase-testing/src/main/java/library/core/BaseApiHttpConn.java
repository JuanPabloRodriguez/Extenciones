package library.core;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.util.Map;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;

import org.json.JSONObject;

/**
 * Clase para hacer conexiones y poder usar APIs.<br>
 * <p>En caso de hacer uso de APIs que requieran certificado de seguridad se debe invocar:
 * <b>BaseApiHttpConn.loadCertified(nbFileCertP12, claveCert, nbFileCacerts);</b><br>
 * <p>Se recomienda hacer uso de la siguiente secuencia:<br>
 * 1- BaseApiHttpConn api = new BaseApiHttpConn(url, type, requestMethod);<br>
 * 2- api.loadConnection();<br>
 * 3- api.setBody(mapBody); // El mapBody debe ser de tipo Map[String,Object] definido previamente<br>
 * 4- String res = api.getResponse(); / JSONObject jsonResp = api.getResponseAsJson();<br>
 * @author smzealo
 */
public class BaseApiHttpConn {

	public final static String CONTENT_TYPE_JSON = "json";
	public final static String CONTENT_TYPE_XML  = "xml";
	public final static String CONTENT_TYPE_URL  = "urlencoded";
	
	private String endPoint;
	private String contentType;
	private String requestMethod;
	protected HttpURLConnection connection = null;
	private boolean responseLoaded;
//***********************************************************************************************************************
	/**
	 * Constructor de la BaseApiHttpConn<br>
	 * Para adicionar otras configuraciones, sobreescribir método <b>protected void loadOtherSettingsConn()</b>
	 * @param endPoint : URL de conexión
	 * @param type : Tipo de contenido del API (BaseApiHttpConn.CONTENT_TYPE_JSON / BaseApiHttpConn.CONTENT_TYPE_XML /
	 *               BaseApiHttpConn.CONTENT_TYPE_URL)
	 * @param requestMethod : GET / POST / HEAD / OPTIONS / PUT / DELETE / TRACE 
	 */
	public BaseApiHttpConn(String endPoint, String type, String requestMethod) {
		this.endPoint = endPoint;
		this.contentType = type;
		this.requestMethod = requestMethod;
	}
//***********************************************************************************************************************
	/**
	 * Método estático que se usa para cargar en JAVA los certificados de seguridad que se requieran.<br>
	 * Este método se sabe que debe ser usado porque se presenta excepción <b>javax.net.ssl.SSLHandshakeException: 
	 * Received fatal alert: handshake_failure</b> al momento de usar la API.
	 * @param nbFileCertP12 - Archivo P12 del certificado (con path y nombre del archivo)
	 * @param claveCert - Clave del certificado
	 * @param nbFileCacerts - Archivo "cacerts" de seguridad del JRE (con path y nombre del archivo) 
	 */
	public static void loadCertified(String nbFileCertP12, String claveCert, String nbFileCacerts) throws Exception {

		System.setProperty("http.protocols", "TLSv1.2");
		System.setProperty("javax.net.ssl.trustStore", nbFileCacerts);
		// CARGA INFORMACIÓN DEL ARCHIVO P12, CON SU CLAVE
		KeyStore keyStore = KeyStore.getInstance("PKCS12");
		char[] password = claveCert.toCharArray();
		keyStore.load(new FileInputStream(nbFileCertP12), password);
		// INDICAR EL ALGORITMO USADO (CAMBIAR SI SE REQUIERE)
		KeyManagerFactory keyManagerFactory = KeyManagerFactory.getInstance("SunX509");
		keyManagerFactory.init(keyStore, password);
		// INDICAR EL PROTOCOLO USADO (CAMBIAR SI SE REQUIERE)
		SSLContext sslContext = SSLContext.getInstance("TLS");
		sslContext.init(keyManagerFactory.getKeyManagers(), null, null);
		// CAMBIAR EL PROTOCOLO DE CONEXIÓN
		HttpsURLConnection.setDefaultSSLSocketFactory(sslContext.getSocketFactory());
	}
//***********************************************************************************************************************
	/**
	 * Retorna el valor del content type que se debe setear dependiendo del content type con el que nace la instancia.
	 */
	private String getValueContentType() {
		String valueContentType = null;
		switch (this.contentType) {
			case CONTENT_TYPE_JSON:
				valueContentType = "application/json";
			break;
			case CONTENT_TYPE_XML:
				valueContentType = "text/xml";
			break;
			case CONTENT_TYPE_URL:
				valueContentType = "application/x-www-form-urlencoded";
			break;
		}
		return valueContentType;
	}
//***********************************************************************************************************************
	/**
	 * Este método se encarga de abrir la conexión al end point correspondiente.<br>
	 * Setea una configuración básica requerida, invoca al método <b>[loadOtherSettingsConn]</b> para cargar
	 * configuraciones o request properties adicionales.
	 */
	public void loadConnection() throws Exception {

		URL url = new URL(this.endPoint);
		connection = (HttpURLConnection) url.openConnection();
		connection.setDoOutput(true); // REQUERIDO : cannot write to a URLConnection if doOutput=false
		//connection.setInstanceFollowRedirects(false);
		connection.setRequestMethod(this.requestMethod);
		connection.setRequestProperty("Accept", "application/json");
		connection.setRequestProperty("Content-Type", this.getValueContentType());
		//connection.setUseCaches(false);
		// CARGA OTROS REQUEST PROPERTIES U OTRAS CONFIGURACIONES DE LA CONEXIÓN
		this.loadOtherSettingsConn();
        this.responseLoaded = false; // NO SE HA CARGADO EL RESPONSE
	}
//***********************************************************************************************************************
	/**
	 * Según el <b>Content Type</b> con el que se crea la instancia del API, se carga el body a la conexión.
	 * @param mapBody - Con cada uno d elos parámetros que se desean cargar.
	 * @throws IOException - En caso que el Content Type no contemple envío de body.
	 */
	public void setBody(Map<String,Object> mapBody) throws IOException {
		
		OutputStream outputStream = connection.getOutputStream();
		if (this.contentType.equals(CONTENT_TYPE_JSON)) {
			JSONObject requestBody = new JSONObject();
			for (String nbParam : mapBody.keySet()) {
				requestBody.put(nbParam, mapBody.get(nbParam));
			}
			outputStream.write(requestBody.toString().getBytes());
		}
//-----------------------------------------------------------------------------------------------------------------------        
		else if (this.contentType.equals(CONTENT_TYPE_URL)) {
			String urlParams = "";
			for (String nbParam : mapBody.keySet()) {
				if (!urlParams.isEmpty())
					urlParams += "&";
				urlParams += nbParam + "=" + mapBody.get(nbParam);
			}
			outputStream.write(urlParams.getBytes(StandardCharsets.UTF_8));
		}
//-----------------------------------------------------------------------------------------------------------------------        
		else
			throw new IOException("ERROR BaseApiHttpConn -- Content type [" + this.contentType
				+ "] NO CONTEMPLADO en método [setBody]");
//-----------------------------------------------------------------------------------------------------------------------        
        outputStream.flush();
        outputStream.close();
	}
//***********************************************************************************************************************
	/**
	 * Retorna el response de la conexión como un String.
	 * @throws IOException En caso que no haya una respuesta positiva (ResponseCode != 200)
	 */
	public String getResponse() throws IOException {
		
		if (connection.getResponseCode() != 200)
			throw new IOException("ERROR BaseApiHttpConn -- [" + connection.getResponseCode() + "] "
				+ connection.getResponseMessage());
		if (this.responseLoaded)
			throw new IOException("ERROR BaseApiHttpConn -- Ya fue invocado el getResponse");
		// SI LLEGA A ESTE PUNTO SÍ HUBO CONEXIÓN CORRECTA Y PUEDE RETORNAR LA RESPUESTA
		BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
		StringBuilder responseBuilder = new StringBuilder();
		String line;
		while ((line = reader.readLine()) != null) {
			responseBuilder.append(line);
		}
		String response = responseBuilder.toString();
		this.responseLoaded = true;
		return response;
	}
//***********************************************************************************************************************
	/**
	 * Retorna el response de la conexión como un JSONObject<br>
	 * Es útil para poder acceder a los datos retornados por el API así:<br><b>
	 * JSONObject jsonResponse = api.getResponseAsJson();<br>
	 * jsonResponse.getString("name_parameter");</b>
	 * @throws IOException En caso que no haya una respuesta positiva (ResponseCode != 200)
	 */
	public JSONObject getResponseAsJson() throws IOException {
		
		if (connection.getResponseCode() != 200)
			throw new IOException("ERROR BaseApiHttpConn -- [" + connection.getResponseCode()+ "] " + connection.getResponseMessage());
		if (this.responseLoaded)
			throw new IOException("ERROR BaseApiHttpConn -- Ya fue invocado el getResponse");
		// SI LLEGA A ESTE PUNTO SÍ HUBO CONEXIÓN CORRECTA Y PUEDE RETORNAR LA RESPUESTA
		BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
		StringBuilder responseBuilder = new StringBuilder();
		String line;
		while ((line = reader.readLine()) != null) {
			responseBuilder.append(line);
		}
		String response = responseBuilder.toString();
		this.responseLoaded = true;
		return new JSONObject(response);
	}
//***********************************************************************************************************************
	/**
	 * Método para cargar configuraciones o request properties adicionales. Por ejemplo:<br>
	 * this.connection.setRequestProperty("Authorization", "Bearer " + accessToken);<br>
	 * this.connection.setInstanceFollowRedirects(false);<br>
	 * this.connection.setUseCaches(false);
	 */
	protected void loadOtherSettingsConn() {
		// TODO SOBREESCRIBIR EN LAS CLASES QUE REQUIERAN REQUEST PROPERTIES ADICIONALES U OTRAS CONFIGURACIONES
		// PARA LA CONEXIÓN
	}
//***********************************************************************************************************************
}
