package library.core;

import org.testng.annotations.Test;

import library.common.ConsoleWindow;
import library.common.Util;
import library.reporting.Evidence;
import library.reporting.Reporter;
import library.settings.SettingsNoWindow;
import library.settings.SettingsRun;
import library.settings.SettingsWindow;

import java.io.IOException;
import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.NoSuchWindowException;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;

/**
 * <b>Se debe crear una variable [Controller] que sea seteada en el método [initializeControllerAndConfiguration]<br>
 * <br>
 * Así se ejecuta en TestNG:<br>
 * BeforeSuite - BeforeTest - BeforeClass - DataProvider<br>
 * [BeforeMethod - Test - AfterMethod]<br>
 * AfterClass - AfterTest - AfterSuite
 * @author Sandra Zea
 */
@Listeners(library.core.ListenerBaseTestNG.class)
public abstract class BaseTestNG {

	private boolean initialConfDone = false; // INDICA SI LA CONFIGURACIÓN INICIAL SE HIZO, SE HACE AL INICIO
	private Controller[] arrControl = null;
	private List<String> listPrevPidChrome = null;

//=======================================================================================================================
	@BeforeClass
	public void beforeClass() {

		// NOMBRE CARPETA DE EVIDENCIAS : SE REQUIERE DE PRIMERAS PARA LA CARGA DE PROPIEDADES
		SettingsRun.EXEC_NAME = this.getClass().getSimpleName();
//-----------------------------------------------------------------------------------------------------------------------
		// CARGA LAS PROPIEDADES DE LA EJECUCIÓN, PARA DETERMINAR DATOS INICIALES DE DICHA EJECUCIÓN
		SettingsRun.loadExecutionProperties();
		SettingsRun.TEST_EXECUTOR = SettingsRun.getProperty(SettingsRun.PROP_TEST_EXECUTOR,
			"Davivienda Automation Team");
		boolean browserIsOpen = Boolean.valueOf(SettingsRun.getProperty(SettingsRun.PROP_WEB_OPENDRIVER, "false"));
		if (!browserIsOpen)
			Util.cleanBrowserDrivers(); // MATA LOS DRIVERS QUE ESTÁN VIVOS
//-----------------------------------------------------------------------------------------------------------------------
		// CARGA LOS PID DE LOS BROWSER CHROME QUE EXISTEN ANTES DEL LANZAMIENTO EN SÍ
		this.listPrevPidChrome = new ArrayList<String>();
		try {
			this.listPrevPidChrome = Util.getTaskPids("Chrome.exe");
		}
		catch (Exception e) {}
//-----------------------------------------------------------------------------------------------------------------------
		// GARANTIZA QUE SE TOMEN EVIDENCIAS E INICIALIZA EL TIPO DE EVIDENCIA EN [null] - SÓLO IMÁGENES
		Evidence.activate();
		Reporter.initializeEvidenceType(null);
//-----------------------------------------------------------------------------------------------------------------------
		// LLAMA AL MÉTODO QUE DEBE SOBREESCRIBIR LA DATA DE LANZAMIENTO REQUERIDA
		launchData();
//-----------------------------------------------------------------------------------------------------------------------
		// DETERMINA SI ABRE CONSOLA DE EJECUCIÓN, SE HACE CON LANZAMIENTO JAR CUANDO ES CON INTERFAZ
		if (SettingsRun.WITH_INTERFACE)
			new ConsoleWindow(); // ALISTA LA VISUALIZACIÓN DE LA CONSOLA: FRAME CUANDO ES JAR O EN EL IDE
		if (Util.isLaunchJAR())
			Reporter.write("LANZAMIENTO DESDE JAR");
		else
			Reporter.write("LANZAMIENTO DESDE IDE");
	}
//***********************************************************************************************************************
	/**
	 * <b>En este punto sólo se han cargado las propiedades de ejecución</b>
	 * <p>
	 * DATOS DEL LANZAMIENTO : Se sugiere el siguiente contenido
	 * <p>
	 * - El FrameWork por naturaleza toma las evidencias que hayan sido almacenadas por ejecución y arma un archivo ZIP,
	 * para luego subirlo a la herramienta de gestión de pruebas. En caso que se requiera una evidencia diferente, se
	 * debe inicializar el tipo de evidencia según se requiera:<br>
	 * <b>Reporter.initializeEvidenceType(new EvidencePdfFile());</b><br>
	 * <b>EvidencePdfFile</b> es el tipo de evidencia más común que se usará para Davivienda, pero hay otros tipo que se
	 * pueden usar. Ver package [dav.library.reporting]<br>
	 * Si desea que los títulos de las evidencias en el PDF se escriban con fecha y hora, debe indicar
	 * <b>Evidence.TITLE_WITH_TIME = true;</b>
	 * <p>
	 * <b> CUANDO SE USA ARCHIVO DE DATOS (SEA EXCEL O JSON):</b><br>
	 * <font face="courier new"> // INDICAR LOS ARCHIVOS DE DATOS QUE PUEDEN SER DESCARGADOS<br>
	 * SettingsRun.DATA_FILES = new String[] { "carpeta en resource/nombre archivo con extensión" };<br>
	 * </font> <b> CUANDO SE USA DATA EN EXCEL:</b><br>
	 * <font face="courier new"> SettingsRun.DEFAULT_HEADER = 2; // USARLO SI EL HEADER NO ESTÁ EN LA FILA[1] <br>
	 * // PARÁMETROS REQUERIDOS EN LA HOJA DE DATOS PARA EL LAUNCH QUE SE ESTÁ HACIENDO<br>
	 * SettingsRun.ARRAY_DATA_PARAMS = new String[] {"param1", "param2", "param3"};</font>
	 * <p>
	 * <b>Cuando sean lanzamientos que no dependan de data, es posible que se requiera:</b><br>
	 * - Indicar que la fuente de datos no es con archivo: <b>SettingsRun.DATA_SOURCE = "SIN ARCHIVO";</b><br>
	 * - Indicar que no se realizará reporte de forma automática: <b>SettingsRun.AUTO_REPORT = false;</b><br>
	 * Este último se debe manejar con cuidado, ya que el control del Reporte final, se hará por codificación directa
	 * invocando el método <b>Reporter.addTestToReport(numIteracion)</b>.
	 */
	abstract public void launchData();
//=======================================================================================================================
	// HACE LA CARGA DE LA CONFIGURACIÓN DE LAS EJECUCIONES A REALIZAR...
	@DataProvider(name = "testData")
	public Object[][] getData() throws Exception {

		if (SettingsRun.WITH_INTERFACE)
			SettingsWindow.launch();
		else
			SettingsNoWindow.launch();
		// EL TAMAÑO DE LA MATRIZ ES [totalExec][1], VAN LOS ROWS QUE SE VAN A EJECUTAR DEL EXCEL
		Object[][] data = SettingsRun.loadDataProvider();
		return data;
	}
//=======================================================================================================================
	@AfterClass
	public void afterClass() throws MalformedURLException {

		Reporter.writeTitle("\n******************** HORA DE CIERRE (" + Util.hourToString("HH:mm:ss") + ")");
		// EN ESTE PUNTO YA SE EXISTEN LAS EVIDENCIA FINALES
		this.lastBeforeDestroy();
		SettingsRun.destroyAll();
		launchClose();
		SettingsRun.terminateRun();
	}
//***********************************************************************************************************************
	/**
	 * Este método es para sobreescribir y hacer un último recorrido antes de hacer el Destroy de todo.<br>
	 * Es útil para iterar por las ejecuciones, <b>OJO</b> no está cargada la iteración así que si desea extraer o
	 * setear información de la hoja de datos, se debe hacer "ByExec".
	 */
	public void lastBeforeDestroy() {

		// HACER OVERWRITE DONDE SE REQUIERA
	}
//***********************************************************************************************************************
	/**
	 * CIERRE DEL LANZAMIENTO:<br>
	 * Invoca el destroy de los Controller que hayan sido creados y que existan.<br>
	 * LIBERAR LAS INSTANCIAS QUE SE REQUIEREN. POR EJEMPLO: HACER CIERRE DE BROWSERS, DE CONSOLAS DEL BACK-END.
	 * <p>
	 * Adicional, realiza el cierre de "Chrome.exe" que fueron generados durante el lanzamiento.
	 */
	public void launchClose() {

		if (this.arrControl != null) {
			for (int posArr = 0; posArr < arrControl.length; posArr++) {
				if (this.arrControl[posArr] != null) {
					try {
						this.arrControl[posArr].destroy();
					}
					catch (NoSuchWindowException e) {}
				}
			}
			this.arrControl = null;
		}
//-----------------------------------------------------------------------------------------------------------------------
		// MATA LOS PROCESOS DE "Chrome.exe" CREADOS DURANTE EL LANZAMIENTO : NO ESTÁN EN [listPrevPidChrome]
		try {
			List<String> listCurrentPidChrome = Util.getTaskPids("Chrome.exe");
			for (String pid : listCurrentPidChrome) {
				if (!listPrevPidChrome.contains(pid)) // FUE CREADO DURANTE EL LANZAMIENTO
					Util.killTaskByPid(pid);
			}
		}
		catch (IOException e) {}
	}
//=======================================================================================================================
	// SE HACE EL LLAMADO AL MÉTODO QUE DA INICIO A LA PRUEBA, SE INDICA QUE SE VA A USAR LA DATA DEL [DataProvider]...
	@Test(dataProvider = "testData")
	public void TestExec(int iteracion) throws MalformedURLException {

//-----------------------------------------------------------------------------------------------------------------------
		// HACE EL LLAMADO A LAS CONFIGURACIONES INICIALES
		if (!initialConfDone) {
			Reporter.initHtmlReport(); // INICIALIZA EL REPORTE HTML
			initialConfDone = true; // PARA INDICAR QUE YA SE HIZO
			Reporter.WRITE_HEADER = false; // PARA QUE LOS [write] NO TENGAN ENCABEZADO
			Reporter.write("\n*** HACIENDO LAS CONFIGURACIONES INICIALES >>>>> (" + Util.hourToString("HH:mm:ss") + ")");
			try {
				initializeControllerAndConfiguration();
			}
			catch (Exception e) {
				e.printStackTrace();
				SettingsRun.exitTest("Exception en [BaseTestNG.TestExec1]\n" + e.getMessage());
			}
			Reporter.write("*** TERMINANDO LAS CONFIGURACIONES INICIALES >>> (" + Util.hourToString("HH:mm:ss") + ")");
		}
//-----------------------------------------------------------------------------------------------------------------------
		try {
			// EMPIEZAN LAS PRUEBAS
			SettingsRun.loadIteration(iteracion); // PARA QUE CARGUE [iteracion] COMO LA EJECUCIÓN ACTUAL
			Reporter.WRITE_HEADER = true; // PARA QUE LOS [write] EMPIECEN CON ENCABEZADO
			Reporter.write(""); // PARA QUE ESCRIBA EL ENCABEZADO DE LA EJECUCIÓN
			if (Boolean.valueOf(SettingsRun.getGlobalData("prop.requiresEvidenceVideo", "false"))) {
				// Evidence.startRecording();
			}
			this.doingTest();
//-----------------------------------------------------------------------------------------------------------------------
		}
		catch (Exception e) {
			String msgErr = e.getMessage() != null ? e.getMessage() : "null"; // PORQUE NULL NO SE PUEDE COMPARAR
			// SI EMPIEZA "BaseTestDONE -- exitTestIteration" NO ES EXCEPTION, CONTINUA CON LA SIGUIENTE ITERACIÓN
			if (!msgErr.startsWith("BaseTestDONE -- exitTestIteration")) {
				e.printStackTrace();
				Reporter.test.fail(e); // PARA QUE GENERE LA SECCIÓN [bug] EN EL INFORME HTML
				// HACE LOS CIERRES REQUERIDOS DE LA EJECUCIÓN
				this.launchClose();
				// DEBE TERMINAR PARA REVISAR CUÁL FUE LA EXCEPCIÓN
				SettingsRun.exitTest("Exception en [BaseTestNG.TestExec2]\n" + msgErr);
			}
//-----------------------------------------------------------------------------------------------------------------------
		}
		finally {
			if (Boolean.valueOf(SettingsRun.getGlobalData("prop.requiresEvidenceVideo", "false"))) {
				// Evidence.stopRecording();
			}
			Reporter.generateLaunchReport(); // PARA QUE VAYA GENERANDO EL REPORTE Y NO SE PIERDA LO REPORTADO
			Reporter.pickupSoftAssert(); // PARA QUE RECOJA TODOS LOS ASSERT SOFT QUE SE HAYAN GENERADO
		}
	}
//***********************************************************************************************************************
	/**
	 * Este es el método que se invoca para inicializar el uso de controladores y realizar las configuraciones iniciales.
	 * (Es invocado en la primera iteración).<br>
	 * - Se sugiere llamar el método <b>this.setController(control...)</b> pasando la instancia del o de los controller
	 * ya inicializada<br>
	 * - Se sugiere incluir las adiciones de parámetros que se requieran (caso de data en excel):<br>
	 * <b>SettingsRun.getTestData().addParametersNotExist("ParamNuevo1", "ParamNuevo2"...);</b><br>
	 * <br>
	 * Para recorrer las ejecuciones a realizar, se sugiere realizar la siguiente secuencia de código:<br>
	 * <br>
	 * <font face="courier new"> int currentIt = SettingsRun.getStartIteration();<br>
	 * do {<br>
	 * // HACER LO REQUERIDO, LA EXTRACCIÓN DE DATOS SE HARÁ ASÍ:<br>
	 * // SettingsRun.getTestData().getParameterByExec("namePAram", currentIt);<br>
	 * currentIt = SettingsRun.getNextIteration(currentIt);<br>
	 * } while (currentIt != 0); </font>
	 */
	abstract public void initializeControllerAndConfiguration() throws Exception;
//***********************************************************************************************************************
	/**
	 * Setea la instancia de los controller a usar.
	 */
	protected void setController(Controller... ctr) {

		this.arrControl = ctr;
	}
//***********************************************************************************************************************
	/**
	 * Cuando se requiera un tipo de evidencia diferente a subir archivo ZIP con las imágenes almacenadas, se debe
	 * iniciar con la carga de la información del archivo de evidencia:<br>
	 * <b>this.loadEvidenceFileInfo(nbFileSimple, nbTestCase);</b><br>
	 * <br>
	 * Finalmente darle el control al o a los "controller" requeridos para las pruebas.
	 */
	abstract public void doingTest() throws Exception;
//***********************************************************************************************************************	
	/**
	 * Carga la información correspondiente a la evidencia que será almacenada en un archivo.
	 */
	protected void loadEvidenceFileInfo(String nbFileSimple, String nbTestCase) {

		Reporter.initializeEvidenceTestFile(nbFileSimple, nbTestCase);
	}
//***********************************************************************************************************************
}