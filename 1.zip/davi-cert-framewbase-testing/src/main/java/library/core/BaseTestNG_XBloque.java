package library.core;

import org.testng.annotations.Test;

import library.common.ConsoleWindow;
import library.common.Util;
import library.reporting.Evidence;
import library.reporting.Reporter;
import library.settings.SettingsNoWindow;
import library.settings.SettingsRun;
import library.settings.SettingsWindow;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.NoSuchWindowException;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;

/**
 * Se debe crear una variable [Controller] e inicializarla como Global y que sea seteada en el método
 * [initializeControllerAndConfiguration]<br>
 * No olvide hacer @Override de los métodos <b>doingTest(), doingTest2(), doingTest3(), doingTest4(), doingTest5()</b>
 * según la cantidad de bloques que tenga la clase.<br>
 * <br>
 * Así se ejecuta en TestNG:<br>
 * BeforeSuite - BeforeTest - BeforeClass - DataProvider<br>
 * [BeforeMethod - Test - AfterMethod]<br>
 * AfterClass - AfterTest - AfterSuite
 * @author Sandra Zea
 */
@Listeners(library.core.ListenerBaseTestNG_XBloque.class)
public abstract class BaseTestNG_XBloque {

	private boolean initialConfDone = false; // INDICA SI LA CONFIGURACIÓN INICIAL SE HIZO, SE HACE AL INICIO
	private Controller[] arrControl = null;
	private List<String> listPrevPidChrome = null; 
	private String[] arrParamsBloque = null; // CONTIENE LOS PARÁMETROS QUE ARMAN LA CLAVE QUE DETERMINA EL BLOQUE
	private String[] arrTitlesBloque = null; // TÍTULO DE CADA BLOQUE
	protected List<Integer> listaExecution = new ArrayList<Integer>();

//=======================================================================================================================
	@BeforeClass
	public void beforeClass() {

		// NOMBRE CARPETA DE EVIDENCIAS : SE REQUIERE DE PRIMERAS PARA LA CARGA DE PROPIEDADES
		SettingsRun.EXEC_NAME = this.getClass().getSimpleName();
//-----------------------------------------------------------------------------------------------------------------------
		// CARGA LAS PROPIEDADES DE LA EJECUCIÓN, PARA DETERMINAR DAOS INICIALES DE DICHA EJECUCIÓN
		SettingsRun.loadExecutionProperties();
		SettingsRun.TEST_EXECUTOR = SettingsRun.getProperty(SettingsRun.PROP_TEST_EXECUTOR, "Davivienda Automation Team");
		boolean browserIsOpen = Boolean.valueOf(SettingsRun.getProperty(SettingsRun.PROP_WEB_OPENDRIVER, "false"));
		if (!browserIsOpen)
			Util.cleanBrowserDrivers(); // MATA LOS DRIVERS QUE ESTÁN VIVOS
//-----------------------------------------------------------------------------------------------------------------------
		// CARGA LOS PID DE LOS BROWSER CHROME QUE EXISTEN ANTES DEL LANZAMIENTO EN SÍ
		this.listPrevPidChrome = new ArrayList<String>();
		try {
			this.listPrevPidChrome = Util.getTaskPids("Chrome.exe");
		}
		catch (Exception e) {}
//-----------------------------------------------------------------------------------------------------------------------
		// GARANTIZA QUE SE TOMEN EVIDENCIAS E INICIALIZA EL TIPO DE EVIDENCIA EN [null] - SÓLO IMÁGENES
		Evidence.activate();
		Reporter.initializeEvidenceType(null);
//-----------------------------------------------------------------------------------------------------------------------
		this.setTotalBloques(1); // POR DEFECTO ASUME 1 BLOQUE, SIN DARLE NOMBRE
		this.setExecKeyBloque(); // PARA QUE NO TOME UNA CLAVE DE EJECUCIÓN, SINO EL ORDEN NATURAL DE LAS ITERACIONES
		launchData(); // LLAMA AL MÉTODO QUE DEBE SOBREESCRIBIR LA DATA DE LANZAMIENTO REQUERIDA
//-----------------------------------------------------------------------------------------------------------------------
		// DETERMINA SI ABRE CONSOLA DE EJECUCIÓN, SE HACE CON LANZAMIENTO JAR CUANDO ES CON INTERFAZ
		if (SettingsRun.WITH_INTERFACE)
			new ConsoleWindow(); // ALISTA LA VISUALIZACIÓN DE LA CONSOLA: FRAME CUANDO ES JAR O EN EL IDE
		if (Util.isLaunchJAR())
			Reporter.write("LANZAMIENTO DESDE JAR");
		else
			Reporter.write("LANZAMIENTO DESDE IDE");
	}
//***********************************************************************************************************************
	/**
	 * Indica el total de bloques que se van a ejecutar y le da un nombre a cada bloque a modo de Título.
	 */
	protected void setTotalBloques(int totalBloques, String... nbBloques) {

		if (totalBloques < 1 || totalBloques > 5)
			SettingsRun.exitTest("BaseTestNG_XBloque ERROR -- El total de bloques debe ser >= 1 y <= 5 ...");
		SettingsRun.NUM_BLOQUES = totalBloques;
		this.arrTitlesBloque = new String[SettingsRun.NUM_BLOQUES];
		int nbsBloquesReci = nbBloques.length;
		for (int posArr = 0; posArr < SettingsRun.NUM_BLOQUES; posArr++) {
			if (posArr < nbsBloquesReci)
				this.arrTitlesBloque[posArr] = nbBloques[posArr];
			else // DA UN NOMBRE GENÉRICO AL BLOQUE
				this.arrTitlesBloque[posArr] = "BLOQUE #" + (posArr + 1);
		}
	}
//***********************************************************************************************************************
	/**
	 * Método que setea los nombres de los parámetros que conformarán el key que determina el lanzamiento por bloque.<br>
	 * Cuando NO hay parámetros hace la iteración de forma natural.
	 */
	protected void setExecKeyBloque(String... params) {

		this.arrParamsBloque = null; // INICIALIZACIÓN
		if (params.length != 0)
			this.arrParamsBloque = params;
	}
//***********************************************************************************************************************
	/**
	 * Método que valida la existencia de los parámetros que conformarán el key que determina el lanzamiento por bloque.
	 */
	private void validateExecKeyBloque() {

		if (this.arrParamsBloque != null) {
			for (int posArr = 0; posArr < this.arrParamsBloque.length; posArr++) {
				if (!SettingsRun.getTestData().parameterExist(this.arrParamsBloque[posArr]))
					SettingsRun.exitTest("BaseTestNG_XBloque ERROR -- Parámetro [" + this.arrParamsBloque[posArr]
						+ "] NO existe en la hoja de datos...");
			}
		}
	}
//***********************************************************************************************************************
	/**
	 * <b>En este punto sólo se han cargado las propiedades de ejecución</b><p>
	 * DATOS DEL LANZAMIENTO : Se sugiere el siguiente contenido
	 * <p>
	 * - Indicar el número de bloques a ejecutar con su título y los parámetros que forman la clave de ejecución:<br>
	 * <b> this.setTotalBloques(2, "TRANSANDO EN CANAL X", "VALIDACIONES EN OTRA APP");<br>
	 * this.setExecKeyBloque("param1", "param2"); // SI NO HAY CLAVE DE EJECUCIÓN, NO INCLUIR ESTA LÍNEA, SE TOMARÁ UNA
	 * EJECUCIÓN NATURAL POR ITERACIÓN</b>
	 * <p>
	 * - El FrameWork por naturaleza toma las evidencias que hayan sido almacenadas por ejecución y arma un archivo ZIP,
	 * para luego subirlo a la herramienta de gestión de pruebas. En caso que se requiera una evidencia de diferente, se
	 * debe inicializar el tipo de evidencia según se requiera:<br>
	 * <b>Reporter.initializeEvidenceType(new EvidencePdfFile());</b><br>
	 * <b>EvidencePdfFile</b> es el tipo de evidencia más común que se usará para Davivienda, pero hay otros tipo que se
	 * pueden usar. Ver package [dav.library.reporting]<br>
	 * Si desea que los títulos de las evidencias en el PDF se escriban con fecha y hora, debe indicar
	 * <b>Evidence.TITLE_WITH_TIME = true;</b>
	 * <p>
	 * <b> CUANDO SE USA ARCHIVO DE DATOS (SEA EXCEL O JSON):</b><br>
	 * <font face="courier new"> // INDICAR LOS ARCHIVOS DE DATOS QUE PUEDEN SER DESCARGADOS<br>
	 * SettingsRun.DATA_FILES = new String[] { "carpeta en resource/nombre archivo con extensión" };<br>
	 * </font> <b> CUANDO SE USA DATA EN EXCEL:</b><br>
	 * <font face="courier new"> SettingsRun.DEFAULT_HEADER = 2; // USARLO SI EL HEADER NO ESTÁ EN LA FILA[1] <br>
	 * // PARÁMETROS REQUERIDOS EN LA HOJA DE DATOS PARA EL LAUNCH QUE SE ESTÁ HACIENDO<br>
	 * SettingsRun.ARRAY_DATA_PARAMS = new String[] {"param1", "param2", "param3"};</font>
	 * <p>
	 * <b>Cuando sean lanzamientos que no dependan de data, es posible que se requiera:</b><br>
	 * - Indicar que la fuente de datos no es con archivo: <b>SettingsRun.DATA_SOURCE = "SIN ARCHIVO";</b><br>
	 * - Indicar que no se realizará reporte de forma automática: <b>SettingsRun.AUTO_REPORT = false;</b><br>
	 * Este último se debe manejar con cuidado, ya que el control del Reporte final, se hará por codificación directa.
	 */
	abstract public void launchData();
//=======================================================================================================================
	@AfterClass
	public void afterClass() {

		Reporter.writeTitle("\n******************** HORA DE CIERRE (" + Util.hourToString("HH:mm:ss") + ")");
		Reporter.loadTestStatusFinalXBloque(); // ACÁ ARMA LOS ARCHIVOS DE EVIDENCIA FINALES
		this.lastBeforeDestroy(); 
		SettingsRun.destroyAll();
		launchClose();
		SettingsRun.terminateRun();
	}
//***********************************************************************************************************************
	/**
	 * Este método es para sobreescribir y hacer un último recorrido antes de hacer el Destroy de todo.<br>
	 * Es útil para iterar por las ejecuciones que están ordenadas en [listaExecution], <b>OJO</b> no está cargada la
	 * iteración así que si desea extraer información de la hoja de datos, se debe hacer "ByExec". 
	 */
	public void lastBeforeDestroy() {
		// HACER OVERWRITE DONDE SE REQUIERA
	}
//***********************************************************************************************************************
	/**
	 * CIERRE DEL LANZAMIENTO:<br>
	 * Invoca el destroy de los Controller que hayan sido creados y que existan.<br>
	 * LIBERAR LAS INSTANCIAS QUE SE REQUIEREN. POR EJEMPLO: HACER CIERRE DE BROWSERS, DE CONSOLAS DEL BACK-END.<br>
	 * <p>Adicional, realiza el cierre de "Chrome.exe" que fueron generados durante el lanzamiento.
	 */
	public void launchClose() {

		if (this.arrControl != null) {
			for (int posArr = 0; posArr < arrControl.length; posArr++) {
				if (this.arrControl[posArr] != null) {
					try {
						this.arrControl[posArr].destroy();
					}
					catch (NoSuchWindowException e) { }
				}
			}
			this.arrControl = null;
		}
//-----------------------------------------------------------------------------------------------------------------------
		// MATA LOS PROCESOS DE "Chrome.exe" CREADOS DURANTE EL LANZAMIENTO : NO ESTÁN EN [listPrevPidChrome]
		try {
			List<String> listCurrentPidChrome = Util.getTaskPids("Chrome.exe");
			for (String pid : listCurrentPidChrome) {
				if (!listPrevPidChrome.contains(pid)) // FUE CREADO DURANTE EL LANZAMIENTO
					Util.killTaskByPid(pid);
			}
		}
		catch (IOException e) { }
	}
//=======================================================================================================================
	// MÉTODO QUE MANEJA LAS PRUEBAS, ITERA SOBRE LA CANTIDAD DE BLOQUES A EJECUTAR
	@Test
	public void TestExec() throws Exception {

		// HACE EL LLAMADO A LAS CONFIGURACIONES INICIALES
		if (!initialConfDone) {
			initialConfDone = true; // PARA INDICAR QUE YA SE HIZO
			
			// CARGA LA INFORMACIÓN DE CONFIGURACIÓN DE EJECUCIÓN
			if (SettingsRun.WITH_INTERFACE) 
				SettingsWindow.launch();
			else
				SettingsNoWindow.launch();
			
			this.validateExecKeyBloque(); // VALIDA QUE EXISTAN LOS PARÁMETROS DEL [key] DEL BLOQUE
			Reporter.initHtmlReport(); // INICIALIZA EL REPORTE HTML
			this.loadIterationsXBloque(); // CARGA EL ORDEN CORRECTO DE LAS ITERACIONES SEGÚN EL BLOQUE DADO
			Reporter.loadListaExecutionXBloque(this.listaExecution);
			Reporter.WRITE_HEADER = false; // PARA QUE LOS [write] NO TENGAN ENCABEZADO
			Reporter.write("\n*** POR EJECUCIÓN EN BLOQUE, LAS PRUEBAS SERÁN LANZADAS EN EL SIGUIENTE ORDEN >>>"
				+ "\n*** [" + Util.arrayToString(this.listaExecution.toArray(), ", ") + "]");
//-----------------------------------------------------------------------------------------------------------------------
			// HACE EL LLAMADO A LAS CONFIGURACIONES INICIALES
			Reporter.write("\n*** HACIENDO LAS CONFIGURACIONES INICIALES >>>>> (" + Util.hourToString("HH:mm:ss") + ")");
			try {
				initializeControllerAndConfiguration();
			}
			catch (Exception e) {
				e.printStackTrace();
				SettingsRun.exitTest("Exception en [BaseTestNG_XBloque.TestExec1]");
			}
			Reporter.write("*** TERMINANDO LAS CONFIGURACIONES INICIALES >>> (" + Util.hourToString("HH:mm:ss") + ")");
		}
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
		Reporter.WRITE_HEADER = true; // PARA QUE LOS [write] EMPIECEN CON ENCABEZADO
		for (int bloque = 1; bloque <= SettingsRun.NUM_BLOQUES; bloque++) {
			// ESCRIBE EL TITLE DEL BLOQUE, SI NO ES VACÍO
			Reporter.writeTitle("\n******************** BLOQUE [" + bloque + "] : " + this.arrTitlesBloque[bloque - 1]);
			// EJECUTA EL BLOQUE
			this.ejecutarDoingTestSegunBloque(bloque);
		}
		Reporter.pickupSoftAssert(); // PARA QUE RECOJA TODOS LOS ASSERT SOFT QUE SE HAYAN GENERADO
	}
//***********************************************************************************************************************
	/**
	 * Método que carga el orden de las iteraciones que se realizarán según el bloque constituido. Adicional llama a la
	 * configuración de las pruebas.
	 */
	private void loadIterationsXBloque() {

		// CARGA EL DICTIONARY [dicIterations] PARA IDENTIFICAR EL ORDEN DE ITERACIÓN
		// Key:Clave que identificará las pruebas que se lanzan juntas, Value=Lista con el número de los row a lanzar
		Map<String, List<Integer>> dicIterations = new HashMap<String, List<Integer>>();
		// LE DA EL ORDEN A LA EJECUCIÓN, TIENE TODAS LAS [Key] DEL DICTIONARY
		List<String> listOrderExec = new ArrayList<String>();
		int currentIt = SettingsRun.getStartIteration();
		String keyBloque;
		List<Integer> listIterations;
		try {
			do {
				Reporter.addTestToReport(currentIt); // ADICIONA AL REPORTE CADA ITERACIÓN EN ORDEN
				keyBloque = getExecKeyBloque(currentIt);
				if (dicIterations.containsKey(keyBloque))
					listIterations = dicIterations.get(keyBloque);
				else {
					listIterations = new ArrayList<Integer>();
					listOrderExec.add(keyBloque);
				}
				listIterations.add(currentIt);
				dicIterations.put(keyBloque, listIterations); // SI YA EXISTÍA, LO SOBREESCRIBE
				currentIt = SettingsRun.getNextIteration(currentIt);
			} while (currentIt != 0);
		}
		catch (Exception e) {
			e.printStackTrace();
			SettingsRun.exitTest("Exception en [BaseTestNG_XBloque.loadIterationsXBloque]");
		}
//-----------------------------------------------------------------------------------------------------------------------
		// DEJA [listaExecution] EN EL ORDEN DE EJECUCIÓN QUE SE DEBE REALIZAR
		for (String keyDic : listOrderExec) {
			for (int it : dicIterations.get(keyDic)) {
				this.listaExecution.add(it);
			}
		}
		SettingsRun.changeOrderExec(this.listaExecution);
	}
//***********************************************************************************************************************
	/**
	 * Método que retorna la clave de ejecución por iteración.<br>
	 * Por ejemplo, si el bloque de ejecución se hace de manera natural dejar el actual, pero si se debe unificar las
	 * iteraciones indicar la clave de esa unificación.<br>
	 * De esta manera se unificarán las iteraciones que cuentan con la misma clave de ejecución.
	 */
	private String getExecKeyBloque(int iteration) throws Exception {

		String execKeyBloque = String.valueOf(iteration);
		if (this.arrParamsBloque != null) {
			execKeyBloque = "";
			for (int posArr = 0; posArr < this.arrParamsBloque.length; posArr++) {
				if (!execKeyBloque.isEmpty())
					execKeyBloque += "-";
				execKeyBloque += SettingsRun.getTestData().getParameterByExec(this.arrParamsBloque[posArr], iteration);
			}
		}
		return execKeyBloque;
	}
//***********************************************************************************************************************
	/**
	 * Este es el método que se invoca para inicializar el uso de controladores y realizar las configuraciones
	 * iniciales.<br>
	 * - Se sugiere llamar el método <b>this.setController(control...)</b> pasando la instancia del o de los controller
	 *   ya inicializada<br>
	 * - Se sugiere incluir las adiciones de parámetros que se requieran (caso de data en excel):<br>
	 * <b>SettingsRun.getTestData().addParametersNotExist("ParamNuevo1", "ParamNuevo2"...);</b><br>
	 * <br>
	 * Para recorrer las ejecuciones a realizar, se sugiere realizar la siguiente secuencia de código:<br>
	 * <br>
	 * <font face="courier new"> int currentIt = SettingsRun.getStartIteration();<br>
	 * do {<br>
	 * // HACER LO REQUERIDO, LA EXTRACCIÓN DE DATOS SE HARÁ ASÍ:<br>
	 * // SettingsRun.getTestData().getParameterByExec("namePAram", currentIt);<br>
	 * currentIt = SettingsRun.getNextIteration(currentIt);<br>
	 * } while (currentIt != 0); </font>
	 */
	abstract public void initializeControllerAndConfiguration() throws Exception;
//***********************************************************************************************************************
	/**
	 * Setea la instancia de los controller a usar.
	 */
	protected void setController(Controller... ctr) {

		this.arrControl = ctr;
	}
//=======================================================================================================================
	/**
	 * Realiza la ejecución del bloque [bloqueExec], este bloque lo hace para todas las iteraciones que se van a lanzar
	 * que existen en [this.listaExecution]
	 */
	private void ejecutarDoingTestSegunBloque(int bloqueExec) {

		int iteration, nextIt, prevIt;
		int totalExecs = this.listaExecution.size();
		for (int posLista = 0; posLista < totalExecs; posLista++) {
			iteration = this.listaExecution.get(posLista);
			SettingsRun.loadIteration(iteration); // PARA QUE CARGUE [iteration] COMO LA EJECUCIÓN ACTUAL
			Reporter.write(""); // PARA QUE ESCRIBA EL ENCABEZADO DE LA EJECUCIÓN
//-----------------------------------------------------------------------------------------------------------------------
			// DEJA GUARDADO EL VALOR DE LA SIGUIENTE ITERACIÓN EN [SettingsRun]
			nextIt = 0;
			if (posLista + 1 < totalExecs)
				nextIt = this.listaExecution.get(posLista + 1);
			SettingsRun.setNextIterationBloque(nextIt);	
//-----------------------------------------------------------------------------------------------------------------------
			// DEJA GUARDADO EL VALOR DE LA ANTERIOR ITERACIÓN EN [SettingsRun]
			prevIt = 0;
			if (posLista > 0)
				prevIt = this.listaExecution.get(posLista - 1);
			SettingsRun.setPrevIterationBloque(prevIt);
//-----------------------------------------------------------------------------------------------------------------------
			try {
				if (bloqueExec == 1) 
					this.doingTest();
				else if (bloqueExec == 2)
					this.doingTest2();
				else if (bloqueExec == 3)
					this.doingTest3();
				else if (bloqueExec == 4)
					this.doingTest4();
				else if (bloqueExec == 5)
					this.doingTest5();
//-----------------------------------------------------------------------------------------------------------------------
			}
			catch (Exception e) {
				String msgErr = e.getMessage() != null ? e.getMessage() : "null"; // PORQUE NULL NO SE PUEDE COMPARAR
				// SI EMPIEZA "BaseTestDONE -- cambiarItFinal" NO ES EXCEPTION, ES PARA QUE TERMINE EL BLOQUE ACTUAL
				if (msgErr.startsWith("BaseTestDONE -- exitCurrentBloque"))
					posLista = totalExecs - 1;
				// SI EMPIEZA "BaseTestDONE -- exitTestIteration" NO ES EXCEPTION, CONTINUA CON LA SIGUIENTE ITERACIÓN
				else if (!msgErr.startsWith("BaseTestDONE -- exitTestIteration")) {
					e.printStackTrace();
					Reporter.test.fail(e); // PARA QUE GENERE LA SECCIÓN [bug] EN EL INFORME HTML
					// HACE LOS CIERRES REQUERIDOS DE LA EJECUCIÓN
					this.launchClose();
					// DEBE TERMINAR PARA REVISAR CUÁL FUE LA EXCEPCIÓN
					SettingsRun.exitTest("Exception en [BaseTestNG_XBloque.ejecutarDoingTestSegunBloque]\n" + msgErr);
				}
//-----------------------------------------------------------------------------------------------------------------------
			}
			finally {
				// SE TOMA COMO COMPLETADA SI ES EL ÚLTIMO BLOQUE, ESTO INDICA QUE PUEDE MOSTRAR EL RESULTADO DE LA
				// TRANSACCIÓN, TAL COMO HAYA QUEDADO:
				if (bloqueExec == SettingsRun.NUM_BLOQUES)
					Reporter.setIterationAsCompleted_XBloque();
				
				Reporter.generateLaunchReport(); // PARA QUE VAYA GENERANDO EL REPORTE Y NO SE PIERDA LO REPORTADO
			}
		} // CIERRA EL CICLO QUE RECORRE CADA BLOQUE
	}
//***********************************************************************************************************************
	/**
	 * 1er bloque de ejecución.<br>
	 * Itera sobre todas las pruebas, según la agrupación indicada en el método [getKeyBloqueExec]<br>
	 * <br>
	 * Cuando se requiera un tipo de evidencia diferente a subir archivo ZIP con las imágenes almacenadas, se debe
	 * iniciar con la carga de la información del archivo de evidencia:<br>
	 * <b>this.loadEvidenceFileInfo(nbFileSimple, nbTestCase);</b><br>
	 * <br>
	 * Finalmente darle el control al o a los "controller" requeridos para las pruebas.
	 */
	public void doingTest() throws Exception {

		if (SettingsRun.NUM_BLOQUES >= 2)
			SettingsRun.exitTest("OBLIGATORIO -- Método [BaseTestNG_XBloque.doingTest] se debe sobre escribir...");
	}
	/**
	 * 2do bloque de ejecución.<br>
	 * Itera sobre todas las pruebas, según la agrupación indicada en el método [getKeyBloqueExec]
	 */
	public void doingTest2() throws Exception {

		if (SettingsRun.NUM_BLOQUES >= 2)
			SettingsRun.exitTest("OBLIGATORIO -- Método [BaseTestNG_XBloque.doingTest2] se debe sobre escribir...");
	}
	/**
	 * 3er bloque de ejecución.<br>
	 * Itera sobre todas las pruebas, según la agrupación indicada en el método [getKeyBloqueExec]
	 */
	public void doingTest3() throws Exception {

		if (SettingsRun.NUM_BLOQUES >= 3)
			SettingsRun.exitTest("OBLIGATORIO -- Método [BaseTestNG_XBloque.doingTest3] se debe sobre escribir...");
	}
	/**
	 * 4to bloque de ejecución.<br>
	 * Itera sobre todas las pruebas, según la agrupación indicada en el método [getKeyBloqueExec]
	 */
	public void doingTest4() throws Exception {

		if (SettingsRun.NUM_BLOQUES >= 4)
			SettingsRun.exitTest("OBLIGATORIO -- Método [BaseTestNG_XBloque.doingTest4] se debe sobre escribir...");
	}
	/**
	 * 5to bloque de ejecución.<br>
	 * Itera sobre todas las pruebas, según la agrupación indicada en el método [getKeyBloqueExec]
	 */
	public void doingTest5() throws Exception {

		if (SettingsRun.NUM_BLOQUES >= 5)
			SettingsRun.exitTest("OBLIGATORIO -- Método [BaseTestNG_XBloque.doingTest5] se debe sobre escribir...");
	}
//***********************************************************************************************************************
	/**
	 * Carga la información correspondiente a la evidencia que será almacenada en un archivo.
	 */
	protected void loadEvidenceFileInfo(String nbFileSimple, String nbTestCase) {

		Reporter.initializeEvidenceTestFile(nbFileSimple, nbTestCase);
	}
//***********************************************************************************************************************
}