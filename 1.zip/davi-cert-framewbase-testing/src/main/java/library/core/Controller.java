package library.core;

public interface Controller {

	public abstract void destroy();
}
