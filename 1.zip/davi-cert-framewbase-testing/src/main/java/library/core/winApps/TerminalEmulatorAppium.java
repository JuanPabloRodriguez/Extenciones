package library.core.winApps;

import org.openqa.selenium.Keys;
import library.core.BaseDesktopApplication;

/**
 * Apertura de emuladores de terminal, haciendo uso de la clase [BaseDesktopApplication] que hace al llamado a través de
 * Appium.
 * @author smzealo
 */
public abstract class TerminalEmulatorAppium extends BaseDesktopApplication {
	
//=======================================================================================================================
	public TerminalEmulatorAppium(String application) {
		super(application);
	}
//***********************************************************************************************************************
	public TerminalEmulatorAppium(TerminalEmulatorAppium parent) {
		super(parent);
	}
//***********************************************************************************************************************
	/**
	 * Este método indica si el TerminalEmulator ha sido abierto por la automatización
	 */
	protected abstract boolean isOpened();
//***********************************************************************************************************************
	/**
	 * Este método activa el TerminalEmulator.
	 */
	protected abstract void activate();
//***********************************************************************************************************************
	/**
	 * Este método primero valida si se encuentra abierto y de ser así procede con el cierre de este.
	 */
	@Override
	protected void close() {
		if (this.isOpened()) super.close();
	}
//***********************************************************************************************************************
	/**
	 * Este método retorna el texto presentado en la pantalla del TerminalEmulator. <br>
	 */
	protected abstract String readTE();
//***********************************************************************************************************************
    /**
     * Envía la teclas [keys] estando en el TerminalEmulator.<br>
     * El envío de [keys] se hace las veces indicadas por [cantidad].
     */
	protected abstract void sendKeys(int cantidad, CharSequence... keys);
//***********************************************************************************************************************
    /**
     * Sobre el TerminalEmulator envía el caracter [character].
     */
    protected void sendKey(char character) {
   		this.sendKeys(1, String.valueOf(character));
   	}
//***********************************************************************************************************************
    /**
     * Sobre el TerminalEmulator envía el [numero].
     */
    protected void sendKey(int numero) {
   		this.sendKeys(1, String.valueOf(numero));
   	}
//***********************************************************************************************************************
    /**
     * Sobre el TerminalEmulator da click en la <b>FLECHA ABAJO</b> el número de veces indicado por [cantidad].
     */
	protected void down(int cantidad) {
		this.sendKeys(cantidad, Keys.ARROW_DOWN);
   	}
//***********************************************************************************************************************
    /**
     * Sobre el TerminalEmulator da click en la <b>FLECHA ARRIBA</b> el número de veces indicado por [cantidad].
     */
	protected void up(int cantidad) {
		this.sendKeys(cantidad, Keys.ARROW_UP);
   	}
//***********************************************************************************************************************
    /**
     * Sobre el TerminalEmulator da click en la <b>FLECHA IZQUIERDA</b> el número de veces indicado por [cantidad].
     */
	protected void left(int cantidad) {
		this.sendKeys(cantidad, Keys.ARROW_LEFT);
   	}
//***********************************************************************************************************************
    /**
     * Sobre el TerminalEmulator da click en la <b>FLECHA DERECHA</b> el número de veces indicado por [cantidad].
     */
	protected void right(int cantidad) {
		this.sendKeys(cantidad, Keys.ARROW_RIGHT);
   	}
//***********************************************************************************************************************
    /**
     * Sobre el TerminalEmulator da click en el <b>TAB</b> el número de veces indicado por [cantidad].
     */
	protected void tab(int cantidad) {
		this.sendKeys(cantidad, Keys.TAB);
   	}
//***********************************************************************************************************************
    /**
     * Sobre el TerminalEmulator da click en el <b>DELETE</b> el número de veces indicado por [cantidad].
     */
   	protected void delete(int cantidad) {
   		this.sendKeys(cantidad, Keys.DELETE);
   	}
//***********************************************************************************************************************
   	/**
     * Sobre el TerminalEmulator da click en <b>PAGE_DOWN</b> el número de veces indicado por [cantidad].
   	 */
   	protected void pageDown(int cantidad) {
   		this.sendKeys(cantidad, Keys.PAGE_DOWN);
   	}
//***********************************************************************************************************************
   	/**
     * Sobre el TerminalEmulator da click en <b>PAGE_UP</b> el número de veces indicado por [cantidad].
   	 */
   	protected void pageUp(int cantidad) {
   		this.sendKeys(cantidad, Keys.PAGE_UP);
   	}
//***********************************************************************************************************************
    /**
     * Sobre el TerminalEmulator da click en el <b>ENTER</b> el número de veces indicado por [cantidad].
     */
	protected void enter(int cantidad) {
		this.sendKeys(cantidad, Keys.ENTER);
   	}
//***********************************************************************************************************************	
    /**
     * Sobre el TerminalEmulator da 1 click en el <b>ENTER</b>.
     */
	protected void enter() {
		this.enter(1);
   	}
//***********************************************************************************************************************
}