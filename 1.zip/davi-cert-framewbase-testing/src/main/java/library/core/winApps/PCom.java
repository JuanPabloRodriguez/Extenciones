package library.core.winApps;

import java.net.MalformedURLException;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.NoSuchWindowException;
import org.openqa.selenium.remote.RemoteWebElement;

import library.common.Util;
import library.common.UtilClipboard;
import library.common.VirtualKeyBoard;
import library.settings.SettingsRun;

/**
 * Esta clase requiere contar con una estación de trabajo configurada en la máquina donde se hace el lanzamiento, de
 * lo contrario no se podrá realizar.
 * @author szea
 */
public class PCom extends TerminalEmulator {
	
	// LOS CARACTERES ESPECIALES DEPENDEN DEL TERMINAL EMULATOR
	private static String[] SPECIAL_CHAR = { "+", "!", "¡", "\\", "*", ";", "'", "-", "/", "[", "]", "@", "%", "&", "#", "=", "?", "¿", "{", "}", "ñ", "Ñ" };
	
	private final static String CLASS_NAME_PCOM = "PCSWS:Main:00400000";
	private final static String CLASS_NAME_PCOM_TE = "PCSWS:Pres:00400000"; // LA TERMINAL DONDE SE ESCRIBE
	private static String NAME_BT_COPY = ""; // BOTÓN DE COPY - SE CARGA CON [loadButtons]
	private static String NAME_BT_PASTE = ""; // BOTÓN DE PASTE - SE CARGA CON [loadButtons]
	
	private VirtualKeyBoard vkb = null;
	private String workStation = "";
	private UtilClipboard clipboard = new UtilClipboard();
	
//=======================================================================================================================
	public PCom(PCom parent) {
		super(parent);
		this.workStation = parent.workStation;
		this.vkb = parent.vkb;
	}
//***********************************************************************************************************************
	public PCom(String workStation){
		super(workStation);
		this.workStation = workStation;
		try {
			vkb = new VirtualKeyBoard();
		} catch (Exception e) {
			e.printStackTrace();
		}
		this.loadButtons(); // CARGA EL ATRIBUTO "Name" DEL BOTÓN COPY
	}
//***********************************************************************************************************************
	/**
	 * Este método indica si el PCom ha sido abierto por la automatización
	 */
	@Override
	protected boolean isOpened() {
		if (!this.isOpened) return false;
		else {
			try {
				this.elementByClassName(CLASS_NAME_PCOM);
				return true;
			} catch (NoSuchWindowException | NoSuchElementException e) {
				return false;
			}
		}
	}
//***********************************************************************************************************************
	/**
	 * Le da el foco a la pantalla de PCom, para que el envío de teclas sea correcto.
	 */
	@Override
	protected void activate() {
		boolean existePCom;
		do {
			existePCom = this.existElementByClassName(CLASS_NAME_PCOM);
		} while (!existePCom);
//-----------------------------------------------------------------------------------------------------------------------
		// EN CASO QUE HAYA EXCEPTION SE DA ALT+TAB DIFERENTES VECES, PARA UBICARSE EN LA PANTALLA DE PCOM
		boolean focusInPcom = false;
		int numTabs = 0;
		do {
			try {
				vkb.altTab(numTabs);
				this.elementByClassName(CLASS_NAME_PCOM).click();
				focusInPcom = true;
			} catch (Exception e) { // SE PRESENTA PORQUE PCOM PUEDE ESTAR ATRÁS DE LA VENTANA ACTUAL
				numTabs++;
			}
		} while (!focusInPcom);
	}
//***********************************************************************************************************************
	/**
	 * Este método retorna el texto presentado en la pantalla de PCom. <br>
	 * Hace el proceso de dar click derecho sobre la barra superior de PCom, para que se desplegue el menú y así poder
	 * seleccionar "Clear Scrollback" y luego "Copy All to Clipboard".
	 */
	@Override
	protected String readTE() {
		
		// LIMPIA EL CONTENIDO DEL CLIPBOARD:
		clipboard.cleanClipboard();
		/* TODO @BORRAR
		Clipboard clipboard = null;
		do {
			try {
				clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
		   		clipboard.setContents(new StringSelection(""), null);
			} catch (Exception e) {
				clipboard = null;
			}
		} while (clipboard == null);
		*/
//-----------------------------------------------------------------------------------------------------------------------
		String textoRetorno = "";
		try {
			//this.focus();
			this.click(this.elementByName(NAME_BT_COPY));
			Util.wait(1); // TIEMPO DE ESPERA PARA QUE PERMITA RECONOCER EL CLIPBOARD
			
			// TRAE EL CONTENIDO DEL [clipboard] COMO UN String
			textoRetorno = clipboard.getClipboard();
			/* TODO @BORRAR
			clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
	        Transferable t = clipboard.getContents( null );
	        if ( t.isDataFlavorSupported(DataFlavor.stringFlavor) )
	            textoRetorno = (String)t.getTransferData( DataFlavor.stringFlavor );
	        */
		} catch (Exception e) {
			textoRetorno = "";
			e.printStackTrace();
		}
//-----------------------------------------------------------------------------------------------------------------------
		// SE REVISA QUE REALMENTE HAYA INFORMACIÓN, CUANDO LA PANTALLA ESTÁ VACÍA TRAE LÍNEAS VACÍAS
		if (!textoRetorno.isEmpty()) {
			String textoTemp = textoRetorno.replace("\n", "").trim();
			if (textoTemp.isEmpty()) {
				textoRetorno = "";
			}
		}
		return textoRetorno;
	}
//***********************************************************************************************************************
    /**
     * Envía la teclas [keys] estando en PCom.<br>
     * El envío de [keys] se hace las veces indicadas por [cantidad].
     */
	@Override
	protected void sendKeys(int cantidad, CharSequence... keys) {
		RemoteWebElement objTerminalEmm = this.elementByClassName(CLASS_NAME_PCOM_TE);
   		for (int veces = 0; veces < cantidad; veces++) {
   			this.sendKeys(objTerminalEmm, keys);
   		}
    }
//***********************************************************************************************************************
	/**
	 * Escribe el [numero] en la pantalla de PCom, el cursor debe estar ubicado en el espacio en donde se requiere
	 * hacer el ingreso.
	 */
	protected void write(int numero) {
   		this.write(String.valueOf(numero));
   	}
//***********************************************************************************************************************
	/**
	 * Escribe el [texto] en la pantalla de PCom, el cursor debe estar ubicado en el espacio en donde se requiere hacer
	 * el ingreso.
	 */
	protected void write(String texto) {
		
		if (Util.itemContainsAnyArrayItem(texto, SPECIAL_CHAR)) {
			clipboard.setClipboard(texto);
			this.click(this.elementByName(NAME_BT_PASTE));
		}
		else
			this.sendKeys(this.elementByClassName(CLASS_NAME_PCOM_TE), texto);
   	}
//***********************************************************************************************************************
	/**
	 * Método que abre la consola de PCom. Retorna [true] si la conexión se pudo realizar, en caso contrario [false].
	 * @param ipAddress - IP a donde se va a realizar al conexión
	 * @param typeConnection - Tipo de conexión, los posibles valores son RAW, TELNET, RLOGIN, SSH, SERIAL
	 */
	protected String openPCom() {
		
		String msgError = this.openApplication(this.workStation);
		if (msgError != null) return msgError; // NO PUDO ABRIR LA APLICACIÓN, HACE EL RETORNO
//-----------------------------------------------------------------------------------------------------------------------		
		// EN ESTE PUNTO PCOM ESTÁ ENVIANDO LA CONEXIÓN, PUEDE HABER CONEXIÓN O NO, SE DA ESPERA DE 1 MINUTO:
		int segsEspera = 0;
		String pantalla;
		do {
			pantalla = this.readTE();
			if (pantalla.isEmpty()) Util.wait(1);
			segsEspera++;
		} while (pantalla.isEmpty() && segsEspera <= 60);
		
		if (pantalla.isEmpty()) {
			this.close();
			this.isOpened = false;
			msgError = "Después de una espera de [60] la pantalla de PCOM estaba vacía";
		}
		return msgError;
	}
//***********************************************************************************************************************
	/**
	 * Carga el "Name" del botón copy de PCom. Queda almacenado en la variable [NAME_BT_COPY].
	 * @throws MalformedURLException 
	 */
	private void loadButtons(){
		NAME_BT_COPY = "Copiar el texto seleccionado en el área común";
		if (!this.existElementByName(NAME_BT_COPY)) {
			NAME_BT_COPY = "Copiar el texto seleccionado en el portapapeles";
			if (!this.existElementByName(NAME_BT_COPY))
				SettingsRun.exitTest("EL NAME DEL BOTÓN DE 'COPY', NO CORRESPONDE CON LOS ALMACENADOS");
		}
		
		NAME_BT_PASTE = "Pegar el contenido del portapapeles a partir de la posición del cursor";
		if (!this.existElementByName(NAME_BT_PASTE)) {
			NAME_BT_PASTE = "PENDIENTE";
			if (!this.existElementByName(NAME_BT_PASTE))
				SettingsRun.exitTest("EL NAME DEL BOTÓN DE 'PASTE', NO CORRESPONDE CON LOS ALMACENADOS");
		}
	}
//***********************************************************************************************************************
}
