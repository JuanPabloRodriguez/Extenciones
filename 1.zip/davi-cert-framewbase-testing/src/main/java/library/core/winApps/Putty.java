package library.core.winApps;

import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.NoSuchWindowException;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebElement;

import library.common.Util;
import library.common.UtilClipboard;
import library.common.VirtualKeyBoard;
import library.reporting.Reporter;

public class Putty extends TerminalEmulator {
	
	// LOS CARACTERES ESPECIALES DEPENDEN DEL TERMINAL EMULATOR
	private static String[] SPECIAL_CHAR = { "!", "¡", "\\", ";", "'", "-", "/", "[", "]", "@", "&", "#", "=", "?", "¿", "{", "}" };
	
	protected static final String APPLICATION = "putty";
	private final static String CLASS_NAME_PUTTY_TE = "PuTTY"; // LA TERMINAL DONDE SE ESCRIBE
	private String accessIdBarraPutty = "TitleBar"; // ID QUE IDENTIFICA LA BARRA SUPERIOR DE PUTTY
	
	// NOMBRE DE LOS TIPOS DE CONEXIÓN EN LA VENTANA DE PUTTY
	public static final String RAW    = "Raw";
	public static final String TELNET = "Telnet";
	public static final String RLOGIN = "Rlogin";
	public static final String SSH    = "SSH";
	public static final String SERIAL = "Serial";

	//protected BaseWindowsApp appWin = null;
	protected static int HEIGHT_BARRA = 30; // VALOR POR DEFECTO 
	private VirtualKeyBoard vkb = null;
	private boolean hizoConecc = false;
	private UtilClipboard clipboard = new UtilClipboard();
	
//=======================================================================================================================
	public Putty() {
		super(APPLICATION);
	}
//***********************************************************************************************************************
	public Putty(Putty parent) {
		super(parent);
		this.hizoConecc = parent.hizoConecc;
	}
//***********************************************************************************************************************
	/**
	 * Este método indica si el Putty ha sido abierto por la automatización
	 */
	protected boolean isOpened() {
		if (!this.isOpened || !this.hizoConecc) return false;
		else {
			try {
				this.elementByAccessibilityId(this.accessIdBarraPutty); // BARRA DE PUTTY
				return true;
			} catch (NoSuchWindowException | NoSuchElementException e) {
				return false;
			}
		}
	}
//***********************************************************************************************************************
	protected void activate() {
		this.elementByAccessibilityId(this.accessIdBarraPutty).click();
	}
//***********************************************************************************************************************
	/**
	 * Este método primero valida si se encuentra abierto el putty, y de ser así procede con el cierre de este.
	 */
	@Override
	protected void close() {
		if (this.isOpened()) {
			try {
				this.click(this.elementByName("Cerrar"));
			}
			catch (NoSuchElementException e) { // EN ALGUNOS CASOS NO DETECTA EL ELEMENTO
				this.sendKeys(1, Keys.ALT, Keys.F4);
			}
			if (this.existElementByName("Aceptar")) {
				try {
					this.click(this.elementByName("Aceptar"));
				} catch (NoSuchWindowException e) {
					Reporter.write("OJO: Máquina que no deja dar click al 'Aceptar' cuando se cierra Putty");
				}
            }
			this.isOpened = false;
		}
	}
//***********************************************************************************************************************
	/**
	 * Este método retorna el texto presentado en la pantalla de Putty. <br>
	 * Hace el proceso de dar click derecho sobre la barra superior de Putty, para que se desplegue el menú y así poder
	 * seleccionar "Clear Scrollback" y luego "Copy All to Clipboard".
	 */
	@Override
	protected String readTE() {
		
		// LIMPIA EL CONTENIDO DEL CLIPBOARD:
		clipboard.cleanClipboard();
		/* TODO @BORRAR
		Clipboard clipboard = null;
		do {
			try {
				clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
		   		clipboard.setContents(new StringSelection(""), null);
			} catch (Exception e) {
				clipboard = null;
			}
		} while (clipboard == null);*/
   		
		String textoRetorno = "";
		try {
			RemoteWebElement barra = this.elementByAccessibilityId(this.accessIdBarraPutty);
			
			if (this.vkb == null) this.vkb = new VirtualKeyBoard();
			this.click(barra);     // PONE EL MOUSE SOBRE LA BARRA 
			vkb.mouseRightClick(); // CLICK DERECHO PARA QUE DESPLEGUE EL MENÚ DEL SISTEMA
			vkb.sendKey('l');      // PARA "Clear Scrollback"
			
			this.click(barra);     // PONE EL MOUSE SOBRE LA BARRA 
			vkb.mouseRightClick(); // CLICK DERECHO PARA QUE DESPLEGUE EL MENÚ DEL SISTEMA
			vkb.sendKey('o');      // PARA "Copy All to Clipboard"
			
			Util.wait(1); // TIEMPO DE ESPERA PARA QUE PERMITA RECONOCER EL CLIPBOARD
			
			// TRAE EL CONTENIDO DEL [clipboard] COMO UN String
			textoRetorno = clipboard.getClipboard();
			/* TODO @BORRAR
			clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
	        Transferable t = clipboard.getContents( null );
	        if ( t.isDataFlavorSupported(DataFlavor.stringFlavor) )
	            textoRetorno = (String)t.getTransferData( DataFlavor.stringFlavor );
	         */
		} catch (Exception e) {
			textoRetorno = "";
		}
		return textoRetorno;
	}
//***********************************************************************************************************************
    /**
     * Envía la teclas [keys] estando en el Emulador de Terminal de Putty.<br>
     * El envío de [keys] se hace las veces indicadas por [cantidad].
     */
	@Override
	protected void sendKeys(int cantidad, CharSequence... keys) {
		RemoteWebElement objTerminalEmm = this.elementByClassName(CLASS_NAME_PUTTY_TE);
   		for (int veces = 0; veces < cantidad; veces++) {
   			this.sendKeys(objTerminalEmm, keys);
   		}
    }
//***********************************************************************************************************************
	/**
	 * Método que asume que ya está abierta la aplicación (Putty) y trata de hacer la conexión.<br>
	 * Retorna [null] si la conexión se pudo realizar, en caso contrario retorna el error presentado.
	 * @param ipAddress - IP a donde se va a realizar al conexión
	 * @param typeConnection - Tipo de conexión, los posibles valores son RAW, TELNET, RLOGIN, SSH, SERIAL
	 */
	protected String doConnection(String ipAddress, String typeConnection) {
		
		// CONFIGURA LA CONEXIÓN
		try {
			this.click(this.elementByName("Connection"));
			RemoteWebElement cmSeconds = this.element("Edit", "Name:=Seconds between keepalives (0 to turn off)");
			this.clear(cmSeconds);
			this.sendKeys(cmSeconds, "25");
			this.click(this.elementByName("Session")); // PARA INGRESAR LA IP
		}
		catch (NoSuchElementException e) {
			Reporter.write("No reconoce en el árbol el nodo 'Connection' - Se cree es máquina DaaS");
		}
//-----------------------------------------------------------------------------------------------------------------------		
		// CONFIGURA EL LANZAMIENTO
		RemoteWebElement objIpAddress = this.element("Edit", "Name:=Host Name (or IP address)");
		this.clear(objIpAddress);
		this.sendKeys(objIpAddress, ipAddress);
		this.click(this.elementByName(typeConnection));
		// ENVÍA LOS COMANDOS PARA HACER LA APERTURA
		return this.doOpenPutty();
	}
//***********************************************************************************************************************
	/**
	 * Método que asume que ya está abierta la aplicación (Putty) y trata de hacer la conexión a una sesión
	 * que debe existir previamente con el nombre [nbSession].<br>
	 * Retorna [null] si la conexión se pudo realizar, en caso contrario retorna el error presentado.
	 * @param nbSession - Nombre de la sesión (que debe estar previamente configurada) a la que se conecta.
	 */
	protected String openSession(String nbSession) {
		
		// PREGUNTA SI ESTÁ LA SESIÓN CON EL NOMBRE [nbSession]
		if (!this.existElementByName(nbSession))
			return "En [openSession] NO está configurada con una sesión con el nombre '" + nbSession + "'";
		// SI LLEGA A ESTE PUNTO, EXISTE LA SESIÓN
		this.click(this.elementByName(nbSession));
		this.click(this.elementByName("Load"));
		// ENVÍA LOS COMANDOS PARA HACER LA APERTURA
		return this.doOpenPutty();
	}
//***********************************************************************************************************************
	/**
	 * Da click en el botón "Open" de tratus y espera la correcta apertura.
	 * @return [null] si se realiza la conexión en caso contrario rerorna el error respectivo
	 */
	private String doOpenPutty() {
		
		String idConfigurationWin = this.getIdWindow();
		this.click(this.elementByName("Open"));
		// BUSCA LAS VENTANAS EXISTENTES, PARA CAMBIAR A LA QUE DEBE APARECER DESPUÉS DE TRATAR DE HACER LA CONEXIÓN
		boolean winChanged = false;
		do {
			for(String idW : this.getIdWindows()) {
				if (!idConfigurationWin.equals(idW)) {
					this.changeWindow(idW);
					winChanged = true;
					break; // TERMINA EL FOR 
				}
			}
		} while (!winChanged);
//-----------------------------------------------------------------------------------------------------------------------		
		// EN ESTE PUNTO PUTTY ESTÁ ENVIANDO LA CONEXIÓN, PUEDE HABER ERROR O CONEXIÓN:
		boolean existDialog = false;
		String pantalla;
		do {
			pantalla = this.readTE();
			if (pantalla.isEmpty()) existDialog = this.existElementByClassName("Button");
		} while (pantalla.isEmpty() && !existDialog);
		
		String msgError = null;
		if (existDialog) {
			this.click(this.elementByClassName("Button"));
			this.close();
			this.isOpened = false;
			msgError = "Salió error en la conexión del PUTTY";
		}
		else {
			this.hizoConecc = true;
			RemoteWebElement barra = this.elementByAccessibilityId(this.accessIdBarraPutty);
			HEIGHT_BARRA = barra.getSize().getHeight();
		}
		return msgError;
	}
//***********************************************************************************************************************
	/**
	 * Escribe el [numero] en la pantalla de Putty, el cursor debe estar ubicado en el espacio en donde se requiere
	 * hacer el ingreso.
	 */
	protected void paste(int numero) {
   		this.paste(String.valueOf(numero));
   	}
//***********************************************************************************************************************
	/**
	 * Escribe el [texto] en la pantalla de Putty, el cursor debe estar ubicado en el espacio en donde se requiere hacer
	 * el ingreso.
	 */
	protected void paste(String texto) {
		/* TODO @BORRAR
   		try { // BORRAR EL PORTAPAPELES CON UN COMANDO
   			Runtime.getRuntime().exec("cmd /c @echo off|clip");
   		} catch (IOException e) {
   				e.printStackTrace();
 		}
 		*/
//-----------------------------------------------------------------------------------------------------------------------
		if (Util.itemContainsAnyArrayItem(texto, SPECIAL_CHAR)) {
			this.elementByAccessibilityId(this.accessIdBarraPutty).click();
			clipboard.setClipboard(texto); // PARA DARLE FOCO AL PUTTY
			RemoteWebElement objTerminalEmm = this.elementByClassName(CLASS_NAME_PUTTY_TE);
			new Actions(this.getDriver()).click(objTerminalEmm).contextClick(objTerminalEmm).release().perform(); // CLICK DERECHO
		}
		else
			this.write(texto);
   	}
//***********************************************************************************************************************
}
