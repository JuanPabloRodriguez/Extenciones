package library.core;

import java.util.HashMap;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import library.common.Util;

/**
 * Esta clase <b>cierra</b> todos los chrome.exe que se estén ejecutando y así mismo los chromedriver.exe<br>
 * Sólo se puede usar cuando en la máquina donde se ejecuta hay una <b>única sesión de chrome</b>, de lo contrario no
 * sabrá cuál escoger.<br>
 * Es requisito poder ejecutar desde un [cmd] un "chrome.exe" si no se puede es porque hace falta adicionar a la variable
 * de ambiente "path" la ruta en donde se encuentra dicho ejecutable. 
 * @author smzealo
 */
public class BasePageWeb_OpeningChrome extends BasePageWeb {

	private static int DEFAULT_CHROME_PORT = 9222;
	private static String DOWNLOAD_DIR_CHROME = null;
	
//***********************************************************************************************************************
	/**
	 * Único constructor: se usa sólo para apertura en navegador Chrome
	 */
	public BasePageWeb_OpeningChrome() {
		super(BasePageWeb.CHROME);
	}
//***********************************************************************************************************************
	/**
	 * @param parentPage
	 */
	public BasePageWeb_OpeningChrome(BasePageWeb parentPage) {
		super(parentPage);
	}
//***********************************************************************************************************************
	/**
     * constructor: se usa sólo para apertura en navegador Chrome
     */
    public BasePageWeb_OpeningChrome(String downloadFilePath) {
        super(BasePageWeb.CHROME, downloadFilePath);
    }
//***********************************************************************************************************************
	/**
	 * Carga las propiedades pertinentes del Chrome.<br>
	 * Mata lo procesos Chrome para garantizar que el que se abre se encuentra en el puerto requerido, es para tener
	 * control y que sea una sesión existente en la máquina local.
	 */
	@Override
	protected void loadChromeProperties() {

		// ES REQUERIDO MATAR LOS PROCESOS, PARA GARANTIZAR QUE EL QUE SE ABRE ES EL [DEFAULT_CHROME_PORT]
		Util.cleanBrowserDrivers();  // MATA LOS DRIVERS QUE ESTÁN VIVOS
		Util.killTask("chrome.exe"); // MATA LOS PROCESOS 'chrome.exe'
		Util.wait(2);
		// HACE LA APERTURA DEL CHROME INDICANDO EL PUERTO DE CONEXIÓN
		Util.executeCmdComand("chrome.exe --explicitly-allowed-ports=" + DEFAULT_CHROME_PORT
			                          + " --remote-debugging-port=" + DEFAULT_CHROME_PORT);
//-----------------------------------------------------------------------------------------------------------------------
		// HACE LA CONEXIÓN CON EL DRIVER
		ChromeOptions options = new ChromeOptions();
		options.setExperimentalOption("debuggerAddress", "localhost:" + DEFAULT_CHROME_PORT);
		options.addArguments("--disable-features=VizDisplayCompositor");
		options.addArguments("--start-maximized");
		options.addArguments("--disable-logging");
		HashMap  <String, String> dict = new HashMap<String, String>();
		dict.put("enabled_labs_experiments", "[ force-compositing-mode-2@1 ]");
		options.setCapability("localState", dict);
		this.setDriver(new ChromeDriver(options));
		this.setPidDriver(); // SETEA EL PID DEL DRIVER CREADO
		this.loadPortYPidAsProperty((ChromeDriver) this.getDriver());
//-----------------------------------------------------------------------------------------------------------------------
		// SI SE DEBE HACER CAMBIO DEL PATH DE DOWNLOAD SE HACE
		if (!this.getDownloadFilePath().isEmpty())
			DOWNLOAD_DIR_CHROME = this.changeDownloadDir_InChrome(this.getDownloadFilePath());
	}
//***********************************************************************************************************************
	@Override
	protected void changeToOriginalDownloadDir_OpeningChrome() {
		if (DOWNLOAD_DIR_CHROME != null)
			this.changeDownloadDir_InChrome(DOWNLOAD_DIR_CHROME);
	}
//***********************************************************************************************************************
	/**
	 * Como la apertura de la página la toma de la sesión abierta, con este método se puede indicar el zoom que debe
	 * tener, se recomienda enviar el valor 100.
	 */
	public void hacerZoom(int porcZoom) {
		this.jse.executeScript("document.body.style.zoom='" + porcZoom + "%';");
	}
//***********************************************************************************************************************
}