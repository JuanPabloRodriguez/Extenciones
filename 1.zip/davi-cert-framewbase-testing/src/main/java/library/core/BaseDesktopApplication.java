package library.core;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.NoSuchWindowException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.appium.java_client.windows.WindowsDriver;
import library.common.Util;
import library.common.UtilClipboard;
import library.reporting.Reporter;
import library.settings.SettingsRun;

public class BaseDesktopApplication {

	private static final String URL_APPDRIV_SERVER = "http://127.0.0.1:LOCAL_PORT/wd/hub";
	protected Map<String, Object> capabilities = new HashMap<String, Object>();
	// NO SE USA [WindowsElement] PARA QUE NO DEPENDA DE APPIUM
	protected WindowsDriver<?> driver;
	protected WebDriverWait explicitWait;
	private String application;
	protected boolean isOpened = false;
	public static String PORT = "4723";

//=======================================================================================================================
	// public BaseWindowsApp() {}
//***********************************************************************************************************************
	/**
	 * Recibe el nombre de la aplicación a abrir, e intenta realizar su apertura.<br>
	 * Deja almacenado en [this.isOpened] si la conexión se realizó.
	 */
	public BaseDesktopApplication(String application) {

		String msgError = this.openApplication(application);
		if (msgError != null)
			SettingsRun.exitTest(msgError);
	}
//***********************************************************************************************************************
	/**
	 * Constructor que hereda todos los elementos del padre [parent] - No genera un driver aparte.
	 */
	public BaseDesktopApplication(BaseDesktopApplication parent) {

		this.driver = parent.driver;
		this.application = parent.application;
		this.isOpened = parent.isOpened;
	}
//***********************************************************************************************************************
	/**
	 * Método que intenta abrir la aplicación indicada = [application]<br>
	 * Retorna [null] si se pudo abrir la aplicación, en caso contrario retorna el mensaje de error presentado.
	 */
	protected String openApplication(String application) {

		String msgError = null;
		this.application = application;
		// CARGA LOS CAPABILITIES GENERALES
		this.loadCapabilities();
		// PERMITE ADICIONAR O MODIFICAR CAPABILITIES
		this.changeCapabilities();
		try {
			// ABRE LA APLICACIÓN DESEADA
			DesiredCapabilities cap = new DesiredCapabilities();
			// RECORRE EL HASHMAP PARA EXTRAER LOS CAPABILITIES
			for (HashMap.Entry<String, Object> capability : capabilities.entrySet()) {
				String capabilityName = capability.getKey();
				Object value = capability.getValue();
				cap.setCapability(capabilityName, value);
			}
			String puerto = SettingsRun.getProperty(SettingsRun.PROP_APPIUM_PORT, PORT);
			String urlRemote = URL_APPDRIV_SERVER.replace("LOCAL_PORT", puerto); // ABRE CON APPIUM
			this.driver = new WindowsDriver<RemoteWebElement>(new URL(urlRemote), cap);
			// this.driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
			Util.wait(2);
			System.out.println("Aplicación abierta: " + driver.getTitle());
			this.isOpened = true;
		}
		catch (Exception e) {
			this.close();
			e.printStackTrace();
			this.isOpened = false;
			msgError = e.getMessage();
			if (msgError.contains("Connection refused: connect"))
				msgError = "REVISE SI APPIUM SE ESTÁ EJECUTANDO - VER ADMINISTRADOR DE TAREAS\n\n" + msgError;
		}
		return msgError;
	}
//***********************************************************************************************************************
	public String getApplication() {

		return this.application;
	}
//***********************************************************************************************************************
	public WindowsDriver<?> getDriver() {

		return this.driver;
	}
//***********************************************************************************************************************
	protected void close() {

		if (this.driver != null) {
			this.driver.close();
			this.isOpened = false;
		}
	}
//***********************************************************************************************************************	
	// Enviar de primeras el ClassName
	@SuppressWarnings("unchecked")
	public RemoteWebElement element(String className, String... properties) {

		boolean objetoEncontrado = false;
		List<RemoteWebElement> elements = (List<RemoteWebElement>) this.driver.findElementsByClassName(className);
		RemoteWebElement elementRet = null;
		if (properties.length == 0 && elements.size() != 0) {
			// Si no se reciben "properties" y si hay elementos con el ClassName enviado, se
			// retorna el primer elemento
			elementRet = elements.get(0);
			objetoEncontrado = true;
		}
		else {
			for (RemoteWebElement element : elements) {
				objetoEncontrado = true; // Valor por defecto para concatenar condición de AND
				for (String property : properties) {
					String[] fields = property.split(":="); // 0:atributo, 1:valor
					objetoEncontrado = objetoEncontrado && element.getAttribute(fields[0]).contentEquals(fields[1]);
					if (!objetoEncontrado)
						break; // Termina el ciclo, porque NO es el objeto buscado
				}
				if (objetoEncontrado) {
					elementRet = element;
					break; // Termina el ciclo, porque YA encontró el objeto buscado
				}
			}
		}
		if (!objetoEncontrado)
			throw new NoSuchElementException("No se encontró elemento con ClassName [" + className + "] y propiedades ["
				+ String.join(";", properties) + "]");
		return elementRet;
	}
//***********************************************************************************************************************	
	public RemoteWebElement elementByName(String name) {

		RemoteWebElement elementRet = null;
		try {
			elementRet = (RemoteWebElement) this.driver.findElementByName(name);
		}
		catch (NoSuchElementException e) {
			elementRet = null;
		}
		return elementRet;
	}
//***********************************************************************************************************************
	@SuppressWarnings("unchecked")
	public List<RemoteWebElement> elementsByName(String name) {

		return (List<RemoteWebElement>) this.driver.findElementsByName(name);
	}
//***********************************************************************************************************************
	public RemoteWebElement elementByClassName(String className) {

		RemoteWebElement elementRet = null;
		try {
			elementRet = (RemoteWebElement) this.driver.findElementByClassName(className);
		}
		catch (NoSuchElementException e) {
			elementRet = null;
		}
		return elementRet;
	}
//***********************************************************************************************************************
	public RemoteWebElement elementByAccessibilityId(String accId) {

		RemoteWebElement elementRet = null;
		try {
			elementRet = (RemoteWebElement) this.driver.findElementByAccessibilityId(accId);
		}
		catch (NoSuchElementException e) {
			elementRet = null;
		}
		return elementRet;
	}
//***********************************************************************************************************************
	public boolean existElementByName(String name) {

		try {
			this.driver.findElementByName(name);
			return true;
		}
		catch (NoSuchWindowException | NoSuchElementException e) {
			return false;
		}
	}
//***********************************************************************************************************************
	public boolean existElementByClassName(String className) {

		try {
			this.driver.findElementByClassName(className);
			return true;
		}
		catch (NoSuchElementException e) {
			return false;
		}
	}
//***********************************************************************************************************************
	public boolean existElementByAccessibilityId(String accId) {

		try {
			this.driver.findElementByAccessibilityId(accId);
			return true;
		}
		catch (NoSuchElementException e) {
			return false;
		}
	}
//***********************************************************************************************************************
	public String getIdWindow() {

		return this.driver.getWindowHandle();
	}
//***********************************************************************************************************************	
	public List<String> getIdWindows() {

		return new ArrayList<String>(this.driver.getWindowHandles());
	}
//***********************************************************************************************************************
	public void changeWindow(String idWindow) {

		this.driver.switchTo().window(idWindow);
	}
//***********************************************************************************************************************
	public boolean changeWindowName(String name) {

		 //Obtener todos los contextos disponibles 
        Set<String> windowHandles = driver.getWindowHandles();

        // Iterar sobre las manijas de ventana y cambiar a la ventana deseada
        for (String windowHandle : windowHandles) {
            driver.switchTo().window(windowHandle);
            if (driver.getTitle().contains(name)) {
                return true;
            }
        }
		return false;
	}
//***********************************************************************************************************************
	/**
	 * Método que almacena la captura de pantalla de la aplicación windows en el archivo requerido.
	 * 
	 * @param nbFilePath = Debe venir con la ruta completa y la extensión de imagen deseada.
	 */
	public void saveScreenshot(String nbFilePath) {

		File dst = new File(nbFilePath);
		if (dst.exists())
			dst.delete(); // Lo borra en caso que exista
		File src = ((TakesScreenshot) this.driver).getScreenshotAs(OutputType.FILE);
		try {
			FileHandler.copy(src, dst);
		}
		catch (IOException e) {
			e.printStackTrace();
		}
	}
//***********************************************************************************************************************
	/**
	 * Método que almacena la captura de pantalla de la aplicación windows en el archivo requerido.
	 * 
	 * @param nbFilePath = Debe venir con la ruta completa y la extensión de imagen deseada.
	 */
	public void saveScreenshot(String nbFilePath, WebElement element) {

		File dst = new File(nbFilePath);
		if (dst.exists())
			dst.delete(); // Lo borra en caso que exista
		File src = element.getScreenshotAs(OutputType.FILE);
		try {
			FileHandler.copy(src, dst);
		}
		catch (IOException e) {
			e.printStackTrace();
		}
	}
//***********************************************************************************************************************
	/**
	 * Retorna el ancho del [element], extrauyéndolo del atribuot "BoundingRectangle".
	 */
	public int getWidthInDesktop(RemoteWebElement element) {

		String dato = element.getAttribute("BoundingRectangle"); // Left:# Top:# Width:# Height:#
		int width = 0;
		if (dato != null) {
			String[] x = dato.split("Width:"); // 0-...., 1-# Height:
			String[] y = x[1].split("Height:"); // 0-#, 1-...
			width = Integer.valueOf(y[0].trim());
		}
		return width;
	}
//***********************************************************************************************************************
	/**
	 * Envía la teclas [keys] sobre el [element] recibido.
	 */
	public void sendKeys(RemoteWebElement element, CharSequence... keys) {

		element.sendKeys(keys);
	}
//***********************************************************************************************************************
	/**
	 * Limpia el contenido del [element] recibido. (si es un input)
	 */
	public void clear(RemoteWebElement element) {

		element.clear();
	}
//***********************************************************************************************************************
	/**
	 * Da click sobre el [element] recibido.
	 */
	public void click(RemoteWebElement element) {

		element.click();
	}
//***********************************************************************************************************************
	/* ESTAS SON LAS NUEVAS IMPLEMENTACIONES PARA LA AUTOMATIZACIÓN DE APLICACIONES DE ESCRITORIO USANDO PAGE-FACTORY */
//***********************************************************************************************************************
	/**
	 * @author PYHOCAST (Yhon L. Castañeda)
	 * 
	 * Este método se encarga de maximizar la venta de la aplicación de escritorio abierta.
	 */
	public void maximizeWindow() {

		this.driver.manage().window().maximize();
	}
//***********************************************************************************************************************
	/**
	 * @author pyhocast (Yhon L. Castañeda)
	 * 
	 * Carga los capabilities requeridos para la conexión con la aplicación de escritorio.
	 */
	private void loadCapabilities() {

		capabilities.put("platformName", "Windows");
		capabilities.put("deviceName", "WindowsPC");
		capabilities.put("app", this.application);
	}
// **********************************************************************************************************************
	/**
	 * @author pyhocast (Yhon L. Castañeda)
	 * 
	 * Después de la carga de capabilities, este método permite cambiar o adicionar capabilities, debe ser sobreescrito
	 * por la clase que herede de esta clase y quiera cambiar o adicionar capabilities para la conexión.
	 */
	protected void changeCapabilities() {

		// TODO SOBREESCRIBIR SEGÚN SE REQUIERA EN LAS CLASES QUE HEREDAN. Ejemplo:
		// this.capabilities.put("ms:waitForAppLaunch", "5");
	}
// **********************************************************************************************************************
	/**
	 * @author PYHOCAST (Yhon L. Castañeda)
	 * 
	 * Este método recibe un <xpath> como parámetro de entrada y permite que sea usado por el mecanismo de localización
	 * <By> para posteriormente retornar un elemento de tipo <WebElement>. Este método es usado principalmente cuando hay
	 * 'xpath' dinámicos que debemos implementar con <PageFactory>
	 * 
	 * @param xpath
	 * @return
	 */
	protected WebElement element(String xpath) {

		WebElement element = null;
		try {
			By locator = By.xpath(xpath);
			element = this.driver.findElement(locator);
		}
		catch (Exception e) {
			Reporter.write("ERROR LOCALIZADOR");
		}
		return element;
	}
// **********************************************************************************************************************
	/**
	 * @author pyhocast (Yhon L. Castañeda)
	 * 
	 * Este método tiene como función, esperar a que un elemento de Windows aparezca. Para ello, se envían dos
	 * parámetros, donde el primero es el tiempo en segundos que va a esperar hasta que aparezca el elemento, el otro
	 * parámetro es el elemento tipo <WebElement> que se quiere buscar.
	 * 
	 * @param timeInSeconds
	 * @param element
	 */
	protected boolean waitUntilElementAppear(int timeInSeconds, WebElement element) {

		boolean visible = false;
		try {
			// explicitWait = new WebDriverWait(this.driver, Duration.ofSeconds(timeInSeconds));
			explicitWait = new WebDriverWait(this.driver, timeInSeconds);
			explicitWait.until(ExpectedConditions.visibilityOf(element)); // @ZEA : PUSE driver -> PERO NO SÉ QUÉ
																			// SIGNIFICA
			visible = true;
		}
		catch (Exception e) {
			visible = false;
		}
		return visible;
	}
// **********************************************************************************************************************
	/**
	 * @author pyhocast (Yhon L. Castañeda)
	 * 
	 * Este método se encarga de validar si el elemento está desplegado. En tal caso que no lo esté, retorna un <false>
	 * 
	 * @param element: Elemento a evaluar.
	 * @return
	 */
	protected boolean isDisplayedDesktopElement(WebElement element) {

		boolean display;
		try {
			display = element.isDisplayed();
		}
		catch (Exception e) {
			display = false;
		}
		return display;
	}
// **********************************************************************************************************************
	/**
	 * @author pyhocast
	 * 
	 * Este método se encarga de dar click al elemento, el cual se pasa por parámetro.
	 * @param element: Locatizador de la aplicación de escritrio (El localizador, debe ser de tipo WebElement).
	 */
	protected void click(WebElement element) {

		try {
			element.click();
		}
		catch (Exception e) {
			Reporter.write("ERROR CLICK ELEMENTO");
		}
	}
// **********************************************************************************************************************
	/**
	 * @author pyhocast (Yhon L. castañeda)
	 * 
	 * Este método se encarga de enviar la información a la pantalla, para ello, se pasa un localizdor de tipo
	 * <Webelement>
	 * @param element: Localizador del campo de texto.
	 * @param keys: Información a digitar en el campo de texto.
	 */
	protected void sendKeys(WebElement element, CharSequence... keys) {

		try {
			element.sendKeys(keys);
		}
		catch (Exception e) {
			Reporter.write("ERROR DIGITAR INFORMACIÓN");
		}
	}
// **********************************************************************************************************************
	/**
	 * @author pyhocast (Yhon L. Castañeda)
	 * 
	 * Este método se encarga de limpiar el campo de tipo texto.
	 * @param element: Localizador del campo de tipo texto.
	 */
	protected void clear(WebElement element) {

		try {
			element.clear();
		}
		catch (Exception e) {
			Reporter.write("ERROR LIMPIAR CAMPO");
		}
	}
// **********************************************************************************************************************
	/**
	 * @author pyhocast (Yhon L. Castañeda)
	 * 
	 * Este método se encarga de leer el texto que contiene el elemento parado por parámetro y lo retorna.
	 * @param element: Localizador del elemento del cual vamos a obtener el texto.
	 * @return <"">, Si no se pudo leer el texto. <NoEmpty>, si se pudo leer el texto
	 */
	protected String getText(WebElement element) {

		String texto = "";
		try {
			texto = element.getText();
			if (texto.isEmpty()) {
				texto = element.getAttribute("innerHTML");
				if (texto == null) {
					texto = element.getAttribute("textContent");
					if (texto == null) {
						texto = element.getAttribute("placeholder");
						if (texto == null) {
							texto = element.getAttribute("value");
							if (texto == null)
								texto = "";
						}
					}
				}
			}
		}
		catch (Exception e) {
			// DEJA QUE EL RETORNO SEA [""]
		}
		return texto;
	}
// **********************************************************************************************************************
	/**
	 * @author pyhocast (Yhon L. Castañeda) Este método se encarga de copiar el texto seleccionado en el aplicativo.
	 */
	public void copy() {

		Actions action = new Actions(this.getDriver());
		new UtilClipboard().cleanClipboard();
		action.sendKeys(Keys.CONTROL).sendKeys("c").build().perform();
		Util.waitMiliseconds(150);
		action.release().perform();
		this.sendKey(Keys.CONTROL);
	}
// **********************************************************************************************************************
	/**
	 * @author pyhocast (Yhon L. Castañeda) Este método se encarga de presionar TAB * @param: number. Ejemplo: 1-2-3-4
	 */
	public void makeTab(int number) {

		Actions action = new Actions(this.getDriver());
		for (int i = 0; i < number; i++) {
			action.sendKeys(Keys.TAB).build().perform();
			Util.waitMiliseconds(150);
			action.release().perform();
		}
	}
// **********************************************************************************************************************
	/**
	 * @author pyhocast (Yhon L. Castañeda) Este método se encarga de presionar ENTER
	 * @param: number. Ejemplo: 1-2-3-4
	 */
	public void makeEnter(int number) {

		Actions action = new Actions(this.getDriver());
		for (int i = 0; i < number; i++) {
			action.sendKeys(Keys.ENTER).build().perform();
			Util.waitMiliseconds(150);
			action.release().perform();
		}
	}
// **********************************************************************************************************************
	/**
	 * @author pyhocast (Yhon L. Castañeda) Este método se encarga de presionar o enviar una tecla. Por ejemplo CONTROL
	 * @param key: Ejemplo. Keys.CONTROL
	 */
	public void sendKey(Keys key) {

		Actions action = new Actions(this.getDriver());
		action.sendKeys(key).build().perform();
		Util.waitMiliseconds(150);
		action.release().perform();
	}
// **********************************************************************************************************************
	/**
	 * @author pyhocast (Yhon L. Castañeda) Este método se encarga de digitar el texto pasado por parametro en donde esté
	 * el cursos
	 */
	public void sendKey(String text) {

		Actions action = new Actions(this.getDriver());
		action.sendKeys(text).build().perform();
		Util.waitMiliseconds(150);
		action.release().perform();
	}
// **********************************************************************************************************************
	/**
	 * @author pyhocast (Yhon L. Castañeda)
	 * 
	 * Este método tiene como objetivo cerrar la aplicación de escritorio que se abrió con <WindowsDriver>. Generalmente
	 * se llama en el método "destroy()" de la clase <Controller>.
	 */
	public void closeWindowsDriver() {

		if (this.driver != null)
			this.driver.close();
	}
// **********************************************************************************************************************
	/**
	 * 
	 * Método encargado de retornar los elementos existentes que corresponden a determinado [xpath]. Si este dato viene
	 * VACÍO, imprime todos los elementos existentes.
	 * 
	 * @param xpath: Localizador de la aplicación de escritrio.
	 */
	public List<WebElement> countAllElements(String xpath) {

		if (xpath.isEmpty())
			xpath = "//*"; // Busca todo
		List<WebElement> elements = this.findElements(By.xpath(xpath));
		Reporter.writeOnlyConsole("Se encontraron [" + elements.size() + "] elementos");
		return elements;
	}
// ***********************************************************************************************************************
	/**
	 * Retorna una lista de WebElement que corresponden al [locator] dado.
	 */
	@SuppressWarnings("unchecked")
	public List<WebElement> findElements(By locator) {

		return (List<WebElement>) this.driver.findElements(locator);
	}
// **********************************************************************************************************************
}