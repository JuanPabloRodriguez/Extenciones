package library.core;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.NoSuchWindowException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebElement;

import io.appium.java_client.windows.WindowsDriver;
import library.common.Util;
import library.settings.SettingsRun;

public class BaseWindowsApp {

	private static final String WIN_APP_DRIVER     = "WinAppDriver.exe";
	private static final String URL_APPDRIV_SERVER = "http://127.0.0.1:4723";
	//private static final String URL_APPDRIV_SERVER = "http://127.0.0.1:4723/wd/hub";
	
	protected Map<String, Object> capabilities = new HashMap<String, Object>();
	
	private static Process process = null;
	private WindowsDriver<RemoteWebElement> driver;
	private String application;
	protected boolean isOpened = false;
	
//=======================================================================================================================
	//public BaseWindowsApp() {}
//***********************************************************************************************************************
	/**
	 * Recibe el nombre de la aplicación a abrir, e intenta realizar su apertura.<br>
	 * Deja almacenado en [this.isOpened] si la conexión se realizó.
	 */
	public BaseWindowsApp(String application) {
		String msgError = this.openApplication(application);
		if (msgError != null) SettingsRun.exitTest(msgError);
	}
//***********************************************************************************************************************
	/**
	 * Constructor que hereda todos los elementos del padre [parent] - No genera un driver aparte.
	 */
	public BaseWindowsApp(BaseWindowsApp parent) {
		this.driver = parent.driver;
		this.application = parent.application;
		this.isOpened = parent.isOpened;
	}
//***********************************************************************************************************************
	/**
	 * Método que intenta abrir la aplicación indicada = [application]<br>
	 * Retorna [null] si se pudo abrir la aplicación, en caso contrario retorna el mensaje de error presentado.
	 */
	protected String openApplication(String application) {
		
		String msgError = null;
		this.application = application;
		
		// CARGA LOS CAPABILITIES GENERALES
		this.loadCapabilities();
		// PERMITE ADICIONAR O MODIFICAR CAPABILITIES
		this.changeCapabilities();

		try {
			// LANZA EL PROCESO DE [WinAppDriver] SI NO SE HA HECHO
			if (!BaseWindowsApp.isRunningWinAppDriver())
				BaseWindowsApp.beginWinAppDriver();
			
			// ABRE LA APLICACIÓN DESEADA
			DesiredCapabilities cap = new DesiredCapabilities();
			// RECORRE EL HASHMAP PARA EXTRAER LOS CAPABILITIES
			for (HashMap.Entry<String, Object> capability : capabilities.entrySet()) {
				String capabilityName = capability.getKey();
				Object value = capability.getValue();
				cap.setCapability(capabilityName, value);
			}
			String urlRemote = URL_APPDRIV_SERVER; // DEFAULT [WinAppDriver]
			Util.wait(2);
			this.driver = new WindowsDriver<RemoteWebElement>(new URL(urlRemote), cap);
			
			Util.wait(2);
			System.out.println("Aplicación abierta: " + driver.getTitle());
			this.isOpened = true;
			
		} catch (Exception e) {
			this.close();
			BaseWindowsApp.destroyWinAppDriver();
			e.printStackTrace();
			this.isOpened = false;
			msgError = e.getMessage();
			if (msgError.contains("Connection refused: connect"))
				msgError = "REVISE SI EL [WinAppDriver.exe] SE ESTÁ EJECUTANDO - VER ADMINISTRADOR DE TAREAS\n\n"
			             + msgError;
		}
		return msgError;
	}
//***********************************************************************************************************************
	/**
	 * Este método se encarga de maximizar la venta de la aplicación de escritorio abierta.
	 */
	public void maximizeWindow() {
		this.driver.manage().window().maximize();
	}
//***********************************************************************************************************************
	/**
	 * Carga los capabilities requeridos para la conexión con la aplicación de escritorio.
	 */
	private void loadCapabilities() {
		capabilities.put("app", this.application);
	}

// **********************************************************************************************************************
	/**
	 * Después de la carga de capabilities, este método permite cambiar o adicionar capabilities, debe ser sobreescrito
	 * por la clase que herede de esta clase y quiera cambiar o adicionar capabilities para la conexión.
	 */
	protected void changeCapabilities() {
		// TODO SOBREESCRIBIR SEGÚN SE REQUIERA EN LAS CLASES QUE HEREDAN. Ejemplo:
		// this.capabilities.put("ms:waitForAppLaunch", "5");
	}
// **********************************************************************************************************************
	public String getApplication() {
		return this.application;
	}
//***********************************************************************************************************************
	public WindowsDriver<RemoteWebElement> getDriver() {
		return this.driver;
	}
//***********************************************************************************************************************
	protected void close() {
		if (this.driver != null) {
			this.driver.close();
			this.isOpened = false;
		}
	}
//***********************************************************************************************************************	
	public static void beginWinAppDriver() {
		try {
			if (BaseWindowsApp.isRunningWinAppDriver())
				return; // YA ESTÁ CORRIENDO EL WINAPPDRIVER NO HAY QUE HACER NADA
			
			System.out.println("Inicializa el [WinAppDriver]...");
			ProcessBuilder builder = new ProcessBuilder(WIN_APP_DRIVER);//.inheritIO();
			// PARA QUE LA SALIDA DE TERMINAL LA ALMACENE EN LA RUTA INDICADA
			if (!Util.directoryExist(SettingsRun.RESULT_DIR)) // EN CASO QUE NO EXISTA, LO CREA
				new File(SettingsRun.RESULT_DIR).mkdirs();
			builder.redirectOutput(new File(SettingsRun.RESULT_DIR + File.separator + "_WINAPP_LOG.txt"));
			process = builder.start();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
//***********************************************************************************************************************
	public static void destroyWinAppDriver() {
		if (process != null) {
			System.out.println("Destruye el [WinAppDriver]...");
			if(process.isAlive()) {
				process.destroy();
				process = null;
			}
		}
	}
//***********************************************************************************************************************
	//Enviar de primeras el ClassName
	public RemoteWebElement element(String className, String... properties) {
		
		boolean objetoEncontrado = false;
		List<RemoteWebElement> elements = this.driver.findElementsByClassName(className);
		RemoteWebElement elementRet = null;
		if (properties.length == 0 && elements.size() != 0) {
			//Si no se reciben "properties" y si hay elementos con el ClassName enviado, se retorna el primer elemento
			elementRet = elements.get(0);
			objetoEncontrado = true;
		} else {
			for (RemoteWebElement element : elements) {
				objetoEncontrado = true; //Valor por defecto para concatenar condición de AND
				for (String property : properties) {
					String[] fields = property.split(":="); //0:atributo, 1:valor
					objetoEncontrado = objetoEncontrado && element.getAttribute(fields[0]).contentEquals(fields[1]);
					if (!objetoEncontrado) break; //Termina el ciclo, porque NO es el objeto buscado
				}
				if (objetoEncontrado) {
					elementRet = element;
					break; //Termina el ciclo, porque YA encontró el objeto buscado
				}
			}
		}
		
		if (!objetoEncontrado)
			throw new NoSuchElementException("No se encontró elemento con ClassName [" + className + "] y propiedades [" + String.join(";", properties) + "]");
		
		return elementRet;
		
	}
//***********************************************************************************************************************	
	public RemoteWebElement elementByName(String name) {
		return this.driver.findElementByName(name);
	}
//***********************************************************************************************************************
	public List<RemoteWebElement> elementsByName(String name) {
		return this.driver.findElementsByName(name);
	}
//***********************************************************************************************************************
	public RemoteWebElement elementByClassName(String className) {
		return this.driver.findElementByClassName(className);
	}
//***********************************************************************************************************************
	public RemoteWebElement elementByAccessibilityId(String accId) {
		return this.driver.findElementByAccessibilityId(accId);
	}
//***********************************************************************************************************************
	public boolean existElementByName(String name) {
		try {
			this.elementByName(name);
			return true;
		} catch (NoSuchWindowException | NoSuchElementException e) {
			return false;
		}
	}
//***********************************************************************************************************************
	public boolean existElementByClassName(String className) {
		try {
			this.elementByClassName(className);
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}
//***********************************************************************************************************************
	public boolean existElementByAccessibilityId(String accId) {
		try {
			this.elementByAccessibilityId(accId);
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}
//***********************************************************************************************************************
	public String getIdWindow() {
		return this.driver.getWindowHandle();
	}
//***********************************************************************************************************************	
	public List<String> getIdWindows() {
		return new ArrayList<String>(this.driver.getWindowHandles());
	}
//***********************************************************************************************************************
	public void changeWindow(String idWindow) {
		this.driver.switchTo().window(idWindow);
	}
//***********************************************************************************************************************
	/**
	 * Método que almacena la captura de pantalla de la aplicación windows en el archivo requerido.
	 * @param nbFilePath = Debe venir con la ruta completa y la extensión de imagen deseada. 
	 */
	public void saveScreenshot(String nbFilePath) {
		
		File dst = new File(nbFilePath);
		if (dst.exists()) dst.delete(); //Lo borra en caso que exista
		
        File src = ((TakesScreenshot)this.driver).getScreenshotAs(OutputType.FILE);
        try {
        	FileHandler.copy(src, dst);
        } catch (IOException e) {
            e.printStackTrace();
        }
	}
//***********************************************************************************************************************
	/**
	 * Método que almacena la captura de pantalla de la aplicación windows en el archivo requerido.
	 * @param nbFilePath = Debe venir con la ruta completa y la extensión de imagen deseada. 
	 */
	public void saveScreenshot(String nbFilePath, WebElement element) {
		
		File dst = new File(nbFilePath);
		if (dst.exists()) dst.delete(); //Lo borra en caso que exista
		
        File src = element.getScreenshotAs(OutputType.FILE);
        try {
        	FileHandler.copy(src, dst);
        } catch (IOException e) {
            e.printStackTrace();
        }
	}
//=======================================================================================================================
	// TODO >> MÉTODOS PARA EL MANEJO DE ENVÍOS DE TECLADO EN AL APLICACIÓN:
    
    /**
     * Envía la teclas [keys]. Si alguna contiene Keys.SHIFT, Keys.ALT, Keys.CONTROL hace el [keyUp] de esa tecla en el
     * orden contrario en que son ingresadas.<br>
     * El envío de [keys] se hace las veces indicadas por [cantidad].
     */
    protected void sendKeys(int cantidad, CharSequence... keys) {
   		Actions action = new Actions(this.getDriver());
   		int totalChar = keys.length;
   		for (int veces = 0; veces < cantidad; veces++) {
			action.sendKeys(keys).build().perform();
			for (int posChar = totalChar-1; posChar >= 0; posChar--) {
				if (keys[posChar].equals(Keys.SHIFT) || keys[posChar].equals(Keys.ALT) || 
					keys[posChar].equals(Keys.CONTROL)) action.keyUp(keys[posChar]).perform();
			}
   		}
    }
//***********************************************************************************************************************
    /**
     * Envía el caracter [character] por teclado.
     */
    protected void sendKey(char character) {
   		this.sendKeys(1, String.valueOf(character));
   	}
//***********************************************************************************************************************
    /**
     * Envía el [numero] por teclado.
     */
    protected void sendKey(int numero) {
   		this.sendKeys(1, String.valueOf(numero));
   	}
//***********************************************************************************************************************
    /**
     * Envía el [texto] por teclado.
     */
    protected void write(String texto) {
   		this.sendKeys(1, texto);
   	}
//***********************************************************************************************************************
    /**
     * Sobre la aplicación windows da click en la <b>FLECHA ABAJO</b> el número de veces indicado por [cantidad].<br>
     * Si desea hacerse sobre un elemento específico, primero debe darse el foco al elemento.
     */
	protected void down(int cantidad) {
		this.sendKeys(cantidad, Keys.ARROW_DOWN);
   	}
//***********************************************************************************************************************
    /**
     * Sobre la aplicación windows da click en la <b>FLECHA ARRIBA</b> el número de veces indicado por [cantidad].<br>
     * Si desea hacerse sobre un elemento específico, primero debe darse el foco al elemento.
     */
	protected void up(int cantidad) {
		this.sendKeys(cantidad, Keys.ARROW_UP);
   	}
//***********************************************************************************************************************
    /**
     * Sobre la aplicación windows da click en la <b>FLECHA IZQUIERDA</b> el número de veces indicado por [cantidad].<br>
     * Si desea hacerse sobre un elemento específico, primero debe darse el foco al elemento.
     */
	protected void left(int cantidad) {
		this.sendKeys(cantidad, Keys.ARROW_LEFT);
   	}
//***********************************************************************************************************************
    /**
     * Sobre la aplicación windows da click en la <b>FLECHA DERECHA</b> el número de veces indicado por [cantidad].<br>
     * Si desea hacerse sobre un elemento específico, primero debe darse el foco al elemento.
     */
	protected void right(int cantidad) {
		this.sendKeys(cantidad, Keys.ARROW_RIGHT);
   	}
//***********************************************************************************************************************
    /**
     * Sobre la aplicación windows da click en el <b>TAB</b> el número de veces indicado por [cantidad].<br>
     * Si desea hacerse desde un elemento específico, primero debe darse el foco al elemento.
     */
	protected void tab(int cantidad) {
		this.sendKeys(cantidad, Keys.TAB);
   	}
//***********************************************************************************************************************
    /**
     * Sobre la aplicación windows da 1 click en el <b>ENTER</b>.<br>
     * Si desea hacerse sobre un elemento específico, primero debe darse el foco al elemento.
     */
	protected void enter(int cantidad) {
		this.sendKeys(cantidad, Keys.ENTER);
   	}
//***********************************************************************************************************************	
    /**
     * Sobre la aplicación windows da click en el <b>ENTER</b> el número de veces indicado por [cantidad].<br>
     * Si desea hacerse sobre un elemento específico, primero debe darse el foco al elemento.
     */
	protected void enter() {
		this.enter(1);
   	}
//***********************************************************************************************************************
	/**
	 * Retorna el ancho del [element], extrayéndolo del atribuot "BoundingRectangle".
	 */
	public int getWidthInDesktop(RemoteWebElement element) {
		String dato = element.getAttribute("BoundingRectangle"); // Left:# Top:# Width:# Height:#
		int width = 0;
		if (dato != null) {
			String[] x = dato.split("Width:"); //0-...., 1-# Height:
			String[] y = x[1].split("Height:"); //0-#, 1-...
			width = Integer.valueOf(y[0].trim());
		}
		return width;
	}
//***********************************************************************************************************************
	/**
	 * Envía la teclas [keys] sobre el [element] recibido.
	 */
	public void sendKeys(RemoteWebElement element, CharSequence... keys) {
		element.sendKeys(keys);
	}
//***********************************************************************************************************************
	/**
	 * Limpia el contenido del [element] recibido. (si es un input)
	 */
	public void clear(RemoteWebElement element) {
		element.clear();
	}
//***********************************************************************************************************************
	/**
	 * Da click sobre el [element] recibido.
	 */
	public void click(RemoteWebElement element) {
		element.click();
	}
//***********************************************************************************************************************
	/**
	 * Indica si WinAppDriver ya está corriendo en la máquina local.
	 */
	public static boolean isRunningWinAppDriver() throws IOException {

		// EJECUTA EL COMANDO PARA BUSCAR LAS TAREAS QUE CORRESPONDAN A "WinAppDriver.exe"
		return Util.isRunningApp("WinAppDriver.exe");
	}
//***********************************************************************************************************************
}