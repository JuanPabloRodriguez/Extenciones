package library.catalogue;

import java.util.ArrayList;
import java.util.List;

import library.data.DataSheet;
import library.settings.SettingsResources;

public class SettingsAppium extends DataSheet {

	public static final String DEVICE      = "Devices";
	public static final String APPLICATION = "Applications";
	private static final String RESOURCE   = "dataSheet/DS_AppiumSettings.xlsx";
	
//=======================================================================================================================
	/**
	 * Constructor que recibe el nombre del setting a usar.
	 * @param nbSetting - Valores permitidos [nbSettingsAppium.DEVICE] / [nbSettingsAppium.APPLICATION]
	 * @Nota Los recursos NO serán descargados de GoogleDrive si el property SettingsRun.PROP_DOWNLOAD_RESOURCES está en
	 * [false] 
	 */
	public SettingsAppium(String nbSetting) throws Exception {
		
		super(); // INICIA EN 1 EL [RowHeader] 
		if (!nbSetting.equals(DEVICE) && !nbSetting.equals(APPLICATION))
			throw new Exception ("\nSettingsAppiumERROR -- La instancia se debe crear con uno de los Settings correctos."
				+ "\nValores permitidos [nbSettingsAppium.DEVICE] o [nbSettingsAppium.APPLICATION]");
		
		this.nbSheet = nbSetting;
		// CARGA LOS NOMBRES DEL HEADER QUE IDENTIFICA DE FORMA ÚNICA CADA REGISTRO
		if (nbSetting.equals(DEVICE))
			this.setKeyHeader(new String[]{"name"});
		else  // nbSetting.equals(APPLICATION)
			this.setKeyHeader(new String[]{"nameApplication"});
		
		String source = SettingsResources.getFullPathResource(RESOURCE);
		this.iniciarDataSheet(source);
	}
//***********************************************************************************************************************
	/**
	 * Método que retorna un String[] que contiene la información de configuración del Device en el siguiente orden:
	 * {0-deviceName, 1-udid, 2-platformName, 3-platformVersion}
	 * Se requiere el nombre del device, tal como está almacenado en el DataSheet "DF_AppiumDevices.json"
	 */
	public String[] getSettingsDevice(String name) throws Exception {
		
		if (!this.nbSheet.equals(DEVICE)) 
			throw new Exception ("\nSettingsAppiumERROR -- No se creó la instancia con el nombre de Settings correcto. "
				+ "Se debió crear con [nbSettingsAppium.DEVICE]");
		
		String[] valueData = {name};
		int regDevice = this.getRowKeyData(valueData);
		if (regDevice == 0)
			throw new Exception ("SettingsAppiumERROR -- No se encuentra el Device con nombre [" + name + "]...");
		
		String[] datosDevice = new String[4];
		datosDevice[0] = this.getParameterByRow("deviceName", regDevice);
		datosDevice[1] = this.getParameterByRow("udid", regDevice);
		datosDevice[2] = this.getParameterByRow("platformName", regDevice);
		datosDevice[3] = this.getParameterByRow("platformVersion", regDevice);
		
		return datosDevice;
	}
//***********************************************************************************************************************
	/**
	 * Método que retorna un String[] que contiene la información de configuración de la aplicación que se cargará en el
	 * Device, en el siguiente orden: {0-appPackage, 1-appActivity, 2-nameIpa}
	 * Se requiere el nombre de la aplicación, tal como está almacenado en el DataSheet "DF_AppiumApps.json"
	 */
	public String[] getSettingsApp(String appName) throws Exception {
		
		if (!this.nbSheet.equals(APPLICATION)) 
			throw new Exception ("\nSettingsAppiumERROR -- No se creó la instancia con el nombre de Settings correcto. "
				+ "Se debió crear con [nbSettingsAppium.APPLICATION]");
		
		String[] valueData = {appName};
		int regApp = this.getRowKeyData(valueData);
		if (regApp == 0)
			throw new Exception ("SettingsAppiumERROR -- No se encuentra la aplicación [" + appName + "]...");
		
		String[] datosApp = new String[3];
		datosApp[0] = this.getParameterByRow("appPackage", regApp);
		datosApp[1] = this.getParameterByRow("appActivity", regApp);
		datosApp[2] = this.getParameterByRow("nameIpa", regApp);
		
		return datosApp;
	}
//***********************************************************************************************************************
	/**
	 * Método que retorna un String[] los Elementos (Devices o Apps) existentes en el DataSheet.
	 */
	public String[] getNbItems() throws Exception {
		
		 // CUANDO ES APPLICATION USA "nameApplication", CUANDO NO (ES DEVICE) USA "name"
		String nbParameter = this.nbSheet.equals(APPLICATION) ? "nameApplication" : "name";
		
		int filaFin  = this.getLastRow();
		List<String> listaItems = new ArrayList<String>();
		String device;
		for (int numfila = 2; numfila <= filaFin; numfila++) {
			device = this.getParameterByRow(nbParameter, numfila).trim();
			if (!device.isEmpty()) listaItems.add(device);
		}
		String[] devices = new String[listaItems.size()];
		return listaItems.toArray(devices);
	}
//***********************************************************************************************************************	
}