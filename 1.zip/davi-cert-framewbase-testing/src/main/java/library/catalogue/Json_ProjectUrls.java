package library.catalogue;

import java.util.ArrayList;
import java.util.List;

import library.common.Util;
import library.data.DataJSON;

public class Json_ProjectUrls extends DataJSON {

	private static final String RESOURCE = "dataFiles/DF_ProjectURLs.json";
	
//=======================================================================================================================
	public Json_ProjectUrls() {
		
		super(); // INICIA EN 1 EL [RowHeader] 
		String source = Util.getFullPathResource(RESOURCE);
		
		// CARGA LOS PARÁMETROS QUE IDENTIFICAN DE FORMA ÚNICA CADA REGISTRO
		this.setKeyParameters(new String[]{"ambiente", "siteName"});
		
		// CARGA EL ARCHIVO FUENTE QUE CONTIENE EL ARCHIVO DE DATOS: LA CARGA SE HACE CON [getResourceAsStream]
		// Y NO CON [getResource(source).getFile()] PORQUE EL ARCHIVO PUEDE ESTAR EN UN EJECUTABLE .JAR
		this.iniciarDataJSON(source, this.getClass().getResourceAsStream(source));
	}
//***********************************************************************************************************************
	/**
	 * Método que retorna la URL correspondiente al ambiente y nombre de site recibidos:<br>
	 * Se requiere el nombre del ambiente y el del site, tal como está almacenado en el archivo de Datos [RESOURCE]
	 */
	public String getSiteUrl(String ambiente, String siteName) throws Exception {
		String[] valueData = { ambiente, siteName };
		int numReg = this.getRegKeyByData(valueData);
		if (numReg == 0)
			throw new Exception ("ProjectUrlsERROR -- No se encuentra la URL para ["
					+ Util.arrayToString(valueData, "-") + "]...");
		
		String url = this.getParameterByReg("siteURL", numReg).trim();
		return url;
	}
//***********************************************************************************************************************
	/**
	 * Método que retorna la URL correspondiente al nombre del site recibido:
	 * Se requiere el nombre del site, tal como está almacenado en el archivo de datos [RESOURCE], se asume que ambiente
	 * va VACÍO "".
	 */
	public String getSiteUrl(String siteName) throws Exception {
		return getSiteUrl("", siteName);
	}
//***********************************************************************************************************************
	/**
	 * Método que retorna la IP correspondiente al ambiente y nombre del site recibidos:<br>
	 * Se requiere el nombre del ambiente y el del site, tal como está almacenado en el archivo de datos [RESOURCE]
	 */
	public String getIp(String ambiente, String siteName) throws Exception {
		
		String[] valueData = {ambiente, siteName};
		int numReg = this.getRegKeyByData(valueData);
		if (numReg == 0)
			throw new Exception ("ProjectUrlsERROR -- No se encuentra la IP para ["
					+ Util.arrayToString(valueData, "-") + "]...");
		
		String url = this.getParameterByReg("ipHost", numReg).trim();
		return url;
	}
//***********************************************************************************************************************
	/**
	 * Método que retorna la IP correspondiente al nombre del site recibido:<br>
	 * Se requiere el nombre del site, tal como está almacenado en el archivo de datos [RESOURCE], se asume que ambiente
	 * va VACÍO "".
	 */
	public String getIp(String siteName) throws Exception {
		return getIp("", siteName);
	}
//***********************************************************************************************************************
	/**
	 * Método que retorna los datos de ambiente, url e ip de un nombre de site recibido por parámetro.<br>
	 * En donde: 0-ambiente, 1-url, 2-ip<br>
	 * Se requiere el nombre del site, tal como está almacenado en el archivo de datos [RESOURCE],
	 * se asume que ambiente va VACÍO "".
	 */
	public String[][] getDatosBySiteName(String siteName) throws Exception {
		
		// RECORRE DESDE EL REGIISTRO 1 HASTA EL FINAL DE REGISTROS, HASTA ENCONTRAR A [siteName]
		String datoDataSh;
		List<Integer> rows = new ArrayList<Integer>();
		int regFin = this.getLastReg();
  		for (int numReg = 1; numReg <= regFin; numReg++) {
			datoDataSh = this.getParameterByReg("siteName", numReg).trim();
			if (datoDataSh.equals(siteName))
				rows.add(numReg);
		}
		
		String[][] datosRet = new String[rows.size()][3];
		int pos = 0;
		for (Integer row : rows) {
			datosRet[pos][0] = this.getParameterByReg("ambiente", row).trim();
			datosRet[pos][1] = this.getParameterByReg("siteURL", row).trim();
			datosRet[pos][2] = this.getParameterByReg("ipHost", row).trim();
			pos++;
		}
		return datosRet;
	}
//***********************************************************************************************************************
}