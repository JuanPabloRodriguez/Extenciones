package library.catalogue;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import library.common.Util;
import library.data.DataJSON;

public class Json_SettingsAppium extends DataJSON {

	public static final String DEVICE = "Devices";
	public static final String APPLICATION = "Applications";
	private static final String DIR_RESOURCES = "dataFiles/";
	// Nombre de los parámetros que identifican de forma única el Device
	private static final String NB_RESOURCE_DEVICE = "DF_AppiumDevices.json";
	// Información de las aplicaciones
	private static final String NB_RESOURCE_APPS   = "DF_AppiumApps.json";
	
	private String currentSetting;
	
//=======================================================================================================================
	public Json_SettingsAppium(String nbSetting) throws Exception {
		
		super(); // CONSTRUCTOR VACÍO 
		if (!nbSetting.equals(DEVICE) && !nbSetting.equals(APPLICATION))
			throw new Exception ("SettingsAppiumERROR -- Data Sheet [" + nbSetting + "] doesn't exist...");
		
		this.currentSetting = nbSetting;
		this.setKeyParameters(new String[]{"name"}); // VALOR DEL PARÁMETRO CLAVE POR DEFECTO
		if (nbSetting.equals(APPLICATION))
			this.setKeyParameters(new String[]{"nameApplication"}); // CAMBIO EL VALOR DEL PARÁMETRO CLAVE
		
		boolean tomarDeResources = true;
		if (Util.isLaunchJAR()) {
			String temp = new File(".").getAbsolutePath(); // VIENE POR EJEMPLO: [C:/Users/userX/Desktop/.]
			String pathTestFilesDir = Util.left(temp, temp.length() - 1); // LE QUITA EL PUNTO FINAL
			String dirSettingsAppium = pathTestFilesDir + "AutoSettings" + File.separator;
			String nbFileSettings = dirSettingsAppium + NB_RESOURCE_DEVICE;
			if (nbSetting.equals(APPLICATION))
				nbFileSettings = dirSettingsAppium + NB_RESOURCE_APPS;
			
			if (new File(nbFileSettings).exists()) {
				tomarDeResources = false; // EL ARCHIVO ESTÁ EN LA CARPETA DEL JAR EN [SettingsRun.FOLDER_SETTINGS_JAR]
				// CARGA EL ARCHIVO FUENTE QUE CONTIENE EL ARCHIVO DE DATOS
				this.iniciarDataJSON(nbFileSettings);
			}
		}
		if (tomarDeResources) {
			String source = Util.getFullPathResource(DIR_RESOURCES + NB_RESOURCE_DEVICE);
			if (nbSetting.equals(APPLICATION))
				source = Util.getFullPathResource(DIR_RESOURCES + NB_RESOURCE_APPS);
			// CARGA EL ARCHIVO FUENTE QUE CONTIENE EL ARCHIVO DE DATOS: LA CARGA SE HACE CON [getResourceAsStream]
			// Y NO CON [getResource(source).getFile()] PORQUE EL ARCHIVO PUEDE ESTAR EN UN EJECUTABLE .JAR
			this.iniciarDataJSON(source, this.getClass().getResourceAsStream(source));
		}
	}
//***********************************************************************************************************************
	/**
	 * Método que retorna un String[] que contiene la información de configuración del Device en el siguiente orden:
	 * {0-deviceName, 1-udid, 2-platformName, 3-platformVersion}
	 * Se requiere el nombre del device, tal como está almacenado en el DataSheet "DF_AppiumDevices.json"
	 */
	public String[] getSettingsDevice(String name) throws Exception {
		
		String[] valueData = {name};
		int regDevice = this.getRegKeyByData(valueData);
		if (regDevice == 0)
			throw new Exception ("SettingsAppiumERROR -- No se encuentra el Device con nombre [" + name + "]...");
		
		String[] datosDevice = new String[4];
		datosDevice[0] = this.getParameterByReg("deviceName", regDevice);
		datosDevice[1] = this.getParameterByReg("udid", regDevice);
		datosDevice[2] = this.getParameterByReg("platformName", regDevice);
		datosDevice[3] = this.getParameterByReg("platformVersion", regDevice);
		
		return datosDevice;
	}
//***********************************************************************************************************************
	/**
	 * Método que retorna un String[] que contiene la información de configuración de la aplicación que se cargará en el
	 * Device, en el siguiente orden: {0-appPackage, 1-appActivity, 2-webContext}
	 * Se requiere el nombre de la aplicación, tal como está almacenado en el DataSheet "DF_AppiumApps.json"
	 */
	public String[] getSettingsApp(String appName) throws Exception {
		
		String[] valueData = {appName};
		int regApp = this.getRegKeyByData(valueData);
		if (regApp == 0)
			throw new Exception ("SettingsAppiumERROR -- No se encuentra la aplicación [" + appName + "]...");
		
		String[] datosApp = new String[3];
		datosApp[0] = this.getParameterByReg("appPackage", regApp);
		datosApp[1] = this.getParameterByReg("appActivity", regApp);
		datosApp[2] = this.getParameterByReg("webContext", regApp);
		
		return datosApp;
	}
//***********************************************************************************************************************
	/**
	 * Método que retorna un String[] los Elementos (Devices o Apps) existentes en el DataSheet.
	 */
	public String[] getNbItems() throws Exception {
		
		String nbParameter = "name"; // SETTING ES DE DEVICE
		if (this.currentSetting.equals(APPLICATION)) 
			nbParameter = "nameApplication";
		
		int regFin  = this.getLastReg();
		//int colDevic = this.getColumnaParameter(nbParameter);
		List<String> listaItems = new ArrayList<String>();
		String device;
		for (int numReg = 1; numReg <= regFin; numReg++) {
			device = this.getParameterByReg(nbParameter, numReg).trim();
			if (!device.isEmpty()) listaItems.add(device);
		}
		String[] devices = new String[listaItems.size()];
		return listaItems.toArray(devices);
	}
//***********************************************************************************************************************	
}