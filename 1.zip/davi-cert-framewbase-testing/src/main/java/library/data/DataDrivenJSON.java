package library.data;

import library.common.ExcelFile;

/**
 * Clase que maneja la información para el manejo de datos principal en un archivo de datos JKSON.
 * @author szea
 */
public class DataDrivenJSON implements DataDriven {

	private int currentReg; // REGISTRO QUE SE ESTÁ EJECUTANDO ACTUALMENTE
	private DataJSON dataJSON;
//=======================================================================================================================	
	/**
	 * Constructor que crea el DataSheet indicando la ruta del archivo fuente. Asume que el RowHeader es la fila [1].
	 */
	public DataDrivenJSON(String source) {
		this.dataJSON = new DataJSON(source);
	}
//***********************************************************************************************************************
	/**
	 * Retorna el número de registro actual del archivo de datos JSON que se está teniendo como registro actual. 
	 */
	@Override
	public int getCurrentExec() {
		return this.currentReg;
	}
//***********************************************************************************************************************
	/**
	 * Retorna el nombre del archivo fuente. 
	 */
	@Override
	public String getSource() {
		return this.dataJSON.getSource();
	}
//***********************************************************************************************************************
	/**
	 * Setea como ejecución actual el número del registro [currentReg]
	 */
	@Override
	public void setCurrentExec(int currentExec) {
		this.currentReg = currentExec;
	}
//***********************************************************************************************************************
	/**
	 * Retorna el número del último registro presentado en el archivo de datos.
	 */
	@Override
	public int getLastExec() {
		return this.dataJSON.getLastReg();
	}
//***********************************************************************************************************************
	/**
	 * Retorna el parámetro del archivo de datos JSON que se encuentra en la ejecución actual. 
	 */
	@Override
	public String getParameter(String nameParameter) {
		return this.getParameterByExec(nameParameter, this.currentReg); 
	}
//***********************************************************************************************************************
	/**
	 * Retorna el parámetro del archivo de datos JSON que se encuentra en la ejecución [numExec]. 
	 */
	@Override
	public String getParameterByExec(String nameParameter, int numExec) {
		return this.dataJSON.getParameterByReg(nameParameter, numExec); 
	}
//***********************************************************************************************************************
	/**
	 * Almacena en el parámetro del archivo de datos que se encuentra en la ejeución actual, el String indicado. 
	 */
	@Override
	public void setParameter(String nameParameter, String value) {
		this.setParameterByExec(nameParameter, this.currentReg, value);
	}
//***********************************************************************************************************************
	/**
	 * Almacena en el parámetro del archivo de datos que se encuentra en la ejeución [numExec], el String indicado. 
	 */
	@Override
	public void setParameterByExec(String nameParameter, int numExec, String value) {
		this.dataJSON.setParameterByReg(nameParameter, numExec, value);
	}
//***********************************************************************************************************************
	/**
	 * Almacena en el parámetro del archivo de datos que se encuentra en la ejeución actual, el double indicado. 
	 */
	@Override
	public void setParameter(String nameParameter, double value) {
		this.setParameterByExec(nameParameter, this.currentReg, value);
	}
//***********************************************************************************************************************
	/**
	 * Almacena en el parámetro del archivo de datos que se encuentra en la ejeución [numExec], el double indicado. 
	 */
	@Override
	public void setParameterByExec(String nameParameter, int numExec, double value) {
		this.dataJSON.setParameterByReg(nameParameter, numExec, value);
	}
//***********************************************************************************************************************
	/**
	 * Indica si el parámetro [nameParameter] existe para la ejecución actual.
	 */
	@Override
	public boolean parameterExist(String nameParameter) {
		return this.dataJSON.parameterExist(nameParameter, this.currentReg);
	}
//***********************************************************************************************************************
	/**
	 * Indica si el parámetro [nameParameter] existe para la ejecución [numExec].
	 */
	@Override
	public boolean parameterExistByExec(String nameParameter, int numExec) {
		return this.dataJSON.parameterExist(nameParameter, numExec);
	}
//***********************************************************************************************************************
	/**
	 * Revisa la existencia de los parámetros mencionados en [nbParameters], si alguno NO está presente, genera una
	 * excepción indicando cuáles NO se encuentran.
	 */
	@Override
	public void validarParameters(String... nbParameters) throws Exception {
		String paramsFaltantes = this.dataJSON.containParameters(nbParameters);
		if (paramsFaltantes != null)
			throw new Exception ("DataDrivenJSON ERROR -- El archivo de datos no contiene los parámetros esperados."
					+ "\n\tFaltan >>> " + paramsFaltantes);
	}
//***********************************************************************************************************************
	/**
	 * Libera la hoja de datos.
	 */
	@Override
	public void liberarData() {
		this.dataJSON.liberarData();
	}
//=======================================================================================================================
	/**
	 * Almacena en el parámetro del archivo de datos que se encuentra en la ejeución actual, el boolean indicado. 
	 */
	public void setParameter(String nameParameter, boolean value) {
		this.setParameterByExec(nameParameter, this.currentReg, value);
	}
//***********************************************************************************************************************
	/**
	 * Almacena en el parámetro del archivo de datos que se encuentra en la ejeución [numExec], el boolean indicado. 
	 */
	public void setParameterByExec(String nameParameter, int numExec, boolean value) {
		this.dataJSON.setParameterByReg(nameParameter, numExec, value);
	}
//***********************************************************************************************************************
	@Override
	public void addParametersNotExist(String... nameParameters) throws Exception {
		// PARA JSON NO SE REQUIERE, SI NO EXISTE LO ADICIONA
	}
//***********************************************************************************************************************
	@Override
	public ExcelFile getAnotherSheetReadOnly(String nbSheet) {
		// PARA JSON NO SE REQUIERE
		return null;
	}
//***********************************************************************************************************************
	@Override
	public void setColor(String nameParameter, short color) {
		// PARA JSON NO SE REQUIERE, NO HAY FORMA DE MANEJAR COLOR
	}
//***********************************************************************************************************************
	@Override
	public void setColorByExec(String nameParameter, int numExec, short color) {
		// PARA JSON NO SE REQUIERE, NO HAY FORMA DE MANEJAR COLOR
	}
//***********************************************************************************************************************
	@Override
	public void setParameterAsHiperlink(String nameParameter, String pathFile) { // TODO Auto-generated method stub
		// PARA JSON NO SE REQUIERE
	}
//***********************************************************************************************************************
	@Override
	public void setParameterAsHiperlinkByExec(String nameParameter, int numExec, String pathFile) { // TODO Auto-generated method stub
		// PARA JSON NO SE REQUIERE
	}
//***********************************************************************************************************************
}