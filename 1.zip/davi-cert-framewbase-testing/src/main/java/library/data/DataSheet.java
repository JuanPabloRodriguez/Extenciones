package library.data;

import java.util.HashMap;
import java.util.Map;

import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;

import library.common.ExcelFile;

import java.io.InputStream;

/**
 * Clase que maneja la información para el manejo de datos en un libro de Excel.
 * Se debe contar con el recurso (path y nombre de archivo) y la hoja en donde se encuentran los datos.
 * @author szea
 */
public class DataSheet {

	private static short COLOR_HEADER = IndexedColors.RED.index; // COLOR POR DEFECTO PARA LOS NUEVOS HEADERS
	private String source;
	protected String nbSheet; // NOMBRE DE LA HOJA CON LOS DATOS
	private int indexSheet = -1; // INDEX DEL SEHEET, SÓLO SE USA EN 1 CONSTRUCTOR
	private ExcelFile excelFile;
	private int rowHeader; // ROW DEL EXCEL EN DONDE SE ENCUENTRA EL NOMBRE DE LOS PARÁMETROS
	private int colFinal;  // COLUMNA DEL EXCEL DONDE SE ENCUENTRA EL ÚLTIMO PARÁMETRO
	private int rowFinal;  // ROW FINLA DEL EXCEL, DONDE HAY INFORMACIÓN
	private Map<String,Integer> parameters; // key=nombre parámetro, value=columna en excel
	private String[] keyHeader;
	private Map<Short,CellStyle> mapStyles = new HashMap<Short,CellStyle>();
	private CellStyle styleNewHeader = null;
//=======================================================================================================================
	public DataSheet() throws Exception { 
		this.rowHeader = 1;
		// TODO para sobreescribir NO usar directamente
	}
	public DataSheet(String source) throws Exception {
		this.source = source;
		this.rowHeader = 1;
		// TODO para sobreescribir NO usar directamente
	}
	/**
	 * <b>No usar directamente de DataSheet</b><br>
	 * Constructor para abrir la hoja de datos [source] indicando el [rowHeader]<br>
	 */
	public DataSheet(String source, int rowHeader) throws Exception {
		this.source = source;
		this.rowHeader = rowHeader;
		// TODO para sobreescribir NO usar directamente
	}
	/**
	 * Constructor para abrir la hoja de datos [source] tomando los datos de su hoja [nbSheet]<br>
	 * Asume que la fila del header es la fila 1.
	 */
	public DataSheet(String source, String nbSheet) throws Exception {
		this.rowHeader = 1;
		this.nbSheet   = nbSheet;
		this.iniciarDataSheet(source);
	}
	/**
	 * Constructor para abrir la hoja de datos [source] tomando los datos de su hoja [nbSheet]<br>
	 * Este método se usa, cuando el [source] se encuentra en los recursos del proyecto JAVA, se requiere el envío del
	 * [inputStreamSource] que corresponde a la fuente que está en dichos recursos.<br>
	 * Asume que la fila del header es la fila 1.
	 */
	public DataSheet(String source, String nbSheet, InputStream inputStreamSource) throws Exception {
		this.rowHeader = 1;
		this.nbSheet   = nbSheet;
		this.iniciarDataSheet(source, inputStreamSource);
	}
	/**
	 * Constructor para abrir la hoja de datos [source] tomando los datos de su hoja [nbSheet], y la fila que contiene
	 * el header (parámetros) es [rowHeader]
	 */
	public DataSheet(String source, String nbSheet, int rowHeader) throws Exception {
		this.rowHeader = rowHeader;
		this.nbSheet   = nbSheet;
		this.iniciarDataSheet(source);
	}
	/**
	 * Constructor para abrir la hoja de datos [source] tomando los datos de la hoja [numSheet] e indicando [rowHeader]
	 * @param indexSheet - El número de la hoja, empieza en 1. Es decir la primera hoja es 1.
	 */
	public DataSheet(String source, int numSheet, int rowHeader) throws Exception {
		this.rowHeader = rowHeader;
		this.nbSheet   = null;
		this.indexSheet = numSheet - 1;
		this.iniciarDataSheet(source);
	}
	/**
	 * Constructor para crear una hoja de datos en [source], le crea una hoja llamada [nbSheet], setea como fila que
	 * contiene el header (parámetros) el valor de [rowHeader] y le adiciona los parámetros [nbParameters]<br>
	 * Si se desea que los headers tengan un color de celda diferente al ROJO (que es el color por defecto), se sugiere
	 * hacer cambio del color con el método <b>DataSheet.changeColorHeader(color)</b> enviando el color requerido,
	 * ejemplo de su uso (se llama antes de la instancia a este constructor):<br>
	 * DataSheet.changeColorHeader(IndexedColors.DARK_RED.index);  
	 * @param nbParameters - Cuando son ingresados, se crea un DataSheet con dichos parámetros
	 */
	public DataSheet(String source, String nbSheet, int rowHeader, String... nbParameters) throws Exception {
		this.rowHeader = rowHeader;
		this.nbSheet   = nbSheet;
		this.iniciarDataSheet(source, nbParameters);
		DataSheet.changeColorHeader(IndexedColors.RED.index); // VUELVE A DEJAR EL COLOR DEFAULT PARA OTROS [DataSheet]
	}
	/**
	 * Constructor para abrir la hoja de datos [source] tomando los datos de su hoja [nbSheet], y la fila que contiene
	 * el header (parámetros) es [rowHeader]<br>
	 * Se recibe un [inputStreamSource] que corresponde a la fuente que está en los recursos del proyecto.<br>
	 */
	public DataSheet(String source, String nbSheet, int rowHeader, InputStream inputStreamSource) throws Exception {
		this.rowHeader = rowHeader;
		this.nbSheet   = nbSheet;
		this.iniciarDataSheet(source, inputStreamSource);
	}
//***********************************************************************************************************************
	/**
	 * Cambia el color para los headers, se usa para cuando se crea el DataSheet con determinados parámetros.
	 * @param color - Color a tomar, or ejemplo: IndexedColors.DARK_RED.index
	 */
	public static void changeColorHeader(short color) {
		DataSheet.COLOR_HEADER = color;
	}
//***********************************************************************************************************************
	/**
	 * Retorna la fuente del DataSheet
	 */
	public String getSource() {
		return this.source;
	}
//***********************************************************************************************************************
	/**
	 * Se encarga de iniciar la hoja de datos: abre el archivo fuente, selecciona la hoja del Excel donde está la data,
	 * carga los parámetros (header) con los que cuenta, carga el rowFinal y la columnaFinal.
	 * Es requerido que ya está cargado:<br>
	 * - El nombre de la hoja en donde están los datos.<br>
	 * - Row Header
	 * @param nbParameters - Cuando son ingresados, se crea un DataSheet con dichos parámetros
	 */
	protected void iniciarDataSheet(String source, String... nbParameters) throws Exception {
		
		this.source = source;
		if (nbParameters.length == 0) { // ES UNA HOJA DE DATOS EXISTENTES
			this.excelFile = new ExcelFile(this.source, ExcelFile.OPEN);
			if (this.nbSheet == null) { // NO SE SABE EL NOMBRE, PERO SE DEBE CONOCER EL INDEX
				this.excelFile.selectSheet(this.indexSheet);
				this.nbSheet = this.excelFile.getCurrentSheetName();
			}
			else
				this.excelFile.selectSheet(this.nbSheet);
			
			if (this.excelFile.getSheet() == null)
				throw new Exception ("DataSheetERROR -- En el Excel se espera una hoja con nombre [" + this.nbSheet
						+ "] y NO se encuentra...");

			this.loadNameParameters();
		}
		else { // ES UNA HOJA DE DATOS NUEVA
			this.excelFile = new ExcelFile(this.source, ExcelFile.CREATE);
			this.excelFile.createSheet(this.nbSheet);
			this.colFinal = 0; // IDENTIFICA QUE NO HAYA COLUMNAS
			this.parameters = new HashMap<String,Integer>(); // CREA LOS PARÁMETROS
			this.addParameters(nbParameters);
		}
		
		this.rowFinal = this.excelFile.getLastRow();
		this.colFinal = this.excelFile.getLastColumn(this.rowHeader);
	}
//***********************************************************************************************************************
	/**
	 * Se encarga de iniciar la hoja de datos: abre el archivo fuente, selecciona la hoja del Excel donde está la data,
	 * carga los parámetros (header) con los que cuenta, carga el rowFinal y la columnaFinal.
	 * Es requerido que ya está cargado:<br>
	 * - El nombre de la hoja en donde están los datos.<br>
	 * - Row Header  
	 */
	protected void iniciarDataSheet(String source, InputStream inputStreamSource) throws Exception {
		
		if (inputStreamSource == null)
			throw new Exception ("DataSheetERROR -- El recurso [inputStreamSource] recibido NO EXISTE - verificar...");

		this.source = source;
		this.excelFile = new ExcelFile(source, inputStreamSource);
		this.excelFile.selectSheet(this.nbSheet);
		
		if (this.excelFile.getSheet() == null)
			throw new Exception ("DataSheetERROR -- En el Excel se espera una hoja con nombre [" + this.nbSheet + "] y NO se encuentra...");

		this.loadNameParameters();
		this.rowFinal = this.excelFile.getLastRow();
		this.colFinal = this.excelFile.getLastColumn(this.rowHeader);
	}
//***********************************************************************************************************************
	/**
	 * Inicializa y setea el dictionary que contiene los parámetros de la hoja de datos. 
	 */
	private void loadNameParameters() throws Exception {
		//Debe cargar los parámetros existentes en el HashMap [parameters]:
		//Key=nombre del parámetro, value=columna donde está
		int colIni = this.excelFile.getFirstColumn(this.rowHeader);
		this.colFinal = this.excelFile.getLastColumn(this.rowHeader);
		String nameParam = "";
		this.parameters = new HashMap<String,Integer>();
		for (int col = colIni; col <= this.colFinal; col++) {
			nameParam = this.excelFile.getStringCellValue(this.rowHeader, col).trim();
			if (!nameParam.isEmpty() && !nameParam.equals("_")) {
				if (parameters.containsKey(nameParam))
					throw new Exception ("DataSheetERROR -- Data Sheet invalid, parameter [" + nameParam + "] is duplicated...");
				//Si no se ha almacenado el parámetro, se almacena:
				parameters.put(nameParam, col);
			}
		}
		
	}
//***********************************************************************************************************************
	/**
	 * Le da el [color] indicado a la celda que se encuentra en la fila [rowNumber] y columna [colNumber]<br>
	 * OJO: este método NO guarda el archivl de excel
	 * @param rowNumber - Fila de la hoja de datos.
	 * @param colNumber - Columna de la hoja de datos.
	 * @param color - Index del color a darle a la celda (p.e: IndexedColors.YELLOW.index)
	 */
	private void setColorByRow(int rowNumber, int colNumber, short color) {
		
		CellStyle newStyle;
		if (mapStyles.containsKey(color)) // LO TRAE DEL DICCIONARIO
			newStyle = mapStyles.get(color);
		else { // CLONA EL STYLE ACTUAL DE LA CELDA PARA LUEGO CAMBIARLE EL FONDO
			newStyle = this.excelFile.cloneCellStyle(rowNumber, colNumber);
	        newStyle.setFillForegroundColor(color);
	        newStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
	        newStyle.setWrapText(false);
		}
        this.excelFile.setCellStyle(rowNumber, colNumber, newStyle);
	}
//***********************************************************************************************************************
	/**
	 * @return El valor del ROW final
	 */
	public int getLastRow() {
		return this.rowFinal;
	}
//***********************************************************************************************************************
	/**
	 * Indica cuál es la última fila existente en el DataSheet, basándose en los parámetros requeridos (uno o varios).
	 * Esto debido a que el Excel puede indicar una fila final que no es real, porque en algún momento se ingresaron
	 * datos en el archivo y luego los borraron, si hay parámetros que indican la existencia del registro, esos son los
	 * que deben ser recibidos en [nbParameters] (no necesariamente TODOS los parámetros).
	 */
	public int getLastRow(int filaInicial, String... nbParameters) throws Exception {
    	int filaFinal = this.getLastRow();
    	boolean hayDatos;
    	do {
    		hayDatos = true; // SE ASUME QUE SÍ HAY DATOS EN LA FILA
        	for (String nbParam : nbParameters) {
        		hayDatos = hayDatos && !this.getParameterByRow(nbParam, filaFinal).trim().isEmpty();
        		if (!hayDatos) break; // PARA QUE TERMINE EL CICLO
			}
        	if (!hayDatos) filaFinal--; // PARA EVALUAR LA ANTERIOR FILA
		} while (!hayDatos && filaFinal >= filaInicial);
    	return filaFinal;
    }
//***********************************************************************************************************************
	/**
	 * @return El valor de la COLUMNA final
	 */
	public int getLastColumn() {
		return this.colFinal;
	}
//***********************************************************************************************************************
	/**
	 * @return El archivo e excel relacionado al [DataSheet]
	 */
	public ExcelFile getExcelFile() {
		return this.excelFile;
	}
//***********************************************************************************************************************
	/**
	 * Cuando los registros de una hoja de datos se identifican de forma única por determinados datos, con este método
	 * se setea el nombre de los encabezados (parámetros) que arman la unicidad de datos.
	 */
	protected void setKeyHeader(String[] keyData) {
		this.keyHeader = keyData;
	}
//***********************************************************************************************************************
	/**
	 * Retorna el parámetro del DataSheet que se encuentra en el Row que se recibe por parámetro.
	 */
	public String getParameterByRow(String nameParameter, int rowNumber) throws Exception {
		int colExcel = this.getColumnaParameter(nameParameter); // SI NO EXISTE GENERA EXCEPCIÓN	
		return this.excelFile.getStringCellValue(rowNumber, colExcel);
	}
//***********************************************************************************************************************
	/**
	 * Almacena en la celda con fila y columna indicados, el String indicado. 
	 * <br>Así mismo se encarga de ir salvando el archivo de datos. 
	 */
	public void setValueByCell(int rowNumber, int colNumber, String value) throws Exception {
		this.excelFile.setStringCellValue(rowNumber, colNumber, value);
		this.excelFile.saveFile(); // PARA QUE VAYA SALVANDO LA HOJA DE DATOS
	}
//***********************************************************************************************************************
	/**
	 * Almacena en el parámetro del DataSheet que se encuentra en el Row que se recibe por parámetro, el String indicado. 
	 * <br>Así mismo se encarga de ir salvando el archivo de datos. 
	 */
	public void setParameterByRow(String nameParameter, int rowNumber, String value) throws Exception {
		int colNumber = this.getColumnaParameter(nameParameter); // SI NO EXISTE GENERA EXCEPCIÓN
		this.excelFile.setStringCellValue(rowNumber, colNumber, value);
		this.excelFile.saveFile(); // PARA QUE VAYA SALVANDO LA HOJA DE DATOS
	}
//***********************************************************************************************************************
	/**
	 * Almacena en el parámetro del DataSheet que se encuentra en el Row que se recibe por parámetro, el double indicado. 
	 * <br>Así mismo se encarga de ir salvando el archivo de datos. 
	 */
	public void setParameterByRow(String nameParameter, int rowNumber, double value) throws Exception {
		int colNumber = this.getColumnaParameter(nameParameter); // SI NO EXISTE GENERA EXCEPCIÓN
		this.excelFile.setNumberCellValue(rowNumber, colNumber, value);
		this.excelFile.saveFile(); // PARA QUE VAYA SALVANDO LA HOJA DE DATOS
	}
//***********************************************************************************************************************
	/**
	 * Almacena en el parámetro del DataSheet que se encuentra en el Row que se recibe por parámetro, el [pathFile] como
	 * un Hiperlink, dejando en la celda el valor del nombre del archivo (sin path).
	 * <br>Así mismo se encarga de ir salvando el archivo de datos. 
	 * @param pathFile - Ruta completa del archivo, con todo y extensión. Debe existir.
	 */
	public void setParameterAsHiperlinkByRow(String nameParameter, int rowNumber, String pathFile) throws Exception {
		int colNumber = this.getColumnaParameter(nameParameter); // SI NO EXISTE GENERA EXCEPCIÓN
		this.excelFile.setHyperlinkToFile(rowNumber, colNumber, pathFile);
		this.excelFile.saveFile(); // PARA QUE VAYA SALVANDO LA HOJA DE DATOS
	}
//***********************************************************************************************************************
	/**
	 * Almacena en el parámetro del DataSheet que se encuentra en el Row que se recibe por parámetro, el valor indicado.<br>
	 * Adicional le da el [color] indicado a la celda.
	 * @param nameParameter - Nombre del parámetro en donde se ubicará la celda (para ubicar la columna).
	 * @param rowNumber - Fila de la hoja de datos.
	 * @param color - Index del color a darle a la celda (p.e: IndexedColors.YELLOW.index)
	 * @param value - Valor a almacenar.
	 */
	public void setColorParameterByRow(String nameParameter, int rowNumber, short color, String value) throws Exception {
		
		int colNumber = this.getColumnaParameter(nameParameter); // SI NO EXISTE GENERA EXCEPCIÓN
		this.excelFile.setStringCellValue(rowNumber, colNumber, value);
		this.setColorByRow(rowNumber, colNumber, color);
        this.excelFile.saveFile(); // PARA QUE VAYA SALVANDO LA HOJA DE DATOS
	}
//***********************************************************************************************************************
	/**
	 * Almacena en el parámetro del DataSheet que se encuentra en el Row que se recibe por parámetro, el double indicado.<br>
	 * Adicional le da el [color] indicado a la celda.
	 * @param nameParameter - Nombre del parámetro en donde se ubicará la celda (para ubicar la columna).
	 * @param rowNumber - Fila de la hoja de datos.
	 * @param color - Index del color a darle a la celda (p.e: IndexedColors.YELLOW.index)
	 * @param value - Valor a almacenar.
	 */
	public void setColorParameterByRow(String nameParameter, int rowNumber, short color, double value) throws Exception {
		
		int colNumber = this.getColumnaParameter(nameParameter); // SI NO EXISTE GENERA EXCEPCIÓN
		this.excelFile.setNumberCellValue(rowNumber, colNumber, value);
		this.setColorByRow(rowNumber, colNumber, color);
        this.excelFile.saveFile(); // PARA QUE VAYA SALVANDO LA HOJA DE DATOS
	}
//***********************************************************************************************************************
	/**
	 * Le da el [color] indicado a la celda del parámetro del DataSheet que se encuentra en el Row que se recibe por
	 * parámetro<br>
	 * @param nameParameter - Nombre del parámetro en donde se ubicará la celda (para ubicar la columna).
	 * @param rowNumber - Fila de la hoja de datos.
	 * @param color - Index del color a darle a la celda (p.e: IndexedColors.YELLOW.index)
	 */
	public void setColorByRow(String nameParameter, int rowNumber, short color) throws Exception {
		
		int colNumber = this.getColumnaParameter(nameParameter); // SI NO EXISTE GENERA EXCEPCIÓN
		this.setColorByRow(rowNumber, colNumber, color);
        this.excelFile.saveFile(); // PARA QUE VAYA SALVANDO LA HOJA DE DATOS
	}
//***********************************************************************************************************************
	/**
	 * Adicionar los parámetros indicados por [nameParameters] a la hoja de datos actual.<br>
	 * Si intenta adicionar un parámetro existente se genera Exception.
	 */
	public void addParameters(String... nameParameters) throws Exception {
		
		// ARMA EL ESTILO DEL HEADER PARA NUEVOS PARÁMETROS
		if (styleNewHeader == null) {
			Font textoParamFont = this.excelFile.getWorkBook().createFont();
			textoParamFont.setColor(IndexedColors.WHITE.index);
			textoParamFont.setBold(true);
	        if (this.colFinal > 0)
	        	styleNewHeader = this.excelFile.cloneCellStyle(this.rowHeader, this.colFinal);
	        else
	        	styleNewHeader = this.excelFile.getWorkBook().createCellStyle();
			styleNewHeader.setFillForegroundColor(DataSheet.COLOR_HEADER);
			styleNewHeader.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			styleNewHeader.setFont(textoParamFont);
			styleNewHeader.setWrapText(false);
		}
		
        String columns = "";
		for (String nameParam : nameParameters) {
			//Si en el HashMap donde están los parámetros ya contiene el parámetro, se genera excepción, sino se adiciona:
			if (parameters.containsKey(nameParam))
				throw new Exception ("DataSheetERROR -- method 'addParameters' : parameter [" + nameParam + "] already exists...");
			
			this.colFinal++; // INCREMENTA LO COLUMNA FINAL
			if (columns.isEmpty()) columns += this.colFinal + ":"; // #COL_INI:
			this.excelFile.setStringCellValue(this.rowHeader, this.colFinal, nameParam); //Lo almacena a la hoja de Excel
			this.excelFile.setCellStyle(this.rowHeader, this.colFinal, styleNewHeader);
			parameters.put(nameParam, this.colFinal); //Lo adiciona al HashMap de parámetros
		}
		if (!columns.isEmpty()) { // SE ADICIONARON COLUMNAS, SE JUSTIFICA PARA QUE SE VEA EL TEXTO
			columns += this.colFinal;
			this.excelFile.justifyColumns(columns); // #COL_INI:#COL_FIN
		}
		this.excelFile.saveFile(); // PARA QUE VAYA SALVANDO LA HOJA DE DATOS
	}
//***********************************************************************************************************************
	/**
	 * Adicionar los parámetros indicados por [nameParameters] a la hoja de datos actual.<br>
	 * Si intenta adicionar un parámetro existente se ignora.
	 */
	public void addParametersNotExist(String... nameParameters) throws Exception {

		// ARMA EL ESTILO DEL HEADER PARA NUEVOS PARÁMETROS
		if (styleNewHeader == null) {
			Font textoParamFont = this.excelFile.getWorkBook().createFont();
			textoParamFont.setColor(IndexedColors.WHITE.index);
			textoParamFont.setBold(true);
			styleNewHeader = this.excelFile.cloneCellStyle(this.rowHeader, this.colFinal);
			styleNewHeader.setFillForegroundColor(DataSheet.COLOR_HEADER);
			styleNewHeader.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			styleNewHeader.setFont(textoParamFont);
			styleNewHeader.setWrapText(false);
		}

        String columns = "";
		for (String nameParam : nameParameters) {
			//Si en el HashMap donde están los parámetros ya contiene el parámetro, se genera excepción, sino se adiciona:
			if (!parameters.containsKey(nameParam)) {
				this.colFinal++; // INCREMENTA LO COLUMNA FINAL
				if (columns.isEmpty()) columns += this.colFinal + ":"; // #COL_INI:
				this.excelFile.setStringCellValue(this.rowHeader, this.colFinal, nameParam); //Lo almacena a la hoja de Excel
				this.excelFile.setCellStyle(this.rowHeader, this.colFinal, styleNewHeader);
				parameters.put(nameParam, this.colFinal); //Lo adiciona al HashMap de parámetros
			}
		}
		if (!columns.isEmpty()) { // SE ADICIONARON COLUMNAS, SE JUSTIFICA PARA QUE SE VEA EL TEXTO
			columns += this.colFinal;
			this.excelFile.justifyColumns(columns); // #COL_INI:#COL_FIN
		}
		this.excelFile.saveFile(); // PARA QUE VAYA SALVANDO LA HOJA DE DATOS
	}
//***********************************************************************************************************************
	/**
	 * Libera el DataSheet, cerrando el archivo. <b>OJO</b> No salva.  
	 */
	public void liberarData() {
		this.excelFile.closeFile();//ZEA saveAndCloseFile();
	}
//***********************************************************************************************************************
	/**
	 * Retorna el número de la columna en el Excel, en donde se encuentra el parámetro [nbParameter]
	 */
	public int getColumnaParameter(String nbParameter) throws Exception {
		if (!this.parameterExist(nbParameter))
			throw new Exception ("DataSheetERROR -- Parameter [" + nbParameter + "] inexisting");
		return (int)this.parameters.get(nbParameter);
	}
//***********************************************************************************************************************
	/**
	 * Indica si el parámetro [nbParameter] se encuentra en el DataSheet.
	 */
	public boolean parameterExist(String nbParameter) {
		return this.parameters.containsKey(nbParameter);
	}
//***********************************************************************************************************************
	/**
	 * Indica si TODOS los parámetros [nbParameters] se encuentran en el DataSheet.
	 */
	public boolean parametersExist(String... nbParameters) {
		boolean todoExiste = true;
		for (String nbParameter : nbParameters) {
			todoExiste = todoExiste & this.parameterExist(nbParameter);
			if (!todoExiste) break; // TERMINA EN CICLO
		}
		return todoExiste;
	}
//***********************************************************************************************************************
	/**
	 * Retorna el número de la fila del Excel del DataSheet, en el que se encuentra el registro cuyos datos clave
	 * coincidan de forma exacta con los recibidos en [valueData] esta información debe venir completa y en el mismo orden
	 * en que se expresaron los encabezados [keyHeader].
	 * Si no se encuentra el retorno es [0].
	 */
	public int getRowKeyData(String[] valueData) throws Exception {

		int totalKeyHeader = this.keyHeader.length;
		if (totalKeyHeader == 0)
			throw new Exception ("DataSheetERROR -- No se tienen identificado los KeyHeader...");
		if (valueData.length != totalKeyHeader)
			throw new Exception ("DataSheetERROR -- Se esperaban [" + totalKeyHeader + "] KeyHeader...");
		
		// Arma array con las columnas donde están los encabezados clave:
		int[] colsKeyHeader = new int[totalKeyHeader];
		String nbHeader;
		for (int pos = 0; pos < totalKeyHeader; pos++) {
			nbHeader = this.keyHeader[pos];
			colsKeyHeader[pos] = this.getColumnaParameter(nbHeader);
		}
		
		// Recorre desde la fila 2 hasta el final de filas, hasta encontrar los datos
		int filaFin = this.excelFile.getLastRow();
		int rowRetorno = 0;
		String datoBuscar, datoDataSh;
		boolean encontroDato;
		for (int fila = 2; fila <= filaFin; fila++) {
			encontroDato = true; //Asume que sí se encuentra el dato
			for (int pos = 0; pos < totalKeyHeader; pos++) {
				datoBuscar = valueData[pos];
				datoDataSh = this.excelFile.getStringCellValue(fila, colsKeyHeader[pos]).trim();
				encontroDato = encontroDato && datoDataSh.equals(datoBuscar);
				if (!encontroDato) break; //Termina el ciclo interno, porque si el dato no coincide no hay que seguir
			}
			if (encontroDato) {
				rowRetorno = fila;
				break; //Termina el ciclo porque se encontró la coincidencia
			}
		}
		return rowRetorno;
	}
//***********************************************************************************************************************
	/**
	 * Verifica si los [nbParameters] existen en la hoja de datos, si TODOS existen el retorno es [null], en caso
	 * contrario retorna una String que indica cuáles de los parámetros no se encuentran.
	 */
	public String containParameters(String... nbParameters) {
		String listaParams = "", sep = "";
		for (String nbParameter : nbParameters) {
			if (!this.parameterExist(nbParameter)) {
				if (!listaParams.isEmpty()) sep = ", ";
				listaParams += sep + nbParameter;
			}
		}
		if (listaParams.isEmpty()) listaParams = null;
		return listaParams;
	}
//***********************************************************************************************************************
}