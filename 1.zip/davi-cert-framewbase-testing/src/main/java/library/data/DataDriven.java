package library.data;

import library.common.ExcelFile;

/**
 * Interfaz que obliga a implementar los métodos que permiten manejar los datos principal en un libro de Excel.
 * Para el manejo de la data siempre se contará con la hoja principal que corresponderá a un sheet en un Excel, esta
 * hoja debe tener el nombre "Data" de forma obligatoria.
 * @author szea
 */
public interface DataDriven {

//***********************************************************************************************************************
	/**
	 * Retorna el nombre del archivo fuente. 
	 */
	public String getSource();
//***********************************************************************************************************************
	/**
	 * Retorna el número de ROW / REGISTRO del archivo de datos que se esta teniendo como la ejecución actual. 
	 */
	public int getCurrentExec();
//***********************************************************************************************************************
	/**
	 * Setea como ejecución actual el número indica por [currentExec] - Puede ser un Row o un Registro.
	 */
	public void setCurrentExec(int currentExec);
//***********************************************************************************************************************
	/**
	 * Retorna el número de ROW / REGISTRO del archivo de datos que corresponde a la última ejecución. 
	 */
	public int getLastExec();
//***********************************************************************************************************************
	/**
	 * Retorna el valor contenido en el parámetro [nameParameter] del archivo de datos que se encuentra en la ejecución
	 * actual. 
	 */
	public String getParameter(String nameParameter);
//***********************************************************************************************************************
	/**
	 * Retorna el valor contenido en el parámetro [nameParameter] del archivo de datos que se encuentra en la ejecución
	 * [numExec].
	 */
	public String getParameterByExec(String nameParameter, int numExec);
//***********************************************************************************************************************
	/**
	 * Almacena en el parámetro [nameParameter] del archivo de datos que se encuentra en la ejecución actual,
	 * el String indicado [value]. 
	 */
	public void setParameter(String nameParameter, String value);
//***********************************************************************************************************************
	/**
	 * Almacena en el parámetro [nameParameter] del archivo de datos que se encuentra en la ejecución [numExec],
	 * el String indicado [value]. 
	 */
	public void setParameterByExec(String nameParameter, int numExec, String value);
//***********************************************************************************************************************
	/**
	 * Almacena en el parámetro [nameParameter] del archivo de datos que se encuentra en la ejecución actual,
	 * el double indicado [value]. 
	 */
	public void setParameter(String nameParameter, double value);
//***********************************************************************************************************************
	/**
	 * Almacena en el parámetro [nameParameter] del archivo de datos que se encuentra en la ejecución [numExec],
	 * el double indicado [value]. 
	 */
	public void setParameterByExec(String nameParameter, int numExec, double value);
//***********************************************************************************************************************
	/**
	 * Almacena en el parámetro [nameParameter] del archivo de datos que se encuentra en la ejecución actual,
	 * el [pathFile] como un Hiperlink, dejando en la celda el valor del nombre del archivo (sin path).
	 * @param pathFile - Ruta completa del archivo, con todo y extensión. Debe existir.
	 */
	public void setParameterAsHiperlink(String nameParameter, String pathFile);
//***********************************************************************************************************************
	/**
	 * Almacena en el parámetro [nameParameter] del archivo de datos que se encuentra en la ejecución [numExec],
	 * el [pathFile] como un Hiperlink, dejando en la celda el valor del nombre del archivo (sin path).
	 * @param pathFile - Ruta completa del archivo, con todo y extensión. Debe existir.
	 */
	public void setParameterAsHiperlinkByExec(String nameParameter, int numExec, String pathFile);
//***********************************************************************************************************************
	/**
	 * Indica si el parámetro [nameParameter] existe para la ejecución actual.
	 */
	public boolean parameterExist(String nameParameter);
//***********************************************************************************************************************
	/**
	 * Indica si el parámetro [nameParameter] existe para la ejecución [numExec].
	 */
	public boolean parameterExistByExec(String nameParameter, int numExec);
//***********************************************************************************************************************
	/**
	 * Revisa la existencia de los parámetros mencionados en [nbParameters], si alguno NO está presente, genera una
	 * excepción indicando cuáles NO se encuentran.
	 */
	public void validarParameters(String... nbParameters) throws Exception;
//***********************************************************************************************************************
	/**
	 * Adicionar los parámetros indicados por [nameParameters] a la hoja de datos actual.<br>
	 * Si intenta adicionar un parámetro existente se ignora.
	 */
	public void addParametersNotExist(String... nameParameters) throws Exception;
//***********************************************************************************************************************
	/**
	 * Libera la hoja de datos.
	 */
	public void liberarData();
//***********************************************************************************************************************
	/**
	 * Retorna en un [ExcelFile] la referencia a otra hoja de datos existente en el DataSheet del DataDriven actual.
	 * <b>OJO:</b> Sólo usarla para leer, no se sugiere escribir, porque puede afectar el DataDriven. 
	 */
	public ExcelFile getAnotherSheetReadOnly(String nbSheet); // SÓLO PARA EXCEL
//***********************************************************************************************************************
	/**
	 * Setea en el parámetro [nameParameter] del archivo de datos que se encuentra en la ejecución actual, el color
	 * indicado por [color].<br>
	 * El color a darle a la celda debe ser de tipo p.e: IndexedColors.YELLOW.index
	 */
	public void setColor(String nameParameter, short color); // SÓLO PARA EXCEL
//***********************************************************************************************************************
	/**
	 * Setea en el parámetro [nameParameter] del archivo de datos que se encuentra en la ejecución [numExec], el color
	 * indicado por [color].<br>
	 * El color a darle a la celda debe ser de tipo p.e: IndexedColors.YELLOW.index
	 */
	public void setColorByExec(String nameParameter, int numExec, short color); // SÓLO PARA EXCEL
//***********************************************************************************************************************
}