package library.data;

import java.io.InputStream;

import library.common.DataJSONFile;

/**
 * Clase que maneja la información para el manejo de datos en un archivo JSON.
 * Se debe contar con el recurso (path y nombre de archivo).
 * @author szea
 */
public class DataJSON {

	private String source;
	private DataJSONFile dataFile;
	private String[] keyParameters;
	
//=======================================================================================================================
	public DataJSON() {
	}
	public DataJSON(String source) {
		this.source = source;
		this.iniciarDataJSON(source);
	}
	public DataJSON(String source, InputStream inputStreamSource) {
		this.iniciarDataJSON(source, inputStreamSource);
	}
//***********************************************************************************************************************
	/**
	 * Se encarga de iniciar el archivo de datos : abre el archivo fuente indicando que es para ABRIR.
	 */
	protected void iniciarDataJSON(String source) {
		this.source = source;
		this.dataFile = new DataJSONFile(this.source, DataJSONFile.OPEN);
	}
//***********************************************************************************************************************
	/**
	 * Se encarga de iniciar el archivo de datos : abre el archivo fuente pasando el [InputStream] del archivo.
	 */
	protected void iniciarDataJSON(String source, InputStream inputStreamSource) {
		this.source = source;
		this.dataFile = new DataJSONFile(source, inputStreamSource);
	}
//***********************************************************************************************************************
	/**
	 * @return El número de registros en la hoja de datos
	 */
	public int getLastReg() {
		return this.dataFile.getLastReg();
	}
//***********************************************************************************************************************
	/**
	 * @return El archivo de datos JSON relacionado al [DataJSON]
	 */
	/*public DataJSONFile getDataFile() {
		return this.dataFile;
	}*/
//***********************************************************************************************************************
	/**
	 * Cuando los registros de una hoja de datos se identifican de forma única por determinados datos, con este método
	 * se setea el nombre de los parámetros que arman la unicidad de datos.
	 */
	protected void setKeyParameters(String[] keyData) {
		this.keyParameters = keyData;
	}
//***********************************************************************************************************************
	/**
	 * Retorna el parámetro del DataSheet que se encuentra en el [regNumber] que se recibe por parámetro.
	 */
	public String getParameterByReg(String nameParameter, int regNumber) {
		return this.dataFile.getStringValue(regNumber, nameParameter);
	}
//***********************************************************************************************************************
	/**
	 * Almacena en el parámetro del DataSheet que se encuentra en el Row que se recibe por parámetro, el String indicado.
	 * <br>Así mismo se encarga de ir salvando el archivo de datos. 
	 */
	public void setParameterByReg(String nameParameter, int regNumber, String value) {
		this.dataFile.setStringValue(regNumber, nameParameter, value);
		this.dataFile.saveFile(); // PARA QUE VAYA SALVANDO EL ARCHIVO DE DATOS
	}
//***********************************************************************************************************************
	/**
	 * Almacena en el parámetro del DataSheet que se encuentra en el Row que se recibe por parámetro, el double indicado. 
	 * <br>Así mismo se encarga de ir salvando el archivo de datos. 
	 */
	public void setParameterByReg(String nameParameter, int regNumber, double value) {
		this.dataFile.setNumberValue(regNumber, nameParameter, value);
		this.dataFile.saveFile(); // PARA QUE VAYA SALVANDO EL ARCHIVO DE DATOS
	}
//***********************************************************************************************************************
	/**
	 * Almacena en el parámetro del DataSheet que se encuentra en el Row que se recibe por parámetro, el boolean indicado. 
	 * <br>Así mismo se encarga de ir salvando el archivo de datos. 
	 */
	public void setParameterByReg(String nameParameter, int regNumber, boolean value) {
		this.dataFile.setBooleanValue(regNumber, nameParameter, value);
		this.dataFile.saveFile(); // PARA QUE VAYA SALVANDO EL ARCHIVO DE DATOS
	}
//***********************************************************************************************************************
	/**
	 * Libera el DataSheet, cerrando el archivo. <b>OJO</b> No salva.  
	 */
	public void liberarData() {
		this.dataFile.closeFile();
	}
//***********************************************************************************************************************
	/**
	 * Retorna el número del registro del DataJSON, en el que se encuentra el registro cuyos datos clave coinciden
	 * de forma exacta con los recibidos en [valueData] esta información debe venir completa y en el mismo orden
	 * en que se expresaron los encabezados [keyHeader].
	 * Si no se encuentra el retorno es [0].
	 * @throws Exception 
	 */
	public int getRegKeyByData(String[] valueData) throws Exception {

		int totalKeyHeader = this.keyParameters.length;
		if (totalKeyHeader == 0)
			throw new Exception ("DataJSONERROR -- No se tienen identificados los KeyHeader...");
		if (valueData.length != totalKeyHeader)
			throw new Exception ("DataJSONERROR -- Se esperaban [" + totalKeyHeader + "] KeyHeader...");
		
		// Recorre todos los registros existemtes en el archivo de datos JSON hasta encontrar el registro que coincida
		// con los datos buscados
		int regFin = this.getLastReg();
		int regRetorno = 0;
		String datoBuscar, datoDataSh;
		boolean encontroDato;
		for (int numReg = 1; numReg <= regFin; numReg++) {
			encontroDato = true; //Asume que sí se encuentra el dato
			for (int pos = 0; pos < totalKeyHeader; pos++) {
				datoBuscar = valueData[pos];
				datoDataSh = this.dataFile.getStringValue(numReg, this.keyParameters[pos]).trim();
				encontroDato = encontroDato && (datoDataSh!= null && datoDataSh.equals(datoBuscar));
				if (!encontroDato) break; //Termina el ciclo interno, porque si el dato no coincide no hay que seguir
			}
			if (encontroDato) {
				regRetorno = numReg;
				break; //Termina el ciclo porque se encontró la coincidencia
			}
		}
		return regRetorno;
	}
//***********************************************************************************************************************
	/**
	 * Verifica si los [nbParameters] se encuentran en el archivo de datos, si TODOS existen el retorno es [null], en
	 * caso contrario se retorna la información de los parámetros que no se encontraban.<br>
	 * Se evalúa siempre el primer registro del archivo JSON.
	 */
	public String containParameters(String... nbParameters) {
		String listaParams = "", sep = "";
		for (String nbParameter : nbParameters) {
			if (!this.dataFile.parameterExist(nbParameter)) {
				if (!listaParams.isEmpty()) sep = ", ";
				listaParams += sep + nbParameter;
			}
		}
		if (listaParams.isEmpty()) listaParams = null;
		return listaParams;
	}
//***********************************************************************************************************************
	/**
	 * Indica si el parámetro [nbParameter] se encuentra en los datos del registro [numReg].
	 */
	public boolean parameterExist(String nbParameter, int numReg) {
		return this.dataFile.parameterExist(nbParameter, numReg);
	}
//***********************************************************************************************************************
	/**
	 * Retorna la fuente del DataJSON
	 */
	public String getSource() {
		return this.source;
	}
//***********************************************************************************************************************
}