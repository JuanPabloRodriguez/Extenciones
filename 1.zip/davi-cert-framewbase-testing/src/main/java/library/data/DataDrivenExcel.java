package library.data;

import library.common.ExcelFile;

/**
 * Clase que maneja la información para el manejo de datos principal en un libro de Excel.
 * Para el manejo de la data siempre se contará con la hoja principal que corresponderá a un sheet en un Excel, esta
 * hoja debe tener el nombre "Data" de forma obligatoria.
 * @author szea
 */
public class DataDrivenExcel implements DataDriven {


	private static final String MAIN_SHEET = "Data"; // NOMBRE DE LA HOJA DEL DATASHEET QUE TIENE LOS DATOS
	private int currentRow; // ROW QUE SE ESTÁ EJECUTANDO ACTUALMENTE
	private DataSheet dataSheet;
	private ExcelFile otherExcelFile = null;
//=======================================================================================================================	
	/**
	 * Constructor que crea el DataSheet indicando la ruta del archivo fuente. Asume que el RowHeader es la fila [1].
	 */
	public DataDrivenExcel(String source) throws Exception {
		dataSheet = new DataSheet(source, MAIN_SHEET);
	}
//***********************************************************************************************************************
	/**
	 * Constructor que crea el DataSheet indicando la ruta del archivo fuente y el rowHeader.
	 */
	public DataDrivenExcel(String source, int rowHeader) throws Exception {
		dataSheet = new DataSheet(source, MAIN_SHEET, rowHeader);
	}
//***********************************************************************************************************************
	/**
	 * Retorna el nombre del archivo fuente. 
	 */
	@Override
	public String getSource() {
		return this.dataSheet.getSource();
	}
//***********************************************************************************************************************
	/**
	 * Retorna la fila del DataSheet que se está teniendo como la fila actual. 
	 */
	@Override
	public int getCurrentExec() {
		return this.currentRow;
	}
//***********************************************************************************************************************
	/**
	 * Setea como ejecución actual el número del row [currentExec]
	 */
	@Override
	public void setCurrentExec(int currentExec) {
		this.currentRow = currentExec;
	}
//***********************************************************************************************************************
	/**
	 * Retorna la fila de la última ejecución.
	 */
	@Override
	public int getLastExec() {
		return this.dataSheet.getLastRow();
	}
//***********************************************************************************************************************
	/**
	 * Retorna el parámetro [nameParameter] del DataSheet que se encuentra en la ejecución actual. 
	 */
	@Override
	public String getParameter(String nameParameter) {
		return this.getParameterByExec(nameParameter, this.currentRow);
	}
//***********************************************************************************************************************
	/**
	 * Retorna el parámetro [nameParameter] del DataSheet que se encuentra en la ejecución [numExec]. 
	 */
	@Override
	public String getParameterByExec(String nameParameter, int numExec) {
		String valParameter = null;
		try {
			valParameter = this.dataSheet.getParameterByRow(nameParameter, numExec);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return valParameter;
	}
//***********************************************************************************************************************
	/**
	 * Almacena en el parámetro [nameParameter] del DataSheet que se encuentra en la ejecución actual, el String indicado. 
	 */
	@Override
	public void setParameter(String nameParameter, String value) {
		this.setParameterByExec(nameParameter, this.currentRow, value);
	}
//***********************************************************************************************************************
	/**
	 * Almacena en el parámetro [nameParameter] del DataSheet que se encuentra en la ejecución [numExec], el String indicado. 
	 */
	@Override
	public void setParameterByExec(String nameParameter, int numExec, String value) {
		try {
			this.dataSheet.setParameterByRow(nameParameter, numExec, value);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
//***********************************************************************************************************************
	/**
	 * Almacena en el parámetro [nameParameter] del DataSheet que se encuentra en la ejecución actual, el double indicado. 
	 */
	@Override
	public void setParameter(String nameParameter, double value) {
		this.setParameterByExec(nameParameter, this.currentRow, value);
	}
//***********************************************************************************************************************
	/**
	 * Almacena en el parámetro [nameParameter] del DataSheet que se encuentra en la ejecución [numExec], el double indicado. 
	 */
	@Override
	public void setParameterByExec(String nameParameter, int numExec, double value) {
		try {
			this.dataSheet.setParameterByRow(nameParameter, numExec, value);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
//***********************************************************************************************************************
	/**
	 * Almacena en el parámetro [nameParameter] del archivo de datos que se encuentra en la ejecución actual,
	 * el [pathFile] como un Hiperlink, dejando en la celda el valor del nombre del archivo (sin path).
	 * @param pathFile - Ruta completa del archivo, con todo y extensión. Debe existir.
	 */
	public void setParameterAsHiperlink(String nameParameter, String pathFile) {
		this.setParameterAsHiperlinkByExec(nameParameter, this.currentRow, pathFile);
	}
//***********************************************************************************************************************
	/**
	 * Almacena en el parámetro [nameParameter] del archivo de datos que se encuentra en la ejecución [numExec],
	 * el [pathFile] como un Hiperlink, dejando en la celda el valor del nombre del archivo (sin path).
	 * @param pathFile - Ruta completa del archivo, con todo y extensión. Debe existir.
	 */
	public void setParameterAsHiperlinkByExec(String nameParameter, int numExec, String pathFile) {
		try {
			this.dataSheet.setParameterAsHiperlinkByRow(nameParameter, numExec, pathFile);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
//***********************************************************************************************************************
	/**
	 * Indica si el parámetro [nameParameter] existe para la ejecución actual, en el caso de Excel es igual la primera
	 * a la actual, porque si existe para uno existe para el resto.
	 */
	@Override
	public boolean parameterExist(String nameParameter) {
		return this.dataSheet.parameterExist(nameParameter);
	}
//***********************************************************************************************************************
	/**
	 * Indica si el parámetro [nameParameter] existe para la ejecución [numExec].
	 */
	@Override
	public boolean parameterExistByExec(String nameParameter, int numExec) {
		return this.dataSheet.parameterExist(nameParameter);
	}
//***********************************************************************************************************************
	/**
	 * Revisa la existencia de los parámetros mencionados en [nbParameters], si alguno NO está presente, genera una
	 * excepción indicando cuáles NO se encuentran.
	 */
	@Override
	public void validarParameters(String... nbParameters) throws Exception {
		String paramsFaltantes = this.dataSheet.containParameters(nbParameters);
		if (paramsFaltantes != null) {
			this.liberarData();
			throw new Exception ("DataDrivenExcel ERROR -- El archivo de datos no contiene los parámetros esperados."
					+ "\n\tFaltan >>> " + paramsFaltantes);
		}
	}
//***********************************************************************************************************************
	/**
	 * Libera el DataSheet, cerrando el archivo. <b>OJO</b> No salva.  
	 */
	@Override
	public void liberarData() {
		this.dataSheet.liberarData();
		if (this.otherExcelFile != null)
			this.otherExcelFile.closeFile();
	}
//***********************************************************************************************************************
	/**
	 * Adicionar los parámetros indicados por [nameParameters] a la hoja de datos actual.<br>
	 * Si intenta adicionar un parámetro existente se ignora.
	 */
	@Override
	public void addParametersNotExist(String... nameParameters) throws Exception {
		this.dataSheet.addParametersNotExist(nameParameters);
	}
//***********************************************************************************************************************
	/**
	 * Retorna en un [ExcelFile] la referencia a otra hoja de datos existente en el DataSheet del DataDriven actual.
	 * <b>OJO:</b> Sólo usarla para leer, no se sugiere escribir, porque puede afectar el DataDriven. 
	 */
	public ExcelFile getAnotherSheetReadOnly(String nbSheet) {
		
		if (this.otherExcelFile != null)
			this.otherExcelFile.closeFile();
		
		this.otherExcelFile = new ExcelFile(this.dataSheet.getSource(), ExcelFile.OPEN);
		this.otherExcelFile.selectSheet(nbSheet);
		
		if (this.otherExcelFile.getSheet() == null) {
			otherExcelFile.closeFile();
			otherExcelFile = null;
		}
		return this.otherExcelFile;
	}
//***********************************************************************************************************************
	@Override
	public void setColor(String nameParameter, short color) {
		try {
			this.dataSheet.setColorByRow(nameParameter, this.currentRow, color);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
//***********************************************************************************************************************
	@Override
	public void setColorByExec(String nameParameter, int numExec, short color) {
		try {
			this.dataSheet.setColorByRow(nameParameter, numExec, color);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
//***********************************************************************************************************************
}