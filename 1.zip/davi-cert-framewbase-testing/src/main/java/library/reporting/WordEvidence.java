package library.reporting;

import java.util.ArrayList;
import java.util.List;

import library.common.WordFile;

public class WordEvidence extends WordFile {

	public static final int OPEN   = 0;
	public static final int CREATE = 1;
	
	private String textoTOC = "[TABLA DE CONTENIDO]";
	private boolean insertTOC = false; // NO TIENE EL TEXTO DE TABLA DE CONTENIDO
	private String evidenceTitle = "";
	private List<String> filesImg; // ARCHIVOS DE IMAGEN QUE SERÁN INCLUIDOS EN EL ARCHIVO
	
	public WordEvidence(String filePath, int typeOpen) {
		super(filePath, typeOpen);
	}

	public String getEvidenceTitle() {
		return this.evidenceTitle;
	}
	
	public void setFilesImg(ArrayList<String> filesImg) {
		this.filesImg = filesImg;
	}
	
	/**
	 * Crea una tabla con la información de los [datosPrueba] que se reciben.
	 */
	public void insertarTablaDatos(String[] datosPrueba) {
		String[][] datos = {datosPrueba};
		
		this.insertTable(datos);
		this.insertEnter();
	}
	
	/**
	 * Arma la línea de evidencia: Cuando se trata de UAT, primero inserta el texto referencia para que la tabla sea
	 * insertada a futuro y luego inserta la evidencia.<br> 
	 * En la evidencia va primero el título, luego la tabla de datosPrueba y finalmente inserta las imágenes.
	 */
	public void armarEvidencias(String evidenceTitle, String datosPrueba, List<String> filesImg, boolean esUAT)
			throws Exception {
		// ES EVIDENCIA PARA UAT Y NO SE HA INGRESADO EL TEXTO PARA LA TABLA DE CONTENIDO: SE ESCRIBE
		if (esUAT && !this.insertTOC) {
			this.writeParagraph(this.textoTOC);
			this.insertTOC = true;
		}
		// ES EVIDENCIA PARA UAT: SE HACE SALTO DE PÁGINA
		if (esUAT) this.insertBreakPage();
		
		this.evidenceTitle = evidenceTitle;
		this.filesImg = filesImg;
		this.writeTitle(WordFile.HEADING1, evidenceTitle);
		this.insertarTablaDatos(datosPrueba.split(","));
		for (String nameFile : this.filesImg) {
			this.insertImage(nameFile);
		}
	}

    /**
     * Cambia el título de la evidencia por [evidenceTitle].
     */
    public void changeTitle(String oldEvidenceTitle, String newEvidenceTitle) {
    	
    	boolean hizoCambio = this.changeText(oldEvidenceTitle, newEvidenceTitle);
    	if (hizoCambio)
    		this.evidenceTitle = newEvidenceTitle;
		/*
    	List<XWPFParagraph> paragraphs = this.document.getParagraphs();
    	for (XWPFParagraph paragraph : paragraphs) {
    		if (paragraph.getText().equals(this.evidenceTitle)) {
    			//String replacedText = StringUtils.
    		}
		}
		*/
    }

}
