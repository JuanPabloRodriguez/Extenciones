package library.reporting;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.testng.asserts.SoftAssert;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import library.common.ConsoleWindow;
import library.common.Util;
import library.settings.SettingsRun;
import library.testTool.alm.Alm;
import library.testTool.alm.AlmConstants;

public class Reporter {

	private static ExtentReports extent;
	public static ExtentTest test; // PUBLIC PORQUE LO LLAMA [ListenerBaseTestNG]
	private static Map<Integer, ExtentTest> dicRegTest = new HashMap<Integer, ExtentTest>();

	private static SoftAssert sAss;
	private static EvidenceType evidenceType;
	private static String nbEvidence;
	//private static List<String> listPathFilesEvid_Pendientes = new ArrayList<String>();
	
	private static String TEST_SET_ID;
	private static String TEST_CONF_ID;
	
	public static boolean WRITE_HEADER = false; // EN [false] NO ESCRIBE EL HEADER QUE MUESTRA EL NÚMERO DE LA EJECUCIÓN
	public static final int MIC_HEADER = -1;
	public static final int MIC_PASS = 0;
	public static final int MIC_FAIL = 1;
	public static final int MIC_DONE = 2;
	public static final int MIC_WARNING = 3;
	public static final int MIC_NOEXEC = 4;
	public static final int MIC_INFO = 5;
	public static final int MIC_NOT_COMPLETED = 6;
	
	// NOMBRE DEL PARÁMETRO EN LA HOJA DE DATOS EN DONDE VIENE EL EVENTO EN QUE QUEDÓ UN LANZAMIENTO
	// SE USA PARA LA RETOMA DE EJECUCIONES
	private static final String PARAM_EVENT_PREV = "ResPrevioTx";
	// EL NOMBRE DEL EVENT STATUS COINCIDE CON LA POSICIÓN AL QUE CORRESPONDE EN EL ARRAY:
	private static final String[] ARR_NB_EVENT_STATUS = {
		"PASSED", "FAILED", "DONE", "WARNING", "NO EXEC", "INFO", "NOT COMPLETED" };
	private static List<Integer> listaExecutionXBloque = null;
	private static List<Boolean> listaIsExecBloqueCompleted = null;
	// NOMBRE DE LAS PRUEBAS POR ITERACIÓN
	private static Map<Integer, String> dicTestNames = new HashMap<Integer, String>();
	private static boolean isInRestart = false;
	
//=======================================================================================================================
	/**
	 * Método para escribir sólo en la consola el [msg] - NO escribe en el archivo LOG. Concatena el Header si se
	 * requiere.
	 */
	public static void writeOnlyConsole(String msg) {
		String msgMostrar = armarMessage(msg, false);
		System.out.println(msgMostrar);
	}
//***********************************************************************************************************************
	/**
	 * Método para escribir en la consola el [msg]. También escribe en el LOG de la ejecución.<br>
	 * La diferencia con el método [write] es que la escritura la hace sin HEADER así se requiriera por eso se indica que
	 * escribe como TITLE.
	 */
	public static void writeTitle(String msg) {
		boolean oldValue = Reporter.WRITE_HEADER;
		try {
			Reporter.WRITE_HEADER = false;
			Reporter.write(msg, false);
			Reporter.WRITE_HEADER = oldValue;
		} catch (Exception e) {
			// HACE NADA, PORQUE NO TIENE POR QUÉ SALIR EXCEPTION
		}
	}
//***********************************************************************************************************************
	/**
	 * Método para escribir en la consola el [msg]. También escribe en el LOG de la ejecución.
	 */
	public static void write(String msg) {
		String msgMostrar = armarMessage(msg, false);
		if (!msgMostrar.isEmpty()) {
			System.out.println(msgMostrar);
			ConsoleWindow.writeInLog(msgMostrar);
		}
	}
//***********************************************************************************************************************
	/**
	 * Método para escribir en la consola el [msg] pero no da ENTER. También escribe en el LOG de la ejecución.
	 */
	public static void writeWithoutLn(String msg) {
		String msgMostrar = armarMessage(msg, false);
		if (!msgMostrar.isEmpty()) {
			System.out.print(msgMostrar);
			ConsoleWindow.writeInLog(msgMostrar); // LE DEJA ENTER EN EL LOG
		}
	}
//***********************************************************************************************************************
	/**
	 * Método para escribir en la consola el [msg]. También escribe en el LOG de la ejecución.<br>
	 * Cuando [nextIteration] es true sale de la iteración actual.
	 */
	public static void write(String msg, boolean nextIteration) throws Exception {
		write(msg);
		if (nextIteration)
			SettingsRun.exitTestIteration();
	}
//***********************************************************************************************************************
	/**
	 * Método para escribir en la consola el [msg] como un error. También escribe en el LOG de la ejecución.
	 */
	public static void writeErr(String msg) {
		String msgMostrar = armarMessage(msg, true);
		System.err.println(msgMostrar);
		ConsoleWindow.writeInLog(msgMostrar);
	}
//***********************************************************************************************************************
	/**
	 * Método para escribir en la consola el [msg] como un error. También escribe en el LOG de la ejecución.<br>
	 * Cuando [nextIteration] es true sale de la iteración actual.
	 */
	public static void writeErr(String msg, boolean nextIteration) throws Exception {
		writeErr(msg);
		if (nextIteration)
			SettingsRun.exitTestIteration();
	}
//***********************************************************************************************************************
	/**
	 * Adiciona al reporte HTML de ejecución, la prueba (registro) correspondiente a la ejecución actual.
	 */
	public static void addTestToReport() {
		
		int currentIt = SettingsRun.getCurrentIteration();
		addTestToReport(currentIt);
	}
//***********************************************************************************************************************
	/**
	 * Adiciona al reporte HTML de ejecución, la prueba (registro) correspondiente a la ejecución [iteration]<br>
	 * El nombre que le da a la prueba será el que se le dióa a la evidencia, pero si no se le dió se pone
	 * "PRUEBA REGISTRO #" y si se cuenta con datos de test configuration y test id también se adicionan al nombre de la
	 * prueba.
	 */
	public static void addTestToReport(int iteration) {
		
		// SE USA PARA EVITAR QUE RESETEE LA EVIDENCIA SI YA LO HIZO
		if (dicRegTest.containsKey(iteration)) { // SI YA FUE ADICIONADO EL REPORTE PARA LA ITERACIÓN DADA, SE CARGA
			Reporter.loadTestReport(iteration);
			return; // TERMINA
		}
		// SI LLEGA A ESTE PUNTO LA ITERACIÓN ES NUEVA : PERO SÓLO SI NO ESTÁ EN [isInRestart]:
		// REINICIA LA EJECUCIÓN DE EVIDENCIA, ÚTIL PARA EVITAR QUE SE TOMEN EVIDENCIAS DE EJECUCIONES PASADAS
		if (!isInRestart) {
			Reporter.nbEvidence = null;
			if (Reporter.evidenceType != null)
				Reporter.evidenceType.resetEvidenceByTest();
		}
//-----------------------------------------------------------------------------------------------------------------------
		String testName = "PRUEBA REGISTRO " + iteration;
		String datoAdd = "";
		// SI YA ESTÁ DEFINIDO EL NOMBRE DE LA PRUEBA
		if (dicTestNames.containsKey(iteration))
			testName = "(R:" + iteration + ") " + dicTestNames.get(iteration);
		// SI HAY HOJA DE DATOS Y SE CUENTA CON EL [idTestConf]
		if (SettingsRun.getTestData() != null && SettingsRun.getTestData().parameterExistByExec(SettingsRun.PARAM_ID_TEST_CONF, iteration)) {
			String idTestConf = SettingsRun.getTestData().getParameter(SettingsRun.PARAM_ID_TEST_CONF).trim();
			if (!idTestConf.isEmpty())
				datoAdd += datoAdd.isEmpty() ? "TC:" + idTestConf : " - TC:" + idTestConf;
		}
		String testNameInReport = datoAdd.isEmpty() ? testName : testName + " (" + datoAdd + ")";
		// HACE LA ADICIÓN USANDO UN MÉTODO QUE LO HACE
		Reporter.addTestToReport(iteration, testNameInReport);
	}
//***********************************************************************************************************************
	/**
	 * Adiciona al reporte HTML de ejecución, una prueba (un registro) asociado a la ejecución correspondiente a
	 * [iteration] dándole el nombre [testName].
	 */
	public static void addTestToReport(int iteration, String testName) {
		
		if (dicRegTest.containsKey(iteration)) { // SI YA FUE ADICIONADO EL REPORTE PARA LA ITERACIÓN DADA, SE CARGA
			Reporter.loadTestReport(iteration);
			return; // TERMINA
		}
//-----------------------------------------------------------------------------------------------------------------------
		Reporter.test = Reporter.extent.createTest(testName);
		// ALMACENA EN MAP LOS REGISTROS DE LOS TEST
		dicRegTest.put(iteration, Reporter.test);
//-----------------------------------------------------------------------------------------------------------------------
		// DUPLICA SI HAY REPORTE PARALELO
		if (Reporter.extentCopyReport != null) {
			Reporter.testCopy = Reporter.extentCopyReport.createTest(testName);
			dicRegTestCopy.put(iteration, Reporter.testCopy);
		}
	}
//***********************************************************************************************************************
	/**
	 * Adiciona al reporte HTML de ejecución, una prueba (un registro) con el nombre [testName], este no corresponde a
	 * ninguna iteración en sí, así que le da un valor negativo al número de ejecución<br>
	 * Retorna el número de registro que almacena.
	 */
	public static int addTestToReport(String testName) {
		
		int iniIt = -1;
		while (dicRegTest.containsKey(iniIt)) {
			iniIt--;
		}
//-----------------------------------------------------------------------------------------------------------------------
		Reporter.test = Reporter.extent.createTest(testName);
		// ALMACENA EN MAP LOS REGISTROS DE LOS TEST
		dicRegTest.put(iniIt, Reporter.test);
//-----------------------------------------------------------------------------------------------------------------------
		// DUPLICA SI HAY REPORTE PARALELO
		if (Reporter.extentCopyReport != null) {
			Reporter.testCopy = Reporter.extentCopyReport.createTest(testName);
			dicRegTestCopy.put(iniIt, Reporter.testCopy);
		}
		return iniIt;
	}
//***********************************************************************************************************************
	/**
	 * En el reporte HTML se reinicia la información de la prueba correspondiente a la ejecución actual.<br>
	 * Adicional garantiza que las evidencias que existían se borran (si existían). 
	 */
	public static void resetTestInReport() {
		
		Reporter.restartTestInReport();
		try {
			Evidence.deleteEvidences();
		}
		catch (IOException e) { }
		Reporter.write("Se hace reinicio en reporte HTML y borrado de evidencias previas...");
	}
//***********************************************************************************************************************
	/**
	 * En el reporte HTML se reinicia la información de la prueba correspondiente a la ejecución actual.
	 */
	private static void restartTestInReport() {
		
		isInRestart = true;
		int currentIt = SettingsRun.getCurrentIteration();
		if (Reporter.test != null) {
			Reporter.extent.removeTest(Reporter.test);
			dicRegTest.remove(currentIt);
		}
//-----------------------------------------------------------------------------------------------------------------------
		// REMUEVE TAMBIÉN SI HAY REPORTE PARALELO
		if (Reporter.extentCopyReport != null && Reporter.testCopy != null) {
			Reporter.extentCopyReport.removeTest(Reporter.testCopy);
			dicRegTestCopy.remove(currentIt);
		}
//-----------------------------------------------------------------------------------------------------------------------
		Reporter.addTestToReport(currentIt);
		isInRestart = false;
	}
//***********************************************************************************************************************
	/**
	 * Carga en la información general el nombre de la prueba que va teniendo cada prueba, en este caso la de la
	 * [iteration] dada recibe el nombre [testName], en caso que [testName] venga en null se carga el nombre de la
	 * evidencia de la ejecución.<br>
	 * Si la iteración ya recibió un nombre de prueba, se sobreescribe.
	 */
	private static void loadTestName(int iteration, String testName) {
		
		if (testName == null)
			testName = Reporter.getSimpleNameEvidence(iteration);
		dicTestNames.put(iteration, testName.trim()); // DEJANDO EL ÚLTIMO SI YA ESTABA
	}
//***********************************************************************************************************************
	/**
	 * Retorna el nombre que puede tener el archivo de evidencia de una iteración dada, no retorna ni ruta ni extensión.<br>
	 * Cuando no se cuenta con un nombre de prueba dado, se da un nombre genérico [(Exec#) YYYYMMDDHHMMSS_RESULTADO_EXEC] 
	 */
	public static String getSimpleNameEvidence(int numIteration) {
		
		String nbArchRepResults = dicTestNames.get(numIteration);
		
		String inicio = "(Exec" + numIteration;
		if (SettingsRun.getTestData() != null && SettingsRun.getTestData().parameterExist(SettingsRun.PARAM_ID_TEST_CONF)) {
			String testConf = SettingsRun.getTestData().getParameter(SettingsRun.PARAM_ID_TEST_CONF).trim();
			if (Util.getListaDatos(testConf, ",").size() == 1)
				inicio += "-" + testConf;
		}
		inicio += ") ";
		
		if (nbArchRepResults != null) {
			nbArchRepResults = inicio + Util.cleanTextForFile(nbArchRepResults.trim());
			if (nbArchRepResults.length() > 150)
				nbArchRepResults = Util.left(nbArchRepResults, 90);
		}
		// ARMA EL NOMBRE DEL ARCHIVO DE REPORTE DE RESULTADOS, SIN PATH NI EXTENSIÓN:
		if (nbArchRepResults == null || nbArchRepResults.isEmpty()) {
			String extension = "";
			try {
				extension = Util.dateToString("yyyymmdd") + Util.hourToString("HHmmss");
			}
			catch (Exception e) { // HACE NADA
			}
			nbArchRepResults = inicio + extension + "_RESULTADO_EXEC";
		}
		return nbArchRepResults;
	}
//***********************************************************************************************************************
	/**
	 * Carga el reporte de la prueba que corresponde a [iteration] que se recibe por parámetro y así mismo deja cargada
	 * la información de la evidencia.
	 */
	public static void loadTestReport(int iteration) {
		if (!dicRegTest.containsKey(iteration))
			Reporter.addTestToReport(iteration);
		else {
			Reporter.test = dicRegTest.get(iteration);
			Reporter.testCopy = dicRegTestCopy.get(iteration);
		}
		
		if (Reporter.evidenceType != null)
			Reporter.evidenceType.loadEvidenceByIteration(iteration);
	}
//***********************************************************************************************************************
	/**
	 * Reporta el evento [eventStatus] en la consola y en el archivo de LOG.<br>
	 * Adicional cuando se trata de un evento que no sea [MIC_HEADER] lo reporta en el LOG del reporte HTML <b>
	 * (Reporter.test.log)</b> y así mismo si se trata de un [MIC_FAIL] genera la assertion para que el caso se muestre
	 * fallido en el reporte final.
	 */
	public static void reportEvent(int eventStatus, String reportMsg) {
		String inicio = "";
		if (eventStatus != Reporter.MIC_HEADER) {
			String it = "";
			if (Util.isLaunchJAR())
				it = "(" + SettingsRun.getCurrentIteration() + ") ";
			inicio = Util.rightComplete(ARR_NB_EVENT_STATUS[eventStatus] + " " + it, 16, '-') + " ";
		}
		// HACE EL PRINT EN CONSOLA SIEMPRE Y CUANDO HAYA ALGO PARA ESCRIBIR
		if (!reportMsg.isEmpty() && !reportMsg.equals("N/A")) {
			if (eventStatus == MIC_FAIL)
				Reporter.writeErr("*** " + inicio + reportMsg);
			else
				Reporter.write("*** " + inicio + reportMsg);
		}
//-----------------------------------------------------------------------------------------------------------------------
		// REPORTA EN EL LOG DEL [test] EL STATUS RECIBIDO
		Status realStatus = Reporter.getStatusByLog(eventStatus);
		if (Reporter.test != null && realStatus != null) {
			Reporter.test.log(realStatus, reportMsg.replace("\n", "<br>"));
			if (Reporter.testCopy != null)
				Reporter.testCopy.log(realStatus, reportMsg.replace("\n", "<br>"));
			// CUANDO SE TRATA DE UNA FALLA DEBE GENERAR LA FALLA PARA QUE QUEDE REPORTADA
			if (eventStatus == MIC_FAIL)
				Reporter.sAss.assertTrue(false); // GENERA EL ASSERT DE FALLA
		}
	}
//***********************************************************************************************************************
	/**
	 * Almacena en hoja de datos la información del evento actual, en una columna llamada [Reporter.PARAM_EVENT_PREV].
	 */
	public static void saveCurrentEvent() throws Exception {
		
		if (SettingsRun.getTestData() == null)
			return;
		// ALMACENA EL RESULTADO DE LA ITERACIÓN, POR SI SE DEBE HACER UNA CARGA POSTERIOR
		if (!SettingsRun.getTestData().parameterExist(PARAM_EVENT_PREV))
			SettingsRun.getTestData().addParametersNotExist(PARAM_EVENT_PREV);
		String resPrevio = Reporter.test.getStatus().toString();
		if (Reporter.test.getStatus().equals(Status.PASS))
			resPrevio = "PASSED";
		else if (Reporter.test.getStatus().equals(Status.FAIL))
			resPrevio = "FAILED";
		SettingsRun.getTestData().setParameter(PARAM_EVENT_PREV, resPrevio);
	}
//***********************************************************************************************************************
	/**
	 * Carga el evento respectivo que venga en la hoja de datos, cuando existe en la hoja de datos el parámetro
	 * [Reporter.PARAM_EVENT_PREV] y viene con valor.
	 */
	public static void reportPreviousEvent() {
		
		int eventStatus = Reporter.getPreviousEvent();
		if (eventStatus != 2)
			Reporter.reportEvent(eventStatus, "Viene de una ejecución previa [" + getEventName(eventStatus) + "]");
	}
//***********************************************************************************************************************
	/**
	 * Retorna el nombre del evento correspondiente a [eventStatus].
	 */
	public static String getEventName(int eventStatus) {
		
		String nbEvento = "";
		if (eventStatus >= 0 && eventStatus < ARR_NB_EVENT_STATUS.length)
			nbEvento = ARR_NB_EVENT_STATUS[eventStatus];
		return nbEvento;
	}
//***********************************************************************************************************************
	/**
	 * Retorna el index del evento previo de la ejecución, que está alamcenado en la hoja de datos, en el parámetro
	 * [Reporter.PARAM_EVENT_PREV].<br>
	 * <b>OJO: Si no está registro un evento previo, el retorno es -2.</b>
	 */
	public static int getPreviousEvent() {
		
		int eventPrev = -2;
		if (SettingsRun.getTestData() == null)
			return eventPrev;
		if (!SettingsRun.getTestData().parameterExist(PARAM_EVENT_PREV))
			return eventPrev;
		// SE DETERMINA EL VALOR DEL EVENTO PREVIO
		String resPrevio = SettingsRun.getTestData().getParameter(PARAM_EVENT_PREV);
		if (!resPrevio.isEmpty()) {
			int eventStatus = Reporter.MIC_WARNING;
			if (resPrevio.equals("PASSED"))
				eventStatus = Reporter.MIC_PASS;
			else if (resPrevio.equals("FAILED"))
				eventStatus = Reporter.MIC_FAIL;
			eventPrev = eventStatus;
		}
		return eventPrev;
	}
//***********************************************************************************************************************
	/**
	 * Cuando se trata de ejecución por bloque, es requerido cargar la lista de ejecución por bloque que se realizará.
	 */
	public static void loadListaExecutionXBloque(List<Integer> listaExecutionXBloque) {
		Reporter.listaExecutionXBloque = listaExecutionXBloque;
		if (listaExecutionXBloque != null) {
			Reporter.listaIsExecBloqueCompleted = new ArrayList<Boolean>();
			for (int posLista = 0; posLista < listaExecutionXBloque.size(); posLista++) {
				Reporter.listaIsExecBloqueCompleted.add(false); // INDICA QUE NO SE HA COMPLETADO
			}
		}
	}
//***********************************************************************************************************************
	/**
	 * En las ejecuciones por bloque indica que la iteración actual ha sido completada, se usa cuando las pruebas
	 * terminan se forma abrupta, saber cuáles ya fueron terminadas.
	 */
	public static void setIterationAsCompleted_XBloque() {
		
		Reporter.setIterationAsCompleted_XBloque(SettingsRun.getCurrentIteration());
	}
//***********************************************************************************************************************
	/**
	 * En las ejecuciones por bloque indica que la iteración [iteration] ha sido completada, se usa cuando las pruebas
	 * terminan se forma abrupta, saber cuáles ya fueron terminadas.
	 */
	public static void setIterationAsCompleted_XBloque(int iteration) {
		
		if (Reporter.listaExecutionXBloque == null)
			return; // NO ES ITERACIÓN POR BLOQUE NO HACE NADA
		int posLista = Reporter.listaExecutionXBloque.indexOf(iteration);
		Reporter.listaIsExecBloqueCompleted.set(posLista, true);
	}
//***********************************************************************************************************************
	/**
	 * Inicializa el tipo de evidencia que se manejará.
	 */
	public static void initializeEvidenceType(EvidenceType evidenceType) {
		Reporter.evidenceType = evidenceType;
	}
//***********************************************************************************************************************
	/**
	 * Crea un archivo de evidencias con nombre [nbFileSimple] para determinado Test.<br>
	 * Setea el nombre del caso de prueba en el archivo de evidencias.<br>
	 * Aplica para aquellos casos en que el tipo de evidencia corresponda a uno que genere archivo y que requiera dejar
	 * registro del nombre de la prueba.<br>
	 */
	public static void initializeEvidenceTestFile(String nbFileSimple, String nbTestCase) {
		
		Reporter.loadTestName(SettingsRun.getCurrentIteration(), nbFileSimple);
		if (Reporter.evidenceType != null) {
			Reporter.evidenceType.createEvidenceByTest();
			Reporter.evidenceType.setNbTestCase(nbTestCase);
		}
		Reporter.restartTestInReport(); // REINICIA LA PRUEBA, PARA QUE TOME EL NOMBRE DE LA EVIDENCIA
	}
//***********************************************************************************************************************
	/**
	 * Crea en la evidencia la información de un nuevo step, indicando: descripción, resultado esperado y estado del Step.
	 * Así mismo adiciona al step, todas las evidencias almacenadas que estén pendiente de ser adicionadas.
	 *//*
	public static void setStepInFile(String description, String expResult, String status) throws Exception {
		if (Reporter.evidenceType != null)
			Reporter.evidenceType.setTestStep(description, expResult, status);
		Reporter.addEvidences();
	}*/
//***********************************************************************************************************************
	/**
	 * Adiciona todas las evidencias almacenadas que estén pendiente de ser adicionadas.
	 *//*
	public static void discardEvidences() {
		// SE INICIALIZA LA LISTA DE IMÁGENES PENDIENTES
		listPathFilesEvid_Pendientes = new ArrayList<String>();
	}*/
//***********************************************************************************************************************
	/**
	 * Retorna la lista de evidencias que estén pendientes de ser adicionadas.
	 *//*
	public static List<String> getEvidencesList() {
		
		return listPathFilesEvid_Pendientes;
	}*/
//***********************************************************************************************************************
	/**
	 * Setea la lista de evidencias [listaPathFilesPend] como las que están pendientes de ser adicionadas.<br>
	 * Usar con cuidado: Este método quita las que estén actualmente en la lista de pendientes.
	 *//*
	public static void setEvidencesList(List<String> listaPathFilesPend) {
		
		listPathFilesEvid_Pendientes = listaPathFilesPend;
	}*/
//***********************************************************************************************************************
	/**
	 * Intenta hacer la carga de las evidencias a la herramienta de pruebas.<br>
	 * La carga se hace indicando estado PASSED, en el TestSet [Evidence.TEST_SET_ID], en el test configuration con ID
	 * [testId].
	 */
	public static void uploadEvidenceToTestTool() {
		
		if (!SettingsRun.doLoadToTestTool())
			return; // NO HACE CARGA DE EVIDENCIAS EN HERRAMIENTAS
//-----------------------------------------------------------------------------------------------------------------------
		// DETERMINA LA INFORMCIÓN BÁSICA PARA HACER LA CARGA EN LA HERRAMIENTA DE GESTIÓN DE PRUEBAS
		Reporter.TEST_SET_ID = null;
		Reporter.TEST_CONF_ID = null; // NO SE CARGA EN HERRAMIENTA DE GESTIÓN
		if (SettingsRun.getTestData() != null) {
			if (SettingsRun.getTestData().parameterExist(SettingsRun.PARAM_ID_TEST_SET))
				Reporter.TEST_SET_ID = SettingsRun.getTestData().getParameter(SettingsRun.PARAM_ID_TEST_SET).trim();
			if (SettingsRun.getTestData().parameterExist(SettingsRun.PARAM_ID_TEST_CONF))
				Reporter.TEST_CONF_ID = SettingsRun.getTestData().getParameter(SettingsRun.PARAM_ID_TEST_CONF).trim();
		}
		if (Reporter.TEST_SET_ID == null)
			Reporter.TEST_SET_ID = SettingsRun.getProperty(SettingsRun.PROP_ID_TEST_SET, "").trim();
		if (Reporter.TEST_CONF_ID == null)
			Reporter.TEST_CONF_ID = SettingsRun.getProperty(SettingsRun.PROP_ID_TEST_CONF, "").trim();
//-----------------------------------------------------------------------------------------------------------------------
		// DETERMINA LA ENTRADA PARA LA HERRAMIENTA DE GESTIÓN DE PRUEBAS
		String testTool = SettingsRun.getProperty(SettingsRun.PROP_TEST_TOOL_NAME, "ALM");
		switch (testTool) {
			case "ALM":
				String nbFile = null; // PARA QUE NO SUBA ARCHIVO A LA INSTANCIA
				if (Reporter.getEntityForUpload().equals("INSTANCE"))
					nbFile = Reporter.getNbEvidenceFile();
				// INTENTA PASAR LA PRUEBA, SÓLO SUBE EVIDENCIA SI ES EN LA [INSTANCE]
				Reporter.uploadEvidenceToALM(nbFile);
			break;
//-----------------------------------------------------------------------------------------------------------------------		
			default: // NO ESTÁ DEFINIDA OTRA HERRAMIENTA
		}
	}
//***********************************************************************************************************************
	// MAP PARA ALMACENAR LAS EVIDNECIAS POR ITERACIÓN KEY=ITERATION, VALUE=RUTA EVIDENCIA FINAL
	private static Map<Integer,String> mapEvidencesByIteration = new HashMap<Integer,String>();
	/**
	 * Este método setea el estado final de la prueba, también cierra el archivo de Evidencias.<br>
	 * Adicional hace el cierre de evidencias de las pruebas según el formato requerido.<br>
	 * En caso que [status] sea [null] se setea el estado de la ejecución como haya quedado en el [Reporter.test]<br>
	 * Por lo general: Método llamado por el Listener.
	 */
	public static void setTestStatus(String status) {
		if (Reporter.evidenceType != null) {
			if (status == null)
				status = Reporter.test.getStatus().toString().toUpperCase();
			Reporter.evidenceType.setTestStatus(status);
		}
		Reporter.generateTestClose(); // PARA CERRAR LAS EVIDENCIAS DE LA PRUEBA EN EL FORMATO REQUERIDO
		mapEvidencesByIteration.put(SettingsRun.getCurrentIteration(), Reporter.nbEvidence);
	}
//***********************************************************************************************************************	
	/**
	 * Almacena las evidencias indicadas a la lista de evidencias pendientes para que puedan ser ingresadas a un archivo
	 * de evidencias.
	 *//*
	public static void addEvidenceAsPendiente(String... filesEvidence) {
		for (String fileEvidence : filesEvidence) {
			listPathFilesEvid_Pendientes.add(fileEvidence);
		}
	}*/
//***********************************************************************************************************************
	/**
	 * Este método inicializa el reporte HTML, creando el objeto para el reporte.
	 */
	public static void initHtmlReport() {
		Reporter.extent = ExtentReporterNG.getReportObject();
	}
//***********************************************************************************************************************
	/**
	 * Este método genera el reporte HTML, invocando el flush() del ExtentReports.
	 */
	public static void generateLaunchReport() {
		if (Reporter.extent != null)
			Reporter.extent.flush();
		if (Reporter.extentCopyReport != null)
			Reporter.testCopy.getExtent().flush(); // PORQUE PUEDE ESTAR EN CUALQUIER REPORTE DE LA COPIA
	}
//=======================================================================================================================
	// TODO >> MÉTODOS PRIVADOS
	private static int NUM_REGISTRO = -1;
	/**
	 * Arma el mensaje que se debe mostrar en consola y en el LOG. Si [WRITE_HEADER] es [true] evalúa si escribe el
	 * mensaje con encabezado.
	 */
	private static String armarMessage(String msg, boolean isError) {
		if (WRITE_HEADER) {
			if (NUM_REGISTRO != SettingsRun.getCurrentIteration()) {
				NUM_REGISTRO = SettingsRun.getCurrentIteration();
				String titleRow = "\n*** EXEC " + NUM_REGISTRO + " >>> (" + Util.hourToString("HH:mm:ss") + ")";
				System.out.println(titleRow);
				ConsoleWindow.writeInLog(titleRow);
			}
		}
		String msgMostrar = "";
		if (isError && !msg.contains("*** FAILED ---"))
			msgMostrar += "*** ERROR ---------- ";
		return (msgMostrar + msg);
	}
//***********************************************************************************************************************
	private static Status getStatusByLog(int eventStatus) {
		Status realStatus = null;
		switch (eventStatus) {
			case MIC_DONE:
			case MIC_INFO:
				realStatus = Status.INFO;
			break;

			case MIC_FAIL:
				realStatus = Status.FAIL;
			break;

			case MIC_PASS:
				realStatus = Status.PASS;
			break;

			case MIC_WARNING:
				realStatus = Status.WARNING;
			break;

			case MIC_NOT_COMPLETED:
			case MIC_NOEXEC:
				realStatus = Status.SKIP;
			break;
		}
		return realStatus;
	}
//***********************************************************************************************************************
	/**
	 * Adiciona en el reporte de evidencias todas las evidencias almacenadas en el directorio de evidencias de la
	 * iteración actual.<br>
	 * Las evidencias se deben ordenar por nombre.
	 */
	private static void addEvidencesToReportFile() {
		
		if (Reporter.evidenceType == null)
			return; // NO HAY TIPO DE EVIDENCIA PARA CARGAR
		
		// RUTA COMPLETA DONDE ESTÁN LAS EVIDENCIAS DE LA ITERACIÓN ACTUAL
		String evidenceDir = Evidence.getNbEvidenceDirectory();
		if (!Util.directoryExist(evidenceDir))
			return; // SI NO EXISTE - HACE NADA PORQUE NO HAY EVIDENCIAS PARA EXTRAER
//-----------------------------------------------------------------------------------------------------------------------
		// EXTRAE LOS ARCHIVOS EXISTENTES EN LA CARPETA ORDENADAS POR NOMBRE
		File[] arrFiles = Util.getFilesOrderBy(evidenceDir, Util.ORDER_BYNAME, true);
		List<String> listPathFilesEvid = new ArrayList<String>();
		for (File evidenceFile : arrFiles) {
			if (Util.isImage(evidenceFile))
				listPathFilesEvid.add(evidenceFile.getAbsolutePath());
		}
		if (listPathFilesEvid.size() == 0)
			return; // NO HAY EVIDENCIAS PARA ADICIONAR
//-----------------------------------------------------------------------------------------------------------------------
		Reporter.evidenceType.insertImage(Util.listToArray(listPathFilesEvid));
		if (!Util.isLaunchJAR() && listaExecutionXBloque == null) // SOLO LO MUESTRA PARA EJECUCIONES NO X BLOQUE
			Reporter.write(
				"*** Evidencias adicionadas:\n    " + Util.listToString(listPathFilesEvid, "\n    "));
	}
//***********************************************************************************************************************
	/**
	 * Este método realiza las acciones de cierre de un Test, se invoca después de setear el estado final de la
	 * prueba:<br>
	 * 1. Revisa si el tipo de evidencia corresponde a la clase [dav.library.core.EvidencePdfFile], si es así deja
	 * almacenadas TODAS las imágenes recopiladas en el archivo de evidencias respectivo.<br>
	 * 2. Revisa si las evidencias se almacenaron en un archivo WORD en tal caso, lo convierte a PDF. <b>OJO:</b> Después
	 * del llamado a este método no se puede adicionar nada más al archivo de evidencias.
	 */
	private static void generateTestClose() {
		
		// SE DEBE GENERAR .ZIP DE LAS EVIDENCIAS, EL NOMBRE DEL ARCHIVO QUEDA EN [Reporter.nbEvidenceZip]
		if (Reporter.evidenceType == null) {
			Reporter.crearZipWithEvidences();
			return; // PARA QUE NO EVALÚE EL RESTO, PORQUE NO HAY NECESIDAD
		}
		// SUBE TODAS LAS EVIDENCIAS DE LA ITERACIÓN AL ARCHIVO DE EVIDENCIAS 
		if (Reporter.evidenceType instanceof dav.library.reporting.EvidencePdfFile) {
			Reporter.addEvidencesToReportFile();
		}
		// DEBE HABER UN ARCHIVO WORD, POR ENDE LO TRANSFORMA
		if (Reporter.evidenceType instanceof dav.library.reporting.EvidencePdfFile ||
			Reporter.evidenceType instanceof dav.library.reporting.EvidencePdfFileWithSteps) {
			
			String wordFilePath = Reporter.evidenceType.getNbEvidenceFile();
			if (wordFilePath != null) {
				
				if (!Reporter.evidenceType.containEvidences())
					new File(wordFilePath).delete(); // BORRA EL ARCHIVO QUE NO CONTIENE EVIDENCIAS

				else { // CONTIENE EVIDENCIAS
					String pdfFilePath = wordFilePath.replace(".docx", ".pdf");
					Reporter.nbEvidence = Util.wordToPDF(wordFilePath, pdfFilePath);
//-----------------------------------------------------------------------------------------------------------------------
					// DA NOMBRE A LA CARPETA SEGÚN EL ESTADO
					String nbFolderbyEstado = "WARNING" + File.separator;
					if (Reporter.test.getStatus().equals(Status.PASS))
						nbFolderbyEstado = "PASSED" + File.separator;
					else if (Reporter.test.getStatus().equals(Status.FAIL))
						nbFolderbyEstado = "FAILED" + File.separator;
//-----------------------------------------------------------------------------------------------------------------------
					// ADICIONA LA CARPETA POR ESTADO A LA CARPETA DE EVIDENCIA FINAL
					String evidTestToolDir = SettingsRun.getFinalEvidencesDir() + nbFolderbyEstado;
					if (!Util.directoryExist(evidTestToolDir))
						new File(evidTestToolDir).mkdirs();
					String simpleFilePdf  = new File(Reporter.nbEvidence).getName();
					try { // SE MUEVE EL ARCHIVO PDF A LA CARPETA RESPECTIVA
						Util.moveFile(Reporter.nbEvidence, evidTestToolDir + simpleFilePdf);
					}
					catch (IOException e) {
						e.printStackTrace();
					}
					Reporter.nbEvidence = evidTestToolDir + simpleFilePdf;
//-----------------------------------------------------------------------------------------------------------------------
					// ADICIONA LA CARPETA POR ESTADO A LA CARPETA DE BACKUP (PARA EL WORD)
					String nameFolderBackup = SettingsRun.getBackupEvidencesDir() + nbFolderbyEstado;
					if (!Util.directoryExist(nameFolderBackup))
						new File(nameFolderBackup).mkdirs();
					String simpleFileWord = new File(wordFilePath).getName();
					try { // MUEVE EL ARCHIVO WORD A LA CARPETA RESPECTIVA DE BACKUP
						Util.moveFile(wordFilePath, nameFolderBackup + simpleFileWord);
					}
					catch (IOException e) {
						e.printStackTrace();
					}
				}
//-----------------------------------------------------------------------------------------------------------------------
			}
		}
	}
//***********************************************************************************************************************
	/**
	 * Este método revisa si el tipo de evidencia corresponde a la clase [dav.library.core.EvidencePdfFile], para
	 * almacenar TODAS las imágenes recopiladas en el archivo de evidencias respectivo.<br>
	 * Cuando corresponde a [dav.library.core.EvidencePdfFileWithSteps] NO es requerido porque cada evidencia se va
	 * almacenando poco a poco.
	 *//*
	public static void saveEvidencesInFile() {
		// ADICIONA TODAS LAS EVIDENCIAS ALMACENADAS A UN ARCHIVO DE WORD
		if (Reporter.evidenceType instanceof dav.library.reporting.EvidencePdfFile)
			Reporter.addEvidences();
	}*/
//***********************************************************************************************************************
	/**
	 * Método que se lanza sólo si se trata de un lanzamiento por bloque, se detecta porque la lista de ejecución por
	 * bloque tiene información: [Reporter.listaExecutionXBloque != null].<br>
	 * Carga al reporte el estado final con el que queda la prueba.<br>
	 * Cuando la prueba es exitosa llama el método de carga de evidencias en la herramienta de gestión de pruebas.<br>
	 * El retorno es [false] si no se trata de un lanzamiento por bloque, [true] en caso contrario.
	 */
	public static boolean loadTestStatusFinalXBloque() {
		
		if (Reporter.listaExecutionXBloque == null)
			return false; // ESTE MÉTODO NO SE EJECUTA SI NO SE ESTÁ REALIZANDO UNA EJECUCIÓN X BLOQUE
		
		int iteration, totalExecs = Reporter.listaExecutionXBloque.size();
		if (totalExecs != 0) {
			Reporter.WRITE_HEADER = false; // PARA QUE LOS [write] NO TENGAN ENCABEZADO
			Reporter.write("\n******************** RESULTADOS LANZAMIENTOS ...\n");
		}
		for (int posLista = 0; posLista < totalExecs; posLista++) {
			iteration = Reporter.listaExecutionXBloque.get(posLista);
			boolean isCompleted = Reporter.listaIsExecBloqueCompleted.get(posLista);
			
			SettingsRun.loadIteration(iteration); // CARGA LA ITERACIÓN PAR CARGAR EL REPORTE HTML Y LA EVIDENCIA
			if (!isCompleted) {
				Status realStatus = Reporter.getStatusByLog(Reporter.MIC_NOT_COMPLETED);
				if (Reporter.test != null)
					Reporter.test.log(realStatus, "No se completó el lanzamiento");
				if (Reporter.testCopy != null)
					Reporter.testCopy.log(realStatus, "No se completó el lanzamiento");
			}
			
			if (Reporter.test.getStatus().equals(Status.PASS)) {
				Reporter.setTestStatus("PASSED"); // SETEA ESTADO FINAL DEL TEST - SALVA ARCHIVO DE EVIDENCIAS SI EXISTE
				Reporter.write(Util.rightComplete("*** EXEC " + iteration + " ", 15, '>') + " TEST PASSED");
				Reporter.uploadEvidenceToTestTool();
			} else if (Reporter.test.getStatus().equals(Status.FAIL)) {
				//Reporter.test.fail(new Throwable("FINAL STATUS [FAILED]")); // ADICIONA LA SECCIÓN [bug], PERO MUESTRA THROW EN REPORTE
				Reporter.setTestStatus("FAILED"); // SETEA ESTADO FINAL DEL TEST - SALVA ARCHIVO DE EVIDENCIAS SI EXISTE
				Reporter.write(Util.rightComplete("*** EXEC " + iteration + " ", 15, '>') + " TEST FAILED");
			} else { // SETEA ESTADO FINAL DEL TEST - SALVA ARCHIVO DE EVIDENCIAS SI EXISTE
				String status = Reporter.test.getStatus().toString();
				Reporter.setTestStatus(status);
				Reporter.write(Util.rightComplete("*** EXEC " + iteration + " ", 15, '>') + " " + status.toUpperCase());
			}
		}
		return true;
	}
//***********************************************************************************************************************
	/**
	 * Crea un zip que contendrá todas las evidencias almacenadas en la carpeta de la ejecución actual,
	 * incluye todo lo existente en dicha carpeta.
	 */
	private static void crearZipWithEvidences() {
		
		// RUTA COMPLETA DONDE ESTÁN LAS EVIDENCIAS DE LA ITERACIÓN ACTUAL
		String evidenceDir = Evidence.getNbEvidenceDirectory();
		if (!Util.directoryExist(evidenceDir))
			return; // SI NO EXISTE - HACE NADA PORQUE NO HAY EVIDENCIAS PARA EXTRAER
		File dirEvidences = new File(evidenceDir);
		if (dirEvidences.listFiles().length == 0)
			return; // NO HAY ARCHIVOS - HACE NADA PORQUE NO HAY EVIDENCIAS PARA EXTRAER
//-----------------------------------------------------------------------------------------------------------------------
		// ALISTA LA RUTA DEL FOLDER CON LAS EVIDENCIAS PARA ALM, SI NO EXISTE LO CREA:
		// CARPETA RESULT DIR / FOLDER_TESTTOOL_EVIDENCE / PASSED (CUANDO EL ESTADO ES PASSED) /
		String evidTestToolDir = SettingsRun.getFinalEvidencesDir();
		if (Reporter.test.getStatus().equals(Status.PASS))
			evidTestToolDir += "PASSED" + System.getProperty("file.separator");
		if (!Util.directoryExist(evidTestToolDir))
			new File(evidTestToolDir).mkdirs();
//-----------------------------------------------------------------------------------------------------------------------
		// ALISTA NOMBRE COMPLETO CON PATH, SIN EXTENSIÓN : DEL ARCHIVO QUE TENDRÁ LA EVIDENCIA FINAL
		int numIteration = SettingsRun.getCurrentIteration();
		String nbFile = Reporter.getSimpleNameEvidence(numIteration);
		Reporter.nbEvidence = evidTestToolDir + nbFile + ".zip";
		try {
			Util.makeZip(Reporter.nbEvidence, evidenceDir);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
//***********************************************************************************************************************
	/**
	 * Retorna el nombre del archivo donde queda almacenada la evidencia consolidada de la prueba (con ruta y extensión)
	 */
	public static String getNbEvidenceFile() {
		if (Reporter.evidenceType != null &&
			Reporter.evidenceType instanceof dav.library.reporting.EvidenceInStep) {
			return Reporter.evidenceType.getNbEvidenceFile();
		}
		return Reporter.nbEvidence;
	}
//***********************************************************************************************************************
	/**
	 * Retorna el nombre del archivo donde queda almacenada la evidencia consolidada de la prueba (con ruta y extensión)
	 * que corresponde a la ejecución [iteration]
	 */
	public static String getNbEvidenceFile(int iteration) {
		
		return mapEvidencesByIteration.get(iteration);
	}
//***********************************************************************************************************************
	/**
	 * Retorna el nombre de la entidad para hacer la carga de evidencias, posibles valores: INSTANCE / RUN / STEP
	 */
	private static String getEntityForUpload() {
		if (Reporter.evidenceType == null)
			return "INSTANCE";
		else
			return Reporter.evidenceType.getEntityForUpload();
	}
//***********************************************************************************************************************
	/**
	 * Inicializa el [SoftAssert] que manejará las fallas de las pruebas.
	 */
	public static void initializeSoftAssert() {
		Reporter.sAss = new SoftAssert();
	}
//***********************************************************************************************************************
	/**
	 * Recoge los [SoftAssert] que se presentaron durante las pruebas.
	 */
	public static void pickupSoftAssert() {
		try {
			Reporter.sAss.assertAll(); // PARA QUE RECOJA TODOS LOS ASSERT SOFT QUE SE HAYAN GENERADO
		}
		catch (AssertionError ae) {
			// [ae] NO HACE NADA PORQUE ES UN ASSERT SOFT, SÓLO PARA CONTROL
		}
	}
//***********************************************************************************************************************
	/**
	 * Carga la evidencia [nbFileEvid] en ALM desde que [Reporter.TEST_SET_ID] y [Reporter.TEST_CONF_ID] contengan
	 * información.<br>
	 * [Reporter.TEST_CONF_ID] puede contener más de 1 TestConfigurationId, pueden ir separados por "," o por decir # a #
	 */
	private static void uploadEvidenceToALM(String nbFileEvid) {
		
		if (Reporter.TEST_SET_ID == null || Reporter.TEST_SET_ID.isEmpty()) {
			Reporter.reportEvent(MIC_INFO, "[FALLA] Carga Evidencia ALM: No se cuenta con ID del TestSet");
			return;
		}
		if (Reporter.TEST_CONF_ID == null || Reporter.TEST_CONF_ID.isEmpty()) {
			Reporter.reportEvent(MIC_INFO, "[FALLA] Carga Evidencia ALM: No se cuenta con ID del TestConfiguration");
			return;
		}
//-----------------------------------------------------------------------------------------------------------------------
		// SE PUEDE HACER LA CARGA EN ALM
		String resultado, msgReport, msgIterat; 
		
		// INICIALIZA LOS DATOS DE FECHA DE EJECUCIÓN Y PLANEADA DE EJECUCIÓN
		Alm.planSchedulingDate = null;
		Alm.execDate = null;
		
		List<Integer> listTestSet = Util.getListaDatos(Reporter.TEST_SET_ID, ",");
		List<Integer> listTestConfig = Util.getListaDatos(Reporter.TEST_CONF_ID, ",");
		for (int posListaTS = 0; posListaTS < listTestSet.size(); posListaTS++) {
			String idTestSet = String.valueOf(listTestSet.get(posListaTS));
			msgIterat = ""; // VALOR POR DEFECTO - SE ASUME QUE NO HAY MENSAJE EN [iterations]
			for (int posListaTC = 0; posListaTC < listTestConfig.size(); posListaTC++) {
				String idTestConf = String.valueOf(listTestConfig.get(posListaTC));
				msgReport = "Carga Evidencia ALM: TestInstance [" + idTestSet + " - " + idTestConf + "] ";
				try {
//-----------------------------------------------------------------------------------------------------------------------
					if (msgIterat.isEmpty()) { // NO SE HA PASADO CORRECTAMENTE LA 1RA PRUEBA CON EVIDENCIA DEL TESTSET
						
						if (Reporter.getEntityForUpload().equals("INSTANCE"))
								resultado = Alm.setTestStatus(AlmConstants.TEST_PASSED, idTestSet, idTestConf,
									nbFileEvid, null, true);
						
						else if (Reporter.getEntityForUpload().equals("STEP"))
							resultado = Alm.loadAttachmentsToStepsLastRun(Reporter.evidenceType.getEvidencesBySteps());
						
						else { // (Reporter.getEntityForUpload().equals("RUN"))
							resultado = Alm.setTestStatusIterations(AlmConstants.TEST_PASSED, idTestSet, idTestConf,
								null, true); // [null] PARA QUE NO PONGA NADA EN EL CAMPO ITERATIONS
		                                     // [true] PARA QUE CREE OTRO RUN SI LA PRUEBA YA ESTÁ PASSED
							if (resultado == null) // HIZO LA CREACIÓN DE LA ENTIDAD
								resultado = Alm.loadAttachmentToLastRun(nbFileEvid, null); // [null] PARA QUE NO CAMBIE EL NOMBRE DEL ARCHIVO DE EVIDENCIA
						}
						if (resultado == null)
							msgIterat = "Evidencia" + idTestConf; // SE PASÓ LA PRUEBA SUBIENDO EVIDENCIA - OK
					}
					else // YA SE PASÓ LA PRIMERA PRUEBA CON EVIDENCIA, LAS OTRAS SE PASAN REFERENCIANDO LA EVIDENCIA
						resultado = Alm.setTestStatusIterations(AlmConstants.TEST_PASSED, idTestSet, idTestConf,
							msgIterat, true);
//-----------------------------------------------------------------------------------------------------------------------
					if (resultado == null)
						Reporter.reportEvent(MIC_INFO, "[OK] " + msgReport);
					else
						Reporter.reportEvent(MIC_INFO, "[FALLA] " + msgReport +  " : " + resultado);
//-----------------------------------------------------------------------------------------------------------------------
				}
				catch (Exception e) {
					Reporter.reportEvent(MIC_INFO, "[FALLA] " + msgReport +  " : " + e.getMessage());
				}
			} // CIERRA EL FOR QUE RECORRE LOS ID DE LOS TEST CONFGURATION
		} // CIERRA EL FOR QUE RECORRE LOS ID DE LOS TEST SET
	}
//***********************************************************************************************************************
	private static ExtentReports extentCopyReport;
	private static ExtentTest testCopy;
	private static Map<Integer, ExtentTest> dicRegTestCopy = new HashMap<Integer, ExtentTest>();
	private static int copy = 1;
	
	public static String createCopyHtmlReport() {
		
		String pathReport = SettingsRun.RESULT_DIR + File.separator + copy + "FinalReport_Copy.html";
		Reporter.extentCopyReport = ExtentReporterNG.createReportObject(pathReport);
		Reporter.copy++;
		return pathReport;
	}
//***********************************************************************************************************************
}