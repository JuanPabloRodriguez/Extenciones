package library.reporting;

import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.imageio.ImageIO;

import org.apache.commons.io.FileUtils;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.rendering.ImageType;
import org.apache.pdfbox.rendering.PDFRenderer;
import org.apache.pdfbox.tools.imageio.ImageIOUtil;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebElement;
import org.openqa.selenium.*;

import library.common.Util;
import library.common.VirtualKeyBoard;
import library.core.BaseMobileApp;
import library.core.BasePageWeb;
import library.core.BaseWindowsApp;
import library.core.BaseDesktopApplication;
import library.settings.SettingsRun;

public class Evidence {

	public static boolean TITLE_WITH_TIME = false;
	public static String NB_CARPETA = ""; // LLEVA VALOR SI LA EVIDENCIA DEBE IR EN ESTA CARPETA
	public static String EVIDIR_PREF = ""; // LLEVA VALOR SI A LA CARPETA DE LAS EVIDENCIAS SE LE DEBE PONER ESTE PREFIJO
	public static int TAM_PREFIJO = 16; // yyyymmddHHmmss# (+ EL ESPACIO)
	private static boolean doEvidence = false; // POR DEFECTO NO TOMA EVIDENCIA
	private static String evidenceTempDir = null;
	private static String LAST_PREFIJO = "";
	private static int CONSECUTIVO = 0;
	private static VirtualKeyBoard vkb;
//***********************************************************************************************************************
	/**
	 * Garantiza que se hará toma de evidencias sin setear el tipo de evidencia, en este caso asume que es almacenamiento
	 * de la imagen.<br>
	 * Se sugiere hacerlo antes de dar inicio a cada @test
	 *//* public static void initializeTestEvidence() { Evidence.initializeTestEvidence(null); } */
//***********************************************************************************************************************

	/**
	 * Garantiza que se hará toma de evidencias, sin esto no hace toma de evidencias.
	 */
	public static void activate() {

		Evidence.doEvidence = true;
	}
//***********************************************************************************************************************
	/**
	 * Indica que NO hará toma de evidencias.
	 */
	public static void inactivate() {

		Evidence.doEvidence = false;
	}
//***********************************************************************************************************************
	/**
	 * Salva la evidencia [nbEvidence] desde un DISPOSITIVO MOBILE.
	 * @return Nombre del archivo (con path y extensión) de la evidencia.
	 */
	public static String save(String nbEvidence, BaseMobileApp app) {

		if (!Evidence.doEvidence)
			return ""; // SI NO SE TOMAN EVIDENCIAS SALE DEL MÉTODO
		// SE TOMA LA EVIDENCIA:
		String totalNbEvidence = armarNombreEvidencia(nbEvidence);
		app.saveScreenshot(totalNbEvidence);
		return totalNbEvidence;
	}
//***********************************************************************************************************************
	/**
	 * Salva la evidencia [nbEvidence] desde un DISPOSITIVO MOBILE, si el screen del dispositivo permite hacer swipe hace
	 * el guardado de todas las pantallas que encuentra.<br>
	 * Para poder hacer un swipe correcto es requerido contar con la cooordenada [Y] donde termina el header, por defecto
	 * su valor es cero, pero en algún punto se debió cargar, si la coordenada es 0 lo hace desde el 25% de la
	 * pantalla.<br>
	 * <b>OJO:</b> Si se hizo swipe, la aplicación queda al final del screen, por ende tenga cuidado si requiere un
	 * elemento que NO está visible por haber realizado el swipe.
	 */
	public static void saveAllScreens(String nbEvidence, BaseMobileApp app) throws Exception {

		if (!Evidence.doEvidence)
			return; // SI NO SE TOMAN EVIDENCIAS SALE DEL MÉTODO
		// SE TOMA LA EVIDENCIA:
		String reemplazo, totalNbEvidence, nbEvidenceTemp = " (ScrX) " + nbEvidence;
		String totalNbEvidenceTemp = armarNombreEvidencia(nbEvidenceTemp);
		int numScreen = 1;
		boolean hizoSwipe;
		app.swipeToStart();
		do {
			reemplazo = " (" + Util.leftComplete(String.valueOf(numScreen), 2, '0') + ") ";
			totalNbEvidence = totalNbEvidenceTemp.replace(" (ScrX) ", reemplazo);
			app.saveScreenshot(totalNbEvidence);
			hizoSwipe = app.swipeDown();
			if (hizoSwipe)
				numScreen++;
		} while (hizoSwipe);
		// SE COMENTAREA PARA DEJAR AL FINAL DEL SECREEN if (numScreen > 1) app.swipeToStart(); // DEVUELVE EL SCREEN AL
		// INICIO
	}
//***********************************************************************************************************************
	/**
	 * Salva una evidencia [nbEvidence] desde una APLICACIÓN WEB de forma temporal, es decir la deja almacenada en la
	 * carpeta de temporales.
	 * @return Nombre del archivo (con path y extensión) de la evidencia.
	 */
	public static String saveTemp(String nbEvidence, BasePageWeb page) {

		if (!Evidence.doEvidence)
			return ""; // SI NO SE TOMAN EVIDENCIAS SALE DEL MÉTODO
		// SE TOMA LA EVIDENCIA:
		String totalNbEvidence = armarNombreEvidenciaTemp(nbEvidence);
		page.saveScreenshot(totalNbEvidence);
		return totalNbEvidence;
	}
//***********************************************************************************************************************
	/**
	 * Salva una evidencia [nbEvidence] desde una APLICACIÓN MOBILE de forma temporal, es decir la deja almacenada en la
	 * carpeta de temporales.
	 * @return Nombre del archivo (con path y extensión) de la evidencia.
	 */
	public static String saveTemp(String nbEvidence, BaseMobileApp app) {

		if (!Evidence.doEvidence)
			return ""; // SI NO SE TOMAN EVIDENCIAS SALE DEL MÉTODO
		// SE TOMA LA EVIDENCIA:
		String totalNbEvidence = armarNombreEvidenciaTemp(nbEvidence);
		app.saveScreenshot(totalNbEvidence);
		return totalNbEvidence;
	}
//***********************************************************************************************************************
	/**
	 * Salva la evidencia [nbEvidence] de lo que se encuentra en primer plano en la pantalla de forma temporal, es decir
	 * la deja almacenada en la carpeta de temporales.
	 * 
	 * @return Nombre del archivo (con path y extensión) de la evidencia.
	 * 
	 * @author DAARUBIO
	 * 
	 */
	public static String saveDesktopTemp(String nbEvidence) {

		if (!Evidence.doEvidence)
			return ""; // SI NO SE TOMAN EVIDENCIAS SALE DEL MÉTODO
		// SE TOMA LA EVIDENCIA:
		String totalNbEvidence = armarNombreEvidenciaTemp(nbEvidence);
		Util.printScreen(totalNbEvidence);
		return totalNbEvidence;
	}
//***********************************************************************************************************************	
	/**
	 * Salva la evidencia [nbEvidence] desde una PÁGINA WEB de forma temporal, es decir la deja almacenada en la carpeta
	 * de temporales. <br>
	 * 
	 * <br>
	 * Nota: Si vienen WebElement en [highlightElements], esos elementos son HigLight en la imagen capturada. <br>
	 * 
	 * @return Nombre del archivo (con path y extensión) de la evidencia.
	 * 
	 * @author DAARUBIO
	 */
	public static String saveTemp(String nbEvidence, BasePageWeb page, WebElement... highlightElements) {

		if (!Evidence.doEvidence)
			return ""; // SI NO SE TOMAN EVIDENCIAS SALE DEL MÉTODO
		// SE TOMA LA EVIDENCIA:
		String totalNbEvidence = armarNombreEvidenciaTemp(nbEvidence);
		if (highlightElements.length != 0)
			page.highlightElements(highlightElements);
		page.saveScreenshot(totalNbEvidence); // TOMA LA EVIDENCIA CON O SIN HIGHLIGHTS
		if (highlightElements.length != 0)
			page.unhighlightElements(highlightElements);
		return totalNbEvidence;
	}
//***********************************************************************************************************************
	/**
	 * Salva la evidencia [nbEvidence] desde una PÁGINA WEB.<br>
	 * Si vienen WebElement en [highlightElements], esos elementos son HigLight en la imagen capturada.
	 * @return Nombre del archivo (con path y extensión) de la evidencia.
	 */
	public static String save(String nbEvidence, BasePageWeb page, WebElement... highlightElements) {

		if (!Evidence.doEvidence)
			return ""; // SI NO SE TOMAN EVIDENCIAS SALE DEL MÉTODO
		// SE TOMA LA EVIDENCIA:
		String totalNbEvidence = armarNombreEvidencia(nbEvidence);
		if (highlightElements.length != 0)
			page.highlightElements(highlightElements);
		page.saveScreenshot(totalNbEvidence); // TOMA LA EVIDENCIA CON O SIN HIGHLIGHTS
		if (highlightElements.length != 0)
			page.unhighlightElements(highlightElements);
		return totalNbEvidence;
	}
//***********************************************************************************************************************
	/**
	 * Salva la evidencia [nbEvidence] de lo que se encuentra en primer plano en la pantalla.
	 * @return Nombre del archivo (con path y extensión) de la evidencia.
	 */
	public static String saveDesktop(String nbEvidence) {

		if (!Evidence.doEvidence)
			return ""; // SI NO SE TOMAN EVIDENCIAS SALE DEL MÉTODO
		// SE TOMA LA EVIDENCIA:
		String totalNbEvidence = armarNombreEvidencia(nbEvidence);
		Util.printScreen(totalNbEvidence);
		return totalNbEvidence;
	}
//***********************************************************************************************************************
	/**
	 * Salva la evidencia [nbEvidence] de lo que se encuentra en primer plano en la pantalla.
	 * @return Nombre del archivo (con path y extensión) de la evidencia.
	 */
	public static String saveObjectDesktop(String nbEvidence, WebElement element) {

		if (!Evidence.doEvidence)
			return ""; // SI NO SE TOMAN EVIDENCIAS SALE DEL MÉTODO
		// SE TOMA LA EVIDENCIA:
		String totalNbEvidence = armarNombreEvidencia(nbEvidence);
		printObjectScreen(totalNbEvidence, element);
		return totalNbEvidence;
	}
//***********************************************************************************************************************
	/**
	 * Salva la evidencia [nbEvidence] de una BasePageWeb la cual está presentando un diálogo de ALERT.<br>
	 * Se requiere contar con el título de la página, se recomienda extraerlo antes de la muestra del ALERT, de lo
	 * contrario, se presentará la Excepción [UnhandledAlertException: unexpected alert open]
	 * @return Nombre del archivo (con path y extensión) de la evidencia.
	 */
	public static String saveWithDialog(String nbEvidence, BasePageWeb page, String pageTitle) throws Exception {

		if (!Evidence.doEvidence)
			return ""; // SI NO SE TOMAN EVIDENCIAS SALE DEL MÉTODO
		// ARMA EL NOMBRE DE LA EVIDENCIA
		String totalNbEvidence = armarNombreEvidencia(nbEvidence);
//-----------------------------------------------------------------------------------------------------------------------
		// ARMA INSTANCIA DEL DESKTOP A TRAVÉS DE [BaseWindowsApp]
		BaseDesktopApplication desktop = new BaseDesktopApplication("Root");
		// ARMA EL NOMBRE DEL ELEMENTO PARA BUSCARLO POR WIN APP DRIVER
		String name = pageTitle + " - Google Chrome"; // VALOR POR DEFECTO
		if (page.getNavegador().equals(BasePageWeb.EDGE))
			name = pageTitle + " - Microsoft Edge";
		else if (page.getNavegador().equals(BasePageWeb.EXPLORER))
			name = pageTitle + " - Internet Explorer";
		else if (page.getNavegador().equals(BasePageWeb.FIREFOX))
			name = pageTitle + " - Firefox"; // PENDIENTE CONFIMAR
		List<RemoteWebElement> elementos = desktop.elementsByName(name);
		if (elementos.size() > 0) {
			if (vkb == null) vkb = new VirtualKeyBoard(); // CREA INSTANCIA PARA EL TECLADO
			vkb.sendKeysCombination("WINDOWS+D"); // MINIMIZA TODAS LAS PANTALLAS DEL DESKTOP
			RemoteWebElement element = elementos.get(elementos.size() - 1); // TOMA EL ÚLTIMO
			int ancho, numTabs = 1;
			do { // GARANTIZA QUE PONGA EN PRIMER PLANO LA PANTALLA CON EL ALERT
				vkb.altTab(numTabs++);
				Util.wait(1);
				ancho = desktop.getWidthInDesktop(element);
			} while (ancho == 0);
		}
		// TOMA LA EVIDENCIA
		Util.printScreen(totalNbEvidence);
		return totalNbEvidence;
	}
//***********************************************************************************************************************
	/**
	 * Salva la evidencia [nbEvidence] desde una APLICACIÓN WINDOWS.
	 * @return Nombre del archivo (con path y extensión) de la evidencia.
	 */
	public static String save(String nbEvidence, BaseDesktopApplication app) {

		if (!Evidence.doEvidence)
			return ""; // SI NO SE TOMAN EVIDENCIAS SALE DEL MÉTODO
		// SE TOMA LA EVIDENCIA:
		String totalNbEvidence = armarNombreEvidencia(nbEvidence);
		app.saveScreenshot(totalNbEvidence);
		return totalNbEvidence;
	}
//***********************************************************************************************************************
	/**
	 * Captura de un elemento especifico en la pantalla para la depuración, se usa Robot para hacer la captura de
	 * pantalla. No se podrá usar en una máquina remota y no podrá usarse en segundo plano. Debe mantener el objeto sobre
	 * el que se desea el printScreen encima de todas las demás ventanas.
	 * 
	 * @param nbPathFile : Nombre del archivo donde se guardará, con ruta y extensión (debe ser de imagen).
	 * @param element : Nombre del archivo donde se guardará, con ruta y extensión (debe ser de imagen).
	 * @author lmbarajas (Lesly Barajas)
	 */
	public static void printObjectScreen(String nbPathFile, WebElement element) {

		try {
			BufferedImage image = new Robot()
				.createScreenCapture(new Rectangle(Toolkit.getDefaultToolkit().getScreenSize()));
			ImageIO.write(image, "png", new File(nbPathFile));
			// Obtener la ubicación del elemento en la página
			Point point = element.getLocation();
			// Obtener ancho y alto del elemento
			int eleWidth = element.getSize().getWidth();
			int eleHeight = element.getSize().getHeight();
			// Recorta la captura de pantalla de toda la página para obtener solo la captura de pantalla del elemento
			BufferedImage eleScreenshot = image.getSubimage(point.getX(), point.getY(), eleWidth, eleHeight);
			ImageIO.write(eleScreenshot, "png", new File(nbPathFile));
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
//***********************************************************************************************************************
	/**
	 * Salva una evidencia [nbEvidence] desde una APLICACIÓN WINDOWS de forma temporal, es decir la deja almacenada en la
	 * carpeta en temporales.
	 * @return Nombre del archivo (con path y extensión) de la evidencia.
	 */
	public static String saveTemp(String nbEvidence, BaseDesktopApplication app) {

		if (!Evidence.doEvidence)
			return ""; // SI NO SE TOMAN EVIDENCIAS SALE DEL MÉTODO
		// SE TOMA LA EVIDENCIA:
		String totalNbEvidence = armarNombreEvidenciaTemp(nbEvidence);
		app.saveScreenshot(totalNbEvidence);
		return totalNbEvidence;
	}
//***********************************************************************************************************************
	/**
	 * Salva la evidencia [nbEvidence] desde una APLICACIÓN WINDOWS.
	 * @return Nombre del archivo (con path y extensión) de la evidencia.
	 */
	public static String save(String nbEvidence, BaseWindowsApp app) {

		if (!Evidence.doEvidence)
			return ""; // SI NO SE TOMAN EVIDENCIAS SALE DEL MÉTODO
		// SE TOMA LA EVIDENCIA:
		String totalNbEvidence = armarNombreEvidencia(nbEvidence);
		app.saveScreenshot(totalNbEvidence);
		return totalNbEvidence;
	}
//***********************************************************************************************************************
	/**
	 * Salva una evidencia [nbEvidence] desde una APLICACIÓN WINDOWS de forma temporal, es decir la deja almacenada en la
	 * carpeta e temporales.
	 * @return Nombre del archivo (con path y extensión) de la evidencia.
	 */
	public static String saveTemp(String nbEvidence, BaseWindowsApp app) {

		if (!Evidence.doEvidence)
			return ""; // SI NO SE TOMAN EVIDENCIAS SALE DEL MÉTODO
		// SE TOMA LA EVIDENCIA:
		String totalNbEvidence = armarNombreEvidenciaTemp(nbEvidence);
		app.saveScreenshot(totalNbEvidence);
		return totalNbEvidence;
	}
//***********************************************************************************************************************
	/**
	 * Salva la evidencia [nbEvidence] de una PÁGINA WEB que NO cuenta con HEADER ni con FOOTER.
	 * @return Nombre del archivo (con path y extensión) de la evidencia.
	 */
	public static String saveFullPage(String nbEvidence, BasePageWeb page) {

		if (!Evidence.doEvidence)
			return ""; // SI NO SE TOMAN EVIDENCIAS SALE DEL MÉTODO
		if (page.isWebContextApp())
			throw new IllegalArgumentException(
				"EvidenceERROR -- El contexto web en una APP no puede usar el método [saveFullPage]");
		// SE TOMA LA EVIDENCIA:
		String totalNbEvidence = armarNombreEvidencia(nbEvidence);
		WebElement elementNull = null;
		page.saveFullScreenshot(totalNbEvidence, elementNull, elementNull);
		return totalNbEvidence;
	}
//***********************************************************************************************************************
	/**
	 * Salva la evidencia [nbEvidence] de una PÁGINA WEB que NO cuenta con HEADER ni con FOOTER, de forma temporal, es
	 * decir la deja almacenada en la carpeta e temporales.
	 * @return Nombre del archivo (con path y extensión) de la evidencia.
	 * @author DAARUBIO
	 */
	public static String saveFullPageTemp(String nbEvidence, BasePageWeb page) {

		if (!Evidence.doEvidence)
			return ""; // SI NO SE TOMAN EVIDENCIAS SALE DEL MÉTODO
		if (page.isWebContextApp())
			throw new IllegalArgumentException(
				"EvidenceERROR -- El contexto web en una APP no puede usar el método [saveFullPage]");
		// SE TOMA LA EVIDENCIA:
		String totalNbEvidence = armarNombreEvidenciaTemp(nbEvidence);
		WebElement elementNull = null;
		page.saveFullScreenshot(totalNbEvidence, elementNull, elementNull);
		return totalNbEvidence;
	}
//***********************************************************************************************************************
	/**
	 * Salva la evidencia [nbEvidence] de una PÁGINA WEB que SÍ cuenta con HEADER el cual aparece después del primer
	 * scroll y NO cuenta con FOOTER.<br>
	 * Requiere el locator del HEADER [locatorHeader]
	 * @return Nombre del archivo (con path y extensión) de la evidencia.
	 */
	public static String saveFullPage(String nbEvidence, BasePageWeb page, By locatorHeader) {

		if (!Evidence.doEvidence)
			return ""; // SI NO SE TOMAN EVIDENCIAS SALE DEL MÉTODO
		if (page.isWebContextApp())
			throw new IllegalArgumentException(
				"EvidenceERROR -- El contexto web en una APP no puede usar el método [saveFullPage]");
		// SE TOMA LA EVIDENCIA:
		String totalNbEvidence = armarNombreEvidencia(nbEvidence);
		page.saveFullScreenshot(totalNbEvidence, locatorHeader, null);
		return totalNbEvidence;
	}
//***********************************************************************************************************************
	/**
	 * Salva la evidencia [nbEvidence] de una PÁGINA WEB que SÍ cuenta con HEADER el cual aparece después del primer
	 * scroll y también cuenta con FOOTER.<br>
	 * Requiere el locator del HEADER [locatorHeader] y el WebElement del FOOTER.
	 * @return Nombre del archivo (con path y extensión) de la evidencia.
	 */
	public static String saveFullPage(String nbEvidence, BasePageWeb page, By locatorHeader, WebElement footer) {

		if (!Evidence.doEvidence)
			return ""; // SI NO SE TOMAN EVIDENCIAS SALE DEL MÉTODO
		if (page.isWebContextApp())
			throw new IllegalArgumentException(
				"EvidenceERROR -- El contexto web en una APP no puede usar el método [saveFullPage]");
		// SE TOMA LA EVIDENCIA:
		String totalNbEvidence = armarNombreEvidencia(nbEvidence);
		page.saveFullScreenshot(totalNbEvidence, locatorHeader, footer);
		return totalNbEvidence;
	}
//***********************************************************************************************************************
	/**
	 * Salva la evidencia [nbEvidence] de una PÁGINA WEB que Sí cuenta con HEADER y con FOOTER.<br>
	 * Requiere el WebElement del HEADER y del FOOTER.
	 * @return Nombre del archivo (con path y extensión) de la evidencia.
	 */
	public static String saveFullPage(String nbEvidence, BasePageWeb page, WebElement header, WebElement footer) {

		if (!Evidence.doEvidence)
			return ""; // SI NO SE TOMAN EVIDENCIAS SALE DEL MÉTODO
		if (page.isWebContextApp())
			throw new IllegalArgumentException(
				"EvidenceERROR -- El contexto web en una APP no puede usar el método [saveFullPage]");
		// SE TOMA LA EVIDENCIA:
		String totalNbEvidence = armarNombreEvidencia(nbEvidence);
		page.saveFullScreenshot(totalNbEvidence, header, footer);
		return totalNbEvidence;
	}
//***********************************************************************************************************************
	/**
	 * Salva la evidencia [nbEvidence] de una PÁGINA WEB, en diferentes imágenes dando los scroll requeridos. Cada scroll
	 * es una imagen.<br>
	 * <b>Se usa para las pantallas del contexto web de una APP en un dispositivo móvil.</b>
	 * @return Un arreglo con las evidencias almacenadas (con path y extensión)
	 */
	public static String[] saveAllScreens(String nbEvidence, BasePageWeb page) {

		if (!Evidence.doEvidence)
			return null; // SI NO SE TOMAN EVIDENCIAS SALE DEL MÉTODO
		// SE TOMA LA EVIDENCIA:
		String totalNbEvidence = armarNombreEvidencia("(ScrX) " + nbEvidence);
		return page.saveFullScreenshot(totalNbEvidence);
	}
//***********************************************************************************************************************
	/**
	 * Salva la evidencia [nbEvidence] de una PÁGINA WEB, haciendo uso del AV PAG sobre el [element]. Cada avance de
	 * página es una imagen.
	 * @return Un arreglo con las evidencias almacenadas (con path y extensión)
	 */
	public static String[] saveFullElementWithAvPage(String nbEvidence, BasePageWeb page, WebElement element) {
		
		if (!Evidence.doEvidence)
			return null; // SI NO SE TOMAN EVIDENCIAS SALE DEL MÉTODO
		// SE TOMA LA EVIDENCIA:
		String totalNbEvidence = armarNombreEvidencia("(ScrX) " + nbEvidence);
		return page.saveFullElementWithAvPage(element, totalNbEvidence);
	}
//***********************************************************************************************************************
	/**
	 * Salva la evidencia del [element], si el elemento tiene scroll, las evidencias se juntan.<br>
	 * Este método requiere que el driver del [page] contenga el [element].<br>
	 * En ocasiones el frame cuando salva la imagen incluye el scroll y en la evidencia final queda ese corte de los
	 * scroll, en esos casos se debe indicar si tiene scroll a lo alto [conScrollHeight] o a lo ancho [conScrollWidth].
	 */
	public static String saveFullElement(String nbEvidence, BasePageWeb page, WebElement element,
		boolean conScrollHeight, boolean conScrollWidth) {

		if (!Evidence.doEvidence)
			return ""; // SI NO SE TOMAN EVIDENCIAS SALE DEL MÉTODO
		String totalNbEvidence = armarNombreEvidencia(nbEvidence);
		try {
			page.saveFullScreenshotElement(totalNbEvidence, element, conScrollHeight, conScrollWidth);
		}
		catch (IOException e) {
			e.printStackTrace();
		}
		return totalNbEvidence;
	}
//***********************************************************************************************************************
	/**
	 * Salva la evidencia del [element]<br>
	 * Este método requiere que el driver del [page] contenga el [element].<br>
	 * Si vienen WebElement en [highlightElements], esos elementos son HigLight en la imagen capturada.
	 */
	public static String saveElement(String nbEvidence, BasePageWeb page, WebElement element,
		WebElement... highlightElements) {

		if (!Evidence.doEvidence)
			return ""; // SI NO SE TOMAN EVIDENCIAS SALE DEL MÉTODO
		String totalNbEvidence = armarNombreEvidencia(nbEvidence);
		try {
			if (highlightElements.length != 0)
				page.highlightElements(highlightElements);
			page.saveFullScreenshotElement(totalNbEvidence, element, false, false); // TOMA LA EVIDENCIA CON O SIN
																					// HIGHLIGHTS
			if (highlightElements.length != 0)
				page.unhighlightElements(highlightElements);
		}
		catch (IOException e) {
			e.printStackTrace();
		}
		return totalNbEvidence;
	}
//***********************************************************************************************************************
	/**
	 * Salva la evidencia del [element]<br>
	 * Este método requiere que el driver del [page] contenga el [element].<br>
	 * Si vienen WebElement en [highlightElements], esos elementos son HigLight en la imagen capturada.
	 */
	public static String saveOnlyElement(String nbEvidence, BasePageWeb page, WebElement element) {

		if (!Evidence.doEvidence)
			return ""; // SI NO SE TOMAN EVIDENCIAS SALE DEL MÉTODO
		String totalNbEvidence = armarNombreEvidencia(nbEvidence);
		page.saveScreenshot(totalNbEvidence, element);
		return totalNbEvidence;
	}
	// ***********************************************************************************************************************
	/**
	 * Salva la evidencia del primer frame, si el frame tiene scroll, las evidencias se juntan.<br>
	 * Este método requiere que el driver del [page] contenga el [element].<br>
	 * Este método deja ubicado el driver del [page] en el frame por Default primero.<br>
	 * En ocasiones el frame cuando salva la imagen incluye el scroll y en la evidencia final queda ese corte de los
	 * scroll, en esos casos se debe indicar si tiene scroll a lo alto [conScrollHeight] o a lo ancho [conScrollWidth].
	 */
	public static String saveFirstFrame(String nbEvidence, BasePageWeb page, boolean conScrollHeight,
		boolean conScrollWidth) throws Exception {

		if (!Evidence.doEvidence)
			return ""; // SI NO SE TOMAN EVIDENCIAS SALE DEL MÉTODO
		page.changeToDefaultFrame();
		WebElement firstFrame = page.getFirstFrame();
		return Evidence.saveFullFrame(nbEvidence, page, firstFrame, conScrollHeight, conScrollWidth);
	}
//***********************************************************************************************************************
	/**
	 * Salva la evidencia del [frame], si el frame tiene scroll, las evidencias se juntas<br>
	 * Este método requiere que el driver del [page] contenga el [frame].<br>
	 * En ocasiones el frame cuando salva la imagen incluye el scroll y en la evidencia final queda ese corte de los
	 * scroll, en esos casos se debe indicar si tiene scroll a lo alto [conScrollHeight] o a lo ancho [conScrollWidth].
	 */
	public static String saveFullFrame(String nbEvidence, BasePageWeb page, WebElement frame, boolean conScrollHeight,
		boolean conScrollWidth) throws Exception {

		if (!Evidence.doEvidence)
			return ""; // SI NO SE TOMAN EVIDENCIAS SALE DEL MÉTODO
		// SE TOMA LA EVIDENCIA:
		String totalNbEvidence = armarNombreEvidencia(nbEvidence);
		page.saveFullScreenshotElement(totalNbEvidence, frame, conScrollHeight, conScrollWidth);
		return totalNbEvidence;
	}
//***********************************************************************************************************************
	/**
	 * Toma el archivo PDF [nbPdfFilePath] y lo transforma en imágenes (cada una de sus páginas es una imagen), y estas
	 * son adicionadas como evidencia.
	 */
	public static void savePdfFileAsImage(String nbPdfFilePath, String nbEvidence) throws Exception {

		if (!Evidence.doEvidence)
			return; // SI NO SE TOMAN EVIDENCIAS SALE DEL MÉTODO
		PDDocument document = PDDocument.load(new File(nbPdfFilePath));
		PDFRenderer pdfRenderer = new PDFRenderer(document);
		String nbEvidenceFin;
		String totalNbEvidenceTemp = armarNombreEvidencia(nbEvidence + " Page(XX)");
		for (int page = 0; page < document.getNumberOfPages(); ++page) {
			nbEvidenceFin = totalNbEvidenceTemp.replace(" Page(XX)", " Page" + (page + 1));
			BufferedImage bim = pdfRenderer.renderImageWithDPI(page, 300, ImageType.RGB);
			ImageIOUtil.writeImage(bim, nbEvidenceFin, 300);
		}
		document.close();
	}
//***********************************************************************************************************************
	/**
	 * Salva como evidencia el archivo [nbFilePath].
	 */
	public static String saveFile(String nbFilePath) throws Exception {

		if (!Evidence.doEvidence)
			return ""; // SI NO SE TOMAN EVIDENCIAS SALE DEL MÉTODO
		// SE MUEVE EL ARCHIVO AL DIRECTORIO DE EVIDENCIAS PONIÉNDOLE EL PREFIJO [yyyymmdd-HHmmss]:
		File file = new File(nbFilePath);
		String nbFileEvidence = getStartEvidenceName() + file.getName(); // directorioEvidencia\yyyymmdd-HHmmss nbFile
		Util.moveFile(nbFilePath, nbFileEvidence);
		return nbFileEvidence;
	}
//***********************************************************************************************************************
	/**
	 * Salva como evidencia el archivo [nbFilePath].
	 */
	public static String saveFile(String nbFilePath, String newNameEvidence) throws Exception {

		if (!Evidence.doEvidence)
			return ""; // SI NO SE TOMAN EVIDENCIAS SALE DEL MÉTODO
		// SE MUEVE EL ARCHIVO AL DIRECTORIO DE EVIDENCIAS PONIÉNDOLE EL PREFIJO [yyyymmdd-HHmmss]:
		String nbFileEvidence = getStartEvidenceName() + newNameEvidence + "."
			+ Util.fileGetExtension(nbFilePath).toLowerCase(); // directorioEvidencia\yyyymmdd-HHmmss nbFile
		Util.moveFile(nbFilePath, nbFileEvidence);
		return nbFileEvidence;
	}
//***********************************************************************************************************************
	/**
	 * Borra la carpeta de evidencias correspondientes a la iteración actual.
	 */
	public static void deleteEvidences() throws IOException {

		if (!Evidence.doEvidence)
			return; // SI NO SE TOMAN EVIDENCIAS SALE DEL MÉTODO
		String evidenceDir = getNbEvidenceDirectory();
		File fileEv = new File(evidenceDir);
		if (fileEv.exists() && fileEv.isDirectory())
			FileUtils.deleteDirectory(fileEv); // BORRA EL DIRECTORIO DE EVIDENCIAS
	}
//***********************************************************************************************************************
	/**
	 * Limpia la carpeta de evidencias temporales.
	 * @param mantener - False : elimina el contenido de la carpeta temporal.<br>
	 * - True : Mueve el contenido de la carpeta temporal a las evidencias de la prueba actual.
	 */
	public static void cleanTempEvidence(boolean mantener) throws Exception {

		if (!Evidence.doEvidence)
			return; // SI NO SE TOMAN EVIDENCIAS SALE DEL MÉTODO
		Evidence.cleanTempEvidence(mantener, getNbEvidenceDirectory()); // CARPETA CON EVIDENCIAS DE LA PRUEBA
	}
//***********************************************************************************************************************
	/**
	 * Limpia la carpeta de evidencias temporales, pero deja las evidencias en [newEvidenceDir] si así se quiere.<br>
	 * En caso de enviar false en [mantener] = Sólo borra la carpeta temporal con las evidencias y no almacena esas
	 * evidencias en ninguna carpeta.
	 * @param mantener <br>
	 * - False : elimina el contenido de la carpeta temporal.<br>
	 * - True : Mueve el contenido de la carpeta temporal a la CARPETA [newEvidenceDir]
	 */
	public static void cleanTempEvidence(boolean mantener, String newEvidenceDir) throws Exception {

		if (!Evidence.doEvidence)
			return; // SI NO SE TOMAN EVIDENCIAS SALE DEL MÉTODO
		if (mantener) // SI SE DEBEN MANTENER LAS EVIDENCIAS TEMPORALES, SE MUEVEN A [newEvidenceDir]:
			Util.moveAllFiles(evidenceTempDir, newEvidenceDir);
		if (evidenceTempDir != null)
			FileUtils.deleteDirectory(new File(evidenceTempDir)); // BORRA EL DIRECTORIO TEMPORAL
	}
//***********************************************************************************************************************
	/**
	 * Copia el contenido de la carpeta de evidencias temporales, en las evidencias de la prueba actual.
	 * @return los archivos con path y extensión a donde se copiaron (del destino).
	 */
	public static String[] copyTempEvidence() throws Exception {

		if (!Evidence.doEvidence)
			return null; // SI NO SE TOMAN EVIDENCIAS SALE DEL MÉTODO
		return Evidence.copyTempEvidence(getNbEvidenceDirectory()); // CARPETA CON EVIDENCIAS DE LA PRUEBA
	}
//***********************************************************************************************************************
	/**
	 * Copia el contenido de la carpeta de evidencias temporales, en la carpeta [newEvidenceDir].
	 * @return los archivos con path y extensión a donde se copiaron (del destino).
	 */
	public static String[] copyTempEvidence(String newEvidenceDir) throws Exception {

		if (!Evidence.doEvidence)
			return null; // SI NO SE TOMAN EVIDENCIAS SALE DEL MÉTODO
		// SI NO SE HA GENERADO CARPETA [newEvidenceDir], SE CREA:
		if (!Util.directoryExist(newEvidenceDir))
			new File(newEvidenceDir).mkdirs();
		return Util.copyAllFiles(evidenceTempDir, newEvidenceDir);
	}
//***********************************************************************************************************************
	/**
	 * Este método copia una evidencia puntual [nbEvidenceToCopy], a la carpeta de evidencias de la prueba actual,
	 * dejándola con el mismo nombre de archivo.<br>
	 * <b>OJO:</b> Si la evidencia ya existe en la carpeta de evidencias de la prueba actual, NO se reemplaza.
	 * @return El nombre con ruta y extensión de la nueva evidencia.
	 */
	public static String copyPuntualEvidence(String nbEvidenceToCopy) throws Exception {

		if (!Evidence.doEvidence)
			return null; // SI NO SE TOMAN EVIDENCIAS SALE DEL MÉTODO
		String dirCurrentTest = getNbEvidenceDirectory(); // CARPETA CON EVIDENCIAS DE LA PRUEBA
		String simpleNbFile = new File(nbEvidenceToCopy).getName();
		String nbNewEvidence = dirCurrentTest + File.separator + simpleNbFile;
		if (!new File(nbNewEvidence).exists())
			Util.copyFile(nbEvidenceToCopy, nbNewEvidence);
		return nbNewEvidence;
	}
//***********************************************************************************************************************
	/**
	 * Este método copia una evidencia puntual [nbEvidenceToCopy], a la carpeta [folderDestino], dejándola con el mismo
	 * nombre de archivo.<br>
	 * <b>OJO:</b> Si la evidencia ya existe en la carpeta [folderDestino], NO se reemplaza.
	 * @return El nombre con ruta y extensión de la nueva evidencia.
	 */
	public static String copyPuntualEvidence(String nbEvidenceToCopy, String folderDestino) throws Exception {

		if (!Evidence.doEvidence)
			return null; // SI NO SE TOMAN EVIDENCIAS SALE DEL MÉTODO
		String simpleNbFile = new File(nbEvidenceToCopy).getName();
		String nbNewEvidence = folderDestino + File.separator + simpleNbFile;
		if (!new File(nbNewEvidence).exists())
			Util.copyFile(nbEvidenceToCopy, nbNewEvidence);
		return nbNewEvidence;
	}
//***********************************************************************************************************************
	/**
	 * Retorna el inicio que debe tener toda evidencia incluyendo las carpetas iniciales. Garantizando que las carpetas
	 * padre existen.<br>
	 * La estructura del retorno es [directorioEvidencia\yyyymmddHHmmss#]
	 */
	public static String getStartEvidenceName() {

		// RUTA COMPLETA DE EVIDENCIAS PARA CADA ITERACIÓN
		String evidenceDir = getNbEvidenceDirectory();
		// SI NO SE HA GENERADO CARPETA DE EVIDENCIAS PARA LA ITERACIÓN ACTUAL, SE CREA:
		if (!Util.directoryExist(evidenceDir)) {
			File directory = new File(evidenceDir);
			directory.mkdirs();
		}
		// [evidenceDir/yyyymmdd-HHmmss ] :
		String today = "yyyymmdd";
		try {
			today = Util.dateToString("yyyymmdd");
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		String currentPrefijo = today + Util.hourToString("HHmmss");
		if (!LAST_PREFIJO.equals(currentPrefijo))
			CONSECUTIVO = 0; // SE REINICIA
		LAST_PREFIJO = currentPrefijo;
		return (evidenceDir + System.getProperty("file.separator") + currentPrefijo + (CONSECUTIVO++) + " ");
	}
//***********************************************************************************************************************
	// MÉTODOS PRIVADOS:
	// ARMA EL NOMBRE DE LA EVIDENCIA CON DIRECTORIOS Y EL FORMATO .PNG
	private static String armarNombreEvidencia(String nbEvidence) {

		// VALIDA EL NOMBRE DE LA EVIDENCIA: 9 CARACTERES QUE NO PERMITE \ ? | < > * : / "
		String nbEvidenciaFinal = Util.cleanTextForFile(nbEvidence);
		// [directorioEvidencia\yyyymmdd-HHmmss nbEvidencia.png]
		return (getStartEvidenceName() + nbEvidenciaFinal + ".png");
	}
//***********************************************************************************************************************
	// ARMA EL NOMBRE DE LA EVIDENCIA TEMPORAL CON DIRECTORIOS Y EL FORMATO .PNG
	private static String armarNombreEvidenciaTemp(String nbEvidence) {

		// VALIDA EL NOMBRE DE LA EVIDENCIA: 9 CARACTERES QUE NO PERMITE \ ? | < > * : / "
		String nbEvidenciaFinal = Util.cleanTextForFile(nbEvidence);
		// [directorioEvidencia\yyyymmdd-HHmmss nbEvidencia.png]
		return (getStartEvidenceTempName() + nbEvidenciaFinal + ".png");
	}
//***********************************************************************************************************************
	/**
	 * Retorna el inicio que debe tener toda evidencia temporal incluyendo las carpetas iniciales. Garantizando que las
	 * carpetas padre existen.<br>
	 * La estructura del retorno es [directorioEvidenciaTemp/yyyymmddHHmmss#]
	 */
	public static String getStartEvidenceTempName() {

		// RUTA COMPLETA DE EVIDENCIAS PARA LOS ARCHIVOS TEMPORALES
		if (evidenceTempDir == null)
			evidenceTempDir = SettingsRun.RESULT_DIR + System.getProperty("file.separator") + "Temp";
		// SI NO SE HA GENERADO CARPETA DE EVIDENCIAS TEMPORAL, SE CREA:
		if (!Util.directoryExist(evidenceTempDir)) {
			File directory = new File(evidenceTempDir);
			directory.mkdirs();
		}
		String today = "yyyymmdd";
		try {
			today = Util.dateToString("yyyymmdd");
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		String currentPrefijo = today + Util.hourToString("HHmmss");
		if (!LAST_PREFIJO.equals(currentPrefijo))
			CONSECUTIVO = 0; // SE REINICIA
		LAST_PREFIJO = currentPrefijo;
		// [evidenceDir/yyyymmddHHmmss#] :
		return (evidenceTempDir + System.getProperty("file.separator") + currentPrefijo + (CONSECUTIVO++) + " ");
	}
//***********************************************************************************************************************
	/**
	 * Retorna el nombre de la carpeta de evidencias, evaluando si se hace por Row y si es evidencia con un [EVIDIR_PREF]
	 * o [NB_CARPETA] definidos.<br>
	 * El nombre enviado va sin el último caracter de separador de carpetas.
	 */
	public static String getNbEvidenceDirectory() {

		if (SettingsRun.RESULT_DIR.isEmpty()) // NO HAY LANZAMIENTO DESDE LAUNCHER TestNG
			SettingsRun.RESULT_DIR = SettingsRun.getResultDirSugerido();
		String rutaEvidencia = SettingsRun.RESULT_DIR;
		String testConfig = "";
		if (SettingsRun.getTestData() != null)
			if (SettingsRun.getTestData().parameterExist(SettingsRun.PARAM_ID_TEST_CONF))
				testConfig = " ("
					+ SettingsRun.getTestData().getParameter(SettingsRun.PARAM_ID_TEST_CONF).replace(" ", "") + ")";
		if (testConfig.equals(" ()"))
			testConfig = ""; // NO HAY TEST CONFIGURATION
		String name = "Exec-";
		if (SettingsRun.testDataInExcel())
			name = "Row-";
		// NOMBRE DE LA CARPETA DE EVIDENCIAS PARA CADA ITERACIÓN:
		String nbCarpeta = EVIDIR_PREF + name + SettingsRun.getCurrentIteration() + testConfig;
		// SI LA EVIDENCIA ES PARA UN NOMBRE DE CARPETA FIJO, LA CARPETA SE CAMBIA:
		if (!Evidence.NB_CARPETA.isEmpty())
			nbCarpeta = "Row-0 (" + Evidence.NB_CARPETA + ")";
		// RETORNA LA RUTA COMPLETA PARA LAS EVIDENCIAS DE LA ITERACIÓN ACTUAL
		rutaEvidencia = (SettingsRun.RESULT_DIR + System.getProperty("file.separator") + nbCarpeta);
		return rutaEvidencia;
	}
	
//***********************************************************************************************************************
	/**
	 * Inicia la grabación de la prueba
	 * @throws MalformedURLException
	 * @throws InterruptedException
	 */
	/*
	public static void startRecording() throws MalformedURLException, InterruptedException {
		VideoRecorderConfiguration.wantToUseFullScreen(true);
		VideoRecorderConfiguration.setCaptureInterval(150);
		
		VideoRecorderConfiguration.setVideoDirectory(new File(SettingsRun.RESULT_DIR));
		VideoRecorderConfiguration.setKeepFrames(true);
		VideoRecorder.start("Row-"+SettingsRun.getCurrentIteration()+ "-TestRecording");

		VideoRecorderTestNGConfiguration.wantToKeepVideoOnSuccess(true);
	}
	
//***********************************************************************************************************************
	/**
	 * termina la grabación de la prueba
	 * @throws MalformedURLException
	 */
	/*
	public static void stopRecording() throws MalformedURLException {
		VideoRecorder.stop();
	}
	*/
}