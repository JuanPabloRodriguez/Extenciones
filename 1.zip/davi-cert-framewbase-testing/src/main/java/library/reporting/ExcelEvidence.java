package library.reporting;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.imageio.ImageIO;

import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.ClientAnchor;
import org.apache.poi.ss.usermodel.Drawing;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Picture;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.util.IOUtils;

import library.common.ExcelFile;

/**
 * EJEMPLO PARA USAR LA CLASE:
 * ArrayList<String> imgs = new ArrayList<String>();
 * imgs.add("Imagen1.jpg");
 * imgs.add("Imagen2.jpg");
 * 	
 * String pathExcel = "RutaExcel.xlsx";
 * ExcelEvidence evidenceXls = new ExcelEvidence(pathExcel, ExcelFile.CREATE);
 * evidenceXls.armarLineaEvidencias("Hoja1", "Prueba caso1", imgs);
 * evidenceXls.armarLineaEvidencias("Hoja2", "Prueba caso1", imgs);
 * imgs.add("Imagen3.jpg");
 * imgs.add("Imagen4.jpg");
 * evidenceXls.armarLineaEvidencias("Hoja1", "Prueba caso2", imgs);
 * evidenceXls.saveAndCloseFile(); // SIEMPRE SALVAR Y CERRAR
 * @author szea
 */

public class ExcelEvidence extends ExcelFile {

	private String evidenceTitle = "";
	private List<String> filesImg; // ARCHIVOS DE IMAGEN QUE SERÁN INCLUIDOS EN EL ARCHIVO
	private int rowImg = 1; // EL INDEX INICIAL ES CERO
	private int colImg = 1; // EL INDEX INICIAL ES CERO
	private HashMap<String,Integer> rowImgXSheet = new HashMap<String,Integer>(); // NOMBRE DE LA HOJA Y ROW
	
	private static int rowTitle;
	private static int colTitle;
	private int rowTablaContenido = 0;

//***********************************************************************************************************************
	public ExcelEvidence(String filePath, int typeOpen) {
		super(filePath, typeOpen);
	}
//***********************************************************************************************************************
	public void setFilesImg(ArrayList<String> filesImg) {
		this.filesImg = filesImg;
	}
//***********************************************************************************************************************
	public void setRowImg(int rowImg) {
		this.rowImg = rowImg;
	}
//***********************************************************************************************************************
	public void setColImg(int colImg) {
		this.colImg = colImg;
	}
//***********************************************************************************************************************
	/**
	 * Inserta en la tabla de contenido la referencia al [sheetName] recibido (así no exista).<br>
	 * OJO: Deja el WorkSheet en la hoja de la tabla de contenido.
	 */
	public void insertarATablaContenido(String sheetName, String evidenceTitle) {
		if (this.rowTablaContenido == 0) { // NO SE HA INSERTADO LA TABLA DE CONTENIDO, SE ADICIONA
			this.createSheet("Indice");
			this.rowTablaContenido = 4; // DONDE EMPIEZA A ESCRIBIR EL CONTENIDO
			
			// CREA EL ESTILO DEL HEADER
			this.createCellStyleHeader();
	        this.setCellStyle(2, 2, cellheader);
			this.setStringCellValue(2, 2, "TABLA DE CONTENIDO");
			this.setColumnsWidth("3", 40000); // 0,25 = 100
	        this.sheet.addMergedRegion(CellRangeAddress.valueOf("$B$2:$C$2"));
		}
		// YA SE INSERTÓ LA TABLA DE CONTENIDO, SE SELECCIONA LA HOJA
		else this.selectSheet("Indice");
		
		// GUARDA EL ÍNDICE DE LAS PRUEBAS A ALMACENAR
		this.setStringCellValue(this.rowTablaContenido, 2, sheetName);
		this.setHyperlinkCell(this.rowTablaContenido, 2, sheetName);
		this.setStringCellValue(this.rowTablaContenido, 3, evidenceTitle);
		
        this.rowTablaContenido++; // INCREMENTA 
	}
//***********************************************************************************************************************
	/**
	 * Arma la línea de evidencia: Cuando se indica que es [conTablaCont] primero inserta en la tabla de contenido la
	 * referencia a la hoja que se va a crear y luego se crea la hoja con la evidencia.<br> 
	 * OJO: Deja el WorkSheet en la hoja creada.<br>
	 * En la evidencia va primero el título [evidenceTitle], seguido del registro de los [datosPrueba] usados (si hay)
	 * y finalmente inserta las imágenes de manera horizontal.
	 */
	public void armarLineaEvidencias(String sheetName, String evidenceTitle, String datosPrueba,
			List<String> filesImg, boolean conTablaCont) {
		
		// SI ES CON TABLA DE CONTENIDO, SE DEBE INSERTAR A LA TABLA DE CONTENIDO:
		if (conTablaCont)
			this.insertarATablaContenido(sheetName, evidenceTitle);
		
		this.evidenceTitle = evidenceTitle;
		this.filesImg = filesImg;
		this.cargarSheet(sheetName); // SELECCIONA HOJA, SETEA FILA Y COLUMNA INICIO
		this.setearTitleYDatos(datosPrueba);
		this.adjuntarEvidencias();
	}
//***********************************************************************************************************************
	/**
	 * Arma una línea de evidencia simple con sólo el título.<br>
	 * OJO: Deja el WorkSheet en la hoja creada.<br>
	 * La evidencia va sin título y sin datos de prueba, finalmente inserta las imágenes de manera horizontal.
	 */
	public void armarLineaEvidencias(String sheetName, String evidenceTitle, List<String> filesImg) {
		
		this.evidenceTitle = evidenceTitle;
		this.filesImg = filesImg;
		this.cargarSheet(sheetName); // SELECCIONA HOJA, SETEA FILA Y COLUMNA INICIO
		this.setearTitleYDatos(null);
		this.adjuntarEvidencias();
	}
//***********************************************************************************************************************
	/**
	 * Si la hoja [sheetName] ya está en el HashMap [rowImgXSheet] es porque ya se creó la hoja en el Excel, debe
	 * seleccionar dicha hoja y extrear del HashMap el número del row en donde se debe hacer la inserción.
	 * Si la hoja [sheetName] NO está en el HashMap [rowImgXSheet] se crea la hoja y se inicia el Row para poner las
	 * imágenes con el valor de la segunda fila existente.
	 * La columna para setear las imágenes siempre se setea con el valor de la segunda columna del Excel.
	 */
	private void cargarSheet(String sheetName) {
		if(this.rowImgXSheet.containsKey(sheetName)) {
			this.selectSheet(sheetName);
			this.setRowImg(this.rowImgXSheet.get(sheetName));
			this.setColImg(1); // SIEMPRE PARA UNA LÍNEA NUEVA SE EMPIEZA EN 1 (0 ES LA PRIMER COLUMNA)
			
		} else { // ES LA PRIMERA VEZ QUE SE VA A USAR LA HOJA
			this.createSheet(sheetName);
			this.setRowImg(1); // PARA HOJA NUEVA EMPIEZA EN 1 (0 ES EL PRIMER ROW)
			this.setColImg(1); // SIEMPRE PARA UNA LÍNEA NUEVA SE EMPIEZA EN 1 (0 ES LA PRIMER COLUMNA)
		}
	}
//***********************************************************************************************************************
	private CellStyle cellheader;
	/**
	 * Crea el estilo del Header si no se ha creado.
	 */
	private void createCellStyleHeader() {
		if (cellheader == null) {
			Font titleFont = this.workBook.createFont();
			titleFont.setColor(IndexedColors.WHITE.index);
			// DEJA EL TAMAÑO NORMAL DE LA LETRA titleFont.setFontHeightInPoints((short) 14.00);
			titleFont.setBold(true);
			// CREA EL [cellheader]
            cellheader = this.workBook.createCellStyle();
            cellheader.setFillForegroundColor(IndexedColors.GREY_50_PERCENT.index);
            cellheader.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            cellheader.setWrapText(false);
            cellheader.setFont(titleFont);
		}
	}
//***********************************************************************************************************************
	/**
	 * Este método se hace si [this.evidenceTitle] tiene información.<br>
	 * Setea el título de la evidencia y pone línea de datos de prueba, si se cuenta con dichas información.
	 */
	private void setearTitleYDatos(String datosPrueba) {
		
		if (this.evidenceTitle != null && !this.evidenceTitle.isEmpty()) {
			// CREA EL ESTILO DEL HEADER
			this.createCellStyleHeader();
			// SETEA EL TÍTULO
			rowTitle = this.rowImg + 1;
			colTitle = this.colImg + 1;
			this.setStringCellValue(rowTitle, colTitle, this.evidenceTitle);
            this.setCellStyle(rowTitle, colTitle, cellheader);
            this.sheet.addMergedRegion(CellRangeAddress.valueOf("$B$"+rowTitle+":$T$"+rowTitle));
			
			if (datosPrueba != null && !datosPrueba.isEmpty()) {
				int rowData = rowTitle + 1;
				this.setStringCellValue(rowData, colTitle, "Datos : " + datosPrueba);
	            this.setCellStyle(rowData, colTitle, cellheader);
	            this.sheet.addMergedRegion(CellRangeAddress.valueOf("$B$"+rowData+":$T$"+rowData));
	            this.rowImg++; // SUMA 1 FILA PARA LAS IMÁGENES
			}
            this.rowImg += 2; // SUMA 2 FILAS PARA EMPEZAR A PONER LAS IMÁGENES
		}
	}
//***********************************************************************************************************************
	/**
	 * Setea imagen a imagen, según lo existente en el atributo [filesImg] que es un ArrayList con los path de
	 * las imágenes a incluir.
	 */
	private void adjuntarEvidencias() {
		// ADJUNTA LAS IMÁGENES:
		int[] coordRowCol;
		int maxRow = 0;
		for (String nameFile : this.filesImg) {
			coordRowCol = insertarImagen(nameFile); //0:ROW, 1:COLUMNA
			if (maxRow < coordRowCol[0]) maxRow = coordRowCol[0]; // SIGUIENTE ROW PARA SIGUIENTE LÍNEA DE EVIDENCIA
			this.colImg = coordRowCol[1]; // CAMBIA EL VALOR DE LA COLUMNA PARA LA SIGUIENTE IMAGEN
		}
		// ALMACENA EL ROW PARA UNA SIGUIENTE LÍNEA DE EVIDENCIA, POR SI SE LLEGA A INCLUIR:
		this.rowImgXSheet.put(this.getSheet().getSheetName(), maxRow);
	}
//***********************************************************************************************************************
	/**
	 * Inserta la imagen [nameFileImg] en la fila [rowImg] y columna [colImg].
	 * Retorna las siguientes coordenadas de fila y columna, sumando lo que ocupa la imagen insertada.
	 * OJO: el retorno no es para usarlo tal cual, se usa la coordenda requerida.
	 */
    public int[] insertarImagen(String nameFileImg) {
    	
    	int[] nextCoord = null;
        try {
        	// TRAER EL CONTENIDO DE LA IMAGEN DE UN [InputStream] A byte[]
            InputStream file = new FileInputStream(nameFileImg);
            byte[] bytes = IOUtils.toByteArray(file);
            // ADICIONAR LA IMAGEN AL WORKBOOK
            int pictureIdx = this.workBook.addPicture(bytes, Workbook.PICTURE_TYPE_JPEG);
            file.close(); // CERRAR EL [InputStream]
            
            Drawing<?> drawing = this.sheet.getDrawingPatriarch(); // CARGAR LA IMAGEN EN LA HOJA
            if (drawing == null) drawing = this.sheet.createDrawingPatriarch();
            
            // CREA EL [ClientAnchor] ASOCIADO AL [workBook]
            ClientAnchor anchor = this.workBook.getCreationHelper().createClientAnchor();
            // SETEA LA FILA Y COLUMNA EN DONDE SE PONDRÁ LA IMAGEN:
            anchor.setRow1(this.rowImg);
            anchor.setCol1(this.colImg);
            //@ SI SE DEJA LA SIGUIENTE LÍNEA : LAS IMÁGENES NO SE MUEVEN CON INSERCIONES DE ROWS NI DE COLUMNAS:
            //@ anchor.setAnchorType(ClientAnchor.AnchorType.DONT_MOVE_AND_RESIZE);
            Picture pict = drawing.createPicture(anchor, pictureIdx);
            // SETEA EL TAMAÑO DE LA IMAGEN
            pict.resize(); // RESETEA LA IMAGEN PARA QUE TOME EL TAMAÑO NORMAL
            this.doResize(pict, nameFileImg);
            // OBTIENE LA INFORMACIÓN PARA RETORNAR FILA Y COLUMNA SIGUIENTE A USAR PARA OTRA IMAGEN
            int rowFin = pict.getPreferredSize().getRow2() + 1;
            int colFin = pict.getPreferredSize().getCol2() + 1;
            nextCoord = new int[] {rowFin, colFin};
        } catch (Exception ex) {
            ex.printStackTrace();
        }
		return nextCoord;
    }
//***********************************************************************************************************************
    /**
     * Cambia el título de la evidencia por [evidenceTitle].
     */
    public void changeTitle(String evidenceTitle) {
    	this.setStringCellValue(rowTitle, colTitle, evidenceTitle);
    }
//***********************************************************************************************************************
    /**
     * Hace el resize de la imagen en el excel, teniendo en cuenta que cuando se trate de una que sea más ancha que alta
     * (Stratus, AS400, Página WEB) se dejará una imagen que ocupe máximo 12 columnas en el excel y para el caso que sea
     * más alta que ancha (celulares) se dejará una imagen de máximo 4 columnas en el excel.
     * @throws IOException 
     */
    private void doResize(Picture pict, String nameFileImg) throws IOException {
    	
        BufferedImage bimg = ImageIO.read(new File(nameFileImg));
        int width  = bimg.getWidth();
        int height = bimg.getHeight();
        
        int numCols = 4;      // #COLs PARA IMAGEN DE DISPOSITIVO MÓVIL
        if (height < width) { // NO ES IMAGEN DE DISPOSITIVO MÓVIL
        	numCols = 12;     // #COLs PARA IMAGEN DE PÁGINA WEB
        	// SI LA DISTRIBUCIÓN ES SUPERIOR DEL 60% ES UNA PANTALLA COMO DE STRATUS
        	int distribuc = (int)(100 * height / width);
        	if (distribuc > 60) numCols = 8; // #COLs PARA IMAGEN COMO DE STRATUS
		}
        // EL #ROWs SE OBTIENE DE LA DISTRIBUCIÓN DEL % CORRESPONDIENTE AL NÚMERO DE COLUMNAS OBTENIDO CON RESPECTO AL
        // ANCHO REAL DE LA IMAGEN, ESE % SE MULTIPLICA POR EL ALTO REAL, SE MULTIPLICA POR 3 Y SE RESTA 1 (regla)
        // SE USA LA MULTIPLICACIÓN POR 1000 PORQUE EL [porcent] DA UN VALOR PEQUEÑO Y LO TOMA COMO CERO (0)
        int numRows = (int) ((height * 1000.0 * numCols / width / 1000) * 3);
        
        pict.getClientAnchor().setRow2(this.rowImg+numRows);
        pict.getClientAnchor().setCol2(this.colImg+numCols);
    /*  COMO SE HACÍA ANTES:       
    	double width = pict.getImageDimension().getWidth();
    	double height = pict.getImageDimension().getHeight();
    	int numColsEsp = 13; // PARA IMÁGENES MÁS ANCHAS QUE ALTAS (STRATUS, AS400, PÁGINAS WEB) SE ESPERAN 13 COLUMNAS
    	// SI [picture] ES MÁS ALTO QUE ANCHO, SE SUPONE QUE PUEDE SER UNA IMAGEN DE CELULAR: SE ESPERAN 4 COLUMNAS
    	if (height > width) numColsEsp = 4;
    	
        int colsReal = 1 + pict.getClientAnchor().getCol2() - pict.getClientAnchor().getCol1();
    	double porcImg = Math.floor(numColsEsp * 100 / colsReal); // EN %
    	pict.resize(porcImg/100); // RESETEA LA IMAGEN AL PORCENTAJE REQUERIDO DEL ORIGINAL
    */
    }
//***********************************************************************************************************************
}