package library.reporting;

import java.util.List;

public interface EvidenceType {

	/**
	 * Permite resetear la evidencia, aplica para los casos en que se requiere un nueVo archivo y por alguna razón
	 * la evidencia de una ejecución pasada se mantiene. 
	 */
	public abstract void resetEvidenceByTest();
	
	/**
	 * Crea el archivo de evidencias, se debió cargar previamente con [Reporter.loadTestName] el nombre simple de cada
	 * prueba por Iteración, si no se hace se creará con un nombe genérico.<br>
	 * La ruta del archivo, la extensión y demás detalles son dadas en la implementación del método.
	 */
	public abstract void createEvidenceByTest();
	
	/**
	 * Carga el archivo de evidencias que corresponde al [numIteration] recibido - este archivo debió ser previamente
	 * creado.
	 */
	public abstract void loadEvidenceByIteration(int numIteration);
	
	/**
	 * Pone el nombre del caso de prueba en la evidencia.
	 */
	public abstract void setNbTestCase(String nbTestCase);
	
	/**
	 * Inserta una o más imágenes al archivo de evidencias.
	 */
	public abstract void insertImage(String... pathFilesImg);
	
	/**
	 * Inserta una tabla con la información del Step, los datos a mostrar del Step vienen en [datosPrueba] el formateo
	 * lo realiza la implemeentacién de este método.
	 */
	public abstract void setTestStep(String... dataTable) throws Exception;
	
    /**
     * Escribe el [texto] en formato de TITLE : Bold / Tamaño 14 
     */
    public abstract void setTitle(String texto);

    /**
     * Escribe el [texto] en formato de SUBTITLE : Bold / Tamaño 12 
     */
    public abstract void setSubtitle(String texto);

    /**
     * Escribe el [texto] en formato de texto : normal / Tamaño 11 
     */
    public abstract void setTexto(String texto);

    /**
     * Escribe el [status] como el estado de la evidencia, y si hay archivo lo debe salvar. 
     */
    public abstract void setTestStatus(String status);

    /**
     * Retorna una lista de evidencias que se han ido acumulando por Paso.<br>
     * Cada elemento existente en una posición de la lista, son las evidencias que corresponden a un paso. 
     */
    public abstract List<String[]> getEvidencesBySteps();

    /**
     * Retorna el nombre del archivo de evidencias, si se generó archivo. 
     */
    public abstract String getNbEvidenceFile();

    /**
     * Retorna el nombre de la entidad para hacer la carga de evidencias, posibles valores: INSTANCE / RUN / STEP 
     */
    public abstract String getEntityForUpload();
    
    /**
     * Indica si se hizo guardado de evidencias en el archivo, es para evitar crear archivos vacíos. 
     */
    public abstract boolean containEvidences();
}
