package library.reporting;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import library.settings.SettingsRun;

public class ExtentReporterNG {
	
    private static ExtentReports extent;
    private static ExtentSparkReporter reporter;
    private static String pathReport;

    public static ExtentReports getReportObject() {
    	
		pathReport = SettingsRun.RESULT_DIR + System.getProperty("file.separator") + "_FinalReport.html";
        reporter = new ExtentSparkReporter(pathReport);
        reporter.config().setReportName("Reporte " + SettingsRun.EXEC_NAME);
        reporter.config().setDocumentTitle("Davivienda - Test Result");
        extent = new ExtentReports();
        extent.attachReporter(reporter);
        extent.setSystemInfo("Tester", SettingsRun.TEST_EXECUTOR);

        return extent;
    }
//***********************************************************************************************************************    
    /**
     * Retorna la ruta completa del reporte
     */
    public static String getPathReport() {
    	return pathReport;
    }
//***********************************************************************************************************************    
    public static ExtentReports createReportObject(String pathReport) {

        ExtentReports extentTemp;
        ExtentSparkReporter reporterTemp;
        
        reporterTemp = new ExtentSparkReporter(pathReport);
        reporterTemp.config().setReportName(reporter.config().getReportName());
        reporterTemp.config().setDocumentTitle(reporter.config().getDocumentTitle());
        extentTemp = new ExtentReports();
        extentTemp.attachReporter(reporterTemp);
        extentTemp.setSystemInfo("Tester", SettingsRun.TEST_EXECUTOR);
        return extentTemp;
    }
//***********************************************************************************************************************    
}
