package library.settings;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

import library.common.Util;
import library.googleApis.ControllerGmail;
import library.googleApis.ControllerGoogleDrive;
import library.reporting.Reporter;

public class SettingsResources {

	// CARPETA COMPARTIDA DEL DRIVE DE [automatizacionqa@davivienda.com]
	public static final String BASE_EXEC_DATA = "ParaData/ExecData/";
//=======================================================================================================================
	// CAMBIAR LA INFORMACIÓN DE LAS SIGUIENTES CONSTANTES SEGÚN LAS NECESIDADES DEL FRAMEWORK
	/**
	 * Directorio de descarga en máquina local de los recursos, lleva el último separador.
	 */
	private final static String DIR_DOWNLOAD_RESOURCES = Util.getDirBaseTemp();
	/**
	 * Directorio de descarga en máquina local de los archivos (NO resources) de GoogleDrive, lleva el último separador.
	 */
	private final static String DIR_DOWNLOAD_FILES = DIR_DOWNLOAD_RESOURCES + "_GDrive" + File.separator;
	/**
	 * Ruta del archivo de credenciales en los Resources, para la conexión a GoogleDrive y a Gmail.
	 */
	private final static String FOLDER_RESOURCE = "credentials";
	private final static String NB_RESOURCE = "DesktopClient_AutoDav.json";
	private final static String STORED_CRED_GMAIL = "credentials/TokenGmail/StoredCredential";
	/**
	 * Ruta completa de archivo de credenciales, este dato debe estar localizado en la máquina local.
	 */
	private final static String JSON_CREDENTIALS = DIR_DOWNLOAD_RESOURCES + FOLDER_RESOURCE + File.separator
		+ NB_RESOURCE;
	/**
	 * Carpeta en el GoogleDrive en donde se encontrarán los recursos a descargar, debe terminar en "/"
	 */
	private final static String PATH_RESOURCES = "Resources/";
//=======================================================================================================================
	// KEY = Resource, VALUE = Path completo
	private static Map<String, String> MAP_RESOURCES_DOWNLOADED = new HashMap<String, String>();
	// KEY = Resource, VALUE = Path completo // OTROS ARCHIVOS DESCARGADOS
	private static Map<String, String> MAP_FILES_DOWNLOADED = new HashMap<String, String>();
	// CONTROLADOR PARA EL MANEJO DE DESCARGA DEL GOOGLE DRIVE
	private static ControllerGoogleDrive CONTROL_GDRIVE = null;
	// CONTROLADOR PARA EL MANEJO DE GMAIL
	private static ControllerGmail CONTROL_GMAIL = null;

//***********************************************************************************************************************
	/**
	 * Se encarga de retornar la ruta completa donde se encuentra alojado un recurso puntual, existente en el GoogleDrive
	 * del framework (automatizacionqa)<br>
	 * <b>OJO:</b> Cuando la propiedad [SettingsRun.PROP_DOWNLOAD_RESOURCES] en el archivo de propiedades de la ejecución
	 * está con valor [false] NO hace descarga de GoogleDrive, sino toma el recurso existente en [DIR_DOWNLOAD_RESOURCES]
	 * <br>
	 * Los recursos se encuentran en:
	 * <a href="https://drive.google.com/drive/folders/1qboqiJODpDgMaWC4J1gDmD_thRehw_y-">Resources Folder</a><br>
	 * Se recomienda usar este método para leer recursos (no modificarlos), si se desea modificar un recurso, se
	 * recomienda hacer uso del método <b>copyResource(recurso, destino)</b> y modificar el destino.
	 * @param resource - Debe venir el nombre del recurso requerido, en formato [folder/nb_resource] separado con slash.
	 */
	public static String getFullPathResource(String resource) {

		// ARMA EL NOMBRE DEL FOLDER DE DESTINO DEL RECURSO, YA QUE DEBE ESTAR CON LA ESTRUCTURA DE CARPETAS
		String folderResource = DIR_DOWNLOAD_RESOURCES;
		String[] arrFolders = resource.split("/");
		for (int posArr = 0; posArr < arrFolders.length - 1; posArr++) {
			folderResource += arrFolders[posArr] + File.separator;
		}
//-----------------------------------------------------------------------------------------------------------------------
		String fullPath;
		if (MAP_RESOURCES_DOWNLOADED.containsKey(resource))
			fullPath = MAP_RESOURCES_DOWNLOADED.get(resource);
		else { // NO SE HA DESCARGADO O ENCONTRADO
			fullPath = folderResource + arrFolders[arrFolders.length - 1];
			boolean hacerDescarga = Boolean
				.valueOf(SettingsRun.getProperty(SettingsRun.PROP_DOWNLOAD_RESOURCES, "false"));
			if (!hacerDescarga) {
				if (new File(fullPath).exists())
					MAP_RESOURCES_DOWNLOADED.put(resource, fullPath);
				else
					hacerDescarga = true; // NO SE ENCONTRÓ, DEBE TRATAR DE HACER LA DESCARGA
			}
//-----------------------------------------------------------------------------------------------------------------------
			if (hacerDescarga) {
				fullPath = null;
				try {
					cargarControlGoogleDrive();
					fullPath = CONTROL_GDRIVE.downloadFile(PATH_RESOURCES + resource, folderResource);
					MAP_RESOURCES_DOWNLOADED.put(resource, fullPath);
				}
				catch (IOException e) {
					if (e.getMessage().equals("connect timed out")) {
						SettingsRun.setProperty(SettingsRun.PROP_DOWNLOAD_RESOURCES, "false");
						fullPath = getFullPathResource(resource);
					}
					else
						throw new NoSuchElementException(e.getMessage());
				}
			}
		}
		return fullPath;
	}
//***********************************************************************************************************************
	/**
	 * Retornar como un InputStream un recurso puntual, existente en el GoogleDrive del framework (automatizacionqa)<br>
	 * <b>OJO:</b> Cuando la propiedad [SettingsRun.PROP_DOWNLOAD_RESOURCES] en el archivo de propiedades de la ejecución
	 * está con valor [false] NO hace descarga de GoogleDrive, sino toma el recurso existente en [DIR_DOWNLOAD_RESOURCES]
	 * <br>
	 * Los recursos se encuentran en:
	 * <a href="https://drive.google.com/drive/folders/1qboqiJODpDgMaWC4J1gDmD_thRehw_y-">Resources Folder</a>
	 * @param resource - Debe venir el nombre del recurso requerido, en formato [folder/nb_resource] separado con slash.
	 */
	public static InputStream getResourceAsStream(String resource) {

		String fullPathresource = getFullPathResource(resource);
		InputStream input = null;
		try {
			if (fullPathresource != null)
				input = new FileInputStream(fullPathresource);
		}
		catch (FileNotFoundException e) {} // HACE NADA
		return input;
	}
//***********************************************************************************************************************
	/**
	 * Copia el recurso existente en el GoogleDrive con nombre [gDriveResource] a [nbFileDestination], si el destino
	 * existe, lo reemplaza.<br>
	 * Este método primero hace la descarga del recurso a la máquina local, para luego copiarlo al destino.
	 * @param nbFileSource - Nombre recurso en Google Drive de automatización (después de Resources).
	 * @param nbFileDestination - Nombre que tendrá el archivo destino (con path y extensión). OJO: El folder donde se
	 *        copie el archivo, debe existir.
	 * @author smzealo (Sandra Zea)
	 */
	public static void copyResource(String gDriveResource, String nbFileDestination) throws IOException {

		String fullPathresource = getFullPathResource(gDriveResource);
		Util.copyFile(fullPathresource, nbFileDestination);
	}
//***********************************************************************************************************************
	/**
	 * Este método hace la descarga de todos los archivos existentes en la carpeta compartida [nbDriveSharedFolder] a la
	 * carpeta de destino [destinationFolder] (NO descarga carpetas)<br>
	 * Si el destino contiene alguno de los archivos, lo sobreescribe.
	 * @param nbDriveSharedFolder - Viene con la ruta tal cual como está en GoogleDrive, los separadores son "/".<br>
	 *        Este folder debió ser compartido con la cuenta del GoogleDrive del framework (automatizacionqa)
	 * @param destinationFolder - Carpeta en la máquina local donde se hará la descarga.
	 *                            Si la carpeta NO existe, este método la crea.
	 * @throws IOException Genera Excepción si el folder [nbDriveSharedFolder] NO existe (case sensitive, OJO con espacios)
	 * @author smzealo (Sandra Zea)
	 */
	public static void downloadFilesFromSharedFolder(String nbDriveSharedFolder, String destinationFolder)
		throws IOException {

		cargarControlGoogleDrive();
		boolean hizoDescarga = CONTROL_GDRIVE.downloadAllSharedFiles(nbDriveSharedFolder, destinationFolder);
		if (!hizoDescarga)
			Reporter.reportEvent(Reporter.MIC_DONE, "SettingsResources -- No hay archivos para descargar de ["
				+ nbDriveSharedFolder + "]");
	}
//***********************************************************************************************************************
	/**
	 * Este método hace la descarga del archivo [nbDriveSharedFile] (es un archivo compartido) a la carpeta de destino
	 * [destinationFolder]<br>
	 * Si el destino contiene el archivo, lo sobreescribe.
	 * @param nbDriveSharedFile - Viene con la ruta tal cual como está en GoogleDrive, los separadores son "/".<br>
	 *        Este archivo debió ser compartido con todo y su folder, para conocer la ruta, a la cuenta del GoogleDrive
	 *        del framework (automatizacionqa).
	 * @param destinationFolder - Carpeta en la máquina local donde se hará la descarga.
	 *                            Si la carpeta NO existe, este método la crea.
	 * @return El nombre completo del archivo, como quedó en la máquina local.
	 * @throws IOException Genera Excepción si el archivo [nbDriveSharedFolder] NO existe
	 * @author smzealo (Sandra Zea)
	 */
	public static String downloadSharedFile(String nbDriveSharedFile, String destinationFolder) throws IOException {

		cargarControlGoogleDrive();
		return CONTROL_GDRIVE.downloadSharedFile(nbDriveSharedFile, destinationFolder);
	}
//***********************************************************************************************************************
	/**
	 * Obliga a crear el CONTROL de GMAIL descargando el recurso asociado al StoredCredential de Gmail.<br>
	 * Se usa cuando se sabe que la clave de la cuenta de correo [automatizacionqa@davivienda.com] cambió.
	 */
	public static void downloadTokenGmail() throws IOException {

		String pathStoredCredFile = getFullPathResource(STORED_CRED_GMAIL);
		CONTROL_GMAIL = new ControllerGmail("automatizacionqa", JSON_CREDENTIALS, pathStoredCredFile);
	}
//***********************************************************************************************************************
	/**
	 * Envía un email a [mailTo] con el [subject] y [content] dados.
	 */
	public static void sendEmail(String mailTo, String subject, String content) throws Exception {

		cargarControlGMail();
		CONTROL_GMAIL.sendEmail(mailTo, subject, content);
	}
//***********************************************************************************************************************
	/**
	 * Envía un email a [mailTo] con el [subject] y [content] dados, adjuntando el archivo [attachment] indicado.
	 */
	public static void sendEmail(String mailTo, String subject, String content, String attachment) throws Exception {

		cargarControlGMail();
		CONTROL_GMAIL.sendEmailWithAttachment(mailTo, subject, content, attachment);
	}
//***********************************************************************************************************************
	/**
	 * Envía un email a [mailTo] con el [subject] y [content] dados, adjuntando los archivos indicados en [listAttach].
	 */
	public static void sendEmail(String mailTo, String subject, String content, List<String> listAttachment)
		throws Exception {

		cargarControlGMail();
		CONTROL_GMAIL.sendEmailWithAttachment(mailTo, subject, content, Util.listToArray(listAttachment));
	}
//***********************************************************************************************************************
	/**
	 * Método para garantizar la carga de los recursos de la credenciales, requeridas para la configuración de Recursos
	 * ya sea de GoogleDrive, como el envío de emails.
	 */
	public static void loadResourcesCredential() {

		try {
			cargarControlGoogleDrive();
			cargarControlGMail();
		}
		catch (IOException e) {
			if (e.getMessage().contains("NO se encuentra el archivo de credenciales")) {
				try {
					// GARANTIZA LA EXISTENCIA DEL ARCHIVO
					if (!Util.directoryExist(DIR_DOWNLOAD_RESOURCES + FOLDER_RESOURCE))
						new File(DIR_DOWNLOAD_RESOURCES + FOLDER_RESOURCE).mkdirs();
					// COPIA EL RECURSO QUE ESTA EN LOS Resources DEL PROYECTO JAVA
					Util.copyFile(SettingsResources.class, FOLDER_RESOURCE + "/" + NB_RESOURCE, JSON_CREDENTIALS);
					loadResourcesCredential();
				}
				catch (IOException e1) {} // NO HACE NADA, PORQUE EL ARCHIVO SÍ EXISTE
			}
		}
	}
//***********************************************************************************************************************
	/**
	 * Método que garantiza que el control del Google Drive está cargado y activo.
	 */
	private static void cargarControlGoogleDrive() throws IOException {

		if (CONTROL_GDRIVE == null)
			CONTROL_GDRIVE = new ControllerGoogleDrive("automatizacionqa", JSON_CREDENTIALS);
	}
//***********************************************************************************************************************
	/**
	 * Método que garantiza que el control del Gmail está cargado y activo.<br>
	 * Obliga la descarga del recurso del Token de Gmail, esto es para garantizar que baja el último requerido.
	 */
	private static void cargarControlGMail() throws IOException {

		if (CONTROL_GMAIL == null)
			downloadTokenGmail();
	}
//***********************************************************************************************************************
	/**
	 * Copia el archivo existente en el GoogleDrive con nombre [gDriveResource] a [nbFileDestination], si el destino
	 * existe, lo reemplaza.<br>
	 * Este método primero hace la descarga del archivo a la máquina local, para luego copiarlo al destino.
	 * @param gDriveFile - Nombre del archivo en Google Drive de automatización (separado por /).
	 * @param nbFileDestination - Nombre que tendrá el archivo destino (con path y extensión). OJO: El folder donde se
	 *        copie el archivo, debe existir.
	 * @author smzealo (Sandra Zea)
	 */
	public static void copyGDriveFile(String gDriveFile, String nbFileDestination) throws IOException {

		String fullPathresource = getFullPathGDriveFile(gDriveFile);
		Util.copyFile(fullPathresource, nbFileDestination);
	}
//***********************************************************************************************************************
	/**
	 * Se encarga de retornar la ruta completa donde se encuentra alojado un archivo de Goggle Drive que fue descargado,
	 * del GoogleDrive del framework (automatizacionqa)<br>
	 * <b>OJO:</b> Cuando la propiedad [SettingsRun.PROP_DOWNLOAD_RESOURCES] en el archivo de propiedades de la ejecución
	 * está con valor [false] NO hace descarga de GoogleDrive, sino toma el archivo existente en [DIR_DOWNLOAD_FILES]
	 * <br>
	 * Los recursos se encuentran en las Unidades del correo automatizacionqa@davivienda.com - no tener en cuenta los
	 * que están en Resources.<br>
	 * Se recomienda usar este método para leer archivos (no modificarlos), si se desea modificar un archivo, se
	 * recomienda hacer uso del método <b>copyGDriveFile(file, destino)</b> y modificar el destino.
	 * @param driveFile - Debe venir el nombre del archivo requerido, en formato [folder/nb_file] separado con slash.
	 */
	public static String getFullPathGDriveFile(String driveFile) {

		// ARMA EL NOMBRE DEL FOLDER DE DESTINO DEL RECURSO, YA QUE DEBE ESTAR CON LA ESTRUCTURA DE CARPETAS
		String folderResource = DIR_DOWNLOAD_FILES;
		String[] arrFolders = driveFile.split("/");
		for (int posArr = 0; posArr < arrFolders.length - 1; posArr++) {
			folderResource += arrFolders[posArr] + File.separator;
		}
//-----------------------------------------------------------------------------------------------------------------------
		String fullPath;
		if (MAP_FILES_DOWNLOADED.containsKey(driveFile))
			fullPath = MAP_FILES_DOWNLOADED.get(driveFile);
		else { // NO SE HA DESCARGADO O ENCONTRADO
			fullPath = folderResource + arrFolders[arrFolders.length - 1];
			boolean hacerDescarga = Boolean
				.valueOf(SettingsRun.getProperty(SettingsRun.PROP_DOWNLOAD_RESOURCES, "true"));
			if (!hacerDescarga) {
				if (new File(fullPath).exists())
					MAP_FILES_DOWNLOADED.put(driveFile, fullPath);
				else
					hacerDescarga = true; // NO SE ENCONTRÓ, DEBE TRATAR DE HACER LA DESCARGA
			}
//-----------------------------------------------------------------------------------------------------------------------
			if (hacerDescarga) {
				fullPath = null;
				try {
					cargarControlGoogleDrive();
					fullPath = CONTROL_GDRIVE.downloadFile(driveFile, folderResource);
					MAP_FILES_DOWNLOADED.put(driveFile, fullPath);
				}
				catch (IOException e) {
					if (e.getMessage().equals("connect timed out")) {
						SettingsRun.setProperty(SettingsRun.PROP_DOWNLOAD_RESOURCES, "false");
						fullPath = getFullPathGDriveFile(driveFile);
					}
					else
						throw new NoSuchElementException(e.getMessage());
				}
			}
		}
		return fullPath;
	}
//***********************************************************************************************************************
}