package library.settings;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.List;

import library.common.ConsoleWindow;
import library.common.Util;
import library.data.DataDriven;
import library.data.DataDrivenExcel;
import library.reporting.Reporter;
import library.testTool.alm.Alm;

/**
 * Clase que maneja el frame JAVA para solicitar la configuración del lanzamiento.<br>
 * Usa la clase [SettingsRun] para hacer el cargue de la configuración.
 * @author szea
 */
public class SettingsNoWindow {

//=======================================================================================================================	
	public static void launch() throws Exception {
		
		try {
			loadSetting();
		} catch (Exception e) {
			e.printStackTrace();
		}
//-----------------------------------------------------------------------------------------------------------------------		
		// SI EL LANZAMIENTO FUE CORRECTO, SE EVALÚA SI LAS PRUEBAS SE CARGAN A LA HERRAMIENTA, EN TAL CASO MUESTRA
		// LA VENTANA QUE PIDE LOS DATOS DE LOGUEO PARA EL ALM Y ADICIONAL EL TEST SET ID
		if (SettingsRun.doLoadToTestTool())
			askingDataTestTool();
	}
//***********************************************************************************************************************
	private static void terminarXError(String msg) {
		Reporter.writeErr("ERROR DE CONFIGURACIÓN -- " + msg);
		System.exit(0);
	}
//***********************************************************************************************************************
	/**
	 * Intenta cargar la configuración.
	 */
	private static void loadSetting() throws Exception {

		String msgErr = "";
		int ini = 0, fin = 0, datoInt;
		int[] rowsEx = new int[0];
//-----------------------------------------------------------------------------------------------------------------------
		// ARCHIVO DE DATOS
		String sourceData = "";
		boolean isJsonFile = false;
		boolean sinArchivo = true;
		
		if (SettingsRun.IS_DEVOPS_LAUNCHER) {
			String fileName;
			String strDir = "/root/";
			File directory = new File(strDir);
			File[] files = directory.listFiles();
			// SI HAY ARCHIVOS BUSCA SI ES JSON O EXCEL
			String fileEsp = SettingsRun.EXEC_NAME.toUpperCase();
			for (File file : files) {
				fileName = file.getName().toUpperCase();
				if (fileName.equals(fileEsp + ".JSON")) {
					sourceData = file.getAbsolutePath();
					isJsonFile = true;
					sinArchivo = false;
					break;
				}
				if (fileName.equals(fileEsp + ".XLS") || fileName.equals(fileEsp + ".XLSX")) {
					sourceData = file.getAbsolutePath();
					isJsonFile = false;
					sinArchivo = false;
					break;
				}
			}
		}
		else { // ES LANZAMIENTO QUE NO REQUIERE APERTURA DE INTERFAZ, PERO NO ES DEVOPS
		
			sinArchivo = SettingsRun.DATA_SOURCE.equals("SIN ARCHIVO");
			isJsonFile = SettingsRun.DATA_SOURCE.equals("JSON");
			sourceData = SettingsRun.getProperty(SettingsRun.PROP_EXEC_DATAFILE, "");
		}
//-----------------------------------------------------------------------------------------------------------------------
		// CUANDO ES CON ARCHIVO DE DATOS : VALIDACIÓN DEL ARCHIVO DE DATOS
		if (!sinArchivo) {
			if (sourceData.isEmpty())
				terminarXError("Se indicó que es CON ARCHIVO pero no se ha indicado el archivo a usar en la propiedad ["
					+ SettingsRun.PROP_EXEC_DATAFILE +"]");
			else {
				String extension = Util.fileGetExtension(sourceData);
				if (isJsonFile && !extension.equals("JSON"))
					terminarXError("Se indicó que es CON ARCHIVO JSON pero el archivo indicado no es JSON");
				else if (!isJsonFile && !extension.equals("XLS") && !extension.equals("XLSX"))
					terminarXError("Se indicó que es CON ARCHIVO EXCEL pero el archivo indicado no es EXCEL");
				
				// SI LLEGA A ESTE PUNTO ES PORQUE SE CUENTA CON LA FUENTE DE LOS DATOS Y CORRESPONDE A LA EXTENSIÓN
				File file = new File(sourceData);
				if (!file.exists())
					terminarXError("El archivo de datos indicado NO EXISTE.");
				else if (file.isDirectory())
					terminarXError("El archivo de datos indicado NO ES ARCHIVO.");
			}
		}
//-----------------------------------------------------------------------------------------------------------------------
		// CUANDO ES CON ARCHIVO DE DATOS : VALIDACIÓN DEL HEADER
		int rowHeader = SettingsRun.DEFAULT_HEADER;
		if (!sinArchivo) { // ES CON ARCHIVO
			String header = SettingsRun.getProperty(SettingsRun.PROP_EXEC_HEADER, "1");
			if (isJsonFile)
				rowHeader = 0; // NO HAY HEADER
			if (!Util.isInteger(header))
				msgErr = "El row del Header debe ser un número entero.";
			else {
				rowHeader = Integer.valueOf(header);
				if (rowHeader < 1 && !isJsonFile)
					msgErr = "El row del Header mínimo debe ser 1.";
			}
		}
//-----------------------------------------------------------------------------------------------------------------------
		// CUANDO ES CON ARCHIVO DE DATOS : VALIDACIÓN DE PROPIEDADES DE RANGO DE EJECUCIÓN
		if (!sinArchivo) {
			String iniS = SettingsRun.getProperty(SettingsRun.PROP_EXEC_ITINI);
			String finS = SettingsRun.getProperty(SettingsRun.PROP_EXEC_ITFIN);
			String lis = SettingsRun.getProperty(SettingsRun.PROP_EXEC_LISTIT);
			
			if (iniS != null && !iniS.isEmpty() && finS != null && !finS.isEmpty()) { // HAY RANGO DE EJECUCIÓN
				if (!Util.isInteger(iniS))
					msgErr = "El rango inicial debe ser un número entero.";
				else {
					ini = Integer.valueOf(iniS);
					if (ini < rowHeader + 1)
						msgErr = "El rango inicial mínimo debe ser " + (rowHeader + 1)
							+ "\nEl header del archivo de datos está en la fila " + rowHeader;
					else { // Rango inicial es correcto
						if (!Util.isInteger(finS))
							msgErr = "El rango final debe ser un número entero.";
						else {
							fin = Integer.valueOf(finS);
							if (fin < ini)
								msgErr = "El rango final debe ser MAYOR O IGUAL al inicial.";
						}
					}
				}
			}
			else if (lis != null && !lis.isEmpty()) {
				try {
					List<Integer> listNumRow = Util.getListaDatos(lis, ",");
					rowsEx = new int[listNumRow.size()];
					for (int pos = 0; pos < listNumRow.size(); pos++) {
						datoInt = listNumRow.get(pos);
						if (datoInt == rowHeader && !isJsonFile) { // ES ARCHIVO DE EXCEL
							msgErr = "Dentro de los Rows a ejecutar, no puede estar el Row Header, revisar.";
							break;
						}
						rowsEx[pos] = datoInt;
					}
				}
				catch (Exception e) {
					msgErr = "Se encontró un dato que NO es un número entero, revisar.";
				}
			}
			else
				msgErr = "No se indicó rango ni lista de ejecución";
		}
//-----------------------------------------------------------------------------------------------------------------------
		if (msgErr.isEmpty() && !sinArchivo) { // NO HUBO ERROR Y ES CON ARCHIVO DE DATOS:
			// VALIDAR QUE LOS PARÁMETROS ESPERADOS EXISTAN EN EL ARCHIVO DE DATOS CARGADO
			msgErr = validarParamsInTestData(sourceData, rowHeader);
		}
//-----------------------------------------------------------------------------------------------------------------------
		if (msgErr.isEmpty()) { // SI NO HAY ERROR SE PUEDE HACER LA CONFIGURACIÓN
			// SE CREA EL DIRECTORIO DE EVIDENCIAS
			String dirEvid = SettingsRun.getResultDirSugerido();
			boolean dirExiste = Util.directoryExist(dirEvid);
			if (dirExiste)
				Reporter.write(
					"\n*** DIRECTORIO DE EVIDENCIAS YA EXISTE... SE REEMPLAZARÁ LO EXISTENTE Y SE ADICIONARÁN LAS NUEVAS EVIDENCIAS");
			else if (!dirExiste) // NO EXISTE, SE CREA
				new File(dirEvid).mkdirs();
			SettingsRun.RESULT_DIR = dirEvid;
			ConsoleWindow.PATH_LOG = SettingsRun.RESULT_DIR + System.getProperty("file.separator") + "_CONSOLE_LOG.txt";
			// SI NO HAY ARCHIVO DE DATOS, SÓLO SE CUENTA CON EL TOTAL DE EJECUCIONES:
			if (sourceData.isEmpty())
				SettingsRun.loadSetting(1); // POR DEFECTO
			else { // EXISTE ARCHIVO SE COPIA EL ARCHIVO DE DATOS AL DIRECTORIO DE EVIDENCIAS
				sourceData = copySource(dirEvid, sourceData);
				// SE HACE CARGA DE LA CONFIGURACIÓN PARA ARCHIVO JSON O EXCEL SEGÚN SEA EL CASO
				try {
					if (isJsonFile) {
						if (ini != 0)
							SettingsRun.loadSettingJson(ini, fin, sourceData);
						else
							SettingsRun.loadSettingJson(rowsEx, sourceData);
					}
					else {
						if (rowHeader > 1) {
							if (ini != 0)
								SettingsRun.loadSetting(ini, fin, sourceData, rowHeader);
							else
								SettingsRun.loadSetting(rowsEx, sourceData, rowHeader);
						}
						else {
							if (ini != 0)
								SettingsRun.loadSetting(ini, fin, sourceData);
							else
								SettingsRun.loadSetting(rowsEx, sourceData);
						}
					}
				}
				catch (ExceptionInInitializerError | IllegalArgumentException e) {
					msgErr = e.getMessage();
					new File(sourceData).delete(); // DEBE BORRAR EL ARCHIVO PARA QUE LO VUELVA A COPIAR
				}
			}
		}
//-------------------------------------------------------------------------------------------------------------------
		if (msgErr.isEmpty())
			Reporter.write("*** EVIDENCIAS ALMACENADAS EN [" + SettingsRun.RESULT_DIR + "]...");
		else
			terminarXError(msgErr);
	}
//***********************************************************************************************************************
	/**
	 * Retorna el nombre del archivo completo en donde se almacena la fuente de datos.
	 */
	private static String copySource(String dirEv, String source) throws IOException {

		File archOrig = new File(source);
		String sourceDest = dirEv + System.getProperty("file.separator") + archOrig.getName();
		// EN CASO QUE EL ARCHIVO SOURCE DE DESTINO EXISTA, GARANTIZA QUE ESTÉ CERRADO
		if (new File(sourceDest).exists()) {
			boolean fileIsLocked;
			do {
				fileIsLocked = Util.fileIsLocked(sourceDest);
				if (fileIsLocked)
					Reporter.writeErr("El siguiente archivo se encuentra abierto:\n" + sourceDest
						+ "\n\nCiérrelo antes de continuar.");
			} while (fileIsLocked);
		}
//-----------------------------------------------------------------------------------------------------------------------
		if (!source.equals(sourceDest)) { // SI ORIGEN Y DESTINO SON DIFERENTES PUEDE HACER LA COPIA
			Path origenPath = Paths.get(source);
			Path destinoPath = Paths.get(sourceDest);
			// SOBREESCRIBIR EL ARCHIVO DE DESTINO SI EXISTE, Y LO COPIA
			Files.copy(origenPath, destinoPath, StandardCopyOption.REPLACE_EXISTING);
		}
		return sourceDest;
	}
//***********************************************************************************************************************	
	/**
	 * Si se cuenta con información de parámetros requeridos para la ejecución [ARRAY_DATA_PARAMS], se valida que dichos
	 * parámetros existan en la hoja de datos global que está seteada. [globalData] NO es [null].
	 */
	private static String validarParamsInTestData(String sourceData, int rowHeader) throws Exception {

		String msgError = "";
		if (SettingsRun.ARRAY_DATA_PARAMS == null) {
			System.err.println(
				"\n*** NO HAY PARÁMETROS PARA VALIDAR SU EXISTENCIA -- [SettingsRun.ARRAY_DATA_PARAMS] ES NULL");
		}
		else { // if (SettingsRun.ARRAY_DATA_PARAMS != null)
			DataDriven globalTemp = null;
			try {
				if (rowHeader > 1)
					globalTemp = new DataDrivenExcel(sourceData, rowHeader);
				else
					globalTemp = new DataDrivenExcel(sourceData);
				globalTemp.validarParameters(SettingsRun.ARRAY_DATA_PARAMS);
			}
			catch (Exception e) {
				String msgErr = "null"; // PORQUE A NULL NO SE LE PUEDE HACER EL .EQUALS
				if (e.getMessage() != null)
					msgErr = e.getMessage();
				if (msgErr.contains("La hoja de datos no contiene") || msgErr.contains("El archivo de datos no contiene"))
					msgError = "AL ARCHIVO DE DATOS LE FALTAN PARÁMETROS PARA LA EJECUCIÓN :\n\n" + msgErr;
				else
					msgError = "HAY PROBLEMAS CON EL ARCHIVO DE DATOS QUE DESEA CARGAR - REVISE HEADER FILA ["
						+ rowHeader + "]:\n\n" + msgErr;
			}
			if (globalTemp != null)
				globalTemp.liberarData();
		}
		return msgError;
	}
//***********************************************************************************************************************
	// SU CIERRE SE HARÁ EN [SettingsRun]
	private static void askingDataTestTool() throws Exception {

		String testTool = SettingsRun.getProperty(SettingsRun.PROP_TEST_TOOL_NAME, "ALM");
		switch (testTool) {
			case "ALM":
				try {
					Alm.configureTestTool(); // CARGA LA CONFIGURACIÓN DE ALM
				}
				catch (ExceptionInInitializerError e) {
					// NO SE PUDO ESTABLECER CONEXIÓN
					Reporter.write("ALM -- No se pudo establecer conexión, NO se subirán evidencias.");
					SettingsRun.noLoadToTestTool();
					return;
				}
//-----------------------------------------------------------------------------------------------------------------------
				// SI LLEGA A ESTE PUNTO SE PUDO HACER LA CONEXIÓN CON ALM
				try {
					// SE REVISAN LAS PROPIEDADES DE EXEC: SI NO HAY TEST DATA Y NO ES AUTO REPORT O
					// SI HAY TEST DATA PERO NO VIENE EL PARÁMETRO DE TEST SET ID,
					if ((SettingsRun.getTestData() == null && !SettingsRun.AUTO_REPORT)
						|| (SettingsRun.getTestData() != null
							&& !SettingsRun.getTestData().parameterExist(SettingsRun.PARAM_ID_TEST_SET))) {
						
						String testSetId = SettingsRun.getProperty(SettingsRun.PROP_ID_TEST_SET, "");
						List<Integer> listTestSet = Util.getListaDatos(testSetId, ",");
						if (listTestSet.size() == 0) { // NO SE CUENTA CON INFORMACIÓN CORRECTA DE TEST SET ID
							Reporter.write("ALM -- No se cuenta con Test Set ID, por ende, NO se subirán evidencias.");
							SettingsRun.noLoadToTestTool();
							return;
						}
					}
				}
				catch (Exception e) {
					e.printStackTrace(); // NO DEBERÍA SACAR ERROR
				}
			break;
//-----------------------------------------------------------------------------------------------------------------------
			default: // NO ESTÁ DEFINIDA LA HERRAMIENTA
		}
	}
//***********************************************************************************************************************
}
