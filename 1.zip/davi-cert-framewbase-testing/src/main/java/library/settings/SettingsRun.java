package library.settings;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;

import javax.swing.JOptionPane;

import library.common.ProgressWindow;
import library.common.Util;
import library.data.DataDriven;
import library.data.DataDrivenExcel;
import library.data.DataDrivenJSON;
import library.reporting.ExtentReporterNG;
import library.reporting.Reporter;
import library.testTool.alm.Alm;
import library.testTool.alm.AlmConstants;

/**
 * Clase que maneja la información de las ejecuciones a realizar. Usa la clase [DataDriven] para cargar el archivo de
 * datos que se usará como data base.
 * @author szea
 */
public class SettingsRun {

	public static final String INIC_RES = "Res";
	private static final String FOLDER_FILE_EVIDENCE = "_FinalEvidences";
	private static final String FOLDER_BACKUP_EVIDENCE = "_BackupEvidences";
//-----------------------------------------------------------------------------------------------------------------------
	public static boolean CHANGE_USER_AGENT = false; // PONER EN TRUE SI DESEA CAMBIAR EL USER AGENT
	public static final String AUTO_USER_AGENT = "Automation - Depto Certificacion Solucion Tecnica";
//-----------------------------------------------------------------------------------------------------------------------
	// VARIABLES DE CONFIGURACIÓN CON VALORES PRE-ESTABLECIDOS
	public static boolean WITH_INTERFACE = true; // POR DEFECTO MUESTRA LA INTERFAZ (JFRAME) EN JAR MUESTRA CONSOLA
	public static boolean OPEN_FOLDER = true; // ABRE AL FINAL DE LAS EJECUCIONES EL FOLDER DE RESULTADOS
	public static String DATA_SOURCE = "EXCEL"; // POSIBLES VALORES EXCEL / JSON / SIN ARCHIVO
	/**
	 * Por defecto tiene el valor [true] si se pone en [false] la generación del reporte HTML es manejado de forma
	 * directa, y en tal caso se debe invocar el método <b>Reporter.addTestToReport(numIteracion)</b> según se requiera.
	 */
	public static boolean AUTO_REPORT = true; // MANEJA DE FORMA AUTOMÁTICA EL REPORTE FINAL
//-----------------------------------------------------------------------------------------------------------------------
	// VARIABLES MODIFICADAS EN CALIENTE SEGÚN EL LANZAMIENTO: PROPIEDADES O DATOS CARGADOS EN INTERFAZ DE LANZAMIENTO
	public static boolean IS_DEVOPS_LAUNCHER;
	public static String TEST_EXECUTOR = null;
	public static String EXEC_NAME = "Temp"; // NOMBRE POR DEFECTO QUE TENDRÁ LA EJECUCIÓN, SI NO SE SETEA
	/**
	 * Carpeta donde quedan las evidencias. No lleva separador al final
	 */
	public static String RESULT_DIR = "";
	// public static String TEST_DIR = ""; // CARPETA QUE ALOJA LOS RESULT DIR (PARENT DEL RESULT_DIR)
//-----------------------------------------------------------------------------------------------------------------------
	// CONFIGURACIÓN EXCLUSIVA DE LAS PRUEBAS
	// NOMBRE DEL HEADER QUE DARÁ EL NOMBRE AL DIRECTORIO DE EVIDENCIAS
	public static final String PARAM_ID_TEST_SET = "idTestSet";
	public static final String PARAM_ID_TEST_CONF = "testConfigId";
	// public static final String PARAM_TEST_NAME = "nbTestCase";
//-----------------------------------------------------------------------------------------------------------------------
	// INFORMACIÓN PARA LAS PROPIEDADES DE EJECUCIÓN
	private static Properties CONFIG = null;
	private static final String PROP_FOLDER = "properties/";
	private static final String PROP_NB_FILE = "Execution.properties";
	private static String FINAL_PROP_NB_FILE = "";
	private static String SOURCE_PROP_NB_FILE = "";
//-----------------------------------------------------------------------------------------------------------------------
	// PROPIEDADES MÍNIMAS REQUERIDAS:
	// MANEJO DE APPIUM, SE USAN PARA AUTOMATIZACIÓN MOBILE Y ALGUNOS CASOS DE APP DE ESCRITORIO
	public static final String PROP_APPIUM_CONN = "prop.appiumConn"; // LOCAL / REMOTA / FARM (DONDE ESTÁ EL DISPOSITIVO)
	public static final String PROP_APPIUM_PORT = "prop.appiumPort"; // REQUERIDO CUANDO ES LOCAL O PARA APP DE
																		// ESCRITORIO
	public static final String PROP_APPIUM_REMOTE_SERVER = "prop.appiumRemoteServer"; // CUANDO ES REMOTO SE REQUIERE
																						// IP:PORT
	public static final String PROP_APPIUM_DEVICE = "prop.appiumDevice"; // NOMBRE DISPOSITIVO, DEBE COINCIDIR CON EL
																			// EXISTENTE EN EL CATÁLOGO DE DEVICES
	// PARA ALMACENAR EL NOMBRE DEL EJECUTOR DE LA PRUEBA (PARA EVIDENCIAS EN PDF)
	public static final String PROP_TEST_EXECUTOR = "prop.testExecutor";
	// CUANDO ESTA PROPIEDAD SE RECIBE, SE ENVÍA EL REPORTE DE RESULTADOS
	private static final String PROP_TEST_EMAIL = "prop.emailExecutor";
	// INDICA SI SE DESCARGAR DE FORMA AUTOMÁTICA EL DRIVER USANDO [io.github.bonigarcia.wdm.WebDriverManager]
	public static final String PROP_DOWNLOAD_DRIVER = "prop.downloadDriver";
	// INDICA SI SE HACE DESCARGA DE RECURSOS
	public static final String PROP_DOWNLOAD_RESOURCES = "prop.downloadResources";
	// PARA INDICAR SI HAY CONEXIÓN CON UNA HERRAMIENTA DE GESTIÓN DE PRUEBAS PARA CARGAR EVIDENCIAS, HAY OTRAS
	// PROPIEDADES PERO SON USADAS POR EL PROYECTO [TEST TOOL CONN]
	public static final String PROP_LOAD_TEST_TOOL = "prop.doLoadInTestTool";
	public static final String PROP_TEST_TOOL_NAME = "prop.testTool";
	public static final String PROP_ID_TEST_SET = "prop.idTestSet";
	public static final String PROP_ID_TEST_CONF = "prop.testConfigId";
	// PARA EL SCRIPTEO : UTIL PARA RETOMAR SESIONES DE CHROME QUE YA ESTÉN ABIERTAS
	public static final String PROP_WEB_OPENDRIVER = "prop.driverIsOpened";
	public static final String PROP_WEB_CHROMEPORT = "prop.chromePortSession";
	public static final String PROP_WEB_CHROMEPID = "prop.chromePID";
	// PROPIEDADES REQUERIDAS CUANDO NO SE USA INTERFAZ
	public static final String PROP_EXEC_SOURCE = "exec.source";
	public static final String PROP_EXEC_DATAFILE = "exec.dataFile";
	public static final String PROP_EXEC_HEADER = "exec.excelHeader";
	public static final String PROP_EXEC_ITINI = "exec.initIteration";
	public static final String PROP_EXEC_ITFIN = "exec.finalIteration";
	public static final String PROP_EXEC_LISTIT = "exec.iterationList";
	// exec.dataFile // exec.source // exec.dataFile
//-----------------------------------------------------------------------------------------------------------------------
	// PARA EL MANEJO DEL ARCHIVO DE DATOS
	// private static DataDriven globalData = null; // DATOS DE EJECUCIÓN GLOBALES
	private static DataDriven testData = null; // DATOS DE EJECUCIÓN POR ITERACIÓN
	private static int[] datosExec = { 1 }; // ARREGLO DE ENTEROS CON LOS ROW O REGISTROS QUE SERÁN LANZADOS
	private static int totalExec = 1; // TOTAL DE EJECUCIONES A REALIZAR (=datosExec.length)
	private static int currentExec; // EJECUCIÓN ACTUAL, SE USA CUANDO NO SE CUENTA CON [testData]
	// ROW/REG, SU POSICIÓN EN [datosExec]
	private static HashMap<Integer, Integer> dicDato_Pos = new HashMap<Integer, Integer>();
	private static int nextRowBloque = -1; // -1 INDICA QUE NO SE ESTÁ USANDO EJECUCIÓN EN BLOQUE
	private static int prevRowBloque = -1; // -1 INDICA QUE NO SE ESTÁ USANDO EJECUCIÓN EN BLOQUE
	public static int NUM_BLOQUES = 0; // 0 VALOR POR DEFECTO CUANDO NO USA EJECUCIÓN EN BLOQUE
	public static int DEFAULT_HEADER = 1; // VALOR DE LA FILA QUE SE TIENE POR DEFECTO COMO EL HEADER, PUEDE CAMBIAR
//-----------------------------------------------------------------------------------------------------------------------
	// PARÁMETROS QUE SE REQUIEREN ESTÉN INCLUIDOS EN LA DATA
	public static String[] ARRAY_DATA_PARAMS = null;
	// ARCHIVOS DE DATOS QUE SE PUEDEN DESCARGAR - SE USA CUANDO LA EJECUCIÓN ES CON .JAR
	public static String[] DATA_FILES = null;
//-----------------------------------------------------------------------------------------------------------------------	
	private static String loadToTestTool = null; // PARA INTENTAR SUBIR EVIDENCIAS A LA HERRAMIENTA DE GESTIÓN
	private static String LINE_SEP = Util.leftComplete("", 103, '=');
//=======================================================================================================================
	/**
	 * Boolean que indica que la carga del archivo de propiedades debe corresponder al del Launch respectivo o en su
	 * defecto al Execution.properties<br>
	 * Por defecto su valor es [true], poner en [false] cuando se vayan a cargar otros properties, útil cuando se usan
	 * JAR que invocan diferentes Launch y el archivo de properties se carga.
	 */
	public static boolean CARGAR_LAUNCH_PROPERTIES = true;

//***********************************************************************************************************************
	/**
	 * Carga como propiedades de ejecución las existentes en [nbFileProperties].<br>
	 * Deja almacenado en [FINAL_PROP_NB_FILE] el nombre del archivo de propiedades que se tomó y también deja marca en
	 * [CARGAR_LAUNCH_PROPERTIES] con el valor [false].<br>
	 * Usar sólo para casos puntuales donde se llaman en un lanzamiento diferentes TestNG
	 * @author SMZEALO (Sandra Zea)
	 */
	public static void loadNewExecutionProperties(String nbFileProperties) {

		// DEJA MARCA QUE INDICA QUE CARGA OTRO PROPERTIES Y NO EL DE EL LAUNCHER RESPECTIVO
		SettingsRun.CARGAR_LAUNCH_PROPERTIES = false;
		// LO PRIMERO ES DETERMINAR LA RUTA DE LOS RECURSOS - ESTO AYUDA A SABER SI ESTÁ EN LANZAMIENTO CON JAR O IDE
		Util.getFullPathResource(PROP_FOLDER + PROP_NB_FILE);
//-----------------------------------------------------------------------------------------------------------------------
		SOURCE_PROP_NB_FILE = nbFileProperties;
		FINAL_PROP_NB_FILE = nbFileProperties; // OJO NO SE DEBERÍA USAR, PORQUE ES EL NOMBRE SIMPLE
		SettingsRun.CONFIG = new Properties(); // LO RESETEA PARA QUE LO CARGUE DE NUEVO
		try {
			SettingsRun.CONFIG.load(new FileInputStream(nbFileProperties));
		}
		catch (Exception e) {
			e.printStackTrace();
		}
//-----------------------------------------------------------------------------------------------------------------------
		SettingsRun.loadCommonExecutionProperties();
	}
//***********************************************************************************************************************
	/**
	 * Carga las propiedades de ejecución.<br>
	 * Garantiza la carga de variables de ejecución requeridas, independiente de si es lanzamiento por IDE, por JAR o por
	 * DEVOPS.<br>
	 * Deja almacenado en [FINAL_PROP_NB_FILE] el nombre del archivo de propiedades que se tomó.<br>
	 * Se ignora la carga de las propiedades del Launcher respectivo si [CARGAR_LAUNCH_PROPERTIES] es [true]
	 * @author SMZEALO (Sandra Zea)
	 */
	public static void loadExecutionProperties() {

		if (!SettingsRun.CARGAR_LAUNCH_PROPERTIES) {
			if (SettingsRun.CONFIG == null)
				SettingsRun.CONFIG = new Properties();
			return; // TIENE MARCA QUE INDICA NO CARGAR EL PROPERTIES DEL LAUNCH
		}
//-----------------------------------------------------------------------------------------------------------------------
		// LO PRIMERO ES DETERMINAR LA RUTA DE LOS RECURSOS - ESTO AYUDA A SABER SI ESTÁ EN LANZAMIENTO CON JAR O IDE
		Util.getFullPathResource(PROP_FOLDER + PROP_NB_FILE);
//-----------------------------------------------------------------------------------------------------------------------
		// DETERMINA EL NOMBRE DEL ARCHIVO DE PROPIEDADES QUE SE USARÁ :
		// POR DEFECTO SE CREE QUE ES EL DEL LAUNCHER TestNG
		FINAL_PROP_NB_FILE = SettingsRun.EXEC_NAME + "." + SettingsRun.PROP_NB_FILE;
		if (SettingsRun.EXEC_NAME.equals("Temp")) // NO HAY UN LAUNCHER TestNG
			FINAL_PROP_NB_FILE = SettingsRun.PROP_NB_FILE; // TOMA EL ARCHIVO DE PROPIEDADES DEL FRAMEWORK BASE
		else { // HAY UN LAUNCHER TestNG, VALIDA QUE EXISTA EL RESOURCE ASOCIADO AL LAUNCHER
			String resource = Util.getFullPathResource(SettingsRun.PROP_FOLDER + FINAL_PROP_NB_FILE);
			InputStream is = SettingsRun.class.getResourceAsStream(resource);
			if (is == null) // NO EXISTE COMO RESOURCE EL ARCHIVO DE PROPIEDADES, SE CAMBIA AL DEL FRAMEWORK BASE
				FINAL_PROP_NB_FILE = SettingsRun.PROP_NB_FILE; // TOMA EL ARCHIVO DE PROPIEDADES DEL FRAMEWORK BASE
		}
//-----------------------------------------------------------------------------------------------------------------------
		try { // CARGA EL ARCHIVO DE LAS PROPIEDADES
			SettingsRun.CONFIG = new Properties();
			if (Util.isLaunchJAR()) { // EL ARCHIVO DE PROPIEDADES ESTÁ EN LA CARPETA DONDE ESTÁ EL .JAR
				String temp = new File(".").getAbsolutePath(); // VIENE POR EJEMPLO: [C:/Users/userX/Desktop/.]
				String pathTestFilesDir = Util.left(temp, temp.length() - 1); // LE QUITA EL PUNTO FINAL
				String nbFileProperties = pathTestFilesDir + FINAL_PROP_NB_FILE;
				File propFile = new File(nbFileProperties);
				if (!propFile.exists()) // SI NO EXISTE EL ARCHIVO HACE UNA COPIA EN LA MÁQUINA LOCAL
					Util.copyFile(SettingsRun.class, SettingsRun.PROP_FOLDER + FINAL_PROP_NB_FILE, nbFileProperties);
				SettingsRun.CONFIG.load(new FileInputStream(propFile));
				SOURCE_PROP_NB_FILE = nbFileProperties;
			}
			else { // EL LANZAMIENTO ES POR IDE, TOMA EL ARCHIVO DE PROPIEDADES DE LOS RECURSOS DEL PROYECTO JAVA
				String source = Util.getFullPathResource(SettingsRun.PROP_FOLDER + FINAL_PROP_NB_FILE);
				SettingsRun.CONFIG.load(SettingsRun.class.getResourceAsStream(source));
				SOURCE_PROP_NB_FILE = SettingsRun.PROP_FOLDER + FINAL_PROP_NB_FILE;
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
//-----------------------------------------------------------------------------------------------------------------------
		SettingsRun.loadCommonExecutionProperties();
	}
//***********************************************************************************************************************
	/**
	 * Realiza carga común de propiedades, es llamada por 2 métodos.
	 */
	private static void loadCommonExecutionProperties() {

		// DETERMINA SI EL LANZAMIENTO ES POR DEVOPS
		SettingsRun.IS_DEVOPS_LAUNCHER = SettingsRun.getProperty(SettingsRun.PROP_EXEC_SOURCE, "").equals("DEVOPS");
		if (SettingsRun.IS_DEVOPS_LAUNCHER) // CUANDO ES POR DEVOPS, NO HABRÁ INTERFACE
			SettingsRun.WITH_INTERFACE = false;
//-----------------------------------------------------------------------------------------------------------------------
		// PARA LA CONEXIÓN CON LA HERRAMIENTA DE GESTIÓN DE PRUEBAS, SE CAMBIA EL NOMBRE DEL ARCHIVO DE PROPIEDADES
		boolean doLoadTestTool = Boolean.valueOf(SettingsRun.getProperty(SettingsRun.PROP_LOAD_TEST_TOOL, "false"));
		String testTool = SettingsRun.getProperty(SettingsRun.PROP_TEST_TOOL_NAME, "ALM");
		if (doLoadTestTool && testTool.equals("ALM"))
			AlmConstants.changePropertiesFile(FINAL_PROP_NB_FILE);
//-----------------------------------------------------------------------------------------------------------------------
		// GARANTIZA LA CARGA DE LAS CREDENCIALES PARA LOS RECURSOS DE GOOGLE DRIVE Y GMAIL
		SettingsResources.loadResourcesCredential();
	}
//***********************************************************************************************************************
	/**
	 * Retorna el nombre de la fuente usada como archivo de propiedades.<br>
	 * Cuando es lanzamiento JAR es la ruta completa donde queda el archivo (con path), cuando es por IDE el resource.
	 */
	public static String getSourcePropertyFile() {

		return SOURCE_PROP_NB_FILE;
	}
//***********************************************************************************************************************
	/**
	 * Retorna la propiedad correspondiente a "key", que se encuentra almacenada en las propiedades de Ejecución.
	 * @author SMZEALO (Sandra Zea)
	 */
	public static String getProperty(String key) {

		if (SettingsRun.CONFIG == null)
			SettingsRun.loadExecutionProperties();
		return SettingsRun.CONFIG.getProperty(key);
	}
//***********************************************************************************************************************
	/**
	 * Retorna la propiedad correspondiente a "key", que se encuentra almacenada en las propiedades de Ejecución.<br>
	 * Si no se encuentra el retorno será [defaultValue]
	 * @author SMZEALO (Sandra Zea)
	 */
	public static String getProperty(String key, String defaultValue) {

		if (SettingsRun.CONFIG == null)
			SettingsRun.loadExecutionProperties();
		return SettingsRun.CONFIG.getProperty(key, defaultValue);
	}
//***********************************************************************************************************************
	/**
	 * Retorna el dato global correspondiente a "nameDato".<br>
	 * Este dato se encuentra en las propiedades de Ejecución.
	 * @author SMZEALO (Sandra Zea)
	 */
	public static String getGlobalData(String nameDato) {

		return getProperty(nameDato);
	}
//***********************************************************************************************************************
	/**
	 * Retorna el dato global correspondiente a "nameDato".<br>
	 * Este dato se encuentra en las propiedades de Ejecución, retorna [defaultValue] en caso que no se encuentre.
	 * @author SMZEALO (Sandra Zea)
	 */
	public static String getGlobalData(String nameDato, String defaultValue) {

		return getProperty(nameDato, defaultValue);
	}
//***********************************************************************************************************************
	/**
	 * Almacena la propiedad y queda para el lanzamiento actual.<br>
	 * @author SMZEALO (Sandra Zea)
	 */
	public static void setProperty(String key, String value) {

		if (SettingsRun.CONFIG == null)
			SettingsRun.loadExecutionProperties();
		SettingsRun.CONFIG.setProperty(key, value);
	}
//***********************************************************************************************************************
	/**
	 * Almacena como dato global de [nameDato] el valor [value].<br>
	 * @author SMZEALO (Sandra Zea)
	 */
	public static void setGlobalData(String nameDato, String value) {

		SettingsRun.setProperty(nameDato, value);
	}
//***********************************************************************************************************************
	/**
	 * Almacena las propiedades actuales en un archivo con extensión ".copy".<br>
	 * Cuando el lanzamiento es por IDE lo deja almacenado en la carpeta [Util.DIR_BASE_TEMP] <br>
	 * Cuando el lanzamiento es por JAR lo deja almacenado en la misma carpeta donde está el JAR.
	 * @author SMZEALO (Sandra Zea)
	 */
	public static void saveCopyProperties() {

		if (SettingsRun.CONFIG == null) // EN CASO QUE NO SE HAYA CARGADO AÚN
			SettingsRun.loadExecutionProperties();
		try {
			String nbFileProperties = Util.getDirBaseTemp() + SettingsRun.FINAL_PROP_NB_FILE; // POR IDE
			if (Util.isLaunchJAR()) {
				String temp = new File(".").getAbsolutePath(); // VIENE POR EJEMPLO: [C:/Users/userX/Desktop/.]
				String pathTestFilesDir = Util.left(temp, temp.length() - 1); // LE QUITA EL PUNTO FINAL
				nbFileProperties = pathTestFilesDir + SettingsRun.FINAL_PROP_NB_FILE;
			}
			OutputStream fos = new FileOutputStream(nbFileProperties + ".copy");
			SettingsRun.CONFIG.store(fos, null);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
//***********************************************************************************************************************
	/**
	 * Carga la configuración inicial para identificar las ejecuciones que se van a lanzar y el DATASHEET [testData] que
	 * se usará como base para extraer la data, el HEADER empieza en la primera línea del Excel.
	 * @author SMZEALO (Sandra Zea)
	 */
	public static void loadSetting(int rowIni, int rowFin, String sourceData) throws Exception {

		rowIni = validarRowIniConHeader(1, rowIni); // Valida que la fila inicial sea diferente a la fila del Header
		calcularTotalExecs(rowIni, rowFin);
		testData = new DataDrivenExcel(sourceData);
		testData.setCurrentExec(rowIni);
		if (rowFin > testData.getLastExec()) {
			Reporter.write("SettingsRun WARNING -- "
				+ "Se modifica el Row final de ejecución, porque el marcado supera lo existente en la data...");
			rowFin = testData.getLastExec();
			totalExec = rowFin - rowIni + 1; // Cambia el total de ejecuciones
		}
		// INICIA EL ARRAY DE EJECUCIONES, VA DESD EL ROW INDICADO POR [rowIni] HASTA LAS VECES REQUERIDAS [totalExec]
		iniciarArrayExec(rowIni);
		Reporter.write(LINE_SEP);
		Reporter.write(
			"*** ARCHIVO DE DATOS CON HEADER EN ROW [1] - SE EJECUTA DEL ROW [" + rowIni + "] AL [" + rowFin + "]...");
	}
//***********************************************************************************************************************
	/**
	 * Carga la configuración inicial para identificar las ejecuciones que se van a lanzar y el ARCHIVO DE DATOS JSON que
	 * se usará como base para extraer la data.
	 * @author SMZEALO (Sandra Zea)
	 */
	public static void loadSettingJson(int rowIni, int rowFin, String sourceData) throws Exception {

		// NO VALIDA rowIni PORQUE JSON NO TIENE HEADER
		calcularTotalExecs(rowIni, rowFin);
		testData = new DataDrivenJSON(sourceData);
		testData.setCurrentExec(rowIni);
		if (rowFin > testData.getLastExec()) {
			Reporter.write(
				"SettingsRun WARNING -- Se modifica el Registro final de ejecución, porque el marcado supera lo existente en la data...");
			rowFin = testData.getLastExec();
			totalExec = rowFin - rowIni + 1; // Cambia el total de ejecuciones
		}
		// Inicia el Array de ejecuciones, va desde el Row indicado por rowIni hasta las
		// veces requeridas [totalExec]
		iniciarArrayExec(rowIni);
		Reporter.write(LINE_SEP);
		Reporter.write("*** ARCHIVO DE DATOS JSON - SE EJECUTA DEL REGISTRO [" + rowIni + "] AL [" + rowFin + "]...");
	}
//***********************************************************************************************************************
	/**
	 * Carga la configuración inicial para identificar las ejecuciones que se van a lanzar y el DATASHEET [testData] que
	 * se usará como base para extraer la data, el HEADER empieza en una línea del Excel diefrente a la primera.
	 * @author SMZEALO (Sandra Zea)
	 */
	public static void loadSetting(int rowIni, int rowFin, String sourceData, int rowHeader) throws Exception {

		rowIni = validarRowIniConHeader(rowHeader, rowIni); // Valida que la fila inicial sea diferente a la fila del
															// Header
		calcularTotalExecs(rowIni, rowFin);
		testData = new DataDrivenExcel(sourceData, rowHeader);
		testData.setCurrentExec(rowIni);
		if (rowFin > testData.getLastExec()) {
			Reporter.write(
				"SettingsRun WARNING -- Se modifica el Row final de ejecución, porque el marcado superaba lo existente en la data...");
			rowFin = testData.getLastExec();
			totalExec = rowFin - rowIni + 1; // Cambia el total de ejecuciones
		}
		// Inicia el Array de ejecuciones, va desde el Row indicado por rowIni hasta las
		// veces requeridas [totalExec]
		iniciarArrayExec(rowIni);
		Reporter.write(LINE_SEP);
		Reporter.write("*** ARCHIVO DE DATOS CON HEADER EN ROW [" + rowHeader + "] - SE EJECUTA DEL ROW [" + rowIni
			+ "] AL [" + rowFin + "]...");
	}
//***********************************************************************************************************************
	/**
	 * Carga la configuración inicial para identificar las ejecuciones que se van a lanzar, las cuales se reciben en un
	 * array que contiene los ROWS a ejecutar. Se recibe el DATASHEET. [testData] que se usará como base para extraer la
	 * data, el HEADER empieza en la primera línea del Excel.
	 * @author SMZEALO (Sandra Zea)
	 */
	public static void loadSetting(int[] rowsEx, String sourceData) throws Exception {

		calcularTotalExecs(rowsEx[0], rowsEx[rowsEx.length - 1]);
		totalExec = rowsEx.length; // Sobreescribe [totalExec]
		testData = new DataDrivenExcel(sourceData);
		SettingsRun.setearRowsExec(rowsEx, 1); // POBLA [datosExec] Y [dicRow_Pos]
		testData.setCurrentExec(datosExec[0]);
		Reporter.write(LINE_SEP);
		Reporter.write("*** ARCHIVO DE DATOS CON HEADER EN ROW [1] - SE EJECUTAN LOS ROWS ["
			+ Util.arrayToString(datosExec, ", ") + "]...");
	}
//***********************************************************************************************************************
	/**
	 * Carga la configuración inicial para identificar las ejecuciones que se van a lanzar, las cuales se reciben en un
	 * array que contiene los REGISTROS a ejecutar. Se recibe el ARCHIVO DE DATOS JSON.
	 * @author SMZEALO (Sandra Zea)
	 */
	public static void loadSettingJson(int[] rowsEx, String sourceData) throws Exception {

		calcularTotalExecs(rowsEx[0], rowsEx[rowsEx.length - 1]);
		totalExec = rowsEx.length; // Sobreescribe [totalExec]
		testData = new DataDrivenJSON(sourceData);
		SettingsRun.setearRowsExec(rowsEx, 0); // POBLA [datosExec] Y [dicRow_Pos]
		testData.setCurrentExec(datosExec[0]);
		Reporter.write(LINE_SEP);
		Reporter.write(
			"*** ARCHIVO DE DATOS JSON - SE EJECUTAN LOS REGISTROS [" + Util.arrayToString(datosExec, ", ") + "]...");
	}
//***********************************************************************************************************************
	/**
	 * Carga la configuración inicial para identificar las ejecuciones que se van a lanzar y el DATASHEET [testData] que
	 * se usará como base para extraer la data, el HEADER empieza en una línea del Excel diefrente a la primera.
	 * @author SMZEALO (Sandra Zea)
	 */
	public static void loadSetting(int[] rowsEx, String sourceData, int rowHeader) throws Exception {

		calcularTotalExecs(rowsEx[0], rowsEx[rowsEx.length - 1]);
		totalExec = rowsEx.length; // Sobreescribe [totalExec]
		testData = new DataDrivenExcel(sourceData, rowHeader);
		SettingsRun.setearRowsExec(rowsEx, rowHeader); // POBLA [datosExec] Y [dicRow_Pos]
		testData.setCurrentExec(datosExec[0]);
		Reporter.write(LINE_SEP);
		Reporter.write("*** ARCHIVO DE DATOS CON HEADER EN ROW [" + rowHeader + "] - SE EJECUTAN LOS ROWS ["
			+ Util.arrayToString(datosExec, ", ") + "]...");
	}
//***********************************************************************************************************************
	/**
	 * Carga la configuración inicial para identificar el número de ejecuciones que se van a lanzar. No hay DATASHEET
	 * [testData] que se use como base para extraer data.
	 * @author SMZEALO (Sandra Zea)
	 */
	public static void loadSetting(int numExecs) throws Exception {

		calcularTotalExecs(1, numExecs);
		// Inicia el Array de ejecuciones, va desde el Row indicado por rowIni hasta las
		// veces requeridas [totalExec]
		iniciarArrayExec(1);
		Reporter.write("*** SIN ARCHIVO DE DATOS - SE REALIZAN [" + numExecs + "] EJECUCIONES...");
	}
//***********************************************************************************************************************
	/**
	 * Valida que la fila inicial no sea igual a la fila del Header, si lo es, se asume que es una fila más.
	 * @author SMZEALO (Sandra Zea)
	 */
	private static int validarRowIniConHeader(int rowHeader, int rowIni) {

		int rowRetorno = rowIni;
		if (rowHeader == rowIni) {
			Reporter.write(
				"SettingsRun WARNING -- Se incrementa en 1 el Row inicial de ejecución, porque NO puede ser el mismo del Header...");
			rowRetorno++;
		}
		return rowRetorno;
	}
//***********************************************************************************************************************
	/**
	 * Valida que la fila inicial y la final sean coherentes = inicial no puede ser mayor a la final Y si es válido,
	 * carga el total de ejecuciones a realizar.
	 * @author SMZEALO (Sandra Zea)
	 */
	private static void calcularTotalExecs(int rowIni, int rowFin) throws Exception {

		if (rowIni > rowFin)
			throw new Exception("BaseTestERROR -- Wrong execution range...");
		totalExec = rowFin - rowIni + 1;
	}
//***********************************************************************************************************************
	/**
	 * Setea en [datosExec] los rows que se pueden ejecutar (cuando no son secuenciales), y se encarga de poblar
	 * [dicRow_Pos] para identificar en qué posición se encuentra el row requerido.<br>
	 * Requiere haber cargado el [globalData].
	 * @author SMZEALO (Sandra Zea)
	 */
	private static void setearRowsExec(int[] rowsEx, int rowHeader) throws Exception {

		String msgError = "", sep = "";
		List<Integer> finalRowsExec = new ArrayList<Integer>();
		testData.setCurrentExec(rowsEx[0]);
		for (int row : rowsEx) {
			if (row <= rowHeader || row > testData.getLastExec()) {
				msgError += sep + row;
				sep = ", ";
			}
			else
				finalRowsExec.add(row);
		}
//-----------------------------------------------------------------------------------------------------------------------		
		if (msgError.isEmpty()) { // NO HUBO ERRORES : CARGA EL ARRAY DE EJECUCIONES Y POBLA EL [dicRow_Pos]
			datosExec = rowsEx;
			for (int i = 0; i < datosExec.length; i++) {
				dicDato_Pos.put(datosExec[i], i); // ROW Y SU POSICIÓN EN EL [datosExec]
			}
		}
		else { // HAY REGISTROS NO VÁLIDOS : SE ARMA EL ARRAY DE EJECUCIONES Y POBLA EL [dicRow_Pos]
			Reporter
				.write("LoadSettings ERROR -- Se excluyen los registros [" + msgError + "] porque no son válidos...");
			datosExec = new int[finalRowsExec.size()];
			for (int pos = 0; pos < finalRowsExec.size(); pos++) {
				datosExec[pos] = finalRowsExec.get(pos);
				dicDato_Pos.put(datosExec[pos], pos); // ROW Y SU POSICIÓN EN EL [datosExec]
			}
			totalExec = datosExec.length;
		}
	}
//***********************************************************************************************************************
	/**
	 * Carga en el arreglo de Rows a lanzar el número del Row del Excel de datos que se tendrá en cuenta.<br>
	 * Va desde [rowIni] e incrementa de 1 en 1 hasta que se sumen [totalExec] veces.
	 * @author SMZEALO (Sandra Zea)
	 */
	private static void iniciarArrayExec(int rowIni) {

		datosExec = new int[totalExec];
		for (int i = 0; i < totalExec; i++) {
			datosExec[i] = rowIni + i;
			dicDato_Pos.put(datosExec[i], i); // ROW Y SU POSICIÓN EN EL [datosExec]
		}
	}
//***********************************************************************************************************************
	/**
	 * Cambia el arreglo de Rows a lanzar con el número del Row del Excel de datos que se tendrá en cuenta.<br>
	 * Se usa para los lanzamientos que son X Bloque.
	 * @author SMZEALO (Sandra Zea)
	 */
	public static void changeOrderExec(List<Integer> listaExecution) {

		for (int i = 0; i < totalExec; i++) {
			datosExec[i] = listaExecution.get(i);
			dicDato_Pos.put(datosExec[i], i); // ROW Y SU POSICIÓN EN EL [datosExec]
		}
	}
//***********************************************************************************************************************
	/**
	 * Carga la iteración del [rowExcelIteration] indicado, como si fuera la iteración actual.<br>
	 * Si se trata de un [AUTO_REPORT] Hace la adición o carga del reporte HTML correspondiente al [rowExcelIteration]
	 * @author SMZEALO (Sandra Zea)
	 */
	public static void loadIteration(int rowExcelIteration) {

		currentExec = rowExcelIteration;
		if (testData != null)
			testData.setCurrentExec(rowExcelIteration);
		if (SettingsRun.AUTO_REPORT)
			Reporter.addTestToReport(); // ADICIONA LA PRUEBA AL REPORTE HTML
	}
//***********************************************************************************************************************
	/**
	 * Retorna el valor del Excel de la hoja de datos que se está ejecutando.
	 * @author SMZEALO (Sandra Zea)
	 */
	public static int getCurrentIteration() {

		int valRetorno = currentExec;
		if (testData != null)
			valRetorno = testData.getCurrentExec();
		return valRetorno;
	}
//***********************************************************************************************************************
	/**
	 * Este método NO se recomienda usarlo, es para los casos de ejecuciones en bloque, las cuales son usadas sólo por
	 * [BaseTestNG_XBloque].
	 * @author SMZEALO (Sandra Zea)
	 */
	public static void setNextIterationBloque(int nextRow) {

		nextRowBloque = nextRow;
	}
//***********************************************************************************************************************
	/**
	 * Este método NO se recomienda usarlo, es para los casos de ejecuciones en bloque, las cuales son usadas sólo por
	 * [BaseTestNG_XBloque].
	 * @author SMZEALO (Sandra Zea)
	 */
	public static void setPrevIterationBloque(int prevRow) {

		prevRowBloque = prevRow;
	}
//***********************************************************************************************************************
	/**
	 * Indica si la ejecución que se está realizando es en bloque, lo hace cuando los lanzamientos se hace desde clases
	 * que son instancias de [BaseTestNG_XBloque] así no sean directas.
	 * @author SMZEALO (Sandra Zea)
	 */
	public static boolean isExecInBloque() {

		return (nextRowBloque != -1);
	}
//***********************************************************************************************************************
	/**
	 * Retorna el valor del Row del Excel de la hoja de datos Global que se ejecutaría en el siguiente lanzamiento
	 * después de la ejecución actual.<br>
	 * Si no hay una siguiente iteración el retorno es 0.
	 * @author SMZEALO (Sandra Zea)
	 */
	public static int getNextIteration() {

		int valRetorno = 0;
		// SE ESTÁ MANEJANDO EJECUCIÓN EN BLOQUE
		if (nextRowBloque != -1)
			valRetorno = nextRowBloque;
		// SE ESTÁ MANEJANDO EJECUCIÓN NATURAL : ROW TO ROW
		else {
			if (!SettingsRun.esIteracionFinal()) {
				if (dicDato_Pos.containsKey(currentExec)) {
					int posRowExecCurrent = dicDato_Pos.get(currentExec);
					valRetorno = datosExec[posRowExecCurrent + 1];
				}
			}
		}
		return valRetorno;
	}
//***********************************************************************************************************************
	/**
	 * Retorna el valor del Row del Excel de la hoja d edatos que se ejecutó anteriormente a la ejecución actual.<br>
	 * Si no hay una siguiente iteración el retorno es 0.<br>
	 * Solo aplica para las ejecuciones que no son por bloque
	 * @author NYBETANC (Narli Betancourth)
	 */
	public static int getPreviousIteration() {

		int valRetorno = 0;
		// SE ESTÁ MANEJANDO EJECUCIÓN EN BLOQUE
		if (nextRowBloque != -1)
			valRetorno = prevRowBloque;
		// SE ESTÁ MANEJANDO EJECUCIÓN NATURAL : ROW TO ROW
		else {
			if (!SettingsRun.esIteracionInicial()) {
				if (dicDato_Pos.containsKey(currentExec)) {
					int posRowExecCurrent = dicDato_Pos.get(currentExec);
					valRetorno = datosExec[posRowExecCurrent - 1];
				}
			}
		}
		return valRetorno;
	}
//************************************************************************************************************************	
	/**
	 * Retorna el valor del Row del Excel de la hoja de datos que se ejecutaría en el siguiente lanzamiento después del
	 * [rowExec].<br>
	 * Si no hay una siguiente iteración el retorno es 0.
	 * @author SMZEALO (Sandra Zea)
	 */
	public static int getNextIteration(int rowExec) {

		int valRetorno = 0;
		if (rowExec != SettingsRun.getEndIteration()) {
			if (dicDato_Pos.containsKey(rowExec)) {
				int posRowExecCurrent = dicDato_Pos.get(rowExec);
				valRetorno = datosExec[posRowExecCurrent + 1];
			}
		}
		return valRetorno;
	}
//***********************************************************************************************************************
	/**
	 * Retorna el valor del Row que corresponde a la primera iteración (row) que se configuró para ejecutar.
	 * @author SMZEALO (Sandra Zea)
	 */
	public static int getStartIteration() {

		return datosExec[0];
	}
//***********************************************************************************************************************
	/**
	 * Retorna el valor del Row que corresponde a la última iteración (row) que se configuró para ejecutar.
	 * @author SMZEALO (Sandra Zea)
	 */
	public static int getEndIteration() {

		return datosExec[datosExec.length - 1];
	}
//***********************************************************************************************************************
	/**
	 * Retorna el DataDriven de la data de la prueba.
	 * @author SMZEALO (Sandra Zea)
	 */
	public static DataDriven getTestData() {

		return testData;
	}
//***********************************************************************************************************************
	/**
	 * Indica si el manejo de datos se hace a través de archivos de Excel.
	 * @author SMZEALO (Sandra Zea)
	 */
	public static boolean testDataInExcel() {

		boolean isExcel = false;
		if (testData != null)
			isExcel = (testData instanceof DataDrivenExcel);
		return isExcel;
	}
//***********************************************************************************************************************
	/**
	 * Este método termina la ejecución actual de la prueba y continúa con la siguiente prueba, según la información de
	 * las ejecuciones a realizar, la cual se encuentra en [datosExec].<br>
	 * Si la prueba actual es la última, termina la ejecución total.
	 * @author SMZEALO (Sandra Zea)
	 */
	public static void exitTestIteration() throws Exception {

		throw new Exception("BaseTestDONE -- exitTestIteration"); // Para indicar el éxito del [exitTestIteration]
	}
//***********************************************************************************************************************
	/**
	 * Este método se usa en ejecuciones por bloque.<br>
	 * Termina la ejecución del bloque actual, en la iteración en la que vaya, permitiendo que continúe con la ejecución
	 * del siguiente bloque.
	 * @author SMZEALO (Sandra Zea)
	 */
	public static void exitCurrentBloque() throws Exception {

		throw new Exception("BaseTestDONE -- exitCurrentBloque");
	}
//***********************************************************************************************************************
	/**
	 * Método que termina la ejecución de la prueba, de forma total, dejando el explorador de Windows abierto en la
	 * carpeta de resultados de la ejecución.<br>
	 * Se usa para casos en donde se desea terminar de manera voluntaria, sin que implique una falla.
	 * @author SMZEALO (Sandra Zea)
	 * @throws MalformedURLException
	 */
	public static void exitTest() {

		if (!Reporter.loadTestStatusFinalXBloque()) // RETORNA [true] SI ES LANZAMIENTO X BLOQUE
			Reporter.setTestStatus(null); // EN LANZAMIENTO QUE NO ES POR BLOQUE DEJA EL ESTADO COMO ESTÉ LA EJECUCIÓN
		Reporter.generateLaunchReport(); // PARA QUE GENERE EL REPORTE FINAL DE RESULTADOS DEL LANZAMIENTO
		Reporter.writeTitle(
			"\n******************** SE TERMINAN LANZAMIENTOS ... HORA (" + Util.hourToString("HH:mm:ss") + ")");
		SettingsRun.destroyAll();
		Reporter.pickupSoftAssert(); // PARA QUE RECOJA TODOS LOS ASSERT SOFT QUE SE HAYAN GENERADO
		SettingsRun.terminateRun();
		if (Boolean.valueOf(SettingsRun.getGlobalData("prop.requiresEvidenceVideo", "false"))) {
			/* try { Evidence.stopRecording(); } catch (MalformedURLException e) { // TODO Auto-generated catch block
			 * e.printStackTrace(); } */
		}
		System.exit(0);
	}
//***********************************************************************************************************************
	/**
	 * Método que termina la ejecución de la prueba, de forma total, presentando como mensaje [exitMsg], dejando el
	 * explorador de Windows abierto en la carpeta de resultados de la ejecución.<br>
	 * Al usar este método, se reporta un evento de [Reporter.MIC_NOT_COMPLETED].
	 * @author SMZEALO (Sandra Zea)
	 * @throws MalformedURLException
	 */
	public static void exitTest(String exitMsg) {

		// PARA QUE INDIQUE EN EL REPORTE DE EVIDENCIAS (SI ES ARCHIVO) QUE NO SE COMPLETÓ
		Reporter.reportEvent(Reporter.MIC_NOT_COMPLETED, exitMsg);
		if (!Reporter.loadTestStatusFinalXBloque()) // RETORNA [true] SI ES LANZAMIENTO X BLOQUE
			Reporter.setTestStatus("NOT COMPLETED"); // EN LANZAMIENTO QUE NO ES POR BLOQUE INDICA NOT COMPLETED
		Reporter.generateLaunchReport(); // PARA QUE GENERE EL REPORTE FINAL DE RESULTADOS DEL LANZAMIENTO
		Reporter.writeTitle(
			"\n******************** SE TERMINAN LANZAMIENTOS ... HORA (" + Util.hourToString("HH:mm:ss") + ")");
		SettingsRun.destroyAll();
		// 4to PARÁMETRO: INFORMATION_MESSAGE, WARNING_MESSAGE, QUESTION_MESSAGE, PLAIN_MESSAGE, ERROR_MESSAGE
		JOptionPane.showMessageDialog(null, "EN CASO DE REQUERIRLO INFORME AL EQUIPO DE AUTOMATION\n\n" + exitMsg + "\n",
			"EXIT TEST", JOptionPane.ERROR_MESSAGE);
		Reporter.pickupSoftAssert(); // PARA QUE RECOJA TODOS LOS ASSERT SOFT QUE SE HAYAN GENERADO
		SettingsRun.terminateRun();
		if (Boolean.valueOf(SettingsRun.getGlobalData("prop.requiresEvidenceVideo", "false"))) {
			/* try { Evidence.stopRecording(); } catch (MalformedURLException e) { // TODO Auto-generated catch block
			 * e.printStackTrace(); } */
		}
		System.exit(0);
	}
//***********************************************************************************************************************
	/**
	 * Método que retorna una matriz de objetos[nx1], del tamaño de la data.<br>
	 * Retorna las iteraciones a ejecutar. Util para manejo de pruebas con TestNG.
	 * @author SMZEALO (Sandra Zea)
	 */
	public static Object[][] loadDataProvider() {

		Object[][] data = new Object[totalExec][1];
		for (int row = 0; row < totalExec; row++) {
			data[row][0] = datosExec[row];
		}
		return data;
	}
//***********************************************************************************************************************
	/**
	 * Garantiza la liberación del archivo que se uso como hoja de datos.
	 * @author SMZEALO (Sandra Zea)
	 */
	public static void liberarData() {

		if (testData != null)
			testData.liberarData();
	}
//***********************************************************************************************************************
	/**
	 * Retorna el nombre del directorio padre del [RESULT_DIR]<br>
	 * Si no hay [RESULT_DIR] el retorno es el directorio temporal<br>
	 * El retorno lleva el último separador.
	 * @author SMZEALO (Sandra Zea)
	 */
	public static String getParentResultDir() {

		String parentResultDir;
		if (RESULT_DIR.isEmpty())
			parentResultDir = new File(Util.getDirBaseTemp()).getParent() + File.separator + ".AUTDAV_EVIDENCES"
				+ File.separator + "Temp" + File.separator;
		else
			parentResultDir = new File(RESULT_DIR).getParent() + File.separator;
		return parentResultDir;
	}
//***********************************************************************************************************************
	/**
	 * Retorna el nombre del directorio en donde deberían quedar almacenadas las evidencias finales de las pruebas, en el
	 * formato respectivo, según el Tipo de Evidencia (archivo PDF, archivo .zip)<br>
	 * El retorno NO es garantía de que el folder exista.<br>
	 * El retorno lleva el último separador.
	 * @author SMZEALO (Sandra Zea)
	 */
	public static String getFinalEvidencesDir() {

		String tempFinalEvidencesDir;
		if (RESULT_DIR.isEmpty())
			tempFinalEvidencesDir = SettingsRun.getParentResultDir();
		else
			tempFinalEvidencesDir = SettingsRun.RESULT_DIR + File.separator;
		return tempFinalEvidencesDir + SettingsRun.FOLDER_FILE_EVIDENCE + File.separator;
	}
//***********************************************************************************************************************
	/**
	 * Retorna el nombre del directorio en donde deberían quedar almacenadas las evidencias finales de backup de las
	 * pruebas, en el formato .DOCX<br>
	 * El retorno NO es garantía de que el folder exista.<br>
	 * El retorno lleva el último separador.
	 * @author SMZEALO (Sandra Zea)
	 */
	public static String getBackupEvidencesDir() {

		String tempFinalEvidencesDir;
		if (RESULT_DIR.isEmpty())
			tempFinalEvidencesDir = SettingsRun.getParentResultDir();
		else
			tempFinalEvidencesDir = SettingsRun.RESULT_DIR + File.separator;
		return tempFinalEvidencesDir + SettingsRun.FOLDER_BACKUP_EVIDENCE + File.separator;
	}
//***********************************************************************************************************************
	/**
	 * Retorna el nombre del directorio en donde se pueden almacenar archivos relacionados a lo que deja la prueba,
	 * retorna uno de los siguientes valores, dependiendo de si el lanzamiento se hace desde el IDE o desde JAR:<br>
	 * - <b>user.home / Base_Evidence / nbClase / </b><br>
	 * - <b>path donde está el JAR / Base_Evidence / nbClase / </b><br>
	 * Note que SÍ lleva el último separador.
	 * @author SMZEALO (Sandra Zea)
	 */
	private static String getTestDirSugerido() {

		String separator = System.getProperty("file.separator");
		String pathTestFilesDir;
		if (!Util.isLaunchJAR())// LANZAMIENTO EN IDE
			pathTestFilesDir = System.getProperty("user.home") + separator;
		else { // LANZAMIENTO CON JAR
			String temp = new File(".").getAbsolutePath(); // VIENE POR EJEMPLO: [C:/Users/userX/Desktop/.]
			pathTestFilesDir = Util.left(temp, temp.length() - 1); // LE QUITA EL PUNTO FINAL
		}
		pathTestFilesDir += ".AUTDAV_EVIDENCES" + separator + EXEC_NAME + separator;
		return pathTestFilesDir;
	}
//***********************************************************************************************************************
	/**
	 * Retorna el directorio que se sugiere, para que allí sean cargadas las evidencias de ejecución.
	 * @author SMZEALO (Sandra Zea)
	 */
	public static String getResultDirSugerido() {

		// ALISTA LA CARPETA EN DONDE SE DEBEN ALMACENAR LAS EVIDENCIAS
		String dirEvid = SettingsRun.getTestDirSugerido();
		File directory = new File(dirEvid);
		if (!directory.exists())
			directory.mkdir();
		File dirTemp;
		String numberRes;
		int result = 1;
		// RECORRE LA INFORMACIÓN DE ARCHIVOS Y CAPERTAS EXISTENTES, PARA DETECTAR CUÁL ES EL SIGUIENTE [Res] A GENERAR
		String[] listado = directory.list();
		if (listado != null) {
			for (int i = 0; i < listado.length; i++) {
				if (listado[i].startsWith(SettingsRun.INIC_RES)) {
					numberRes = Util.right(listado[i], listado[i].length() - SettingsRun.INIC_RES.length());
					if (Util.isInteger(numberRes)) {
						dirTemp = new File(dirEvid + listado[i]);
						if (dirTemp.isDirectory()) {
							if (result <= Integer.valueOf(numberRes))
								result = Integer.valueOf(numberRes) + 1;
						}
					}
				}
			}
		}
		return (dirEvid + SettingsRun.INIC_RES + result);
	}
//***********************************************************************************************************************
	/**
	 * Indica si se está en la primera iteración.
	 * @author SMZEALO (Sandra Zea)
	 */
	public static boolean esIteracionInicial() {

		boolean esItInicial;
		// SE ESTÁ MANEJANDO EJECUCIÓN EN BLOQUE
		if (nextRowBloque != -1)
			esItInicial = (prevRowBloque == 0);
		// SE ESTÁ MANEJANDO EJECUCIÓN NATURAL : ROW TO ROW
		else
			esItInicial = (SettingsRun.getCurrentIteration() == SettingsRun.getStartIteration());
		return esItInicial;
	}
//***********************************************************************************************************************
	/**
	 * Indica si se está en la última iteración.
	 * @author SMZEALO (Sandra Zea)
	 */
	public static boolean esIteracionFinal() {

		boolean esItFinal;
		// SE ESTÁ MANEJANDO EJECUCIÓN EN BLOQUE
		if (nextRowBloque != -1)
			esItFinal = (nextRowBloque == 0);
		// SE ESTÁ MANEJANDO EJECUCIÓN NATURAL : ROW TO ROW
		else
			esItFinal = (SettingsRun.getCurrentIteration() == SettingsRun.getEndIteration());
		return esItFinal;
	}
//***********************************************************************************************************************
	/**
	 * Cambia los datos existentes en el parámetro [nameParameter] por [newValue], desde el row actual hasta el último,
	 * desde que el registro cuente con los valores indicados en [valCondicion] en sus parámetros [paramsCondicion]<br>
	 * [paramsCondicion] y [valCondicion] deben ser Arrays del mismo tamaño, el uno representa los parámetros a buscar y
	 * el otro los valores a buscar.
	 * @author SMZEALO (Sandra Zea)
	 */
	public static void changeData(String[] paramsCondicion, String[] valCondicion, String nameParameter, String newValue)
		throws Exception {

		if (testData == null)
			return;
		int row, posRowExecCurrent = dicDato_Pos.get(currentExec); // POSICIÓN DESDE DONDE DEBE RECORRER LA DATA
		String valueData;
		boolean rowCumpleCond;
		for (int posRowExec = posRowExecCurrent; posRowExec < datosExec.length; posRowExec++) {
			row = datosExec[posRowExec];
			rowCumpleCond = (paramsCondicion.length > 0);
			for (int posArr = 0; posArr < paramsCondicion.length; posArr++) {
				valueData = testData.getParameterByExec(paramsCondicion[posArr], row);
				rowCumpleCond = rowCumpleCond && valueData.equals(valCondicion[posArr]);
				if (!rowCumpleCond)
					break; // ROMPE EL CICLO
			}
			// SI EL ROW CUMPLE LAS CONDICIONES, DEEB HACER EL CAMBIO DEL DATO
			if (rowCumpleCond)
				testData.setParameterByExec(nameParameter, row, newValue);
		}
	}
//***********************************************************************************************************************
	/**
	 * Método que retorna si por configuración de la ejecución (según la data), es posible subir a la herramienta de
	 * gestión de pruebas la ejecución y así mismo la carga de evidencias.
	 * @author SMZEALO (Sandra Zea)
	 */
	public static boolean doLoadToTestTool() {

		if (loadToTestTool == null) {
			// REVISA LA PROPIEDAD [doLoadInTestTool] SI NO VIENE SE ASUME QUE NO SUBE A HERRAMIENTA
			boolean doLoadTestTool = Boolean.valueOf(SettingsRun.getProperty(SettingsRun.PROP_LOAD_TEST_TOOL, "false"));
			if (doLoadTestTool) {
				doLoadTestTool = false; // SE INICIALIZA DE NUEVO
				List<Integer> listaTestId;
				// SI HAY [testData] Y EXISTE EL PARÁMETRO DEL [Reporter.PARAM_TESTID]: SE PODRÍA CARGAR LA EJECUCIÓN,
				// SI ALGUNA DE LAS ITERACIONES QUE SE LANZAN CUENTAN CON VALOR NUMÉRICO EN DICHO PARÁMETRO
				if (SettingsRun.testData != null) {
					if (SettingsRun.testData.parameterExist(SettingsRun.PARAM_ID_TEST_CONF)) {
						try {
							for (int posRow = 0; posRow < datosExec.length; posRow++) {
								listaTestId = Util.getListaDatos(SettingsRun.getTestData()
									.getParameterByExec(SettingsRun.PARAM_ID_TEST_CONF, datosExec[posRow]), ",");
								doLoadTestTool = (listaTestId.size() > 0);
								if (doLoadTestTool)
									break; // TERMINA EL CICLO
							}
						}
						catch (Exception e) {
							e.printStackTrace(); // NO LLEGA, POR ESO SE PREGUNTA SI [parameterExist]
						}
					}
				}
				else if (!SettingsRun.AUTO_REPORT) { // CUANDO NO HAY TEST_DATA Y NO ES AUTO_REPORT
					// PUEDE SER LANZAMIENTO QUE TENGA EL DATO DEL [testConfigId] EN LAS PROPIEDADES DE EJECUCIÓN
					String testConfId = SettingsRun.getProperty(SettingsRun.PROP_ID_TEST_CONF, "");
					if (testConfId != null) {
						listaTestId = Util.getListaDatos(testConfId, ",");
						doLoadTestTool = (listaTestId.size() > 0);
					}
				}
			}
			loadToTestTool = String.valueOf(doLoadTestTool);
		}
		return Boolean.valueOf(loadToTestTool);
	}
//***********************************************************************************************************************
	/**
	 * Se marca de manera directa que NO se cargarán pruebas en la herramienta de gestión de pruebas.<br>
	 * Por lo general se usa cuando no se pudo hacer la conexión, entonces se debe indicar de manera directa que no haga
	 * carga en la herramienta.
	 */
	public static void noLoadToTestTool() {

		loadToTestTool = String.valueOf("false");
	}
//***********************************************************************************************************************
	/**
	 * Método que hace la liberación general de las configuraciones de ejecución:<br>
	 * - Libera la Hoja de datos de prueba.<br>
	 * - Cierra conexión con ALM si la hay.
	 * @author SMZEALO (Sandra Zea)
	 */
	public static void destroyAll() {

		SettingsRun.liberarData(); // SALVA Y LIBERA [DataGobal] SI EXISTE
		if (ProgressWindow.isOpened()) // SI QUEDÓ ABIERTA UNA PANTALLA DE PROGRESS LA CIERRA
			ProgressWindow.closeProgressWindow();
		try {
			String testTool = SettingsRun.getProperty(SettingsRun.PROP_TEST_TOOL_NAME, "ALM");
//-----------------------------------------------------------------------------------------------------------------------
			// SU APERTURA SE HIZO EN [SettingsWindow]
			switch (testTool) {
				case "ALM":
					Alm.closeSession();
				break;

				default: // NO ESTÁ DEFINIDA LA HERRAMIENTA
			}
//-----------------------------------------------------------------------------------------------------------------------
		}
		catch (Exception e) {}
	}
//***********************************************************************************************************************
	/**
	 * Este método se encarga de:<br>
	 * 1. Enviar correo de respuesta al email de ejecución (si existe).<br>
	 * 2. Deja abierto en el explorador de windows la carpeta que contiene los resultados de ejecución.
	 * @author SMZEALO (Sandra Zea)
	 */
	public static void terminateRun() {

		// ENVÍA CORREO DE RESPUESTA DE LA EJECUCIÓN, SI SE CUENTA CON EL EMAIL Y TIENE ESTRUCTURA VÁLIDA
		String email = SettingsRun.getProperty(SettingsRun.PROP_TEST_EMAIL, "");
		if (Util.isEmailValid(email)) {
			String subject = "DAV Automation - Fin ejecución [" + SettingsRun.EXEC_NAME + "]";
			String content = "Se informa que la ejecución de las pruebas, lanzadas a través de la automatización, ha finalizado.";
			try {
				if (new File(ExtentReporterNG.getPathReport()).exists()) {
					content += "\nRevisar el resultado en el archivo adjunto";
					SettingsResources.sendEmail(email, subject, content, ExtentReporterNG.getPathReport());
				}
				else // NO HAY ARCHIVO DE RESULTADOS, SÓLO SE AVISA QUE TERMINÓ
					SettingsResources.sendEmail(email, subject, content);
			}
			catch (Exception e) {} // NO HACE NADA SI HUBO ERROR
		}
//-----------------------------------------------------------------------------------------------------------------------
		// DEJA ABIERTO WINDOWS EN LA CARPETA DE RESULTADO, SI NO ES DEVOPS Y SE [OPEN_FOLDER] ES [true]
		if (SettingsRun.IS_DEVOPS_LAUNCHER || !SettingsRun.OPEN_FOLDER)
			return; // NO ABRE EL FOLDER
		try {
			if (!SettingsRun.RESULT_DIR.isEmpty())
				new ProcessBuilder(Util.getSistemaOperativo().contains("MAC") ? "open" : "explorer.exe",
					SettingsRun.RESULT_DIR).start();
		}
		catch (IOException e) {}
	}
//***********************************************************************************************************************
}