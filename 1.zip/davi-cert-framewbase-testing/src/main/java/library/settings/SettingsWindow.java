package library.settings;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.List;
import java.util.NoSuchElementException;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.filechooser.FileFilter;
import javax.swing.filechooser.FileNameExtensionFilter;

import library.common.ConsoleWindow;
import library.common.Util;
import library.data.DataDriven;
import library.data.DataDrivenExcel;
import library.reporting.Reporter;
import library.testTool.alm.Alm;

/**
 * Clase que maneja el frame JAVA para solicitar la configuración del lanzamiento.<br>
 * Usa la clase [SettingsRun] para hacer el cargue de la configuración.
 * @author szea
 */
@SuppressWarnings("serial")
public class SettingsWindow extends JFrame implements ActionListener {

	private static final String NB_DOWNLOAD_ICON = "icons/IMGdownload";
	private static final String NB_DOWNLOAD_ICON_TXT = "icons/IMGlogoProv"; // ESTÁ EN UtilCommon
	String valHeader, dataFile = null;
	JRadioButton radExcel, radJson, radSinArch;
	JLabel labelGeneral;
	JRadioButton radio1, radio2;
	ButtonGroup grupoRadArchivo, grupoDeRadios;
	JTextField rowInic, rowFin, rows, header, nbDataFile, nbDirEvid;
	JButton botonOk, botonCancel, btArchDat, btDirEvid, btDownload;
	private boolean thereIsException = false;
	private static String msgException = null;
	private boolean isJsonFile = false;
	private boolean esLaunchPorIde, isSinArchivo = false; // SE USA SÓLO CUANDO ES LANZAMIENTO POR JAR
	private boolean configurationDone = false;
	boolean showWarningXExisteDirEvid = true; // INDICA QUE DEBE MOSTRAR ALERTA POR DIRECTORIO DE EVIDENCIAS EXISTENTE
	static boolean showWarningSinParamsToVal = true; // INDICA QUE DEBE MOSTRAR ALERTA SI NO HAY PARÁMETROS PARA VALIDAR

//=======================================================================================================================	
	public SettingsWindow() {

		super("CONFIGURACIÓN EJECUCIÓN...");
		esLaunchPorIde = !Util.isLaunchJAR(); // INDICA SI EL LANZAMIENTO ES POR IDE, SI NO, ES POR JAR
		isSinArchivo = SettingsRun.DATA_SOURCE.equals("SIN ARCHIVO");
		valHeader = String.valueOf(SettingsRun.DEFAULT_HEADER);
		int alto = 360;
		if (!esLaunchPorIde && isSinArchivo)
			alto = 200;
		if (!esLaunchPorIde && !isSinArchivo)
			this.isJsonFile = SettingsRun.DATA_SOURCE.equals("JSON");
		// PARA QUE EL BOTÓN DE CLOSE NO SIRVA : [JFrame.DO_NOTHING_ON_CLOSE] - PARA QUE CIERRE : [JFrame.EXIT_ON_CLOSE]
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setResizable(false); // PARA QUE NO PUEDA MAXIMIZAR LA VENTANA
		setIconImage(Util.getImageEncode(NB_DOWNLOAD_ICON_TXT));
		setSize(360, alto); // ancho, alto
		setLocationRelativeTo(null); // Pone la ventana en el centro
		getContentPane().setLayout(null);
		iniciarComponentes();
	}
//***********************************************************************************************************************	
	// MÉTODO QUE ARMA LA FORMA QUE SE PRESENTA
	private void iniciarComponentes() {

		int y0 = 20, y1 = 80, y2 = 110, y3 = 130, y4 = 175, y5 = 215, y6 = 260;
		JLabel labelEvid = new JLabel("Directorio de Evidencias");
		labelEvid.setBounds(30, y0, 150, 20);
		nbDirEvid = new JTextField(SettingsRun.getResultDirSugerido());
		nbDirEvid.setToolTipText("Seleccionar directorio evidencias");
		nbDirEvid.setBounds(30, y0 + 20, 251, 30);
		btDirEvid = new JButton();
		btDirEvid.setText("...");
		btDirEvid.setBounds(281, y0 + 20, 29, 29);
		btDirEvid.addActionListener(this);
//-----------------------------------------------------------------------------------------------------------------------
		// RADIO BUTTONS DE ARCHIVO A USAR, NO SE MOSTRARÁ CUANDO ES LANZAMIENTO CON JAR
		radExcel = new JRadioButton("Arch.Excel", true);
		radExcel.setBounds(30, y1, 95, 30); // x, y, ancho, alto
		radExcel.addActionListener(this);
		radJson = new JRadioButton("Arch.Json", true);
		radJson.setBounds(130, y1, 90, 30); // x, y, ancho, alto
		radJson.addActionListener(this);
		grupoRadArchivo = new ButtonGroup();
		grupoRadArchivo.add(radExcel);
		grupoRadArchivo.add(radJson);
		radSinArch = new JRadioButton("Sin Archivo", true);
		radSinArch.setBounds(225, y1, 90, 30); // x, y, ancho, alto
		radSinArch.addActionListener(this);
		grupoRadArchivo.add(radSinArch);
//-----------------------------------------------------------------------------------------------------------------------
		if (!esLaunchPorIde) { // LANZAMIENTO DESDE JAR
			if (isSinArchivo)
				y6 = 100;
			else { // ES CON ARCHIVO
				labelGeneral = new JLabel("LANZAMIENTO USA ARCHIVO " + SettingsRun.DATA_SOURCE);
				labelGeneral.setForeground(Color.BLUE);
				labelGeneral.setBounds(30, y1, 240, 20);
				Image img = Util.getImageEncode(NB_DOWNLOAD_ICON);
				Image newImg = img.getScaledInstance(29, 29, Image.SCALE_SMOOTH);
				btDownload = new JButton(new ImageIcon(newImg));
				btDownload.setBounds(281, y1, 29, 29);
				btDownload.setBorder(BorderFactory.createEmptyBorder()); // Quita el borde del botón
				btDownload.setContentAreaFilled(false); // Quita el filled del botón
				btDownload.setToolTipText("Descargar Archivo de Datos");
				btDownload.setCursor(new Cursor(Cursor.HAND_CURSOR));
				btDownload.addActionListener(this);
			}
		}
//-----------------------------------------------------------------------------------------------------------------------
		JLabel labelArch = new JLabel("Header   Archivo de Datos");
		if (!esLaunchPorIde && this.isJsonFile)
			labelArch = new JLabel("Archivo de Datos"); // ES POR .JAR Y ARCHIVO JSON
		labelArch.setBounds(30, y2, 250, 20);
		header = new JTextField(valHeader);
		header.setBounds(30, y3, 40, 30);
		header.setEnabled(true);
		if (!esLaunchPorIde)
			header.setEnabled(false);
//-----------------------------------------------------------------------------------------------------------------------
		if (dataFile == null)
			dataFile = SettingsRun.getProperty(SettingsRun.PROP_EXEC_DATAFILE, "");
		nbDataFile = new JTextField(dataFile);
		nbDataFile.setToolTipText("Seleccionar el archivo de datos");
		nbDataFile.setBounds(70, y3, 211, 30);
		if (!esLaunchPorIde && this.isJsonFile)
			nbDataFile.setBounds(30, y3, 251, 30);
		btArchDat = new JButton();
		btArchDat.setText("...");
		btArchDat.setBounds(281, y3, 29, 29);
		btArchDat.addActionListener(this);
		radio1 = new JRadioButton("Dar rango ejecución", true);
		radio1.setBounds(30, y4, 170, 30); // x, y, ancho, alto
		radio1.addActionListener(this);
		rowInic = new JTextField();
		rowInic.setBounds(205, y4, 40, 30);
		rowInic.setEnabled(true);
		JLabel label = new JLabel(" - ");
		label.setBounds(250, y4, 10, 30);
		rowFin = new JTextField();
		rowFin.setBounds(270, y4, 40, 30);
		rowFin.setEnabled(true);
		radio2 = new JRadioButton("Rows separados por \",\"");
		radio2.setBounds(30, y5, 170, 30);
		radio2.addActionListener(this);
		rows = new JTextField();
		rows.setBounds(205, y5, 105, 30);
		rows.setEnabled(false);
		rows.setBackground(Color.LIGHT_GRAY);
		grupoDeRadios = new ButtonGroup();
		grupoDeRadios.add(radio1);
		grupoDeRadios.add(radio2);
		botonOk = new JButton();
		botonOk.setText("OK");
		botonOk.setBounds(30, y6, 110, 40);
		botonOk.addActionListener(this);
		botonCancel = new JButton();
		botonCancel.setText("Cancelar");
		botonCancel.setBounds(200, y6, 110, 40);
		botonCancel.addActionListener(this);
//-----------------------------------------------------------------------------------------------------------------------
		add(labelEvid);
		add(nbDirEvid);
		add(btDirEvid);
		if (esLaunchPorIde) { // CUANDO ES POR IDE:
			add(radExcel);
			add(radJson);
			add(radSinArch);
			add(labelArch);
			add(header);
			add(nbDataFile);
			add(btArchDat);
			add(radio1);
			add(rowInic);
			add(label);
			add(rowFin);
			add(radio2);
			add(rows);
		}
		else if (!isSinArchivo) { // CUANDO ES POR JAR Y ES CON ARCHIVO
			add(labelGeneral); // add(btDownload); // MUESTRA BOTÓN DE DESCARGA ARCHIVO DE DATOS
			radExcel.setSelected(true);
			radJson.setSelected(false);
			radSinArch.setSelected(false);
			add(labelArch);
			add(nbDataFile);
			add(btArchDat);
			if (!this.isJsonFile) // ES ARCHIVO EXCEL
				add(header);
			else { // ES ARCHIVO JSON
				header.setText("");
				radExcel.setSelected(false);
				radJson.setSelected(true);
			}
			add(radio1);
			add(rowInic);
			add(label);
			add(rowFin);
			add(radio2);
			add(rows);
		}
		else { // CUANDO ES POR JAR Y ES SIN ARCHIVO VA DIRECTO AL "OK" Y "CANCELAR"
			header.setText("");
			nbDataFile.setText("");
			radExcel.setSelected(false);
			radJson.setSelected(false);
			radSinArch.setSelected(true);
			radio1.setSelected(false);
			rowInic.setText("");
			rowFin.setText("");
			radio2.setSelected(true);
			rows.setText("1"); // POR DEFECTO 1 EJECUCIÓN
		}
		add(botonOk);
		add(botonCancel);
	}
//***********************************************************************************************************************
	/**
	 * Acciones a realizar dependiendo del evento presentado.
	 */
	public void actionPerformed(ActionEvent e) {

		String root;
//----------------------------------------------------------------------------------------------------------------------- 
		if (e.getSource() == botonOk) { // DA CLICK EN ELBOTÓN "OK"
			try {
				if (directoryIsValid()) {
					if (this.loadSetting()) {
						dispose(); // CIERRA LA VENTANA
						configurationDone = true; // PUEDE CERRAR LA VENTANA PORQUE SE HIZO LA CARGA
					}
				}
			}
			catch (Exception e1) {
				thereIsException = true; // PUEDE CERRAR LA VENTANA PORQUE HUBO ERROR
				msgException = e1.getMessage();
				e1.printStackTrace();
			}
//----------------------------------------------------------------------------------------------------------------------- 
		}
		else if (e.getSource() == botonCancel) { // DA CLICK EN EL BOTÓN "CANCELAR"
			System.out.println("*** EJECUCIÓN CANCELADA...");
			System.exit(0);
//----------------------------------------------------------------------------------------------------------------------- 
		}
		else if (e.getSource() == radio1) { // SELECCIONA EL RADIO1 - DAR RANGO DE EJECUCIÓN
			rowInic.setEnabled(true);
			rowInic.setBackground(Color.WHITE);
			rowFin.setEnabled(true);
			rowFin.setBackground(Color.WHITE);
			rows.setEnabled(false);
			rows.setBackground(Color.LIGHT_GRAY);
			rows.setText("");
//----------------------------------------------------------------------------------------------------------------------- 
		}
		else if (e.getSource() == radio2) { // SELECCIONA EL RADIO2 - ROWS SEPARADOS / TOTAL EJECUCIONES
			radio2Selected();
//----------------------------------------------------------------------------------------------------------------------- 
		}
		else if (e.getSource() == radio1) { // SELECCIONA EL RADIO1 - DAR RANGO DE EJECUCIÓN
			rowInic.setEnabled(true);
			rowInic.setBackground(Color.WHITE);
			rowFin.setEnabled(true);
			rowFin.setBackground(Color.WHITE);
			rows.setEnabled(false);
			rows.setBackground(Color.LIGHT_GRAY);
			rows.setText("");
//----------------------------------------------------------------------------------------------------------------------- 
		}
		else if (e.getSource() == radExcel) { // SE DA CLICK EN EL CHECK BOX DE ARCHIVO EXCEL
			this.isJsonFile = false;
			header.setEnabled(true);
			header.setText(valHeader);
			header.setBackground(Color.WHITE);
			nbDataFile.setEnabled(true);
			nbDataFile.setText(dataFile);
			nbDataFile.setBackground(Color.WHITE);
			btArchDat.setEnabled(true);
			radio1.setEnabled(true);
			radio2.setText("Rows separados por \",\"");
//----------------------------------------------------------------------------------------------------------------------- 
		}
		else if (e.getSource() == radJson) { // SE DA CLICK EN EL CHECK BOX DE ARCHIVO JSON
			this.isJsonFile = true;
			header.setEnabled(false);
			header.setText("");
			header.setBackground(Color.LIGHT_GRAY);
			nbDataFile.setEnabled(true);
			nbDataFile.setText(dataFile);
			nbDataFile.setBackground(Color.WHITE);
			btArchDat.setEnabled(true);
			radio1.setEnabled(true);
			radio2.setText("Regs separados por \",\"");
//----------------------------------------------------------------------------------------------------------------------- 
		}
		else if (e.getSource() == radSinArch) { // SE DA CLICK EN EL CHECK BOX DE SIN ARCHIVO
			this.isJsonFile = false;
			header.setEnabled(false);
			header.setText("");
			header.setBackground(Color.LIGHT_GRAY);
			nbDataFile.setEnabled(false);
			nbDataFile.setText("");
			nbDataFile.setBackground(Color.LIGHT_GRAY);
			btArchDat.setEnabled(false);
			radio1.setEnabled(false);
			radio2.setSelected(true);
			radio2Selected();
			radio2.setText("Total ejecuciones");
			rows.setText("1"); // POR DEFECTO 1 EJECUCIÓN
//----------------------------------------------------------------------------------------------------------------------- 
		}
		else if (e.getSource() == btArchDat) { // DA CLICK PARA CARGAR EL ARCHIVO DE DATOS
			root = nbDataFile.getText().trim();
			if (root.isEmpty())
				root = "C:\\";
			JFileChooser fileChooser = new JFileChooser(root);
			fileChooser.setApproveButtonText("Seleccionar");
			fileChooser.setDialogTitle("Archivo de Datos");
			fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY); // SÓLO ARCHIVOS
			FileFilter filtro = new FileNameExtensionFilter("Archivos excel", "xls", "xlsx"); // FILTRO DE EXCEL
			if (this.isJsonFile)
				filtro = new FileNameExtensionFilter("Archivos JSON", "json"); // FILTRO DE JSON
			fileChooser.setFileFilter(filtro);
			int seleccion = fileChooser.showOpenDialog(fileChooser);
			if (seleccion == JFileChooser.APPROVE_OPTION)
				nbDataFile.setText(fileChooser.getSelectedFile().getAbsolutePath());
//----------------------------------------------------------------------------------------------------------------------- 
		}
		else if (e.getSource() == btDirEvid) { // DA CLICK PARA CARGAR EL DIRECTORIO DE EVIDENCIAS
			root = nbDirEvid.getText().trim();
			if (root.isEmpty())
				root = "C:\\";
			JFileChooser fileChooser = new JFileChooser(".");
			fileChooser.setApproveButtonText("Seleccionar");
			fileChooser.setDialogTitle("Directorio Evidencias");
			fileChooser.setFileFilter(null);
			fileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY); // SÓLO CARPETAS
			int seleccion = fileChooser.showOpenDialog(fileChooser);
			if (seleccion == JFileChooser.APPROVE_OPTION)
				nbDirEvid.setText(fileChooser.getSelectedFile().getAbsolutePath());
//----------------------------------------------------------------------------------------------------------------------- 
		}
		else if (e.getSource() == btDownload) { // DA CLICK EN EL BOTÓN DE DESCARGA DE ARCHIVO DE DATOS
			if (SettingsRun.DATA_FILES == null || SettingsRun.DATA_FILES.length == 0) {
				JOptionPane.showMessageDialog(null, "No hay archivos de Datos para descargar", "ALERTA...",
					JOptionPane.WARNING_MESSAGE);
			}
			else
				this.downloadFile(SettingsRun.DATA_FILES);
		}
	}
//***********************************************************************************************************************	
	public void radio2Selected() {

		rowInic.setEnabled(false);
		rowInic.setBackground(Color.LIGHT_GRAY);
		rowFin.setEnabled(false);
		rowFin.setBackground(Color.LIGHT_GRAY);
		rows.setEnabled(true);
		rows.setBackground(Color.WHITE);
		rowInic.setText("");
		rowFin.setText("");
	}
//***********************************************************************************************************************
	private boolean directoryIsValid() {

		String dirEvid = nbDirEvid.getText().trim();
		boolean isValid = false;
		if (dirEvid.isEmpty())
			JOptionPane.showMessageDialog(null, "Se debe ingresar el 'Directorio de Evidencias'",
				"ERROR DE CONFIGURACIÓN", JOptionPane.ERROR_MESSAGE);
		else
			isValid = true;
		return isValid;
	}
//***********************************************************************************************************************
	/**
	 * Intenta cargar la configuración.<br>
	 * Si el retorno es [true] es porque se hizo sin errores, en caso contrario es porque no se pudo realizar.
	 */
	private boolean loadSetting() throws Exception {

		String msgErr = "";
		int ini = 0, fin = 0, numExecs = 0, datoInt;
		int[] rowsEx = new int[0];
		String dato, sourceData = "";
//-----------------------------------------------------------------------------------------------------------------------
		// DETERMINA EL VALOR DEL HEADER
		dato = header.getText().trim();
		int rowHeader = SettingsRun.DEFAULT_HEADER;
		if (Util.isInteger(dato))
			rowHeader = Integer.valueOf(dato);
		if (this.isJsonFile)
			rowHeader = 0; // NO HAY HEADER
//-----------------------------------------------------------------------------------------------------------------------
		if (radio1.isSelected()) { // Se tiene rango
			dato = rowInic.getText().trim();
			if (!Util.isInteger(dato))
				msgErr = "El rango inicial debe ser un número entero.";
			else {
				ini = Integer.valueOf(dato);
				if (ini < rowHeader + 1)
					msgErr = "El rango inicial mínimo debe ser " + (rowHeader + 1)
						+ "\nEl header del archivo de datos está en la fila " + rowHeader;
				else { // Rango inicial es correcto
					dato = rowFin.getText().trim();
					if (!Util.isInteger(dato))
						msgErr = "El rango final debe ser un número entero.";
					else {
						fin = Integer.valueOf(dato);
						if (fin < ini)
							msgErr = "El rango final debe ser MAYOR O IGUAL al inicial.";
					}
				}
			}
//-----------------------------------------------------------------------------------------------------------------------
		}
		else if (radio2.isSelected()) {
			dato = rows.getText().trim();
			String msgTipo = "Rows";
			if (radJson.isSelected())
				msgTipo = "Registros";
			if (dato.isEmpty()) {
				msgErr = "No se ingresó información del total de ejecuciones a realizar.";
				if (radExcel.isSelected() || radJson.isSelected())
					msgErr = "No se ingresó información de los " + msgTipo + " a ejecutar.";
			}
			else if (radExcel.isSelected() || radJson.isSelected()) { // Hay información de rows se genera el Array
																		// [rowsEx]
				try {
					List<Integer> listNumRow = Util.getListaDatos(dato, ",");
					rowsEx = new int[listNumRow.size()];
					for (int pos = 0; pos < listNumRow.size(); pos++) {
						datoInt = listNumRow.get(pos);
						if (datoInt == rowHeader && !this.isJsonFile) { // ES ARCHIVO DE EXCEL
							msgErr = "Dentro de los Rows a ejecutar, no puede estar el Row Header - Revisar.";
							break;
						}
						if (Util.itemInArray(datoInt, rowsEx)) {
							msgErr = "Dentro de los Rows a ejecutar, se está repitiendo el [" + datoInt + "] - Revisar.";
							break;
						}
						rowsEx[pos] = datoInt;
					}
				}
				catch (Exception e) {
					msgErr = "Se encontró un dato que NO es un número entero - Revisar.";
				}
//-----------------------------------------------------------------------------------------------------------------------
			}
			else if (radSinArch.isSelected()) { // NO HAY INFORMACIÓN DE ROWS, SE DETERMINA EL TOTAL DE EJECUCIONES
				if (!Util.isInteger(dato))
					msgErr = "El TOTAL de ejecuciones a realizar debe ser un número entero.";
				else {
					numExecs = Integer.valueOf(dato);
					if (numExecs == 0)
						msgErr = "Se requiere un TOTAL de ejecuciones MAYOR a cero (0).";
				}
			}
		}
//-----------------------------------------------------------------------------------------------------------------------
		// NO HUBO ERROR Y ES CON ARCHIVO DE DATOS:
		if (msgErr.isEmpty() && (radExcel.isSelected() || radJson.isSelected())) {
			dato = header.getText().trim();
			if (this.isJsonFile)
				dato = "0"; // NO HAY HEADER
			if (!Util.isInteger(dato))
				msgErr = "El row del Header debe ser un número entero.";
			else {
				rowHeader = Integer.valueOf(dato);
				if (rowHeader < 1 && !this.isJsonFile)
					msgErr = "El row del Header mínimo debe ser 1.";
				else {
					sourceData = nbDataFile.getText().trim();
					if (sourceData.isEmpty())
						msgErr = "NO se ha ingresado el archivo de datos a usar.";
					else {
						File file = new File(sourceData);
						if (!file.exists()) {
							// REVISA PORQUE PUEDE SER UN ARCHIVO DE DATOS DEL DRIVE: INTENTA DESCARGARLO DEL DRIVE
							try {
								sourceData = SettingsResources
									.getFullPathGDriveFile(SettingsResources.BASE_EXEC_DATA + sourceData);
							}
							catch (NoSuchElementException e) {
								msgErr = "El archivo de datos indicado NO EXISTE.";
							}
						}
						else if (file.isDirectory())
							msgErr = "El archivo de datos indicado NO ES ARCHIVO.";
					}
				}
			}
			// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
			// VALIDAR QUE LOS PARÁMETROS ESPERADOS EXISTAN EN EL ARCHIVO DE DATOS CARGADO
			if (msgErr.isEmpty() && !sourceData.isEmpty())
				msgErr = validarParamsInTestData(sourceData, rowHeader);
		}
//-----------------------------------------------------------------------------------------------------------------------
		if (msgErr.isEmpty()) { // SI NO HAY ERROR SE PUEDE HACER LA CONFIGURACIÓN
			// 1-SE CREA EL DIRECTORIO DE EVIDENCIAS
			String dirEvid = nbDirEvid.getText().trim();
			boolean dirExiste = Util.directoryExist(dirEvid);
			if (dirExiste && showWarningXExisteDirEvid)
				Reporter.write(
					"\n*** DIRECTORIO DE EVIDENCIAS YA EXISTE... SE REEMPLAZARÁ LO EXISTENTE Y SE ADICIONARÁN LAS NUEVAS EVIDENCIAS");
			else if (!dirExiste) { // NO EXISTE, SE CREA
				File directory = new File(dirEvid);
				directory.mkdirs();
				showWarningXExisteDirEvid = false; // COMO SE CREÓ - SI VUELVE A ESTE PUNTO PARA QUE NO MUESTRE ALERTA
			}
			SettingsRun.RESULT_DIR = dirEvid;
			ConsoleWindow.PATH_LOG = SettingsRun.RESULT_DIR + System.getProperty("file.separator") + "_CONSOLE_LOG.txt";
			// 2-SI NO HAY ARCHIVO DE DATOS, SÓLO SE CUENTA CON EL TOTAL DE EJECUCIONES:
			if (sourceData.isEmpty())
				SettingsRun.loadSetting(numExecs);
			else { // EXISTE ARCHIVO
					// 2-SE COPIA EL ARCHIVO DE DATOS AL DIRECTORIO DE EVIDENCIAS
				sourceData = copySource(dirEvid, sourceData);
				// 3-SE HACE CARGA DE LA CONFIGURACIÓN PARA ARCHIVO JSON O EXCEL SEGÚN SEA EL CASO
				try {
					if (this.isJsonFile) {
						if (ini != 0)
							SettingsRun.loadSettingJson(ini, fin, sourceData);
						else
							SettingsRun.loadSettingJson(rowsEx, sourceData);
					}
					else {
						if (rowHeader > 1) {
							if (ini != 0)
								SettingsRun.loadSetting(ini, fin, sourceData, rowHeader);
							else
								SettingsRun.loadSetting(rowsEx, sourceData, rowHeader);
						}
						else {
							if (ini != 0)
								SettingsRun.loadSetting(ini, fin, sourceData);
							else
								SettingsRun.loadSetting(rowsEx, sourceData);
						}
					}
				}
				catch (ExceptionInInitializerError | IllegalArgumentException e) {
					msgErr = e.getMessage();
					new File(sourceData).delete(); // DEBE BORRAR EL ARCHIVO PARA QUE LO VUELVA A COPIAR
				}
			}
		}
//-------------------------------------------------------------------------------------------------------------------
		if (msgErr.isEmpty())
			Reporter.write("*** EVIDENCIAS ALMACENADAS EN [" + SettingsRun.RESULT_DIR + "]...");
		else
			JOptionPane.showMessageDialog(null, msgErr, "ERROR DE CONFIGURACIÓN", JOptionPane.ERROR_MESSAGE);
		return msgErr.isEmpty(); // SI EL ERROR ES EMPTY SE HIZO LA CARGA DE CONFIGURACIÓN
	}
//***********************************************************************************************************************
	/**
	 * Retorna el nombre del archivo completo en donde se almacena la fuente de datos.
	 */
	private String copySource(String dirEv, String source) throws IOException {

		File archOrig = new File(source);
		String sourceDest = dirEv + System.getProperty("file.separator") + archOrig.getName();
		// EN CASO QUE EL ARCHIVO SOURCE DE DESTINO EXISTA, GARANTIZA QUE ESTÉ CERRADO
		if (new File(sourceDest).exists()) {
			boolean fileIsLocked;
			do {
				fileIsLocked = Util.fileIsLocked(sourceDest);
				if (fileIsLocked)
					JOptionPane.showMessageDialog(null,
						"El siguiente archivo se encuentra abierto:\n" + sourceDest + "\n\nCiérrelo antes de continuar.",
						"ERROR DE CONFIGURACIÓN", JOptionPane.INFORMATION_MESSAGE);
			} while (fileIsLocked);
		}
//-----------------------------------------------------------------------------------------------------------------------
		if (!source.equals(sourceDest)) { // SI ORIGEN Y DESTINO SON DIFERENTES PUEDE HACER LA COPIA
			Path origenPath = Paths.get(source);
			Path destinoPath = Paths.get(sourceDest);
			// SOBREESCRIBIR EL ARCHIVO DE DESTINO SI EXISTE, Y LO COPIA
			Files.copy(origenPath, destinoPath, StandardCopyOption.REPLACE_EXISTING);
		}
		return sourceDest;
	}
//***********************************************************************************************************************	
	/**
	 * Retorna si se presentó Exception.
	 */
	public boolean getThereIsException() {

		return this.thereIsException;
	}
//***********************************************************************************************************************	
	/**
	 * Retorna si se hizo la configuracióm.
	 */
	public boolean getConfigurationDone() {

		return this.configurationDone;
	}
//***********************************************************************************************************************	
	/**
	 * Se puede cerrar la ventana si hubo Exception o si se hizo la configuración
	 */
	public boolean canCloseWindow() {

		return (this.thereIsException || this.configurationDone);
	}
//***********************************************************************************************************************	
	public static void launch() {

		SettingsWindow window = new SettingsWindow();
		window.setVisible(true);
		do { // ESPERA MIENTRAS NO SE PUEDA CERRAR LA VENTANA DE CONFIGURACIÓN
			Util.wait(1);
		} while (!window.canCloseWindow());
		// SI HUBO ERROR EN LA CONFIGURACIÓN, NO PUEDE HACER NADA, SE SALE DEL TEST
		if (window.getThereIsException())
			SettingsRun.exitTest("Exception en [SettingsWindow]\n" + msgException);
//-----------------------------------------------------------------------------------------------------------------------		
		// SI EL LANZAMIENTO FUE CORRECTO, SE EVALÚA SI LAS PRUEBAS SE CARGAN A LA HERRAMIENTA, EN TAL CASO MUESTRA
		// LA VENTANA QUE PIDE LOS DATOS DE LOGUEO PARA EL ALM Y ADICIONAL EL TEST SET ID
		if (SettingsRun.doLoadToTestTool())
			SettingsWindow.askingDataTestTool();
	}
//***********************************************************************************************************************	
	/**
	 * Si se cuenta con información de parámetros requeridos para la ejecución [ARRAY_DATA_PARAMS], se valida que dichos
	 * parámetros existan en la hoja de datos global que está seteada. [globalData] NO es [null].
	 */
	private static String validarParamsInTestData(String sourceGlobal, int rowHeader) throws Exception {

		String msgError = "";
		if (SettingsRun.ARRAY_DATA_PARAMS == null && showWarningSinParamsToVal) {
			System.err.println(
				"\n*** NO HAY PARÁMETROS PARA VALIDAR SU EXISTENCIA -- [SettingsRun.ARRAY_DATA_PARAMS] ES NULL");
			showWarningSinParamsToVal = false; // YA MOSTRÓ ALERTA, PARA QUE NO VUELVA A MOSTRARLA
		}
		else if (SettingsRun.ARRAY_DATA_PARAMS != null) {
			DataDriven globalTemp = null;
			try {
				if (rowHeader > 1)
					globalTemp = new DataDrivenExcel(sourceGlobal, rowHeader);
				else
					globalTemp = new DataDrivenExcel(sourceGlobal);
				globalTemp.validarParameters(SettingsRun.ARRAY_DATA_PARAMS);
			}
			catch (Exception e) {
				String msgErr = "null"; // PORQUE A NULL NO SE LE PUEDE HACER EL .EQUALS
				if (e.getMessage() != null)
					msgErr = e.getMessage();
				if (msgErr.contains("La hoja de datos no contiene")
					|| msgErr.contains("El archivo de datos no contiene"))
					msgError = "AL ARCHIVO DE DATOS LE FALTAN PARÁMETROS PARA LA EJECUCIÓN :\n\n" + msgErr;
				else
					msgError = "HAY PROBLEMAS CON EL ARCHIVO DE DATOS QUE DESEA CARGAR - REVISE HEADER FILA ["
						+ rowHeader + "]:\n\n" + msgErr;
				// LA
			}
			if (globalTemp != null)
				globalTemp.liberarData();
		}
		return msgError;
	}
//***********************************************************************************************************************
	/**
	 * Intenta descargar los archivos [sourceFiles] que deben existir en los "resources" del proyecto, en el directorio
	 * que se indique a través de un "JFileChooser".
	 */
	private void downloadFile(String... sourceFiles) {

		try {
			String root = "C:\\";
			JFileChooser fileChooser = new JFileChooser(root);
			fileChooser.setApproveButtonText("Seleccionar");
			fileChooser.setDialogTitle("Directorio Descarga");
			fileChooser.setFileFilter(null);
			fileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY); // SÓLO CARPETAS
			// fileChooser.setSelectedFile(new File(root + nbFile));
			int seleccion = fileChooser.showSaveDialog(fileChooser);
			if (seleccion == JFileChooser.APPROVE_OPTION) {
				String directory = fileChooser.getSelectedFile().getAbsolutePath();
				int answer = JOptionPane.showConfirmDialog(null, "Se descargarán los archivos de datos.\n"
					+ "En caso que existan se sobreescribirán.\n\n" + "¿Desea continuar?", "DESCARGA ARCHIVO DE DATOS",
					JOptionPane.YES_NO_OPTION);
				if (answer == JOptionPane.NO_OPTION)
					return; // NO HACE NADA
				String[] arrTempDir;
				String separator;
				for (String sourceFile : sourceFiles) {
					separator = System.getProperty("file.separator");
					if (sourceFile.contains("/"))
						separator = "/";
					arrTempDir = sourceFile.split(separator);
					String destino = directory + System.getProperty("file.separator")
						+ arrTempDir[arrTempDir.length - 1];
					// DESCARGA EL ARCHIVO
					InputStream src = Util.getResourceAsStream(sourceFile);
					Path destinoPath = Paths.get(destino);
					try {
						Files.copy(src, destinoPath, StandardCopyOption.REPLACE_EXISTING);
						src.close();
					}
					catch (java.nio.file.AccessDeniedException e) {
						JOptionPane.showMessageDialog(null, "Acceso Denegado!!!\nRevise la ruta de destino.");
					}
				}
				new ProcessBuilder("explorer.exe", directory).start(); // ABRE LA CARPETA DONDE QUEDARON LOS ARCHIVOS
			}
		}
		catch (Exception e) {
			Util.showExceptionInFrame(e);
			e.printStackTrace();
		}
	}
//***********************************************************************************************************************
	// SU CIERRE SE HARÁ EN [SettingsRun]
	private static void askingDataTestTool() {

		String testTool = SettingsRun.getProperty(SettingsRun.PROP_TEST_TOOL_NAME, "ALM");
		switch (testTool) {
			case "ALM":
				try {
					Alm.configureTestToolJFrame(); // SOLICITA LA CONFIGURACIÓN DE ALM
					// SE REVISAN LAS PROPIEDADES DE EXEC: SI NO HAY TEST DATA Y NO ES AUTO REPORT O
					// SI HAY TEST DATA PERO NO VIENE EL PARÁMETRO DE TEST SET ID,
					if ((SettingsRun.getTestData() == null && !SettingsRun.AUTO_REPORT)
						|| (SettingsRun.getTestData() != null
							&& !SettingsRun.getTestData().parameterExist(SettingsRun.PARAM_ID_TEST_SET))) {
						String testSetId = SettingsRun.getProperty(SettingsRun.PROP_ID_TEST_SET, "");
						List<Integer> listTestSet = Util.getListaDatos(testSetId, ",");
						if (listTestSet.size() == 0) { // NO SE CUENTA CON INFORMACIÓN CORRECTA DE TEST SET ID
							do {
								testSetId = (String) (JOptionPane.showInputDialog(null,
									"ID del TestSet donde se\ncargarán las evidencias", "TESTSET ID",
									JOptionPane.INFORMATION_MESSAGE, null, null, testSetId));
								if (testSetId != null) // ES [null] SI CANCELA
									listTestSet = Util.getListaDatos(testSetId, ",");
							} while (listTestSet.size() == 0);
							// GARANTIZA QUE DEJA EL DATO EN LOS PROPERTIES
							SettingsRun.setProperty(SettingsRun.PROP_ID_TEST_SET, Util.listToString(listTestSet, ","));
						}
					}
				}
				catch (Exception e) {
					e.printStackTrace(); // NO DEBERÍA SACAR ERROR
				}
			break;

//-----------------------------------------------------------------------------------------------------------------------
			default: // NO ESTÁ DEFINIDA LA HERRAMIENTA
			break;
		}
	}
//***********************************************************************************************************************
}
