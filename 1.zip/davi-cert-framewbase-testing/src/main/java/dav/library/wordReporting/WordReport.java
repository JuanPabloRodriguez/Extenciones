package dav.library.wordReporting;

//import client.library.reporting.ReportTemplateType;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import library.common.Util;
import library.reporting.Evidence;

import static dav.library.wordReporting.WordReportConstants.*;

import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.List;
import java.io.File;

public class WordReport {

    private final List<String> stepTableHeaders = Arrays.asList(DESCRIPTION_HEADER, EXPECTEDRESULTS_HEADER);
    //ACTUALRESULTS_HEADER);
    private WordTable wordTable;
    private int stepNumber;

    protected final Logger log = LogManager.getLogger(this);

    /**
     * Constructor
     *
     * @param outFileName
     */
    public WordReport(String outFileName, String templateName) throws FileNotFoundException {
        //ReportTemplateType reportTemplateType = ReportTemplateType.get(templateName);
    	// TAB_INICIO = Ayuda a reconocer la tabla que contiene dicho texto para instanciarla
        wordTable = new WordTable(outFileName, TAB_INICIO, templateName);
        stepNumber = 1;
    }

    public String getFullReportPath() {
    	return wordTable.getFullReportPath();
    }
    
    /**
     * Updates Table with Overall Report description
     *
     * @param param
     * @param input
     */
    public void setGeneralTableParam(String param, String input) {
        if (input != null) {
            wordTable.replaceAll(param, input);
        } else {
            wordTable.replaceAll(param, "");
        }
    }

    /**
     * Updates Table with Overall Report description
     *
     * @param param
     * @param input
     */
    public void setGeneralTableParam(String param, boolean input) {
        if (input) {
            wordTable.replaceAll(param, "True");
        } else {
            wordTable.replaceAll(param, "False");
        }
    }

    /**
     * Creates/Updates the Test Step Table in Report
     *
     * @param scenarioDesc
     * @param expectedRes
     * @param stepStatus
     * @param fileName
     */
    public void addStepToTable(String scenarioDesc, String expectedRes, String stepStatus, String fileNameAdd) {
        if (wordTable.checkTableExists()) {
            addOverviewRow(stepNumber, stepStatus);
            addTablesHeaders();
            addResultsRow(scenarioDesc, expectedRes, fileNameAdd);
            wordTable.addBordersTable();
            stepNumber++;
        } else {
            log.warn("Test Steps Table was Not Found in Word Report Template");
        }
    }

    public void addStepToTable(String scenarioDesc, String expectedRes, String stepStatus, String[] arrFilesNameAdd) {
        if (wordTable.checkTableExists()) {
            addOverviewRow(stepNumber, stepStatus);
            addTablesHeaders();
            addResultsRow(scenarioDesc, expectedRes, arrFilesNameAdd);
            wordTable.addBordersTable();
            stepNumber++;
        } else {
            log.warn("Test Steps Table was Not Found in Word Report Template");
        }
    }

    public void addImages(String[] arrFilesNameAdd) {
    	
    	String simpleName, title, time;
    	java.util.Date fechaHora;
        for (String fileNameAdd : arrFilesNameAdd) {
            if (!fileNameAdd.isEmpty()) {
            	simpleName = new File(fileNameAdd).getName();
            	if (Evidence.TITLE_WITH_TIME) {
            		try {
						fechaHora = Util.stringToDate(Util.left(simpleName, Evidence.TAM_PREFIJO-2), "yyyymmddHHmmss");
						time = Util.dateToString(fechaHora, "dd/mm/yyyy") + " " + Util.hourToString(fechaHora, "HH:mm:ss");
					}
					catch (Exception e) { // NO DEBERÍA PASAR - NOS ASEGURAMOS QUE NO ENTRA
						time = "";
					}
            		title = "(" + time + ") " // (DD/MM/YYYY HH:MM:SS) XXXXXXXXX
            			+ Util.right(simpleName, simpleName.length()-Evidence.TAM_PREFIJO).replace(".png", "");
            	}
            	else
            		title = Util.right(simpleName, simpleName.length()-Evidence.TAM_PREFIJO).replace(".png", "");
            	wordTable.writeBold(title);
            	wordTable.addImage(fileNameAdd);
            }
		}
    }
    
    /**
     * Initializes TestStep Table
     *
     * @param stepNumber
     * @param stepStatus
     */
    private void addOverviewRow(int stepNumber, String stepStatus) {
        if (wordTable.getLastRow() > 0)
            wordTable.addNewRow();

        int lastTableRow = wordTable.getLastRow();

        wordTable.setCellText(getStepColumnText(stepNumber, lastTableRow));
        wordTable.colorRow(lastTableRow, 0, wordTable.getNumberOfRowColumns(lastTableRow), BANORTE_STEP);
        wordTable.setCellText(getStepStatusColumnText(stepStatus, lastTableRow));
    }

    private TableRowDetail getStepStatusColumnText(String stepStatus, int lastTableRow) {
        String fontColor;

        if (stepStatus.equalsIgnoreCase(PASSED)) {
            fontColor = WHITE;
        } else if (stepStatus.equalsIgnoreCase(FAILED)) {
            fontColor = YELLOW;
        } else {
            fontColor = YELLOW;
        }

        return new TableRowDetail(lastTableRow,
                1,
                ARIAL,
                FONT_SIZE,
                fontColor,
                String.format("%s", stepStatus),
                true,
                false);
    }

    private TableRowDetail getStepColumnText(int stepNumber, int lastTableRow) {
        return new TableRowDetail(lastTableRow,
                0,
                ARIAL,
                FONT_SIZE,
                WHITE,
                String.format("Step %d", stepNumber),
                true,
                false);
    }

    /**
     * Adds Test step Headers for each step in report
     */
    private void addTablesHeaders() {
        int cellsCounter = 0;
        wordTable.addNewRow();
        int lastTableRow = wordTable.getLastRow();

        //wordTable.colorRow(lastTableRow, 0, wordTable.getNumberOfRowColumns(lastTableRow), BLUE_HEADERS);
        wordTable.colorRow(lastTableRow, 0, wordTable.getNumberOfRowColumns(lastTableRow), BANORTE_HEADERS);
        //BANORTE_HEADERS
        wordTable.centerRowText(lastTableRow);

        for (String key : stepTableHeaders) {
            wordTable.setCellText(new TableRowDetail(lastTableRow,
                    cellsCounter,
                    ARIAL,
                    FONT_SIZE,
                    WHITE,
                    key,
                    true,
                    false));
            cellsCounter++;
        }
    }

    /**
     * Adds Test step details for each step in report
     *
     * @param scenarioDesc
     * @param expectedRes
     * @param actualRes
     * @param fileName
     */
    private void addResultsRow(String scenarioDesc, String expectedRes, String fileNameAdd) {
        wordTable.addNewRow();
        int lastTableRow = wordTable.getLastRow();

        wordTable.setCellText(new TableRowDetail(lastTableRow, 0, ARIAL, FONT_SIZE, BLACK, scenarioDesc, false, false));
        wordTable.setCellText(new TableRowDetail(lastTableRow, 1, ARIAL, FONT_SIZE, BLACK, expectedRes, false, false));
        if (!fileNameAdd.isEmpty()) {
            wordTable.addNewRow();
            wordTable.mergeCell(lastTableRow + 1);
            wordTable.addImageToCell(lastTableRow + 1, 0, fileNameAdd);
        }
    }

    private void addResultsRow(String scenarioDesc, String expectedRes, String[] arrFilesNameAdd) {
        wordTable.addNewRow();
        int lastTableRow = wordTable.getLastRow();

        wordTable.setCellText(new TableRowDetail(lastTableRow, 0, ARIAL, FONT_SIZE, BLACK, scenarioDesc, false, false));
        wordTable.setCellText(new TableRowDetail(lastTableRow, 1, ARIAL, FONT_SIZE, BLACK, expectedRes, false, false));
        
        int addRow = 1;
        for (String fileNameAdd : arrFilesNameAdd) {
            if (!fileNameAdd.isEmpty()) {
                wordTable.addNewRow();
                wordTable.mergeCell(lastTableRow + addRow);
                wordTable.addImageToCell(lastTableRow + addRow, 0, fileNameAdd);
                addRow++;
            }
		}
    }
    
    public String saveDocument() {

        return wordTable.saveDocument();
    }
}
