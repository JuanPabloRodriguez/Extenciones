package dav.library.wordReporting;

public class TableRowDetail {
    private final int row;
    private final int cell;
    private final String fontFamily;
    private final int fontSize;
    private final String colorRGB;
    private final String text;
    private final boolean bold;
    private final boolean addBreak;

    /**
     * @param cell
     * @param fontFamily
     * @param fontSize
     * @param colorRGB
     * @param text
     * @param bold
     * @param addBreak
     */
    public TableRowDetail(int row, int cell, String fontFamily, int fontSize, String colorRGB, String text, boolean bold, boolean addBreak) {
        this.row = row;
        this.cell = cell;
        this.fontFamily = fontFamily;
        this.fontSize = fontSize;
        this.colorRGB = colorRGB;
        this.text = text;
        this.bold = bold;
        this.addBreak = addBreak;
    }

    public int getRow() {
        return row;
    }

    public int getCell() {
        return cell;
    }

    public String getFontFamily() {
        return fontFamily;
    }

    public int getFontSize() {
        return fontSize;
    }

    public String getColorRGB() {
        return colorRGB;
    }

    public String getText() {
        return text;
    }

    public boolean isBold() {
        return bold;
    }

    public boolean isAddBreak() {
        return addBreak;
    }
}
