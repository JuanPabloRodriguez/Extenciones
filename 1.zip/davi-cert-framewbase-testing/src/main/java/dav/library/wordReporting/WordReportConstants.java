package dav.library.wordReporting;

public class WordReportConstants {

    public static final String TESTCASE_NAME         = "tcName";
    public static final String TESTCASE_CREATIONDATE = "tcCreationDate";
    public static final String TESTCASE_DESIGNER     = "tcDesigner";
    public static final String TESTCASE_STATUS       = "tcStatus";
    public static final String TAB_INICIO            = "tabInicio";

    public static final String DESCRIPTION_HEADER     = "Descripción";
    public static final String EXPECTEDRESULTS_HEADER = "Resultado Esperado";
    //public static final String ACTUALRESULTS_HEADER = "Actual Result";

    public static final String ARIAL = "Arial";

    public static final String BLUE = "000066";
    public static final String GREEN = "00B050";
    public static final String RED = "ff0000";
    public static final String YELLOW = "FFFF00";
    public static final String BLACK = "000000";
    public static final String WHITE = "FFFFFF";
    public static final String BLUE_HEADERS = "006699";
    public static final String BANORTE_STEP = "800000"; //"943634";
    public static final String BANORTE_HEADERS = "808080"; //"D99594";

    public static final int IMAGE_WIDTH = 300;
    public static final int IMAGE_MAX_WIDTH = 300;
    public static final int IMAGE_MAX_WIDTH_MOB = 200;
    public static final int IMAGE_HEIGHT = 200;
    public static final int IMAGE_MAX_HEIGHT = 600;
    public static final int IMAGE_MAX_HEIGHT_MOB = 264;

    public static final int FONT_SIZE = 10;

    public static final String PASSED = "passed";
    public static final String FAILED = "failed";

}
