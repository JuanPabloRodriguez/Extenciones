package dav.library.wordReporting;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.util.Units;
import org.apache.poi.xwpf.usermodel.*;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.*;

import library.common.Util;

import java.io.*;
import java.math.BigInteger;
import java.util.List;

import static dav.library.wordReporting.WordReportConstants.IMAGE_HEIGHT;
import static dav.library.wordReporting.WordReportConstants.IMAGE_WIDTH;
import static org.apache.poi.xwpf.usermodel.Document.*;

public class WordTable extends WordBaseClient {

    private XWPFTable table = null;

    public WordTable(String outFileName, String findTableByText, String templateName) throws FileNotFoundException {
        super(outFileName, templateName);
        findTableByFirstRowText(findTableByText);
    }

    public WordTable(String outFileName, int rows, int columns, String templateName) throws FileNotFoundException {
        super(outFileName, templateName);
        createTable(rows, columns);
    }

    /**
     * Finds table by the first row text
     *
     * @param firstRowText
     * @return
     */
    protected void findTableByFirstRowText(String firstRowText) {
        for (XWPFTable tbl : document.getTables()) {
            if (tbl.getRow(0).getCell(0).getText().contains(firstRowText)) {
                this.table = tbl;
            }
        }
    }

    public boolean checkTableExists() {
        return table != null;
    }

    /**
     * Creates XWPF Table
     *
     * @param rows
     * @param columns
     * @return
     */
    protected void createTable(int rows, int columns) {
        this.table = document.createTable(rows, columns);
    }

    /**
     * Adds to Row into Table
     */
    public void addNewRow() {
        table.createRow();
    }

    /**
     * Merges Table Cells Horizontally
     *
     * @param row
     * @param startCol
     * @param endCol
     */
    protected void mergeCellsHorizontal(int row, int startCol, int endCol) {
        for (int cellIndex = startCol; cellIndex <= endCol; cellIndex++) {
            XWPFTableCell cell = table.getRow(row).getCell(cellIndex);
            if (cellIndex == startCol) {
                cell.getCTTc().addNewTcPr().addNewHMerge().setVal(STMerge.RESTART);
            } else {
                cell.getCTTc().addNewTcPr().addNewHMerge().setVal(STMerge.CONTINUE);
            }
        }
    }

    /**
     * Gets Row Cell Position
     *
     * @param row
     * @return
     */
    protected int getRowPosition(int row) {
        XWPFTableRow tableRow = getTableRow(row);
        int counter = 0;
        for (XWPFTableRow rows : table.getRows()) {
            if (tableRow == rows) {
                return counter;
            }
            counter++;
        }
        return -1;
    }

    /**
     * Gets Number of Columns in a Row
     *
     * @param row
     * @return
     */
    public int getNumberOfRowColumns(int row) {
        int counter = 0;
        XWPFTableRow tableRow = getTableRow(row);
        counter = tableRow.getTableCells().size();
        /*
        for (XWPFTableCell tableCell : tableRow.getTableCells()) {
            counter++;
        }*/
        return counter - 1;
    }

    /**
     * Colors Row Background
     *
     * @param row
     * @param startCol
     * @param endCol
     * @param color
     */
    public void colorRow(int row, int startCol, int endCol, String color) {
        for (int cellIndex = startCol; cellIndex <= endCol; cellIndex++) {
            XWPFTableCell tableCell = table.getRow(row).getCell(cellIndex);
            tableCell.setColor(color);
        }
    }

    /**
     * Formats Cell text
     *
     * @param tableRowDetail
     */
    public void setCellText(TableRowDetail tableRowDetail) {
        XWPFTableCell tableCell = getTableCell(tableRowDetail.getRow(), tableRowDetail.getCell());
        tableCell.removeParagraph(0);
        XWPFRun run = tableCell.addParagraph().createRun();
        run.setFontFamily(tableRowDetail.getFontFamily());
        run.setFontSize(tableRowDetail.getFontSize());
        run.setColor(tableRowDetail.getColorRGB());
        run.setText(tableRowDetail.getText());
        run.setBold(tableRowDetail.isBold());
        if (tableRowDetail.isAddBreak()) run.addBreak();
    }

    /**
     * Adds Borders to Table
     */
    public void addBordersTable() {
        CTTblPr tblpro = table.getCTTbl().getTblPr();
        CTTblBorders borders = tblpro.addNewTblBorders();
        borders.addNewBottom().setVal(STBorder.SINGLE);
        borders.addNewLeft().setVal(STBorder.SINGLE);
        borders.addNewRight().setVal(STBorder.SINGLE);
        borders.addNewTop().setVal(STBorder.SINGLE);
        borders.addNewInsideH().setVal(STBorder.SINGLE);
        borders.addNewInsideV().setVal(STBorder.SINGLE);
    }

    /**
     * Align cells text in a row to center
     *
     * @param row
     */
    public void centerRowText(int row) {
        XWPFTableRow tableRow = getTableRow(row);
        for (XWPFTableCell tableCell : tableRow.getTableCells()) {
            tableCell.setVerticalAlignment(XWPFTableCell.XWPFVertAlign.CENTER);
            CTTc cttc = tableCell.getCTTc();
            CTP ctp = cttc.getPList().get(0);
            CTPPr ctppr = ctp.getPPr();

            if (ctppr == null) {
                ctppr = ctp.addNewPPr();
            }
            CTJc ctjc = ctppr.getJc();
            if (ctjc == null) {
                ctjc = ctppr.addNewJc();
            }
            ctjc.setVal(STJc.CENTER);
        }
    }

    /**
     * Sets table column width
     *
     * @param widths
     */
    public void setTableColumnsWidth(long... widths) {
        CTTblGrid grid = table.getCTTbl().addNewTblGrid();
        for (long w : widths) {
            grid.addNewGridCol().setW(BigInteger.valueOf(w));
        }
    }

    /**
     * Gets the number of rows in a table
     *
     * @return
     */
    public int getLastRow() {
        return table.getNumberOfRows() - 1;
    }

    /**
     * Adds Attachment to Table cell
     *
     * @param cell
     * @param fileName
     */
    public void addImageToCell(int row, int cell, String fileName) {
        int imageWidth = IMAGE_WIDTH;
        int imageHeight = IMAGE_HEIGHT;
        XWPFTableCell tableCell = getTableRow(row).getCell(cell);


        XWPFRun run = tableCell.addParagraph().createRun();
        tableCell.getParagraphs().get(1).setAlignment(ParagraphAlignment.CENTER);
        //run.addBreak();
        File fileToUpload = new File(fileName);
        if (!Util.isImage(fileToUpload)) {
        	run.setText(fileName);
        	System.out.println("Se debe subir como evidencia el archivo " + fileName);
		}
        else {
	        try (InputStream image = new FileInputStream(fileName)) {
	            List<Integer> size = getImageSize(fileName);
	            if (size != null) {
	                imageWidth = size.get(0);
	                imageHeight = size.get(1);
	            }
	            if (fileName.toLowerCase().contains(".jpeg")) {
	                run.addPicture(image, PICTURE_TYPE_JPEG, fileToUpload.getName(), Units.toEMU(imageWidth), Units.toEMU(imageHeight));
	            } else if (fileName.toLowerCase().contains(".png")) {
	                run.addPicture(image, PICTURE_TYPE_PNG, fileToUpload.getName(), Units.toEMU(imageWidth), Units.toEMU(imageHeight));
	            } else if (fileName.toLowerCase().contains(".gif")) {
	                run.addPicture(image, PICTURE_TYPE_GIF, fileToUpload.getName(), Units.toEMU(imageWidth), Units.toEMU(imageHeight));
	            }
	            run.addBreak();
	        } catch (IOException | NullPointerException | InvalidFormatException e) {
	            log.error("Image {} Not loaded. {}", fileName, e.getMessage());
	        }
        }
    }

    private XWPFTableRow getTableRow(int row) {
        return table.getRow(row);
    }

    private XWPFTableCell getTableCell(int row, int cell) {
        return table.getRow(row).getCell(cell);
    }

    public void mergeCell(int row) {
    	int span = 2; // son 2 columnas
        getTableRow(row).getCell(0).getCTTc().addNewTcPr().addNewHMerge().setVal(STMerge.RESTART);
        getTableRow(row).getCell(0).getCTTc().getTcPr().addNewGridSpan().setVal(BigInteger.valueOf((long)span));
        
    	getTableRow(row).getCell(1).getCTTc().addNewTcPr().addNewHMerge().setVal(STMerge.CONTINUE);
    	getTableRow(row).getCell(1).getCTTc().getTcPr().addNewGridSpan().setVal(BigInteger.valueOf((long)span));
    }
    
}
