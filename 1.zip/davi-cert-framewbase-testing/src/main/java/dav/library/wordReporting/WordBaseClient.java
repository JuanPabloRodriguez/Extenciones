package dav.library.wordReporting;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.util.Units;
import org.apache.poi.xwpf.usermodel.*;

import library.common.Util;
import library.settings.SettingsResources;
import library.settings.SettingsRun;

import javax.imageio.ImageIO;

import static dav.library.wordReporting.WordReportConstants.*;
import static org.apache.poi.xwpf.usermodel.Document.PICTURE_TYPE_GIF;
import static org.apache.poi.xwpf.usermodel.Document.PICTURE_TYPE_JPEG;
import static org.apache.poi.xwpf.usermodel.Document.PICTURE_TYPE_PNG;

import java.awt.image.BufferedImage;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class WordBaseClient {
	
    protected XWPFDocument document = null;
    private String outFileName;
    private File targetFolder;
    private String fullReportPath;

    protected final Logger log = LogManager.getLogger(this);
    
//=======================================================================================================================
    /**
     * Constructor
     * @param outFileName
     * @param templateName
     */
    public WordBaseClient(String outFileName, String templateName) throws FileNotFoundException {
        this.outFileName = outFileName;
        openDocument(templateName);
        
        String targetPath = SettingsRun.getFinalEvidencesDir();
        String nbInicioFile = targetPath + this.outFileName;
        fullReportPath = nbInicioFile + ".docx"; // NOMBRE INICIAL
        boolean existeArchivo;
        int cont = 1;
        do {
        	existeArchivo = new File(fullReportPath).exists();
        	if (existeArchivo) { // SI EXISTE EL ARCHIVO SE DEBE PONER UN CONSECUTIVO EN EL NOMBRE
        		fullReportPath = nbInicioFile + " (" + cont + ").docx";
        		cont++;
			}
		} while (existeArchivo);
        targetFolder = new File(targetPath); // ALMACENA EL NOMBRE DEL FOLDER PARA EL ARCHIVO
    }
//***********************************************************************************************************************
    public String getFullReportPath() {
    	return this.fullReportPath;
    }
//***********************************************************************************************************************
    /**
     * Opens Word Report Template
     */
    protected void openDocument(String templateName) throws FileNotFoundException {
    	
		try {
			InputStream inputStream = SettingsResources.getResourceAsStream(templateName);
	        if(inputStream != null) {
	            try {
	                document = new XWPFDocument(inputStream);
	            } catch (FileNotFoundException e) {
	                log.error("File {} Not Found. {}", inputStream, e.getMessage());
	            } catch (IOException | NullPointerException e) {
	                log.error("File {} Not loaded. {}", inputStream, e.getMessage());
	            }
	        }
		}
		catch (Exception e1) {
			e1.printStackTrace();
		}
    }
//***********************************************************************************************************************
    /**
     * Saves Word Report
     * @return path
     */
    public String saveDocument() {

    	if (!Util.directoryExist(targetFolder))
    		targetFolder.mkdirs();

        try(OutputStream fileOut = new FileOutputStream(fullReportPath)) {
            document.write(fileOut);
        } catch (FileNotFoundException e) {
            log.error("File {} Not Found. {}", outFileName, e.getMessage());
        } catch (IOException e) {
            log.error("File {} Not created. {}", outFileName, e.getMessage());
        } catch (NullPointerException e) {
            log.error("Blank File {} created. {}", outFileName, e.getMessage());
        }

        File fullReportName = new File(fullReportPath);

        if (fullReportName.exists()) {
            log.info("Word Report generation successful. {}", fullReportName.getName());
            return fullReportName.getAbsolutePath();
        } else {
            log.error("Word Report generation failed. {}", fullReportName.getName());
            return null;
        }
    }
//***********************************************************************************************************************
    /**
     * Replace All
     * @param findWhat
     * @param replaceWith
     */
    public void replaceAll(String findWhat, String replaceWith) {
        replaceInParagraphs(findWhat, replaceWith);
        replaceInTables(findWhat, replaceWith);
    }
//***********************************************************************************************************************
    private void replaceInParagraphs(String findWhat, String replaceWith) {
        for (XWPFParagraph p : document.getParagraphs()) {
            List<XWPFRun> runs = p.getRuns();
            if (runs != null) {
                for (XWPFRun r : runs) {
                    replaceOnMatch(findWhat, replaceWith, r);
                }
            }
        }
    }
//***********************************************************************************************************************
    private void replaceInTables(String findWhat, String replaceWith) {
        for (XWPFTable tbl : document.getTables()) {
            for (XWPFTableRow row : tbl.getRows()) {
                for (XWPFTableCell cell : row.getTableCells()) {
                    for (XWPFParagraph p : cell.getParagraphs()) {
                        for (XWPFRun r : p.getRuns()) {
                            replaceOnMatch(findWhat, replaceWith, r);
                        }
                    }
                }
            }
        }
    }
//***********************************************************************************************************************
    private void replaceOnMatch(String findWhat, String replaceWith, XWPFRun r) {
        String text = r.getText(0);
        if (text != null && text.contains(findWhat)) {
            text = text.replace(findWhat.trim(), replaceWith);
            r.setText(text, 0);
        }
    }
//***********************************************************************************************************************
    protected List<Integer> getImageSize(String fileName) {
        List<Integer> size = null;
        try{
            BufferedImage image = ImageIO.read(new File(fileName));
            size = new ArrayList<>();
            int percentage;
            int width = image.getWidth();
            int height = image.getHeight();

            int maxWidth  = IMAGE_MAX_WIDTH;
            int maxHeight = IMAGE_MAX_HEIGHT;
            if (width < height) { // ES IMAGEN VERTICAL
            	maxWidth  = IMAGE_MAX_WIDTH_MOB;
            	maxHeight = IMAGE_MAX_HEIGHT_MOB;
			}
            
            if (width > maxWidth) {
                percentage = (maxWidth * 100) / width;
                width = maxWidth;
                height = ((percentage * height) / 100);
            }

            if (height > maxHeight) {
                percentage = (maxHeight * 100) / height;
                width = ((percentage * width) / 100);
                height = maxHeight;
            }
            size.add(width);
            size.add(height);
        } catch (IOException e) {
            log.error("Step Image {} not found. {}", fileName, e.getMessage());
        }
        return size;
    }
//***********************************************************************************************************************
	public void insertEnter() {
	    XWPFRun run = this.document.createParagraph().createRun();
	    run.setText("");
	}
//***********************************************************************************************************************
	public void writeBold(String texto) {
		XWPFParagraph paragraph = this.document.createParagraph();
	    XWPFRun run = paragraph.createRun();
	    run.setBold(true);
	    run.setText(texto);
	}
//***********************************************************************************************************************
    /**
     * Adds Attachment to Table cell
     *
     * @param cell
     * @param fileName
     */
    public void addImage(String fileName) {
        int imageWidth = IMAGE_WIDTH;
        int imageHeight = IMAGE_HEIGHT;

		XWPFParagraph paragraph = this.document.createParagraph();    
		XWPFRun run = paragraph.createRun();
		paragraph.setAlignment(ParagraphAlignment.CENTER);
        //run.addBreak();
        File fileToUpload = new File(fileName);
        if (!Util.isImage(fileToUpload)) {
        	run.setText(fileName);
        	System.out.println("Se debe subir como evidencia el archivo " + fileName);
		}
        else {
	        try (InputStream image = new FileInputStream(fileName)) {
	            List<Integer> size = getImageSize(fileName);
	            if (size != null) {
	                imageWidth = size.get(0);
	                imageHeight = size.get(1);
	            }
	            if (fileName.toLowerCase().contains(".jpeg")) {
	                run.addPicture(image, PICTURE_TYPE_JPEG, fileToUpload.getName(), Units.toEMU(imageWidth), Units.toEMU(imageHeight));
	            } else if (fileName.toLowerCase().contains(".png")) {
	                run.addPicture(image, PICTURE_TYPE_PNG, fileToUpload.getName(), Units.toEMU(imageWidth), Units.toEMU(imageHeight));
	            } else if (fileName.toLowerCase().contains(".gif")) {
	                run.addPicture(image, PICTURE_TYPE_GIF, fileToUpload.getName(), Units.toEMU(imageWidth), Units.toEMU(imageHeight));
	            }
	            run.addBreak();
	        } catch (IOException | NullPointerException | InvalidFormatException e) {
	            log.error("Image {} Not loaded. {}", fileName, e.getMessage());
	        }
        }
    }
//***********************************************************************************************************************
}