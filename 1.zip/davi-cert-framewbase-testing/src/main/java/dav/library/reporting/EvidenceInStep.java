package dav.library.reporting;

import java.util.ArrayList;
import java.util.List;

import library.reporting.EvidenceType;

public class EvidenceInStep implements EvidenceType {

	private List<String[]> listaEvidencesByStep = new ArrayList<String[]>();
	private boolean guardaEvidencia = false;
	
//***********************************************************************************************************************
	@Override
	public void resetEvidenceByTest() {
		this.listaEvidencesByStep = new ArrayList<String[]>();
	}
//***********************************************************************************************************************
	@Override
	public void createEvidenceByTest() {
		this.listaEvidencesByStep = new ArrayList<String[]>();
	}
//***********************************************************************************************************************
	@Override
	public void loadEvidenceByIteration(int numIteration) {
		// NO SE ESTÁ USANDO
	}
//***********************************************************************************************************************
	@Override
	public void setNbTestCase(String nbTestCase) {
		// NO SE ENVÍA NOMBRE DE CASO DE PRUEBA
	}
//***********************************************************************************************************************
	@Override
	public void insertImage(String... pathFilesImg) {
		this.listaEvidencesByStep.add(pathFilesImg);
		this.guardaEvidencia = true;
	}
//***********************************************************************************************************************
	@Override
	public void setTestStep(String... dataTable) throws Exception {
		// NO HAY TABLA PARA INSERTAR
	}
//***********************************************************************************************************************
	@Override
	public void setTitle(String texto) {
		// NO HAY TÍTULO PARA ARCHIVO
	}
//***********************************************************************************************************************
	@Override
	public void setSubtitle(String texto) {
		// NO HAY TÍTULO PARA ARCHIVO
	}
//***********************************************************************************************************************
	@Override
	public void setTexto(String texto) {
		// NO HAY TÍTULO PARA ARCHIVO
	}
//***********************************************************************************************************************
	@Override
	public void setTestStatus(String status) {
		// NO HAY ESTADO PARA ARCHIVO
	}
//***********************************************************************************************************************
	@Override
	public List<String[]> getEvidencesBySteps() {
		return this.listaEvidencesByStep;
	}
//***********************************************************************************************************************
	@Override
	public String getNbEvidenceFile() {
		return null;
	}
//***********************************************************************************************************************
	@Override
	public String getEntityForUpload() {
		return "STEP";
	}
//***********************************************************************************************************************
	@Override
	public boolean containEvidences() {
		return this.guardaEvidencia;
	}
//***********************************************************************************************************************
}
