package dav.library.reporting;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import dav.library.wordReporting.WordReport;
import dav.library.wordReporting.WordReportConstants;
import library.common.Util;
import library.reporting.EvidenceType;
import library.reporting.Reporter;
import library.settings.SettingsRun;

public class EvidencePdfFile implements EvidenceType {

	private static final String TPT_REPORT = "templates/TPT_TestReport.docx";
	private WordReport wordFile;
	private Map<Integer,WordReport> dicEvidenceTest = new HashMap<Integer,WordReport>();
	private boolean guardaEvidencia = false;
    
//***********************************************************************************************************************
	@Override
	public void resetEvidenceByTest() {
		this.wordFile = null;
	}
//***********************************************************************************************************************
	@Override
	public void createEvidenceByTest() {
		
		int numIteration = SettingsRun.getCurrentIteration();
		String nbArchRepResults = Reporter.getSimpleNameEvidence(numIteration);
		try {
			this.wordFile = new WordReport(nbArchRepResults, TPT_REPORT);
			this.dicEvidenceTest.put(numIteration, this.wordFile);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
//***********************************************************************************************************************
	@Override
	public void loadEvidenceByIteration(int numIteration) {
		this.wordFile = this.dicEvidenceTest.get(numIteration);
	}
//***********************************************************************************************************************
	@Override
	public void setNbTestCase(String nbTestCase) {
		
		if (this.wordFile == null)
			this.createEvidenceByTest(); // NO SE HA DADO NOMBRE AL ARCHIVO DE EVIDENCIAS, SE CREA GENÉRICO
		try {
			this.wordFile.setGeneralTableParam(WordReportConstants.TESTCASE_CREATIONDATE,
				Util.dateToString("dd/mm/yyyy") + " " + Util.hourToString("HH:mm:ss"));
			this.wordFile.setGeneralTableParam(WordReportConstants.TESTCASE_DESIGNER, SettingsRun.TEST_EXECUTOR);
			this.wordFile.setGeneralTableParam(WordReportConstants.TESTCASE_NAME, nbTestCase);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
//***********************************************************************************************************************
	@Override
	public void insertImage(String... pathFilesImg) {
		
		if (this.wordFile == null)
			this.setNbTestCase(SettingsRun.EXEC_NAME + " Exec" + SettingsRun.getCurrentIteration());
		// ARMA LISTA CON LOS TÍTULOS DE LAS IMÁGENES, LAS ADICIONA Y VA SALVANDO EL ARCHIVO
		this.wordFile.addImages(pathFilesImg);
		this.wordFile.saveDocument();
		this.guardaEvidencia = true;
	}
//***********************************************************************************************************************
	@Override
	public void setTestStep(String... dataTable) throws Exception {
		// NO HAY TABLA PARA INSERTAR
	}
//***********************************************************************************************************************
	@Override
	public void setTitle(String texto) {}
//***********************************************************************************************************************
	@Override
	public void setSubtitle(String texto) {}
//***********************************************************************************************************************
	@Override
	public void setTexto(String texto) {}
//***********************************************************************************************************************
	/**
	 * Escribe el [status] como el estado de la evidencia, y si hay archivo lo debe salvar.
	 */
	@Override
	public void setTestStatus(String status) {
		if (this.wordFile == null)
			return; // NO HAY FORMA DE SETEAR UN ESTADO A UN DOCUMENTO QUE NO EXISTE
		this.wordFile.saveDocument();
	}
//***********************************************************************************************************************
	@Override
	public List<String[]> getEvidencesBySteps() {
		return null;
	}
//***********************************************************************************************************************
	@Override
	public String getNbEvidenceFile() {
		if (this.wordFile == null)
			return null; // NO HAY FORMA DE EXTRAER EL NOMBRE DEL ARCHIVO SI EL DOCUMENTO QUE NO EXISTE
		return this.wordFile.getFullReportPath();
	}
//***********************************************************************************************************************
	@Override
	public String getEntityForUpload() {
		return "INSTANCE";
	}
//***********************************************************************************************************************
	@Override
	public boolean containEvidences() {
		return this.guardaEvidencia;
	}
//***********************************************************************************************************************
}