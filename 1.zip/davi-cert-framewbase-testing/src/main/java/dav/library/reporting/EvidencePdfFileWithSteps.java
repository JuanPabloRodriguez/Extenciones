package dav.library.reporting;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import dav.library.wordReporting.WordReport;
import dav.library.wordReporting.WordReportConstants;
import library.common.Util;
import library.reporting.EvidenceType;
import library.reporting.Reporter;
import library.settings.SettingsRun;

public class EvidencePdfFileWithSteps implements EvidenceType {

	private static final String TPT_REPORT = "templates/TPT_TestReportWithSteps.docx";
	private WordReport wordFile;
	private Map<Integer,WordReport> dicEvidenceTest = new HashMap<Integer,WordReport>();
	private String descripcion, resultadoEsp, stepStatus;
	private boolean guardaEvidencia = false;
	
//***********************************************************************************************************************
	@Override
	public void resetEvidenceByTest() {
		this.wordFile = null;
	}
//***********************************************************************************************************************
	@Override
	public void createEvidenceByTest() {
	
		int numIteration = SettingsRun.getCurrentIteration();
		String nbArchRepResults = Reporter.getSimpleNameEvidence(numIteration);
		try {
			this.wordFile = new WordReport(nbArchRepResults, TPT_REPORT);
			this.dicEvidenceTest.put(numIteration, this.wordFile);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
//***********************************************************************************************************************
	@Override
	public void loadEvidenceByIteration(int numIteration) {
		this.wordFile = this.dicEvidenceTest.get(numIteration);
	}
//***********************************************************************************************************************
	@Override
	public void setNbTestCase(String nbTestCase) {
		
		if (this.wordFile == null)
			this.createEvidenceByTest(); // NO SE HA DADO NOMBRE AL ARCHIVO DE EVIDENCIAS, SE CREA GENÉRICO
		
		try {
			this.wordFile.setGeneralTableParam(WordReportConstants.TESTCASE_CREATIONDATE,
				Util.dateToString("dd/mm/yyyy") + " " + Util.hourToString("HH:mm:ss"));
			this.wordFile.setGeneralTableParam(WordReportConstants.TESTCASE_DESIGNER, SettingsRun.TEST_EXECUTOR);
			this.wordFile.setGeneralTableParam(WordReportConstants.TESTCASE_NAME, nbTestCase);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
//***********************************************************************************************************************
	@Override
	public void insertImage(String... pathFilesImg) {
		if (this.wordFile == null)
			this.createEvidenceByTest(); // NO SE HA DADO NOMBRE AL ARCHIVO DE EVIDENCIAS, SE CREA GENÉRICO
		// ADICIONA EL STEP, ADICIONA IMÁGENES (EL SAVE SE HACE 1 SOLA VEZ - ACÁ NO)
		this.wordFile.addStepToTable(descripcion, resultadoEsp, stepStatus, pathFilesImg);
		this.guardaEvidencia = true;
	}
//***********************************************************************************************************************
	/**
	 * 0-Descripción, 1-Resultado Esperado, 2-Status del Step<br>
	 * Página para los colores de relleno:
	 * http://www.htmlcsscolor.com/hex/A7BFDE
	 */
	@Override
	public void setTestStep(String... dataTable) throws Exception {
		
		if (dataTable.length != 3)
			throw new Exception("EvidenceWordFile ERROR -- Se requiere descripción, resultado esperado y estado del Step");
		
		descripcion  = dataTable[0];
		resultadoEsp = dataTable[1];
		stepStatus   = dataTable[2];
	}
//***********************************************************************************************************************
	@Override
	public void setTitle(String texto) {
		
	}
//***********************************************************************************************************************
	@Override
	public void setSubtitle(String texto) {
		
	}
//***********************************************************************************************************************
	@Override
	public void setTexto(String texto) {
		
	}
//***********************************************************************************************************************
    /**
     * Escribe el [status] como el estado de la evidencia, y si hay archivo lo debe salvar. 
     */
	@Override
	public void setTestStatus(String status) {
		if (this.wordFile == null) return; // NO HAY FORMA DE SETEAR UN ESTADO A UN DOCUMENTO QUE NO EXISTE
		this.wordFile.setGeneralTableParam(WordReportConstants.TESTCASE_STATUS, status);
		this.wordFile.saveDocument();
	}
//***********************************************************************************************************************
	@Override
	public List<String[]> getEvidencesBySteps() {
		return null;
	}
//***********************************************************************************************************************
	@Override
	public String getNbEvidenceFile() {
		if (this.wordFile == null)
			return null; // NO HAY FORMA DE EXTRAER EL NOMBRE DEL ARCHIVO SI EL DOCUMENTO QUE NO EXISTE
		return this.wordFile.getFullReportPath();
	}
//***********************************************************************************************************************
	@Override
	public String getEntityForUpload() {
		return "INSTANCE";
	}
//***********************************************************************************************************************
	@Override
	public boolean containEvidences() {
		return this.guardaEvidencia;
	}
//***********************************************************************************************************************
}