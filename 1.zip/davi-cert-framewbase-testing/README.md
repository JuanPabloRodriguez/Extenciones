# FrameWBase

Proyecto que contiene la base de trabajo de Selenium para automatizar: Páginas Web, Aplicaciones de Escritorio, Aplicaciones en dispositivos móviles.
PD: Se crea la rama DAV_AUTO.